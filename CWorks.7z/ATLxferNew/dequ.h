/*
	Ver.1.1 : (1) Xfer �� parameter TrimR+TrimL (except DEQUSYMS+DEQUSYMX)
	Ver.1.1 : (2) Xfer �� parameter �� SymX+data+SymX�� data ���B�z, ��SymX�h���ᵹBody�Axfer.
	Ver.1.2 : (1) DEQU :: add �� LIFO ���c
	Ver.1.3 : (1) DSlinkRelease(Para)�L�kupdate Para ,�諾���s�� ReleaseDSLINK(&Para)
*/

#ifndef __DEQU_H__
#define __DEQU_H__

#include "mystr.h"
#include <unistd.h>

#define _dequVer_	"DEQU-v1.3a@20191016"

#define DEQUKEY    		"#dequ"
#define DEQUPARST  		'<'
#define DEQUPARED  		'>'
#define DEQUBDYST  		"{{"
#define DEQUBDYED  		"}}"
#define DEQUSYMS   		"?\""			// Parameter , body : SymS+data+SymS <- ���B�z
#define DEQUSYMX   		"'`" 			// Xfer�ɳB�z Parameter : SymX+data+SymX <- data ���B�z,SymX�h���ᵹBody�Axfer.
#define DEQULCMT   		';'
#define DEQUCMTC   		'@'
#define DEQUBDYVPAST 	'$'
#define DEQUBDYVPAED 	'$'


typedef struct dslink {
	MyStr data;
	dslink *nxt;
} DSLINK;

void ReleaseDSLINK(DSLINK **p);

class DEQU {
private:
          MyStr      NAME;
          MyStr      BODY;
          int        PARN;
          DSLINK*	 Para;
          MyStr      TMP;
protected:
                void  Setup(const char *s);
public:
//		  	    void DSlinkRelease(DSLINK *p); �L�k update release�᪺ p
          const char *GetTrimDEQU(const char *dequstr);
          const char *GetNameFromTrimDEQU(const char *trimdequ);
          const char *GetBodyFromTrimDEQU(const char *trimdequ);
          const char *GetParaFromTrimDEQU(const char *trimdequ);
		  		  		  
          const char *GetName(void);
          const char *GetBody(void);
                 int  GetParN(void);
          const char *GetPara(void);

          DEQU();
          DEQU(MyStr &S);
          DEQU(const char *s);
          ~DEQU();
          
		  DEQU& operator=(const char *s);
		  DEQU& operator=(MyStr &S);

		  bool  operator==(const char* name);
		  bool  operator==(MyStr &S);
		  bool  operator!=(const char* name);
		  bool  operator!=(MyStr &S);

};
//###############################################################################

typedef struct dqlink {
	int SN;
	int PARN;
	MyStr NAME;
	dqlink *nxt;
} DQLINK;

//###############################################################################

#define DEQU_DB_MaxLineLen    128

class DEQU_DB {
private:
	 int 			CNT;
	 MyStr			DBfile;
	 DQLINK			*DBP;
	 MyStr			TMP;
protected:
	 void			ReleaseDBP(void);
	 const char*	ParaAnalyze(MyStr &PA,MyStr &SYM);
	 const char *	PickupLineDequPara(MyStr &LL,MyStr &DEQNM,MyStr &SYM,MyStr &LS,MyStr &LE);
public:
	 const char* 	GetDBfile(void);
	 int			GetCNT(void);
	 
	 int 			GetDEQUSeqN(const char *dequname);
	 int 			Add(DEQU& DD);
	 const char*	DEQU_Inside(const char *line);
	 int 			SearchDEQUparN(const char *dequname);
	 const char*	GetDEQUdefParaInDB(const char *dequname);
	 const char*	GetDEQUbodyInDB(const char *dequname);
	 const char*	GetDEQUnameByDBIdx(const int si);

	 const char*	DEQU_xfer(const char *line);
	 
	 int			DB_foutput(const char *filename);

					DEQU_DB(const char *dbfname);
					DEQU_DB(const char *dbfname,DEQU& DD);
					~DEQU_DB();
};

#endif

