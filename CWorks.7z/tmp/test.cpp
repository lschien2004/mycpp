#include "mystr.h"

using namespace std;

int main(int ac,char **av) {
	MyStr T;
	T="Hello world!";
	cout << endl << (char*)T << endl;
	exit(0);
}
