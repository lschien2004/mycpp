/*##############################################################################################
	v1.0@20191019	initial ver.
################################################################################################*/

#ifndef __NameStr_h__
    #define __NameStr_h__
	#define __NameStrVer__	"NameStr-v1.0@20191019"

#include "mystr.h"

class NameStr : public MyStr {
private:
		 	 char *myname;
protected:
virtual 	 void releasename(void);

public:
			NameStr(const char *name=NULL,const char *s=NULL);
			NameStr(const char *name,const char sc);
			NameStr(const char *name,MyStr &S);
			NameStr(const char *name,const int v);
			NameStr(const char *name,const long lv);
			
			NameStr(const char nc,const char *s=NULL);
			NameStr(const char nc,const char sc);
			NameStr(const char nc,MyStr &S);
			NameStr(const char nc,const int v);
			NameStr(const char nc,const long lv);
			
			NameStr(MyStr &NAME,const char *s=NULL);
			NameStr(MyStr &NAME,const char sc);
			NameStr(MyStr &NAME,MyStr &S);
			NameStr(MyStr &NAME,const int v);
			NameStr(MyStr &NAME,const long lv);

			NameStr(const int nv,const char *s=NULL);
			NameStr(const int nv,const char sc);
			NameStr(const int nv,MyStr &S);
			NameStr(const int nv,const int v);
			NameStr(const int nv,const long lv);

			NameStr(const long nlv,const char *s=NULL);
			NameStr(const long nlv,const char sc);
			NameStr(const long nlv,MyStr &S);
			NameStr(const long nlv,const int v);
			NameStr(const long nlv,const long lv);

			NameStr(NameStr &NS);

			~NameStr();
			
			const char *SetName(const char c);
			const char *SetName(const char *name);
			const char *SetName(MyStr &NAME);
			const char *SetName(const int nv);
			const char *SetName(const long nlv);

			const char *GetName();
		     bool	   IsNameEmpty();
		     bool	   IsNotNameEmpty();

virtual 	NameStr& operator=(NameStr &NS);
virtual 	NameStr& operator=(const char sc);
virtual 	NameStr& operator=(const char *s);
virtual 	NameStr& operator=(MyStr &S);
virtual 	NameStr& operator=(const int v);
virtual 	NameStr& operator=(const long lv);

virtual 	NameStr& operator+=(NameStr &NS);
virtual 	NameStr& operator+=(const char sc);
virtual 	NameStr& operator+=(const char *s);
virtual 	NameStr& operator+=(MyStr &S);
virtual 	NameStr& operator+=(const int v);
virtual 	NameStr& operator+=(const long lv);

virtual 	const char* operator+(NameStr &NS);
virtual 	 bool 	 operator==(NameStr &NS);
virtual 	 bool 	 operator!=(NameStr &NS);

};

#endif
