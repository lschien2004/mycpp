#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>    //printf
#include <stdlib.h>   //malloc
#include <string.h>   //strncpy
#include <unistd.h>   //close
#include <iostream>
#include <ctime>

#include "mystr.h"
#include "namestr.h"
#include "arraystr.h"
#include "arraynamestr.h"
#include "namearraystr.h"
#include "dequdb.h"
#include "mystd.h"

#define __ATLXferVer__ "ATLxfer-v2.0@20191024"

#define __Author__ "L.S Chien"

#define _DOS_

#ifdef _DOS_
	#define __SYS__ "DOS"
    #define SymPath  '\\'
#else
	#define __SYS__ "UNIX"
    #define SymPath  '/'
#endif

#define FileInsertStatement "INSERT"

#define StrMaxLen 256


//########################################
//		Global Variables
//========================================
struct setting {
	FileObj 	FO;		//output file information & operation
	FnameObj	INF;	//input file information
	FnameObj	ONF;	//Dequ output file information
	FnameObj	DBF;	//DB store file information
	ArrayStr	OPC;	//Compile option list
	ArrayStr	OPS;	//xfer program option list
	MyStr		Me;		//my name AV[0]
	int			err;
	MyStr		ErrMsg;
};

static setting SS;
//########################################

const char *GetTimeStr(void) {
	time_t now = time(0);
	tm *lt = localtime(&now);
	MyStr DateTime;
	DateTime=(1900+lt->tm_year);
	DateTime+="/";
	DateTime+=(1+lt->tm_mon);
	DateTime+="/";
	DateTime+=(lt->tm_mday);
	DateTime+=" ";
	DateTime+=(1+lt->tm_hour);
	DateTime+=":";
	DateTime+=(1+lt->tm_min);
	DateTime+=":";
	DateTime+=(1+lt->tm_sec);
	return (char*)DateTime;
}

void usage(void)
{
	tout out;
	out.prt("\n##################################################################");
	out.prt("\n[[[ ATL Xfer % % By % (DequDef=%)]]]",__SYS__, __PgmVer__,__Author__,__DequDef__);
	out.prt("\n==================================================================");
	out.prt("\n     This tool is used to convert the source files which writed with");
	out.prt("\n% macro to a .asc file for ADV tester's compiler .\n",_DEQUKEY);
	out.prt("\n Usage : %  main_src_file  [output_path]",(char*)SS.Me);
	out.prt("\n       >> w/o output_path -> output in current path .\n");
	out.prt("\n    Ex : % wtmain.src ASCDIR",(char*)SS.Me);
	out.prt("\n       >> Transfer wtmain.src to ASCDIR%wtmain.asc",SymPath);
	out.prt("\n    Ex : % ..%wtmain.src",(char*)SS.Me,SymPath);
	out.prt("\n       >> Transfer ..%wtmain.src to .%wtmain.asc\n",SymPath,SymPath);
	out.prt("\n Note :");
	out.prt("\n     1) Except DOS ver. ,all of inserted files must be lower-case file name !");
	out.prt("\n     2) main_src_file and all of inserted files must be stored in the same");
	out.prt("\n        path !");
	out.prt("\n     3) All of inserted files' att_name must use the same att_name of ");
	out.prt("\n        main_src_file !");
	out.prt("\n        Ex: main_src_file is main.s , the insertd files must be *.s");
	out.prt("\n     4) If main_src_file's att_name is .asc and output_path is same");
	out.prt("\n        as main_src_file's path, then output file's att_name will");
	out.prt("\n        change to be .asc2)");
	out.prt("\n  Regarding % marco :",_DEQUKEY);
	out.prt("\n     1) Re-define the same % macro name will be rejected since V1.6",_DEQUKEY);
	out.prt("\n     2) Name of % macro must exist at the least one lower-case or",_DEQUKEY);
	out.prt("\n        inclinding one of % chars.",_DEQUNAME_exack_chars);
	out.prt("\n     3) Don't support ATL compile option for % macro transfer now !",_DEQUKEY);
	out.prt("\n==================================================================");
	out.prt("\n Related lib :");
	out.prt("\n   %\t \t%",__MyStdVer__,__FileObjVer__);
	out.prt("\n   %\t \t%",__MyStrVer__,__NameStrVer__);
	out.prt("\n   %\t%",__ArrayStrVer__,__ArrayNameStrVer__);
	out.prt("\n   %\t%",__NameArrayStrVer__,__DequDBVer__);
	out.prt("\n##################################################################\n");
}



void ArgAnalyzer(const int ac,char **av) {
	tout out;
	MyStr S,F;
	
	SS.err=-1;
	Me = av[0];
	if(ac<2) { SS.ErrMsg="!!! Error : bad usage !!!"; return; }
	SS.INF=av[1];
	if(!SS.INF.IsFileExist()) { 
		SS.ErrMsg="!!! Error : file '";
		SS.ErrMsg+=INF.GetFullFileName();
		SS.ErrMsg+="' not found !!!",INF.GetFullFileName()); 
		return; 
	}
	if(ac>2) {
		S=av[2];
		if(S[0]!='-') {
			if(SS.ONF.IsPathExist((char*)S)) {
				//**********************************
				//	av[2] = output path
				//**********************************
				if( S[(int)S-1]!=_SymDir ) S+=_SymDir;
				F=S+SS.INF.GetFileName();
				F=F.GetRangeWithWdDel(INF.GetFileAtt());
				//--------------------------------
				S=".asc";
				if(S==SS.INF.GetFileAtt()) S=S+"2";
				F+=S;
				SS.ONF.NameSetByFullFileName(F);
			} else {
				//**********************************
				//	av[2] = output file
				//**********************************
				SS.ONF.NameSetByFullFileName(S);
			}
		}
	}
}

int main(int ac,char **av) {
	tout out;
	if(ArgAnalyzer(ac,av)<0) {
		out.prt("\n%",SS.ErrMsg);
		usage(); exit(1);
	}
	exit(0);
}
