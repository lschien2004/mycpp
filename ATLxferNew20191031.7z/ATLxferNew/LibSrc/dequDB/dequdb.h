/*##############################################################################################
	v1.0@20191023	new dequ lib
	v1.1@20191024	+ enum DequCode
					WellFormatCheck return DequCode type
					Setup return DequCode type
					+GetErrMessage(DequCode)
	v1.5@20191030	Marge DEQU_DB
					_DEQUSYMS(?")->(") & _DEQUSYMU(?) for macro xferred symblk 
################################################################################################*/
#ifndef __DequDB__h__
    #define __DequDB__h__
    #define __DequDBVer__	"DequDB-v1.5@20191030"

    #define _dequFmtVer_	"V1.3"

#include "mystr.h"
#include "namestr.h"
#include "arraystr.h"
#include "arraynamestr.h"
#include "namearraystr.h"
#include "fileobj.h"


#ifndef __DequDef__
    #define __DequDef__ 2

 #define _DEQUKEY    		"#dequ"
 #define _DEQUPARST  		'<'
 #define _DEQUPARED  		'>'
 #define _DEQUBDYST  		"{{"
 #define _DEQUBDYED  		"}}"
 #define _DEQUSYMS   		"\""			// SymS+data+SymS willn't be xferred.
 #define _DEQUSYMU   		"?"				// SymU+data+SymU will be xferred.
 #define _DEQUSYMX   		"'`" 			// SymX+data+SymX->parameter xfer->data->data will be xferred .
 #define _DEQUSYMA   		"?\"'`" 		// SYMS+SYMU+SYMX
 #define _DEQULCMT   		';'
 #define _DEQUCMTC   		'@'
 #define _DEQUBDYVPAST 		'$'
 #define _DEQUBDYVPAED 		'$'

 #define _DEQUNAME_exack_chars "-_+#~!"

enum DequCode{_well=0,_none,_err_name,_err_namerule,_err_para,_err_body};

#endif //#ifndef __DequDef__

#ifndef _DEQU_ExKeyS
    #define _DEQU_ExKeyS ".~"
    #define _DEQU_ExKeyE "~."
#endif

//***********************************************
//		DEQU_DB used struct & function
//***********************************************
#define DEQU_DB_MaxLineLen    128

typedef struct dslink {
	MyStr data;
	dslink *nxt;
} DSLINK;

typedef struct dqlink {
	int SN;
	int PARN;
	MyStr NAME;
	dqlink *nxt;
} DQLINK;

void ReleaseDSLINK(DSLINK **p);
//***********************************************

void AddExchgLineCmtWithExSymBlk(MyStr &LL,ArrayNameStr &Exchg);
void AddExchgSymChrCmtWithExSymBlk(MyStr &LL,ArrayNameStr &Exchg);
void AddExchgSymBlk(MyStr &LL,ArrayNameStr &Exchg);
void AddExchgSymBlkS(MyStr &LL,ArrayNameStr &Exchg);
void AddExchgSymBlkU(MyStr &LL,ArrayNameStr &Exchg);

const char *GetUnExchgStrByExkey(MyStr &LL,ArrayNameStr &Exchg,const char *Exkey);

const char *GetLineCmtUnExchgStr(MyStr &LL,ArrayNameStr &Exchg);
const char *GetSymChrCmtUnExchgStr(MyStr &LL,ArrayNameStr &Exchg);

const char *GetSymBlkUnExchgStr(MyStr &LL,ArrayNameStr &Exchg);
const char *GetSymBlkSUnExchgStr(MyStr &LL,ArrayNameStr &Exchg);
const char *GetSymBlkUUnExchgStr(MyStr &LL,ArrayNameStr &Exchg);

const char *GetAllUnExchgStr(MyStr &LL,ArrayNameStr &Exchg);

int CheckExkeyInside(MyStr &LL,const char *exkey);

class SDequ : public NameArrayStr {
protected:
//	 NameArrayStr	NAS;
	 MyStr		    BDY;
public:
virtual void Reset(void);
virtual SDequ& operator=(SDequ&);
};


class Dequ : public  SDequ {
private:
	 MyStr		 tmp;

protected:
	 ArrayNameStr	Exchg;

public:
			Dequ();
			Dequ(Dequ &DQ);
			
	 	   void 	Reset(void);

	        int 	GetParaCnt(void);
	 const char 	*GetParaList(void);
	 const char 	*GetBody(void);
	 
	 	    PO2 	GetPointOfDequContents(MyStr &LL);
	 
	   DequCode 	IsWellName(MyStr &NM);
	   DequCode 	IsWellContents(MyStr &LL);

	   DequCode 	ContentsToDequ(MyStr &InputStr,MyStr &OutputStr,Dequ &ODQ);
	 
	 
	        int 	IsExchgInStr(MyStr &LL);
	   DequCode 	Setup(MyStr &LL);

	       void 	ExchgAddLineCmt(MyStr &LL);
	       void 	ExchgAddSymChrCmt(MyStr &LL);
	       void 	ExchgAddSymBlk(MyStr &LL);
	
	 const char 	*GetUnExchgAll(MyStr &LL);
	 
	 const char 	*GetErrMessage(DequCode r);
	 
virtual Dequ& operator=(Dequ&);

};

class DEQU_DB {
private:
	 int 			CNT;
	 MyStr			DBfile;
	 DQLINK			*DBP;
	 MyStr			TMP;
protected:
	 void			ReleaseDBP(void);
	 const char*	ParaAnalyze(MyStr &PA,const char *sym);
	 const char*	ParaAnalyze(MyStr &PA,MyStr &SYM);
	 const char *	PickupLineDequPara(MyStr &LL,MyStr &DEQNM,MyStr &SYM,MyStr &LS,MyStr &LE);
public:
	 const char* 	GetDBfile(void);
	 int			GetCNT(void);
	 
	 int 			GetDEQUSeqN(const char *dequname);

	 int 			Add(Dequ& DQ);

	 const char*	DEQU_Inside(MyStr &LL);
	 const char*	DEQU_Inside(const char *line);
	 
	 int 			SearchDEQUparN(const char *dequname);
	 const char*	GetDEQUdefParaInDB(const char *dequname);
	 const char*	GetDEQUbodyInDB(const char *dequname);
	 const char*	GetDEQUnameByDBIdx(const int si);

	 const char*	DEQU_xfer(const char *line);
	 
	 int			DB_foutput(const char *filename);

					DEQU_DB(const char *dbfname);
					~DEQU_DB();
};

#endif //#ifndef __DequDB__h__
