
#include "intstack.h"

IntStack::IntStack(const int is) { state=is; nxt=NULL; }
IntStack::~IntStack() { Reset(); }

void IntStack::Reset(const int is) {
	IntStack *pp=this->nxt;
	while(pp!=NULL) { 
		IntStack *cp=pp;
		pp=pp->nxt;  delete cp;
	}
	state=is;
}

int IntStack::StackCnt(void) {
	int n=0; IntStack *pp=this;
	while(pp->nxt!=NULL) { n++; pp=pp->nxt; }
	return n;
}

int IntStack::Push(const int v) {
	IntStack *np=new IntStack(state);
	if(np==NULL) return -1;
	np->nxt=nxt; state=v; nxt=np;
	return StackCnt();
}
int IntStack::Pop(void) {
	if(this->nxt==NULL) return -1;
	IntStack *np=this->nxt;
	if(np!=NULL) { state=np->state; nxt=np->nxt; np->nxt=NULL; delete np; }
	return StackCnt();
}

int IntStack::GetVal(void) { return state; }
int IntStack::SetVal(const int v) { state=v; return state; }
