#ifndef __IntStack__
  #define __IntStack__
  
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <iostream>

//#######################################################
class IntStack {
protected:
	int	state;
	IntStack	*nxt;
public:
	IntStack(const int is=1);
	~IntStack();
	void	  Reset(const int is=1);
	int Push(const int v);
	int Pop(void);
	int StackCnt(void);
	int GetVal(void);
	int SetVal(const int v);
};
#endif

