#include "arraynamestr.h"

static NameStr ArrayNameStrTMP;

void ArrayNameStr::Release(ArrayNameStr *nd) {
	ArrayNameStr *cp=nd;
	while(cp!=NULL) {
		ArrayNameStr *p=cp;
		cp=cp->nxt;
		if(p->pstr!=NULL) delete p->pstr;
		if(p==this) { p->pstr=NULL; p->nxt=NULL; }
		else free(p);
	}
}

ArrayNameStr *ArrayNameStr::GetNode(MyStr &NM) {
	ArrayNameStr *cp=this;
	while(cp!=NULL) {
		if(cp->pstr!=NULL) {
			if(NM==cp->pstr->GetName()) return cp;
		}
		cp=cp->nxt;
	}
	return NULL;
}

ArrayNameStr *ArrayNameStr::GetNode(int idx) {
	if(idx>-1) {
		ArrayNameStr *cp=this;
		int cnt=-1;
		while(cp!=NULL) {
			if(cp->pstr!=NULL) cnt++;
			if(cnt==idx) return cp;
			cp=cp->nxt;
		}
	}
	return NULL;
}

int ArrayNameStr::GetArrayCnt(void) {
	ArrayNameStr *cp=this;
	int cnt=0;
	while(cp!=NULL) {
		if(cp->pstr!=NULL) cnt++;
		cp=cp->nxt;
	}
	return cnt;
}

const char* ArrayNameStr::GetNameByIdx(int idx){
	ArrayNameStr *p=GetNode(idx);
	if(p!=NULL) return p->pstr->GetName();
	return NULL;
}
const char* ArrayNameStr::GetStrByIdx(int idx){
	ArrayNameStr *p=GetNode(idx);
	if(p!=NULL) return (char*)*(p->pstr);
	return NULL;
}

int ArrayNameStr::DelByIdx(int idx) {
	ArrayNameStr *cp=GetNode(idx);
	ArrayNameStr *pp=GetNode(idx-1);
	if(cp!=NULL) {
		if(pp==NULL) {
			if(cp->nxt==NULL) { 
				delete cp->pstr; cp->pstr=NULL; 
			} else {	
				pp=cp; cp=cp->nxt;
				*(pp->pstr)=*(cp->pstr);
				pp->nxt=cp->nxt;
				cp->nxt=NULL; Release(cp);
			}
		} else {
			pp->nxt=cp->nxt; cp->nxt=NULL;
			Release(cp);
		}
		return 0;
	}
	return -1;
}

int ArrayNameStr::DelByNameStr(NameStr &NS) {
	int idx=GetIdxByNameStr(NS);
	if(idx>-1) return DelByIdx(idx);
	return -1;
}

int ArrayNameStr::DelByName(MyStr &NM) {
	int idx=GetIdxByName(NM);
	if(idx>-1) return DelByIdx(idx);
	return -1;
}

int ArrayNameStr::DelByName(const char *name) {
	MyStr NM(name); return DelByName(NM);
}
int ArrayNameStr::DelByName(const char nc) {
	MyStr NM(nc); return DelByName(NM);
}
int ArrayNameStr::DelByName(const int ni) {
	MyStr NM(ni); return DelByName(NM);
}
int ArrayNameStr::DelByName(const long nl) {
	MyStr NM(nl); return DelByName(NM);
}

NameStr& ArrayNameStr::operator[](int idx) {
	NameStr NS;
	ArrayNameStrTMP=NS;
	ArrayNameStr *p=GetNode(idx);
	if(p!=NULL) return *(p->pstr);
	return ArrayNameStrTMP;
}
int ArrayNameStr::Add(ArrayNameStr &ANS) { 
	int n=ANS.GetArrayCnt();
	int r=0;
	if(n>0) { for(int i=0;i<n;i++) r=Add(ANS[i]); }
	return r;
}

int ArrayNameStr::Add(NameStr &NS) {
	MyStr NM(NS.GetName());
	if((int)NM>0) {
		int cnt=0;
		ArrayNameStr *cp=this;
		while(cp->pstr!=NULL) {
			cnt++;
			if(cp->nxt==NULL) cp->nxt=new ArrayNameStr;
			cp=cp->nxt;
		}
		cp->pstr = new NameStr(NS);
		cnt++;
		return cnt;
	}
	return 0;
}

int ArrayNameStr::Add(MyStr &NM,const char c) { 
	if((int)NM>0) { NameStr NS(NM,c);  return Add(NS); }
	return 0;
}
int ArrayNameStr::Add(MyStr &NM,const char *s) { 
	if((int)NM>0) { NameStr NS(NM,s);  return Add(NS); }
	return 0;
}
int ArrayNameStr::Add(MyStr &NM,MyStr &S) { 
	if((int)NM>0) { NameStr NS(NM,S);  return Add(NS); }
	return 0;
}
int ArrayNameStr::Add(MyStr &NM,const int i) { 
	if((int)NM>0) { NameStr NS(NM,i);  return Add(NS); }
	return 0;
}
int ArrayNameStr::Add(MyStr &NM,const long l) { 
	if((int)NM>0) { NameStr NS(NM,l);  return Add(NS); }
	return 0;
}

int ArrayNameStr::Add(const char nc,const char c) 	{ MyStr NM(nc); return Add(NM,c); }
int ArrayNameStr::Add(const char nc,const char *s) 	{ MyStr NM(nc); return Add(NM,s); }
int ArrayNameStr::Add(const char nc,MyStr &S) 		{ MyStr NM(nc); return Add(NM,S); }
int ArrayNameStr::Add(const char nc,const int i) 	{ MyStr NM(nc); return Add(NM,i); }
int ArrayNameStr::Add(const char nc,const long l) 	{ MyStr NM(nc); return Add(NM,l); }

int ArrayNameStr::Add(const char *name,const char c) 	{ MyStr NM(name); return Add(NM,c); }
int ArrayNameStr::Add(const char *name,const char *s) 	{ MyStr NM(name); return Add(NM,s); }
int ArrayNameStr::Add(const char *name,MyStr &S) 		{ MyStr NM(name); return Add(NM,S); }
int ArrayNameStr::Add(const char *name,const int i) 	{ MyStr NM(name); return Add(NM,i); }
int ArrayNameStr::Add(const char *name,const long l) 	{ MyStr NM(name); return Add(NM,l); }

int ArrayNameStr::Add(const int ni,const char c) 	{ MyStr NM(ni); return Add(NM,c); }
int ArrayNameStr::Add(const int ni,const char *s) 	{ MyStr NM(ni); return Add(NM,s); }
int ArrayNameStr::Add(const int ni,MyStr &S) 		{ MyStr NM(ni); return Add(NM,S); }
int ArrayNameStr::Add(const int ni,const int i) 	{ MyStr NM(ni); return Add(NM,i); }
int ArrayNameStr::Add(const int ni,const long l) 	{ MyStr NM(ni); return Add(NM,l); }

int ArrayNameStr::Add(const long nl,const char c) 	{ MyStr NM(nl); return Add(NM,c); }
int ArrayNameStr::Add(const long nl,const char *s) 	{ MyStr NM(nl); return Add(NM,s); }
int ArrayNameStr::Add(const long nl,MyStr &S) 		{ MyStr NM(nl); return Add(NM,S); }
int ArrayNameStr::Add(const long nl,const int i) 	{ MyStr NM(nl); return Add(NM,i); }
int ArrayNameStr::Add(const long nl,const long l) 	{ MyStr NM(nl); return Add(NM,l); }


ArrayNameStr::ArrayNameStr() 						{ pstr=NULL; nxt=NULL;}
ArrayNameStr::ArrayNameStr(NameStr &NS) 			{ pstr=NULL; nxt=NULL; Add(NS); }
ArrayNameStr::ArrayNameStr(ArrayNameStr &ANS) 		{ pstr=NULL; nxt=NULL; Add(ANS); }

ArrayNameStr::ArrayNameStr(const char nc,const char c)	{ pstr=NULL; nxt=NULL; Add(nc,c); }
ArrayNameStr::ArrayNameStr(const char nc,const char *s)	{ pstr=NULL; nxt=NULL; Add(nc,s); }
ArrayNameStr::ArrayNameStr(const char nc,MyStr &S)		{ pstr=NULL; nxt=NULL; Add(nc,S); }
ArrayNameStr::ArrayNameStr(const char nc,const int i)	{ pstr=NULL; nxt=NULL; Add(nc,i); }
ArrayNameStr::ArrayNameStr(const char nc,const long l)	{ pstr=NULL; nxt=NULL; Add(nc,l); }

ArrayNameStr::ArrayNameStr(const char *name,const char c)	{ pstr=NULL; nxt=NULL; Add(name,c); }
ArrayNameStr::ArrayNameStr(const char *name,const char *s)	{ pstr=NULL; nxt=NULL; Add(name,s); }
ArrayNameStr::ArrayNameStr(const char *name,MyStr &S)		{ pstr=NULL; nxt=NULL; Add(name,S); }
ArrayNameStr::ArrayNameStr(const char *name,const int i)	{ pstr=NULL; nxt=NULL; Add(name,i); }
ArrayNameStr::ArrayNameStr(const char *name,const long l)	{ pstr=NULL; nxt=NULL; Add(name,l); }

ArrayNameStr::ArrayNameStr(MyStr &NM,const char c)	{ pstr=NULL; nxt=NULL; Add(NM,c); }
ArrayNameStr::ArrayNameStr(MyStr &NM,const char *s)	{ pstr=NULL; nxt=NULL; Add(NM,s); }
ArrayNameStr::ArrayNameStr(MyStr &NM,MyStr &S)		{ pstr=NULL; nxt=NULL; Add(NM,S); }
ArrayNameStr::ArrayNameStr(MyStr &NM,const int i)	{ pstr=NULL; nxt=NULL; Add(NM,i); }
ArrayNameStr::ArrayNameStr(MyStr &NM,const long l)	{ pstr=NULL; nxt=NULL; Add(NM,l); }

ArrayNameStr::ArrayNameStr(const int ni,const char c)	{ pstr=NULL; nxt=NULL; Add(ni,c); }
ArrayNameStr::ArrayNameStr(const int ni,const char *s)	{ pstr=NULL; nxt=NULL; Add(ni,s); }
ArrayNameStr::ArrayNameStr(const int ni,MyStr &S)		{ pstr=NULL; nxt=NULL; Add(ni,S); }
ArrayNameStr::ArrayNameStr(const int ni,const int i)	{ pstr=NULL; nxt=NULL; Add(ni,i); }
ArrayNameStr::ArrayNameStr(const int ni,const long l)	{ pstr=NULL; nxt=NULL; Add(ni,l); }

ArrayNameStr::ArrayNameStr(const long nl,const char c)	{ pstr=NULL; nxt=NULL; Add(nl,c); }
ArrayNameStr::ArrayNameStr(const long nl,const char *s)	{ pstr=NULL; nxt=NULL; Add(nl,s); }
ArrayNameStr::ArrayNameStr(const long nl,MyStr &S)		{ pstr=NULL; nxt=NULL; Add(nl,S); }
ArrayNameStr::ArrayNameStr(const long nl,const int i)	{ pstr=NULL; nxt=NULL; Add(nl,i); }
ArrayNameStr::ArrayNameStr(const long nl,const long l)	{ pstr=NULL; nxt=NULL; Add(nl,l); }

ArrayNameStr::~ArrayNameStr() { Release(this); }

ArrayNameStr& ArrayNameStr::operator=(NameStr &NS) 			{ Release(this); return operator+=(NS); }
ArrayNameStr& ArrayNameStr::operator=(ArrayNameStr &ANS)	{ Release(this); return operator+=(ANS); }

ArrayNameStr& ArrayNameStr::operator+=(NameStr &NS) 		{ Add(NS); return *this; }
ArrayNameStr& ArrayNameStr::operator+=(ArrayNameStr &ANS) 	{ Add(ANS); return *this; }

const char *ArrayNameStr::NameList(const char c,const int si) 	{ MyStr DIV(c); return NameList(DIV,si); }
const char *ArrayNameStr::NameList(const char *d,const int si) 	{ MyStr DIV(d); return NameList(DIV,si); }
const char *ArrayNameStr::NameList(MyStr &DIV,const int si) {
	ArrayNameStrTMP="";
	ArrayNameStr *cp=this;
	int cnt=0;
	int idx=-1;
	while(cp!=NULL) {
		if(cp->pstr!=NULL) {
			idx++;
			if(idx>=si) {
				if(cnt++>0) ArrayNameStrTMP+=DIV;
				ArrayNameStrTMP+=(cp->pstr->GetName());
			}
		}
		cp=cp->nxt;
	}
	return (char*)ArrayNameStrTMP;
}

const char *ArrayNameStr::NameListRev(const char c,const int si) 	{ MyStr DIV(c); return NameListRev(DIV,si); }
const char *ArrayNameStr::NameListRev(const char *d,const int si) 	{ MyStr DIV(d); return NameListRev(DIV,si); }
const char*	ArrayNameStr::NameListRev(MyStr &DIV,const int si) {
	ArrayNameStrTMP="";
	ArrayNameStr *cp=this;
	int cnt=0;
	int idx=-1;
	while(cp!=NULL) {
		if(cp->pstr!=NULL) {
			idx++;
			if(idx>=si) {
				MyStr T(cp->pstr->GetName());
				if(cnt++>0) T+=DIV;
				ArrayNameStrTMP=T+ArrayNameStrTMP;
			}
		}
		cp=cp->nxt;
	}
	return (char*)ArrayNameStrTMP;
}

const char *ArrayNameStr::StrList(const char c,const int si) 	{ MyStr DIV(c); return StrList(DIV,si); }
const char *ArrayNameStr::StrList(const char *d,const int si) 	{ MyStr DIV(d); return StrList(DIV,si); }
const char *ArrayNameStr::StrList(MyStr &DIV,const int si) {
	ArrayNameStrTMP="";
	ArrayNameStr *cp=this;
	int cnt=0;
	int idx=-1;
	while(cp!=NULL) {
		if(cp->pstr!=NULL) {
			idx++;
			if(idx>=si) {
				if(cnt++>0) ArrayNameStrTMP+=DIV;
				ArrayNameStrTMP+=(char*)*(cp->pstr);
			}
		}
		cp=cp->nxt;
	}
	return (char*)ArrayNameStrTMP;
}

const char *ArrayNameStr::StrListRev(const char c,const int si) 	{ MyStr DIV(c); return StrListRev(DIV,si); }
const char *ArrayNameStr::StrListRev(const char *d,const int si) 	{ MyStr DIV(d); return StrListRev(DIV,si); }
const char*	ArrayNameStr::StrListRev(MyStr &DIV,const int si) {
	ArrayNameStrTMP="";
	ArrayNameStr *cp=this;
	int cnt=0;
	int idx=-1;
	while(cp!=NULL) {
		if(cp->pstr!=NULL) {
			idx++;
			if(idx>=si) {
				MyStr T((char*)*(cp->pstr));
				if(cnt++>0) T+=DIV;
				ArrayNameStrTMP=T+ArrayNameStrTMP;
			}
		}
		cp=cp->nxt;
	}
	return (char*)ArrayNameStrTMP;
}

int ArrayNameStr::GetIdxByNameStr(NameStr &NS,const int si) {
	MyStr NM(NS.GetName());
	if((int)NM>0) {
		ArrayNameStr *p=this;
		int idx=0;
		while(p!=NULL) {
			if(idx>=si) { 
				if(NS==*(p->pstr)) return idx;
			}
			idx++; p=p->nxt;
		}
	}
	return -1;
}

int ArrayNameStr::GetIdxByName(const char nc,const int si) 		{ MyStr NM(nc); 	return GetIdxByName(NM,si); }
int ArrayNameStr::GetIdxByName(const char *name,const int si)	{ MyStr NM(name); 	return GetIdxByName(NM,si); }
int ArrayNameStr::GetIdxByName(const int ni,const int si)		{ MyStr NM(ni); 	return GetIdxByName(NM,si); }
int ArrayNameStr::GetIdxByName(const long nl,const int si)		{ MyStr NM(nl); 	return GetIdxByName(NM,si); }
int ArrayNameStr::GetIdxByName(MyStr &NM,const int si){
	if((int)NM>0) {
		ArrayNameStr *p=this;
		int idx=0;
		while(p!=NULL) {
			if(idx>=si) { if(NM==p->pstr->GetName()) return idx; }
			idx++; p=p->nxt;
		}
	}
	return -1;
}
int ArrayNameStr::GetIdxByStr(const char sc,const int si)		{ MyStr S(sc); 	return GetIdxByStr(S,si); }
int ArrayNameStr::GetIdxByStr(const char *s,const int si)		{ MyStr S(s); 	return GetIdxByStr(S,si); }
int ArrayNameStr::GetIdxByStr(const int i,const int si)			{ MyStr S(i); 	return GetIdxByStr(S,si); }
int ArrayNameStr::GetIdxByStr(const long l,const int si)		{ MyStr S(l); 	return GetIdxByStr(S,si); }
int ArrayNameStr::GetIdxByStr(MyStr &S,const int si){
	ArrayNameStr *p=this;
	int idx=0;
	while(p!=NULL) {
		if(idx>=si) { if(S==((const char*)*(p->pstr))) return idx; }
		idx++; p=p->nxt;
	}
	return -1;
}
