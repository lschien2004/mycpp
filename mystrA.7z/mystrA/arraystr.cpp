#include "arraystr.h"

static MyStr ArrayStrTMP;

int ArrayStr::Del(int idx) {
	if(idx>-1 && idx<GetArrayCNT()) { MyStr S(GetSTR(idx)); return Del(S); }
	return -1;
}
int ArrayStr::Del(const char *s) {
	if(s!=NULL) { MyStr S(s); return Del(S); }
	return -1;
}
int ArrayStr::Del(MyStr &S) {
//printf("\n>>S=[%s]",(char*)S);
	ArrayStr *cp=this;
	ArrayStr *pp=NULL;
	while(cp!=NULL) {
//printf("\n>>pp=%u cp=%u",pp,cp);
		if(cp->pstr!=NULL) {
			if(*(cp->pstr)==S) {
//printf(" ** cp->nxt=%u",cp->nxt);
				if(pp!=NULL) { 
					pp->nxt=cp->nxt; cp->nxt=NULL; 
//printf("\n>>pp=%u pp->nxt=%u cp=%u cp->nxt=%u",pp,pp->nxt,cp,cp->nxt);
					Release(cp); return 0;
				} else if(cp->nxt!=NULL) { 
					pp=cp; cp=cp->nxt;
					pp->nxt=cp->nxt;
					*(pp->pstr)=*(cp->pstr);
					cp->nxt=NULL; Release(cp);
					return 0;
				} else if(cp->pstr!=NULL) { delete cp->pstr; cp->pstr=NULL; }
				return 0;
        	}
		} else break;
        pp=cp;  cp=cp->nxt;
	}
	return -1;
}
int ArrayStr::Add(ArrayStr &A) { 
	int n=A.GetArrayCNT();
	int r=0;
	if(n>0) { for(int i=0;i<n;i++) r=Add(A[i]); }
	return r;
}
int ArrayStr::Add(const char *s) { 
	if(s==NULL) return 0;
	MyStr S(s);  return Add(S); 
}
int ArrayStr::Add(MyStr &S) {
	if((int)S>0) {
		int cnt=0;
		ArrayStr *cp=this;
		while(cp->pstr!=NULL) {
			cnt++;
			if(cp->nxt==NULL) cp->nxt=new ArrayStr;
			cp=cp->nxt;
		}
		cp->pstr = new MyStr(S);
		cnt++;
		return cnt;
	}
	return 0;
}
int ArrayStr::Add(const int v) { MyStr T(v); return Add((char*)T); }
int ArrayStr::Add(const long lv) { MyStr T(lv); return Add((char*)T); }


void ArrayStr::Release(ArrayStr *nd) {
	ArrayStr *cp=nd;
//printf("\nRel:cp=%u this=%u",cp,this);
	while(cp!=NULL) {
		ArrayStr *p=cp;
//printf("\n>>Rel:p->nxt=%u p->pstr=%u",p->nxt,p->pstr);
		cp=cp->nxt;
//printf("\n>>Rel:cp=%u p=%u",cp,p);
		if(p->pstr!=NULL) delete p->pstr;
		if(p==this) { p->pstr=NULL; p->nxt=NULL; }
		else free(p);
	}
}
ArrayStr *ArrayStr::GetNode(MyStr &S) {
	ArrayStr *cp=this;
	while(cp!=NULL) {
		if(cp->pstr!=NULL) {
			if(*(cp->pstr)==S) return cp;
		}
		cp=cp->nxt;
	}
	return NULL;
}
ArrayStr *ArrayStr::GetNode(int idx) {
	if(idx>-1) {
		ArrayStr *cp=this;
		int cnt=-1;
		while(cp!=NULL) {
			if(cp->pstr!=NULL) cnt++;
			if(cnt==idx) return cp;
			cp=cp->nxt;
		}
	}
	return NULL;
}
int ArrayStr::GetArrayCNT(void) {
	ArrayStr *cp=this;
	int cnt=0;
	while(cp!=NULL) {
		if(cp->pstr!=NULL) cnt++;
		cp=cp->nxt;
	}
	return cnt;
}
const char* ArrayStr::GetSTR(int idx){
	ArrayStr *p=GetNode(idx);
	if(p!=NULL) return (char*)*(p->pstr);
	return NULL;
}

ArrayStr::ArrayStr() { pstr=NULL; nxt=NULL;}
ArrayStr::ArrayStr(const char *s) { pstr=NULL; nxt=NULL; Add(s); }
ArrayStr::ArrayStr(MyStr &S) { pstr=NULL; nxt=NULL; Add(S); }
ArrayStr::ArrayStr(ArrayStr &A) { pstr=NULL; nxt=NULL; operator+=(A); }
ArrayStr::ArrayStr(const int v) { pstr=NULL; nxt=NULL; MyStr T(v); Add(T); }
ArrayStr::ArrayStr(const long lv) { pstr=NULL; nxt=NULL; MyStr T(lv); Add(T); }

ArrayStr::~ArrayStr() { Release(this); }

ArrayStr& ArrayStr::operator=(ArrayStr &A) { Release(this); return operator+=(A); }

MyStr& ArrayStr::operator[](int idx) { 
	ArrayStrTMP="";
	ArrayStr *p=GetNode(idx);
	if(p!=NULL) return *(p->pstr);
	return ArrayStrTMP;
}

ArrayStr& ArrayStr::operator+=(const char *s) { Add(s); return *this; }
ArrayStr& ArrayStr::operator+=(MyStr &S) { Add(S); return *this; }
ArrayStr& ArrayStr::operator+=(ArrayStr &A) { Add(A); return *this; }

const char *ArrayStr::List(const char c) { MyStr DIV(c); return List(DIV); }
const char *ArrayStr::List(const char *d) { MyStr DIV(d); return List(DIV); }
const char *ArrayStr::List(MyStr &DIV) {
	ArrayStrTMP="";
	ArrayStr *cp=this;
	int cnt=0;
	while(cp!=NULL) {
		if(cp->pstr!=NULL) { 
			if(cnt++>0) ArrayStrTMP+=DIV;
			ArrayStrTMP+=*(cp->pstr);
		}
		cp=cp->nxt;
	}
	return ArrayStrTMP;
}

const char *ArrayStr::ListRev(const char c) { MyStr DIV(c); return ListRev(DIV); }
const char *ArrayStr::ListRev(const char *d) { MyStr DIV(d); return ListRev(DIV); }
const char*	ArrayStr::ListRev(MyStr &DIV) {
	ArrayStrTMP="";
	ArrayStr *cp=this;
	int cnt=0;
	while(cp!=NULL) {
		if(cp->pstr!=NULL) {
			MyStr T=*(cp->pstr);
			if(cnt++>0) T+=DIV;
			ArrayStrTMP=T+ArrayStrTMP;
		}
		cp=cp->nxt;
	}
	return ArrayStrTMP;
}

int ArrayStr::GetIDX(const char *s) {
	if(s!=NULL) {
		MyStr S(s);
		return GetIDX(S);
	}
	return -1;
}
int ArrayStr::GetIDX(MyStr &S) {
	ArrayStr *cp=this;
	int cnt=0;
	while(cp!=NULL) {
		if(cp->pstr!=NULL) { 
			if(*(cp->pstr)==S) return cnt;
			cnt++;
		}
		cp=cp->nxt;
	}
	return -1;
}
