#include "namearraystr.h"

const char *NameArrayStr::GetName(void) { return (char*)myname; }

bool NameArrayStr::IsNameEmpty() 	{ if((int)myname<1) return true; else return false; }
bool NameArrayStr::IsNotNameEmpty()	{ if((int)myname<1) return false; else return true; }

const char *NameArrayStr::SetName(const char c)		{ myname=c; 	return GetName(); }
const char *NameArrayStr::SetName(const char *name)	{ myname=name; 	return GetName(); }
const char *NameArrayStr::SetName(MyStr &NAME) 		{ myname=NAME; 	return GetName(); }
const char *NameArrayStr::SetName(const int ni)		{ myname=ni; 	return GetName(); }
const char *NameArrayStr::SetName(const long nl)	{ myname=nl; 	return GetName(); }

NameArrayStr::NameArrayStr(NameStr &NS) { myname=NS.GetName(); Add((char*)NS); }
NameArrayStr::NameArrayStr(NameArrayStr &NSA) { myname=NSA.GetName(); Add((ArrayStr&)NSA); }

NameArrayStr::NameArrayStr(const char *name,const char *s) 		{ myname=name; Add(s); }
NameArrayStr::NameArrayStr(const char *name,const char sc) 		{ myname=name; Add(sc); }
NameArrayStr::NameArrayStr(const char *name,MyStr &S) 			{ myname=name; Add(S); }
NameArrayStr::NameArrayStr(const char *name,NameStr &NS) 		{ myname=name; Add((char*)NS); }
NameArrayStr::NameArrayStr(const char *name,ArrayStr &SA) 		{ myname=name; Add(SA); }
NameArrayStr::NameArrayStr(const char *name,NameArrayStr &NSA) 	{ myname=name; Add((ArrayStr&)NSA); }
NameArrayStr::NameArrayStr(const char *name,const int i) 		{ myname=name; Add(i); }
NameArrayStr::NameArrayStr(const char *name,const long l) 		{ myname=name; Add(l); }

NameArrayStr& NameArrayStr::operator=(NameArrayStr &NSA) { 
	myname=NSA.GetName(); 
	int n=GetArrayCNT();
	if(n>0) Release(GetNode(0));
	Add((ArrayStr&)NSA);
	return *this;
}
NameArrayStr& NameArrayStr::operator=(ArrayStr &SA) { 
	int n=GetArrayCNT();
	if(n>0) Release(GetNode(0));
	Add(SA);
	return *this;
}

NameArrayStr& NameArrayStr::operator+=(const char c)		{ Add(c); 				 return *this; }
NameArrayStr& NameArrayStr::operator+=(const char *s)		{ Add(s); 				 return *this; }
NameArrayStr& NameArrayStr::operator+=(MyStr &S)			{ Add(S); 				 return *this; }
NameArrayStr& NameArrayStr::operator+=(NameStr &NS) 		{ Add((MyStr&)NS); 		 return *this; }
NameArrayStr& NameArrayStr::operator+=(ArrayStr &SA) 		{ Add(SA); 				 return *this; }
NameArrayStr& NameArrayStr::operator+=(NameArrayStr &NSA) 	{ Add((ArrayStr&)NSA); 	 return *this; }
NameArrayStr& NameArrayStr::operator+=(const int i) 		{ Add(i); 				 return *this; }
NameArrayStr& NameArrayStr::operator+=(const long l) 		{ Add(l); 				 return *this; }

void NameArrayStr::Reset(void) { myname=""; Release(this); }
