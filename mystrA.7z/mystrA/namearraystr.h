/*########################################################################################
	v1.0@20191021 	initial ver.
##########################################################################################*/

#ifndef __NameArrayStr_h__
    #define __NameArrayStr_h__
	#define __NameArrayStrVer_h___	"NameArrayStr-v1.0@20191021"
	
#include "mystr.h"
#include "namestr.h"
#include "arraystr.h"

class NameArrayStr : public ArrayStr {
private:
 			MyStr 		myname;
protected:
public:
			NameArrayStr(NameStr &NS);
			NameArrayStr(NameArrayStr &NSA);

			NameArrayStr(const char *name=NULL,const char *s=NULL);
			NameArrayStr(const char *name,const char sc);
			NameArrayStr(const char *name,MyStr &S);
			NameArrayStr(const char *name,NameStr &NS);
			NameArrayStr(const char *name,ArrayStr &SA);
			NameArrayStr(const char *name,NameArrayStr &NSA);
			NameArrayStr(const char *name,const int i);
			NameArrayStr(const char *name,const long l);
			
	 	 	const char *GetName(void);
	 	 	
		     bool	   IsNameEmpty();
		     bool	   IsNotNameEmpty();

			const char *SetName(const char c);
			const char *SetName(const char *name);
			const char *SetName(MyStr &NAME);
			const char *SetName(const int ni);
			const char *SetName(const long nl);

virtual 	NameArrayStr& operator=(NameArrayStr &NSA);
virtual 	NameArrayStr& operator=(ArrayStr &SA);

virtual 	NameArrayStr& operator+=(const char c);
virtual 	NameArrayStr& operator+=(const char *s);
virtual 	NameArrayStr& operator+=(MyStr &S);
virtual 	NameArrayStr& operator+=(NameStr &NS);
virtual 	NameArrayStr& operator+=(ArrayStr &SA);
virtual 	NameArrayStr& operator+=(NameArrayStr &NSA);
virtual 	NameArrayStr& operator+=(const int i);
virtual 	NameArrayStr& operator+=(const long l);

};

#endif
