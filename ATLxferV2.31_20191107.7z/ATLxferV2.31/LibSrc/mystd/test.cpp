#include "mystr.h"
#include "namestr.h"
#include "mystd.h"

int main(int ac,char **av)
{
	namestr NS("NameStr","Yes");
	MyStr S("Hello world");
	tout out;
	out << "\n"
	<< S
	<< "! "
	<< 123
	<<" "<< NS;
	
	out.prt("\n/% % % % /%",(char*)S,(char*)NS,345);
	
    return 0;
}

