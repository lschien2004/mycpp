
#include "mystr.h"
#include "namestr.h"
#include "arraystr.h"
#include "namearraystr.h"
#include "mystd.h"

int main(int ac,char **av) {
	tout out;
	int n,i;
	MyStr S;
	NameStr NS;
	
	out.prt("\nNameArrayStr NAX;");
	NameArrayStr NAX;
	n=NAX.GetArrayCnt();
	out.prt("\nNAX.GetName()=\"%\",NAX.GetArrayCnt()=%",NAX.GetName(),n);
	out.prt("\nIsNameEmpty=% , IsNotNameEmpty=%",(int)NAX.IsNameEmpty(),(int)NAX.IsNotNameEmpty());
	i=0; out.prt("\n(char*)NAX[%]=\"%\"",i,(char*)NAX[i]);
	i=0; out<<" ,NAX.GetStr(" << i << ")=\"" << NAX.GetStr(i) << "\"";

	out.prt("\nNAX.SetName(\"NAX\");");
	NAX.SetName("NAX");
	n=NAX.GetArrayCnt();
	out.prt("\nIsNameEmpty=% , IsNotNameEmpty=%",(int)NAX.IsNameEmpty(),(int)NAX.IsNotNameEmpty());
	out.prt("\nNAX.GetName()=\"%\",NAX.GetArrayCnt()=%",NAX.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAX[%]=\"%\"",i,(char*)NAX[i]);
		out.prt(" ,NAX.GetIdx(NAX[%])=%",i,NAX.GetIdx(NAX[i]));
		out.prt(" ,NAX.GetStr(%)=\"%\"",i,NAX.GetStr(i));
	}
	S="NAX-S";
	out.prt("\nS=\"%\";",(char*)S);
	out.prt("\nNAX.SetName(S);");
	NAX.SetName(S);
	n=NAX.GetArrayCnt();
	out.prt("\nIsNameEmpty=% , IsNotNameEmpty=%",(int)NAX.IsNameEmpty(),(int)NAX.IsNotNameEmpty());
	out.prt("\nNAX.GetName()=\"%\",NAX.GetArrayCnt()=%",NAX.GetName(),n);
	S="DATA-S";
	out.prt("\nS=\"%\";",(char*)S);
	out.prt("\nNAX+=S;");
	NAX+=S;
	n=NAX.GetArrayCnt();
	out.prt("\nNAX.GetName()=\"%\",NAX.GetArrayCnt()=%",NAX.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAX[%]=\"%\"",i,(char*)NAX[i]);
		out.prt(" ,NAX.GetIdx(NAX[%])=%",i,NAX.GetIdx(NAX[i]));
		out.prt(" ,NAX.GetStr(%)=\"%\"",i,NAX.GetStr(i));
	}
	out.prt("\nNAX+=\"DATA1\";");
	NAX+="DATA1";
	n=NAX.GetArrayCnt();
	out.prt("\nNAX.GetName()=\"%\",NAX.GetArrayCnt()=%",NAX.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAX[%]=\"%\"",i,(char*)NAX[i]);
		out.prt(" ,NAX.GetIdx(NAX[%])=%",i,NAX.GetIdx(NAX[i]));
		out.prt(" ,NAX.GetStr(%)=\"%\"",i,NAX.GetStr(i));
	}
	out.prt("\nNAX.Add(\"Data2\";");
	NAX.Add("Data2");
	n=NAX.GetArrayCnt();
	out.prt("\nNAX.GetName()=\"%\",NAX.GetArrayCnt()=%",NAX.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAX[%]=\"%\"",i,(char*)NAX[i]);
		out.prt(" ,NAX.GetIdx(NAX[%])=%",i,NAX.GetIdx(NAX[i]));
		out.prt(" ,NAX.GetStr(%)=\"%\"",i,NAX.GetStr(i));
	}
	
	out.prt("\n\nNameArrayStr NAS(\"NAS\");");
	NameArrayStr NAS("NAS");
	n=NAS.GetArrayCnt();
	out.prt("\nNAS.GetName()=\"%\",NAS.GetArrayCnt()=%",NAS.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAS[%]=\"%\"",i,(char*)NAS[i]);
		out.prt(" ,NAS.GetIdx(NAS[%])=%",i,NAS.GetIdx(NAS[i]));
		out.prt(" ,NAS.GetStr(%)=\"%\"",i,NAS.GetStr(i));
	}
	out.prt("\n\nNAS+=\"NAS-data0\";");
	NAS+="NAS-data0";
	n=NAS.GetArrayCnt();
	out.prt("\nNAS.GetName()=\"%\",NAS.GetArrayCnt()=%",NAS.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAS[%]=\"%\"",i,(char*)NAS[i]);
		out.prt(" ,NAS.GetIdx(NAS[%])=%",i,NAS.GetIdx(NAS[i]));
		out.prt(" ,NAS.GetStr(%)=\"%\"",i,NAS.GetStr(i));
	}
	out.prt("\n\nNAS+=NAX;");
	NAS+=NAX;
	n=NAS.GetArrayCnt();
	out.prt("\nNAS.GetName()=\"%\",NAS.GetArrayCnt()=%",NAS.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAS[%]=\"%\"",i,(char*)NAS[i]);
		out.prt(" ,NAS.GetIdx(NAS[%])=%",i,NAS.GetIdx(NAS[i]));
		out.prt(" ,NAS.GetStr(%)=\"%\"",i,NAS.GetStr(i));
	}
	
	NameStr NX("NXname","NXdata");
	out.prt("\n\nNX[\"%\"]=\"%\"",NX.GetName(),(char*)NX);
	NS.SetName("NSname"); NS="NSdata";
	out.prt("\nNS[\"%\"]=\"%\"",NS.GetName(),(char*)NS);

	out.prt("\n\nNAS+=NS;");
	NAS+=NS;
	n=NAS.GetArrayCnt();
	out.prt("\nNAS.GetName()=\"%\",NAS.GetArrayCnt()=%",NAS.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAS[%]=\"%\"",i,(char*)NAS[i]);
		out.prt(" ,NAS.GetIdx(NAS[%])=%",i,NAS.GetIdx(NAS[i]));
		out.prt(" ,NAS.GetStr(%)=\"%\"",i,NAS.GetStr(i));
	}
	out.prt("\n\nNAS.List()=\"%\"",NAS.List());	
	out.prt("\n\nNAS.ListRev(';')=\"%\"",NAS.ListRev(';'));	

	
	i=NAS.DelByIdx(0);
	out.prt("\n\nNAS.DelByIdx(0)=%",i);
	n=NAS.GetArrayCnt();
	out.prt("\nNAS.GetName()=\"%\",NAS.GetArrayCnt()=%",NAS.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAS[%]=\"%\"",i,(char*)NAS[i]);
		out.prt(" ,NAS.GetIdx(NAS[%])=%",i,NAS.GetIdx(NAS[i]));
		out.prt(" ,NAS.GetStr(%)=\"%\"",i,NAS.GetStr(i));
	}
	n--; 
	i=NAS.DelByIdx(n);
	out.prt("\n\nNAS.DelByIdx(%)=%",n,i);
	n=NAS.GetArrayCnt();
	out.prt("\nNAS.GetName()=\"%\",NAS.GetArrayCnt()=%",NAS.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAS[%]=\"%\"",i,(char*)NAS[i]);
		out.prt(" ,NAS.GetIdx(NAS[%])=%",i,NAS.GetIdx(NAS[i]));
		out.prt(" ,NAS.GetStr(%)=\"%\"",i,NAS.GetStr(i));
	}
	S=NAS[1];
	out.prt("\n\nS=\"%\";",(char*)S);
	i=NAS.DelByStr(S);
	out.prt("\nNAS.DelByStr(S)=%",i);
	n=NAS.GetArrayCnt();
	out.prt("\nNAS.GetName()=\"%\",NAS.GetArrayCnt()=%",NAS.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAS[%]=\"%\"",i,(char*)NAS[i]);
		out.prt(" ,NAS.GetIdx(NAS[%])=%",i,NAS.GetIdx(NAS[i]));
		out.prt(" ,NAS.GetStr(%)=\"%\"",i,NAS.GetStr(i));
	}
	
	i=NAS.DelByIdx(1);
	out.prt("\n\nNAS.DelByIdx(1)=%",i);
	n=NAS.GetArrayCnt();
	out.prt("\nNAS.GetName()=\"%\",NAS.GetArrayCnt()=%",NAS.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAS[%]=\"%\"",i,(char*)NAS[i]);
		out.prt(" ,NAS.GetIdx(NAS[%])=%",i,NAS.GetIdx(NAS[i]));
		out.prt(" ,NAS.GetStr(%)=\"%\"",i,NAS.GetStr(i));
	}
	i=NAS.DelByIdx(1);
	out.prt("\n\nNAS.DelByIdx(1)=%;",i);
	n=NAS.GetArrayCnt();
	out.prt("\nNAS.GetName()=\"%\",NAS.GetArrayCnt()=%",NAS.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAS[%]=\"%\"",i,(char*)NAS[i]);
		out.prt(" ,NAS.GetIdx(NAS[%])=%",i,NAS.GetIdx(NAS[i]));
		out.prt(" ,NAS.GetStr(%)=\"%\"",i,NAS.GetStr(i));
	}
	
	i=NAS.DelByIdx(0);
	out.prt("\n\nNAS.DelByIdx(0)=%;",i);
	n=NAS.GetArrayCnt();
	out.prt("\nNAS.GetName()=\"%\",NAS.GetArrayCnt()=%",NAS.GetName(),n);
	
	i=NAS.DelByIdx(0);
	out.prt("\n\nNAS.DelByIdx(0)=%;",i);
	n=NAS.GetArrayCnt();
	out.prt("\nNAS.GetName()=\"%\",NAS.GetArrayCnt()=%",NAS.GetName(),n);
		
	out.prt("\n\nNAX=NS;");
	NAX=NS;
	n=NAX.GetArrayCnt();
	out.prt("\nNAX.GetName()=\"%\",NAX.GetArrayCnt()=%",NAX.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAX[%]=\"%\"",i,(char*)NAX[i]);
		out.prt(" ,NAX.GetIdx(NAX[%])=%",i,NAX.GetIdx(NAX[i]));
		out.prt(" ,NAX.GetStr(%)=\"%\"",i,NAX.GetStr(i));
	}
	out.prt("\n\nNAX+=NX;");
	NAX+=NX;
	n=NAX.GetArrayCnt();
	out.prt("\nNAX.GetName()=\"%\",NAX.GetArrayCnt()=%",NAX.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAX[%]=\"%\"",i,(char*)NAX[i]);
		out.prt(" ,NAX.GetIdx(NAX[%])=%",i,NAX.GetIdx(NAX[i]));
		out.prt(" ,NAX.GetStr(%)=\"%\"",i,NAX.GetStr(i));
	}
	out.prt("\n\nNAX+=NX;");
	NAX+=NX;
	n=NAX.GetArrayCnt();
	out.prt("\nNAX.GetName()=\"%\",NAX.GetArrayCnt()=%",NAX.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAX[%]=\"%\"",i,(char*)NAX[i]);
		out.prt(" ,NAX.GetIdx(NAX[%])=%",i,NAX.GetIdx(NAX[i]));
		out.prt(" ,NAX.GetStr(%)=\"%\"",i,NAX.GetStr(i));
	}
	out.prt("\n\nNAX+=NS;");
	NAX+=NS;
	n=NAX.GetArrayCnt();
	out.prt("\nNAX.GetName()=\"%\",NAX.GetArrayCnt()=%",NAX.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAX[%]=\"%\"",i,(char*)NAX[i]);
		out.prt(" ,NAX.GetIdx(NAX[%])=%",i,NAX.GetIdx(NAX[i]));
		out.prt(" ,NAX.GetStr(%)=\"%\"",i,NAX.GetStr(i));
	}

	S=(char*)NX;
	out.prt("\n\nS=\"%\";",(char*)S);
	i=NAX.DelRevByStr(S);
	out.prt("\nNAX.DelRevByStr(S)=%;",i);
	n=NAX.GetArrayCnt();
	out.prt("\nNAX.GetName()=\"%\",NAX.GetArrayCnt()=%",NAX.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAX[%]=\"%\"",i,(char*)NAX[i]);
		out.prt(" ,NAX.GetIdx(NAX[%])=%",i,NAX.GetIdx(NAX[i]));
		out.prt(" ,NAX.GetStr(%)=\"%\"",i,NAX.GetStr(i));
	}
	S=(char*)NS;
	out.prt("\n\nS=\"%\";",(char*)S);
	i=NAX.DelAllByStr(S);
	out.prt("\nNAX.DelAllByStr(S)=%;",i);
	n=NAX.GetArrayCnt();
	out.prt("\nNAX.GetName()=\"%\",NAX.GetArrayCnt()=%",NAX.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAX[%]=\"%\"",i,(char*)NAX[i]);
		out.prt(" ,NAX.GetIdx(NAX[%])=%",i,NAX.GetIdx(NAX[i]));
		out.prt(" ,NAX.GetStr(%)=\"%\"",i,NAX.GetStr(i));
	}
	
	out.prt("\n\nS=\"%\";",(char*)S);
	i=NAX.DelAllByStr(S);
	out.prt("\nNAX.DelAllByStr(S)=%;",i);
	n=NAX.GetArrayCnt();
	out.prt("\nNAX.GetName()=\"%\",NAX.GetArrayCnt()=%",NAX.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAX[%]=\"%\"",i,(char*)NAX[i]);
		out.prt(" ,NAX.GetIdx(NAX[%])=%",i,NAX.GetIdx(NAX[i]));
		out.prt(" ,NAX.GetStr(%)=\"%\"",i,NAX.GetStr(i));
	}

	S=(char*)NX;
	out.prt("\n\nS=\"%\";",(char*)S);
	i=NAX.DelAllByStr(S);
	out.prt("\nNAX.DelAllByStr(S)=%;",i);
	n=NAX.GetArrayCnt();
	out.prt("\nNAX.GetName()=\"%\",NAX.GetArrayCnt()=%",NAX.GetName(),n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)NAX[%]=\"%\"",i,(char*)NAX[i]);
		out.prt(" ,NAX.GetIdx(NAX[%])=%",i,NAX.GetIdx(NAX[i]));
		out.prt(" ,NAX.GetStr(%)=\"%\"",i,NAX.GetStr(i));
	}

	return 0;
}
