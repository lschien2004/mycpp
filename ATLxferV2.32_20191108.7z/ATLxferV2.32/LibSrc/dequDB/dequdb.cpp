#include "dequdb.h"

static MyStr TmpStr;

void ReleaseDSLINK(DSLINK **p) {
//printf("\nReleaseDSLINK(*p=%u)",*p);
	while(*p!=NULL) { 
//printf("..*p=%u",*p);
		DSLINK *t=*p;
		*p=(*p)->nxt;
		delete t;
	}
//printf("..Last *p=%u",*p);
}
//=====================================================================
void AddExchgLineCmtWithExSymBlk(MyStr &LL,ArrayNameStr &Exchg) {
	PO2 pp;
	MyStr SYM(_DEQUSYMS);
	SYM+=_DEQUSYMU;
	pp.p1=LL.InStrExSymBlk(_DEQULCMT,(char*)SYM);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		pp.p2=LL.InStrExSymBlk(pp.p1,"\n",(char*)SYM);
		MyStr T(_DEQU_ExKeyS); T+="cl"; T+=n; T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2-1));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp.p1=LL.InStrExSymBlk(_DEQULCMT,(char*)SYM);
	}
}
void AddExchgLineCmtWithExLineSymBlk(MyStr &LL,ArrayNameStr &Exchg) {
	PO2 pp;
	pp.p1=LL.InStrExLineSymBlk(_DEQULCMT,_DEQUSYMA);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		pp.p2=LL.InStrExLineSymBlk(pp.p1,"\n",_DEQUSYMA);
		MyStr T(_DEQU_ExKeyS); T+="cl"; T+=n; T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2-1));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp.p1=LL.InStrExLineSymBlk(_DEQULCMT,_DEQUSYMA);
	}
}
//=====================================================================
void AddExchgSymChrCmtWithExSymBlk(MyStr &LL,ArrayNameStr &Exchg) {
	PO2 pp;
	pp.p1=LL.InStrExSymBlk(_DEQUCMTC,_DEQUSYMA);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		pp.p2=pp.p1+1;
		MyStr T(_DEQU_ExKeyS); T+="cc"; T+=n; T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp.p1=LL.InStrExSymBlk(_DEQUCMTC,_DEQUSYMA);
	}
}
void AddExchgSymChrCmtWithExLineSymBlk(MyStr &LL,ArrayNameStr &Exchg) {
	PO2 pp;
	pp.p1=LL.InStrExLineSymBlk(_DEQUCMTC,_DEQUSYMA);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		pp.p2=pp.p1+1;
		MyStr T(_DEQU_ExKeyS); T+="cc"; T+=n; T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp.p1=LL.InStrExLineSymBlk(_DEQUCMTC,_DEQUSYMA);
	}
}
//=====================================================================
void AddExchgWithSymlst(MyStr &LL,ArrayNameStr &Exchg,const char *symlst) {
	MyStr SYM(symlst);
	if((int)SYM<1) return;
	PO2 pp;
	pp=LL.SymBlkIdxInStr(0,-1,(char*)SYM);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		MyStr T(_DEQU_ExKeyS); T+="sm"; T+=n; T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp=LL.SymBlkIdxInStr(0,-1,(char*)SYM);
	}
}
//----------------------------------------------------------------------
void AddExchgWithLineSymlst(MyStr &LL,ArrayNameStr &Exchg,const char *symlst) {
	MyStr SYM(symlst);
	if((int)SYM<1) return;
	PO2 pp;
	pp=LL.LineSymBlkIdxInStr(0,-1,(char*)SYM);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		MyStr T(_DEQU_ExKeyS); T+="sm"; T+=n; T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp=LL.LineSymBlkIdxInStr(0,-1,(char*)SYM);
	}
}
//=====================================================================
void AddExchgSymBlk(MyStr &LL,ArrayNameStr &Exchg) { 
	MyStr SYM(_DEQUSYMS); SYM+=_DEQUSYMU; 
	return AddExchgWithSymlst(LL,Exchg,(char*)SYM);
}
void AddExchgSymBlkS(MyStr &LL,ArrayNameStr &Exchg) { return AddExchgWithSymlst(LL,Exchg,_DEQUSYMS); }
void AddExchgSymBlkU(MyStr &LL,ArrayNameStr &Exchg) { return AddExchgWithSymlst(LL,Exchg,_DEQUSYMU); }
void AddExchgSymBlkA(MyStr &LL,ArrayNameStr &Exchg) { return AddExchgWithSymlst(LL,Exchg,_DEQUSYMA); }
//=====================================================================
void AddExchgLineSymBlk(MyStr &LL,ArrayNameStr &Exchg) {
	MyStr SYM(_DEQUSYMS); SYM+=_DEQUSYMU; 
	return AddExchgWithLineSymlst(LL,Exchg,(char*)SYM);
}
void AddExchgLineSymBlkS(MyStr &LL,ArrayNameStr &Exchg) { return AddExchgWithLineSymlst(LL,Exchg,_DEQUSYMS); }
void AddExchgLineSymBlkU(MyStr &LL,ArrayNameStr &Exchg) { return AddExchgWithLineSymlst(LL,Exchg,_DEQUSYMU); }
void AddExchgLineSymBlkA(MyStr &LL,ArrayNameStr &Exchg) { return AddExchgWithLineSymlst(LL,Exchg,_DEQUSYMA); }
//=====================================================================
const char *GetUnExchgStrByExkey(MyStr &LL,ArrayNameStr &Exchg,const char *Exkey) {
	TmpStr=LL; MyStr K(Exkey);
	if((int)K>0) {
		for(int n=Exchg.GetArrayCnt()-1;n>-1;n--) {
			if(WdIdxInStr(Exchg[n].GetName(),(char*)K)>-1)
				TmpStr=TmpStr.GetRangeWithWdChg(Exchg.GetNameByIdx(n),(char*)Exchg[n]);
		}
	} else {
		for(int n=Exchg.GetArrayCnt()-1;n>-1;n--) {
			TmpStr=TmpStr.GetRangeWithWdChg(Exchg.GetNameByIdx(n),(char*)Exchg[n]);
		}
	}
	return (char*)TmpStr;
}
int CheckExkeyInside(MyStr &LL,const char *exkey) {
	MyStr K(exkey); if((int)K<1) return -1; else return LL.InStr(K); 
}
const char *GetLineCmtUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { MyStr K(_DEQU_ExKeyS); K+="cl"; return GetUnExchgStrByExkey(LL,Exchg,(char*)K); }
const char *GetSymChrCmtUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { MyStr K(_DEQU_ExKeyS); K+="cc"; return GetUnExchgStrByExkey(LL,Exchg,(char*)K); }
const char *GetSymBlkSUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { MyStr K(_DEQU_ExKeyS); K+="sm"; return GetUnExchgStrByExkey(LL,Exchg,(char*)K); }
const char *GetSymBlkUUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { MyStr K(_DEQU_ExKeyS); K+="um"; return GetUnExchgStrByExkey(LL,Exchg,(char*)K); }
const char *GetSymBlkUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { 
	MyStr K,S(LL);
	K=_DEQU_ExKeyS; K+="sm";
	S=GetUnExchgStrByExkey(S,Exchg,(char*)K);
	K=_DEQU_ExKeyS; K+="um";
	return GetUnExchgStrByExkey(S,Exchg,(char*)K); 
}

const char *GetAllUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { return GetUnExchgStrByExkey(LL,Exchg,""); }
//=====================================================================
const char *GetRemoveExchgStrByExkey(MyStr &LL,ArrayNameStr &Exchg,const char *Exkey) {
	TmpStr=LL; MyStr K(Exkey);
	if((int)K>0) {
		for(int n=Exchg.GetArrayCnt()-1;n>-1;n--) {
			if(WdIdxInStr(Exchg[n].GetName(),(char*)K)>-1)
				TmpStr=TmpStr.GetRangeWithWdChg(Exchg.GetNameByIdx(n),"");
		}
	} else {
		for(int n=Exchg.GetArrayCnt()-1;n>-1;n--) {
			TmpStr=TmpStr.GetRangeWithWdChg(Exchg.GetNameByIdx(n),"");
		}
	}
	return (char*)TmpStr;
}

const char *GetRemoveAllExchgStr(MyStr &LL,ArrayNameStr &Exchg) { return GetRemoveExchgStrByExkey(LL,Exchg,""); }
//=====================================================================
const char *GetDequErrMessage(DequCode r){
	switch (r) {
		case _well:
			TmpStr="";
			break;
		case _none:
			TmpStr="No DEQU defintion !";
			break;
		case _err_name:
			TmpStr="bad DEQU name format !";
			break;
		case _err_dyncname:
			TmpStr="Break dync(Insided) DEQU name rule (MUST w/i one parent $parameter$)!";
			break;
		case _err_namerule:
			TmpStr="Break DEQU name rule (w/o Lcase char request >1 Ucase char + >1 \"";
			TmpStr+=_DEQUNAME_exack_chars;
			TmpStr+="\" char & Not #HEX)!";
			break;
		case _err_name_overlap:
			TmpStr="DEQU name overlap !";
			break;
		case _err_para:
			TmpStr="DEQU parameter < > missing !";
			break;
		case _err_body:
			TmpStr="DEQU body {{ }} missing !";
			break;
		case _err_dbfile:
			TmpStr="DEQU DB file acess fail !";
			break;
		default:
			TmpStr="Unknow DEQU format problem !";
			break;
	}
	return (char*)TmpStr;
}

//##################################################################
//				SDequ	SDequ	SDequ	SDequ	
//##################################################################

void SDequ::Reset(void) { NameArrayStr::Reset(); BDY=""; }
SDequ& SDequ::operator=(SDequ &SD) { NameArrayStr::operator=((NameArrayStr&)SD); BDY=SD.BDY; return *this; }

//##################################################################
//				Dequ	Dequ	Dequ	Dequ	
//##################################################################
Dequ::Dequ() {}
Dequ::Dequ(Dequ &DQ) { Dequ::operator=(DQ); }

Dequ& Dequ::operator=(Dequ &DQ) { 
	SDequ::operator=((SDequ&)DQ); 
	Exchg=DQ.Exchg;
	return *this;
}

void Dequ::Reset(void) {
	SDequ::Reset(); Exchg.Reset(); BDY="";
}

int Dequ::GetParaCnt(void) { return GetArrayCnt(); }
const char *Dequ::GetParaList(void) { return List(','); }
const char *Dequ::GetBody(void) { return (char*)BDY; }

//void Dequ::ExchgAddLineCmt(MyStr &LL) 			{ return AddExchgLineCmtWithExSymBlk(LL,Exchg); }
//void Dequ::ExchgAddSymChrCmt(MyStr &LL) 			{ return AddExchgSymChrCmtWithExSymBlk(LL,Exchg); }
//void Dequ::ExchgAddSymBlk(MyStr &LL) 				{ return AddExchgSymBlk(LL,Exchg); }
void Dequ::ExchgAddLineCmt(MyStr &LL) 				{ return AddExchgLineCmtWithExLineSymBlk(LL,Exchg); }
void Dequ::ExchgAddSymChrCmt(MyStr &LL) 			{ return AddExchgSymChrCmtWithExLineSymBlk(LL,Exchg); }
void Dequ::ExchgAddSymBlk(MyStr &LL) 				{ return AddExchgLineSymBlk(LL,Exchg); }

const char *Dequ::GetUnExchgAll(MyStr &LL) 			{ return GetAllUnExchgStr(LL,Exchg); }

PO2  Dequ::GetPointOfDequContents(MyStr &LL) {
	MyStr FF(LL),LS;
	ArrayNameStr ANS;
	//AddExchgLineCmtWithExSymBlk(FF,ANS);
	//AddExchgSymBlk(FF,ANS);
	AddExchgLineCmtWithExLineSymBlk(FF,ANS);
	AddExchgLineSymBlk(FF,ANS);

	PO2 pp=FF.GetPointOfStackPairKey(_DEQUKEY,_DEQUBDYED);
	if(pp.p1>0) 	{ LS=FF.GetRangeByIdx(-1,pp.p1-1); 	LS=GetAllUnExchgStr(LS,ANS); pp.p1=(int)LS; }
	if(pp.p2>0) 	{ LS=FF.GetRangeByIdx(-1,pp.p2-1); 	LS=GetAllUnExchgStr(LS,ANS); pp.p2=(int)LS; }
	return pp;
}

int Dequ::IsExchgInStr(MyStr &LL) { return CheckExkeyInside(LL,_DEQU_ExKeyS); }

DequCode Dequ::IsWellName(MyStr &NM) {
//printf("\nIsWellName[%s]",(char*)NM);
	int UC=0,SC=0;
	if(NM!=NM.GetTrimA()) return _err_name;
	if((int)NM>0 && IsExchgInStr(NM)<0) {
		//if((NM.WdCntInStr('$')%2)==1) return _err_namerule;
				
		if(NM.InStr(_DEQUKEY)>-1) return _err_namerule;
		if(NM.InStr(_DEQUPARST)>-1) return _err_namerule;
		if(NM.InStr(_DEQUPARED)>-1) return _err_namerule;
		if(NM.InStr(_DEQUBDYST)>-1) return _err_namerule;
		if(NM.InStr(_DEQUBDYED)>-1) return _err_namerule;

		if(NM.InStr("%IFE")>-1) return _err_namerule;
		if(NM.InStr("%IFN")>-1) return _err_namerule;
		if(NM.InStr("EQUATE")>-1) return _err_namerule;

		if(NM.LowerCaseInside()>0) return _well;
		int XHexC=0;
		for(int n=0;n<(int)NM;n++) {
			if(NM[n]>='A' && NM[n]<='Z') UC++;
			if(NM[n]>='G' && NM[n]<='Z') XHexC++;
			if(WdIdxInStr(_DEQUNAME_exack_chars,NM[n])>-1) { 
				if(n>0 || NM[n]!='#') XHexC++;
				SC++;
			}
		}
		if(UC>0 && SC>0 && XHexC>0) return _well;
		return _err_namerule;
	}
	return _err_name;
}

DequCode Dequ::IsWellDyncContents(MyStr &LL,MyStr &PPA) {
	MyStr PA(PPA.GetTrimA());
	if((int)PA<1) {
//printf("\nIsWellDyncContents[%s]PPA[%]<1 error!\n",(char*)LL,(char*)PPA);
		return _err_dyncname;
	}
	if(PA[(int)PA-1]!=',') PA=PA+',';
	//-----------------------------------------
	Dequ DQ; MyStr FF,T;
	DequCode r=DQ.ContentsToDequ(LL,FF,DQ);
	if(r!=_well) {
//printf("\nIsWellDyncContents[%s]DQ.ContentsToDequ->err(%d)!\n",(char*)LL,(int)r);
		return r;
	}
	MyStr NM(DQ.GetName());
	//if((NM.WdCntInStr('$')%2)==1) return _err_dyncname;
	//-----------------------------------------
	int i=0 , q=0;
	int p=PA.InStr(i,',');
	while(p>-1) {
		q++; T='$';
		if(p>0) T+=PA.GetRangeByIdx(i,p-1);
		else	T+=q;
		T+='$';
		if(NM.InStr(T)>-1) break;
		i=p+1;
		p=PA.InStr(i,',');
	}
	if(p<0) {
//printf("\nIsWellDyncContents[%s]PA[%s]NAME[%s] $para$ error!\n",(char*)LL,(char*)PA,(char*)NM);
		return _err_dyncname;
	}
	PO2 pp=GetPointOfDequContents(FF);
	if(pp.p1>-1 && pp.p2>pp.p1) return IsWellDyncContents(FF,PPA);
	return _well;
}

DequCode Dequ::IsWellContents(MyStr &LL) {
	ArrayNameStr TmpExchg;
	MyStr FF(LL);
	//--------------------------------------------------------------------
	//AddExchgLineCmtWithExSymBlk(FF,TmpExchg);
	//AddExchgSymChrCmtWithExSymBlk(FF,TmpExchg);
	//AddExchgSymBlk(FF,TmpExchg);
	AddExchgLineCmtWithExLineSymBlk(FF,TmpExchg);
	AddExchgSymChrCmtWithExLineSymBlk(FF,TmpExchg);
	AddExchgLineSymBlk(FF,TmpExchg);

//printf("\nIsWellContents(%s),FF(%s)",(char*)LL,(char*)FF);
	PO2 pp=GetPointOfDequContents(FF);
//printf("\npp.p1=%d,pp.p2=%d",pp.p1,pp.p2);
	if(pp.p1<0) return _none;			//error format : #dequ not found
	if(pp.p2<0) return _err_body;		//error format : }} not found
	//--------------------------------------------------------------------
	FF=FF.GetRangeByIdx(pp.p1,pp.p2);
	FF=FF.GetRangeWithWdChg('\t',' ');
//printf("\nFF(%s)",(char*)FF);
	MyStr T(_DEQUKEY); T+=' ';
	int p=FF.InStr(T);
	if(p<0) return _err_name;			//error format :  #dequ+<space> or #dequ+<tab>
	//--------------------------------------------------------------------
	p+=(int)T;
	FF=FF.GetRangeByIdx(p,(int)FF-strlen(_DEQUBDYED)-1);
	FF=FF.GetLineTrim();
	
	int k=FF.InStr(_DEQUBDYST);
//printf("\n#>FF(%s) k=%d",(char*)FF,k);
	if(k<0) return _err_body;						//error format : '{{' missing
	if(k<1) return _err_name;						//error format : NAME missing

	MyStr PA,BDY;
	int q1=FF.InStr(-1,k-1,_DEQUPARST);
	int q2=FF.InStr(-1,k-1,_DEQUPARED);
//printf("\n#>FF(%s) k=%d , q1=%d q2=%d ",(char*)FF,k,q1,q2);

	//--------------------------------------------------------------------
	if(q1>-1 && q2<0) 	return _err_para;			//error format : parameter > missing before {{
	if(q1<0  && q2>-1) 	return _err_para;			//error format : parameter < missing before {{
	if(q1>-1) { 
		T=FF.GetRangeByIdx(-1,q1-1);
		PA=FF.GetRangeByIdx(q1+1,q2-1);
		PA=PA.GetLineTrimA();
	} else T=FF.GetRangeByIdx(-1,k-1); 
	T=T.GetTrim();
	//--------------------------------------------------------------------
	DequCode r=IsWellName(T);
//printf("\n#>T(%s) r=%d PA=(%s)",(char*)T,(int)r,(char*)PA);

	if(r!=_well) return r;							//error format : NAME MUST w/i LowCase or exack chars
	//--------------------------------------------------------------------
	if(IsExchgInStr(PA)>-1) return _err_para;			//error format : Parameters w/i Exchg contents
	//--------------------------------------------------------------------
	k+=strlen(_DEQUBDYST);
	BDY=FF.GetRangeByIdx(k,-1);
	BDY=BDY.GetLineTrim();
	//--------------------------------------------------------------------	
	pp=GetPointOfDequContents(BDY);
	//--------------------------------------------------------------------	
	BDY=GetAllUnExchgStr(BDY,TmpExchg);
//printf("\n#>BDY(%s) k=%d pp.p1=%d pp.p2=%d ",(char*)BDY,k,pp.p1,pp.p2);
	if(pp.p1<0 && pp.p2<0) return _well;
	if(pp.p1>-1 && pp.p2>pp.p1) {
		if((int)PA<1) return _err_dyncname;
		PA+=','; return IsWellDyncContents(BDY,PA);
	}
	return _err_body;								//error format : bad #dequ inside
}

DequCode Dequ::ContentsToDequ(MyStr &InputStr,MyStr &OutputStr,Dequ &ODQ) {
//printf("\n#InputStr=[%s]",(char*)InputStr);
	ODQ.Reset();	MyStr FF(InputStr);	
	//--------------------------------------------------------------------
	//AddExchgLineCmtWithExSymBlk(FF,ODQ.Exchg);
	//AddExchgSymChrCmtWithExSymBlk(FF,ODQ.Exchg);
	//AddExchgSymBlk(FF,ODQ.Exchg);
	AddExchgLineCmtWithExLineSymBlk(FF,ODQ.Exchg);
	AddExchgSymChrCmtWithExLineSymBlk(FF,ODQ.Exchg);
	AddExchgLineSymBlk(FF,ODQ.Exchg);
	PO2 pp=GetPointOfDequContents(FF);
//printf("\n#pp.p1=%d pp.p2=%d",pp.p1,pp.p2);
	if(pp.p1<0) return _none;		//error format : no #dequ found
	if(pp.p2<0) return _err_body;	//error format : no }} found
	//--------------------------------------------------------------------
	if(pp.p1>0)	OutputStr=FF.GetRangeByIdx(-1,pp.p1-1);
	else 		OutputStr="";
	
	MyStr T;
	int p=OutputStr.InStrRev('\n');
	if(p>-1) { 
		T=OutputStr.GetRangeByIdx(p,-1); 
		T=T.GetTrim(); 
		if((int)T<1) {
			if(p>0) OutputStr=OutputStr.GetRangeByIdx(-1,p-1);
			else 	OutputStr="";
		}
	}
//printf("\n#OutputStr=[%s]",(char*)OutputStr);
	int x=FF.InStr(pp.p2,'\n');
	if(x>0) {
		T=FF.GetRangeByIdx(pp.p2+1,x);
		T=T.GetTrim();
		if((int)T>0) 	OutputStr+=FF.GetRangeByIdx(pp.p2+1,-1);
		else			OutputStr+=FF.GetRangeByIdx(x+1,-1);
	}
	OutputStr=GetAllUnExchgStr(OutputStr,ODQ.Exchg);
//printf("\n#OutputStr=[%s]",(char*)OutputStr);
	//--------------------------------------------------------------------
	FF=FF.GetRangeByIdx(pp.p1,pp.p2);
	MyStr S(FF.GetRangeWithWdChg('\t',' '));
	T=_DEQUKEY; T+=' ';
	p=S.InStr(T);
	if(p<0) return _err_name;			//error format :  #dequ+<space> or #dequ+<tab>
	//--------------------------------------------------------------------
	p+=(int)T;
	FF=FF.GetRangeByIdx(p,(int)FF-strlen(_DEQUBDYED)-1);
//	FF=FF.GetLineTrim();

	int k=FF.InStr(_DEQUBDYST);
	if(k<0) return _err_body;						//error format : '{{' missing

	MyStr PA;
	int q1=FF.InStr(-1,k-1,_DEQUPARST);
	int q2=FF.InStr(-1,k-1,_DEQUPARED);
	//--------------------------------------------------------------------
	if(q1>-1 && q2<0) 	return _err_para;			//error format : parameter > missing before {{
	if(q1<0  && q2>-1) 	return _err_para;			//error format : parameter < missing before {{
	if(q1>-1) { 
		S=FF.GetRangeByIdx(-1,q1-1); S=S.GetTrim();
		PA=FF.GetRangeByIdx(q1+1,q2-1);
	} else {
		S=FF.GetRangeByIdx(-1,k-1); S=S.GetTrim();
	}
	//--------------------------------------------------------------------
	DequCode r=IsWellName(S);
	if(r!=_well) return r;	//error format : NAME MUST w/i LowCase or exack chars
	ODQ.SetName(S);
	//--------------------------------------------------------------------
	if(IsExchgInStr(PA)>-1) return _err_para;			//error format : Parameters w/i Exchg contents
	//--------------------------------------------------------------------
	k+=strlen(_DEQUBDYST);
	ODQ.BDY=FF.GetRangeByIdx(k,-1);
	ODQ.BDY=GetAllUnExchgStr(ODQ.BDY,ODQ.Exchg);
	//ODQ.BDY=ODQ.BDY.GetTrim();
	//--------------------------------------------------------------------	
//printf("\n#PA=[%s]",(char*)PA);
//printf("->#BDY=[%s]",(char*)ODQ.BDY);
	if((int)PA>0) {
		PA+=","; k=0; q1=0;
		p=PA.InStr(k,",");
		while(p>-1) {
			q1++;
			if(p>0) {
				S=PA.GetRangeByIdx(k,p-1);
				S=S.GetTrim();
				if((int)S<1) S=q1;
			} else	S=q1;
			ODQ+=S;
			k=p+1;
			p=PA.InStr(k,",");
		}
	}
	//--------------------------------------------------------------------	
	pp=GetPointOfDequContents(ODQ.BDY);

	//ODQ.BDY=GetAllUnExchgStr(ODQ.BDY,ODQ.Exchg);
	//ODQ.BDY=ODQ.BDY.GetTrim();

	if(pp.p1<0 && pp.p2<0) return _well;
	if(pp.p1>-1 && pp.p2>pp.p1) return IsWellContents(ODQ.BDY);
	return _err_body;								//error format : bad #dequ inside
}

DequCode Dequ::Setup(MyStr &LL) {
	Dequ ODQ; MyStr OutS;
	DequCode rcode=ContentsToDequ(LL,OutS,ODQ);
	if(rcode==_well) { operator=(ODQ);  LL=OutS; }
	return rcode;
}

const char *Dequ::GetErrMessage(DequCode r){ return GetDequErrMessage(r); }

const char *Dequ::RemoveLineCmt(MyStr &LL) {
	MyStr LX(LL);
	//AddExchgLineCmtWithExSymBlk(LX,Exchg);
	AddExchgLineCmtWithExLineSymBlk(LX,Exchg);
	for(int n=0;n<Exchg.GetArrayCnt();n++) {
		MyStr T(Exchg[n].GetName());
		if(T.InStr("cl")>-1) LX=LX.GetRangeWithWdDel((char*)T);
	}
	TmpStr=LX;	return (char*)TmpStr;
}
const char *Dequ::RemoveSymChrCmt(MyStr &LL) {
	MyStr LX(LL);
	//AddExchgSymChrCmtWithExSymBlk(LX,Exchg);
	AddExchgSymChrCmtWithExLineSymBlk(LX,Exchg);
	for(int n=0;n<Exchg.GetArrayCnt();n++) {
		MyStr T(Exchg[n].GetName());
		if(T.InStr("cc")>-1) LX=LX.GetRangeWithWdDel((char*)T);
	}
	TmpStr=LX;	return (char*)TmpStr;
}
const char *Dequ::RemoveSymBlkS(MyStr &LL) {
	MyStr LX(LL);
	//AddExchgSymBlkS(LX,Exchg);
	AddExchgLineSymBlkS(LX,Exchg);
	for(int n=0;n<Exchg.GetArrayCnt();n++) {
		MyStr T(Exchg[n].GetName());
		if(T.InStr("sm")>-1) LX=LX.GetRangeWithWdDel((char*)T);
	}
	TmpStr=LX;	return (char*)TmpStr;
}
const char *Dequ::RemoveSymBlkU(MyStr &LL) {
	MyStr LX(LL);
	//AddExchgSymBlkU(LX,Exchg);
	AddExchgLineSymBlkU(LX,Exchg);
	for(int n=0;n<Exchg.GetArrayCnt();n++) {
		MyStr T(Exchg[n].GetName());
		if(T.InStr("um")>-1) LX=LX.GetRangeWithWdDel((char*)T);
	}
	TmpStr=LX;	return (char*)TmpStr;
}
const char *Dequ::RemoveSymBlk(MyStr &LL) {
	MyStr T(RemoveSymBlkS(LL));
	TmpStr=RemoveSymBlkU(LL);
	return (char*)TmpStr;
}
//####################################################################
//#		DEQU_DB
//####################################################################

const char *DEQU_DB::GetErrMessage(DequCode r){ return GetDequErrMessage(r); }

DEQU_DB::DEQU_DB(const char *dbfname) { 
	if(dbfname==NULL) 	DBfile="tmptmp.dequ";
	else				DBfile=dbfname;
	CNT=0; DBP=NULL; 
}
DEQU_DB::~DEQU_DB() { ReleaseDBP(); }

//===================================================
int DEQU_DB::GetCNT(void) {return CNT; }
const char* DEQU_DB::GetDBfile(void) {return (char*)DBfile; }
void DEQU_DB::SetDBfile(const char *dbfname) { DBfile=dbfname; }
//===================================================
void DEQU_DB::ReleaseDBP(void) {
	while(DBP!=NULL) {
		DQLINK *tp=DBP;
		DBP=DBP->nxt;
		delete tp;
		CNT--;
	}
}
//===================================================
DequCode DEQU_DB::Add(Dequ& DQ) {
//printf("\nDEQU_DB::Add('%s') BODY=[%s]",DQ.GetName(),DQ.GetBody());
//printf("PARN=%d Para='%s')\n",DQ.GetParaCnt(),DQ.GetParaList());
	MyStr T(DQ.GetName());
	//if(T=="") { printf("\n!!! Warning : request DEQU_DB.Add(NULL) !!!\n"); return 0; }
	if(T=="") return _err_name;
	
//printf("\nDEQU_Inside(%s)",(char*)T);
	T=DEQU_Inside(T);
//printf("=(%s)",(char*)T);
	//if(T==DQ.GetName()) { printf("\n!!! Error : reject one more DEQU_DB.Add(%s) !!!\n",(char*)T); return -1; }
	if(T==DQ.GetName()) return _err_name_overlap;
	
	CNT++;
	DQLINK *dp = new DQLINK;
	dp->SN=CNT;
	dp->NAME=DQ.GetName();
	dp->PARN=DQ.GetParaCnt();
	dp->nxt=NULL;
	if(DBP==NULL) DBP=dp;
	else {
		//******** FIFO *********		
		//DQLINK *tp=DBP;
		//while(tp->nxt!=NULL) tp=tp->nxt;
		//tp->nxt=dp;
		//******** LIFO *********
		dp->nxt=DBP;
		DBP=dp;
	}
	
	if(CNT==1) 	T="w";
    else 		T="a";
    
    FILE *fp=fopen((char*)DBfile,(char*)T);
	if(fp==NULL) return _err_dbfile;

	//---------------------------------------------
	//	File write new ODequ macro
	//---------------------------------------------
	int mxlen=DEQU_DB_MaxLineLen;
	MyStr B(DQ.GetBody());
	//================================================
	int n;	
	for(n=0;n<DBP->PARN;n++) {
		T=_DEQUBDYVPAST;
		T+=DQ[n];
		T+=_DEQUBDYVPAED;
		MyStr N(_DEQUBDYVPAST);
		N+=(n+1);
		N+=_DEQUBDYVPAED;
		B=B.GetRangeWithWdChg((char*)T,(char*)N);
	}
	//================================================
	B=B.GetRangeWithWdChg("\n","\\n");
//printf("\nName(%s),body[%s]",DQ.GetName(),(char*)B);
	int l=(int)B;
	n=0;
	while(l>mxlen) { n++; l-=mxlen;}
	if(l>0) n++;
	fprintf(fp,"_{%s}_(%d)_[%d]_<%s>_@%s@_$%d$_\n",(char*)DBP->NAME,DBP->PARN,n,DQ.GetParaList(),_dequFmtVer_,DBP->SN);
	for(l=1;l<n;l++) fprintf(fp,"%s\n",B.GetRangeByIdx((l-1)*mxlen,(l-1)*mxlen+mxlen-1));
	fprintf(fp,"%s\n",B.GetRangeByIdx((n-1)*mxlen,-1));
	//---------------------------------------------
	fclose(fp);
	//return CNT;
	return _well;
}
//===================================================
int DEQU_DB::GetDEQUSeqN(const char *dequname) {
	MyStr DQ(dequname);
	if(CNT>0 || (int)DQ>0) {
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			if(dp->NAME==DQ) return dp->SN;
			dp=dp->nxt;
		}
	}
	return -1;
}
//===================================================
int DEQU_DB::SearchDEQUparN(const char *dequname) {
	MyStr DQ(dequname);
	if(CNT>0 || (int)DQ>0) {
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			if(dp->NAME==DQ) return dp->PARN;
			dp=dp->nxt;
		}
	}
	return -1;
}
//===================================================
const char*  DEQU_DB::GetDEQUnameByDBIdx(const int si) {
	TMP="";
	if(CNT>0 && si>-1 && si<CNT) {
		int n=-1;
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			n++;
			if(n==si) { TMP=dp->NAME; break; }
			dp=dp->nxt;
		}
	}
	return (char*)TMP;
}
//===================================================
const char* DEQU_DB::DEQU_Inside(const char *line) {MyStr LL(line); return DEQU_Inside(LL); }
const char* DEQU_DB::DEQU_Inside(MyStr &LL) {
	TMP="";
	MyStr S(LL.GetLineDelByKeyExSymBlk(_DEQULCMT,"",_DEQUSYMS));
	int n=-1;
	int l=-1;
	
	if(CNT>0 || (int)S>0) {
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			int p=S.InStr((char*)dp->NAME);
			int x=(int)dp->NAME;
			if(p>-1) {
				if(n<0 || p<n || (p==n && x>l) ) { n=p; TMP=dp->NAME; l=x; }
			}
			dp=dp->nxt;
		}
	}
	return (char*)TMP;
}
//===================================================
const char *DEQU_DB::GetDEQUdefParaInDB(const char *dequname) {
	TMP="";
	int sq=GetDEQUSeqN(dequname);
	if(sq<1) return (char*)TMP;
	FILE *fp;
	char line[DEQU_DB_MaxLineLen+5];
	if((fp=fopen((char*)DBfile,"r"))==NULL) {
		printf("\n!!! Error : Open '%s' for read fail !!!\n",(char*)DBfile);
		return (char*)TMP;
	}
	MyStr DQ("_{");
	DQ+=dequname;
	DQ+="}_";
	while(1) {
		if(fgets(line,DEQU_DB_MaxLineLen+2,fp)==NULL) break;
		MyStr LL(line);
		int s=atoi(LL.GetRangeBtwKey("_$","$_"));
		if(LL.InStr((char*)DQ)>-1 && s==sq) { TMP=LL.GetRangeBtwKey("_<",">_"); break; }
	}
	fclose(fp);
	return (char*)TMP;
}
//===================================================
const char *DEQU_DB::GetDEQUbodyInDB(const char *dequname) {
	TMP="";
	int sq=GetDEQUSeqN(dequname);
//printf("\ndequname[%s],Seq[%d]",dequname,sq);
	if(sq<1) return (char*)TMP;
	FILE *fp;
	char line[DEQU_DB_MaxLineLen+5];
	if((fp=fopen((char*)DBfile,"r"))==NULL) {
		printf("\n!!! Error : Open '%s' for read fail !!!\n",(char*)DBfile);
		return (char*)TMP;
	}
	MyStr DQ("_{");
	DQ+=dequname;
	DQ+="}_";
	while(1) {
		if(fgets(line,DEQU_DB_MaxLineLen+2,fp)==NULL) { fclose(fp); break; }
		MyStr LL(line);
		int s=atoi(LL.GetRangeBtwKey("_$","$_"));
//printf("\nLL[%s],s[%d]",(char*)LL,s);
		if(LL.InStr((char*)DQ)>-1 && s==sq) {
//printf("\nline='%s'",line);
			int n=atoi(LL.GetRangeBtwKey("_[","]_"));
//printf(" => LL='%s' , n=%d",(char*)LL,n);
			LL="";
			for(int x=0;x<n;x++) {
				if(fgets(line,DEQU_DB_MaxLineLen+2,fp)==NULL) break;
//printf("\n>> line='%s'",line);
				LL+=line;
			}
			fclose(fp);
//printf("\n##>LL='%s'",(char*)LL);
			LL=LL.GetRangeWithWdDel('\n');
			TMP=LL.GetRangeWithWdChg("\\n","\n");
			break;
		}
	}
	return (char*)TMP;
}
//===================================================
const char *DEQU_DB::DEQU_xfer(const char *line) {
	MyStr BDY,LS,LE,PX;
	MyStr LL(line);
	
//printf("\n#>DEQU_xfer LL=[%s]<<line=[%s]",(char*)LL,line);

	ArrayNameStr ANS;
	//AddExchgLineCmtWithExSymBlk(LL,ANS);
	//AddExchgSymBlkS(LL,ANS);
	AddExchgLineCmtWithExLineSymBlk(LL,ANS);
	AddExchgLineSymBlkS(LL,ANS);
	
//printf("\n#>Exchged LL=[%s]",(char*)LL);
	MyStr NM(DEQU_Inside((char*)LL));
//printf("\n#>DEQU_xfer NM=[%s]",(char*)NM);

	MyStr SYMS(_DEQUSYMS);
//	MyStr SYMA(_DEQUSYMA);
	
	if(NM!="") {
		int c=SearchDEQUparN((char*)NM);
//printf("\n#>DEQU_xfer NM=[%s]",(char*)NM);

		//MyStr PA(PickupLineDequPara(LL,NM,SYMA,LS,LE));
		MyStr PA(PickupLineDequPara(LL,NM,SYMS,LS,LE));
		
		BDY=GetDEQUbodyInDB((char*)NM);
		BDY=BDY.GetTrim();
//printf("\n#>BDY=[%s]",(char*)BDY);
		//AddExchgLineCmtWithExSymBlk(BDY,ANS);
		//AddExchgSymBlkS(BDY,ANS);
		AddExchgLineCmtWithExLineSymBlk(BDY,ANS);
		AddExchgLineSymBlkS(BDY,ANS);
//printf("\n##>BDY=[%s]",(char*)BDY);
		if(PA!="") {
//printf("\n##>PA=[%s]",(char*)PA);
			MyStr PAC(PA.GetRangeWithSpDelExSymBlk(_DEQUSYMA));
			if(PAC!="") { 
				PA+=',';
				//int c=SearchDEQUparN((char*)NM);
				//int s=0;
				for(int a=0;a<c;a++) {
					PX=ParaAnalyze(PA,_DEQUSYMA);
//printf("\n##>PX[%d]=[%s]\n>>>PA=[%s]",a+1,(char*)PX,(char*)PA);
					PX=PX.GetLineTrimExSymBlk(_DEQUSYMA);
//printf(">>>PX=[%s]",(char*)PX);
					MyStr NX('$');
					NX+=(a+1);
					NX+='$';
					BDY=BDY.GetRangeWithWdChg((char*)NX,(char*)PX);
//printf("\n##>BDY=[%s]",(char*)BDY);
				}
			}
		}
//printf("\n###>LS 1 =[%s]",(char*)LS);
		LS+=BDY;
//printf("\n###>LS 2 =[%s]",(char*)LS);
		LS+=LE;
		
		LS=GetAllUnExchgStr(LS,ANS);
		
		LS=LS.GetDos2Unix();
//printf("\n###>LS 3 =[%s]",(char*)LS);
		return DEQU_xfer((const char*)LS);
	}
//printf("\n*>LL=[%s]",(char*)LL);

	NM=_DEQUSYMX;
	int n=(int)NM;
	if(n>0) {
		LS="";
		int k=0;
		PO2 PS=LL.SymBlkIdxInStr(k,-1,_DEQUSYMS);
//printf("\n**>k=%d PS.p1=%d PS.p2=%d",k,PS.p1,PS.p2);
		while(PS.p1>-1) {
			if(PS.p1>k) { LE=LL.GetRangeByIdx(k,PS.p1-1); LS+=LE.GetRangeWithDelBlkSymChr(-1,-1,_DEQUSYMX); }
			LE=LL.GetRangeByIdx(PS.p1,PS.p2);
			LS+=LE.GetRangeWithDelBlkSymChr(_DEQUSYMX);
			k=PS.p2+1;
			PS=LL.SymBlkIdxInStr(k,-1,_DEQUSYMS);
		}
		if(k<(int)LL) {
			LE=LL.GetRangeByIdx(k,-1);
//printf("\n***>LE=[%s]",(char*)LE);
			LS+=LE.GetRangeWithDelBlkSymChr(_DEQUSYMX);
//printf("\n***>LS=[%s]",(char*)LS);
		}
		PS=LS.SymBlkIdxInStr(-1,-1,_DEQUSYMX);
//printf("\n****>PS.p1=%d PS.p2=%d",PS.p1,PS.p2);
		
		LS=GetAllUnExchgStr(LS,ANS);
		
		if(PS.p1>-1) 	return DEQU_xfer((char*)LS);
	} else LS=GetAllUnExchgStr(LL,ANS);

//	TMP=LS.GetRangeWithDelSpLine();
	TMP=LS;
	
	return (char*)TMP;
}

//===================================================
const char *DEQU_DB::PickupLineDequPara(MyStr &LL,MyStr &DEQNM,MyStr &SYM,MyStr &LS,MyStr &LE) {
	LS="";
	LE="";
	MyStr T;
	int n=LL.InStrExSymBlk((char*)DEQNM,(char*)SYM);

//printf("\n**>DEQNM=[%s] n=%d LL=[%s]",(char*)DEQNM,n,(char*)LL);	
	if(n>-1) { 
		if(n>0) LS=LL.GetRangeByIdx(-1,n-1);
		int sp=n+(int)DEQNM;
	
		MyStr NM(_DEQUPARED);
		int lpaed=(int)NM;
		NM=_DEQUPARST;
		int lpast=(int)NM;
		
		int a=LL.InStrExSymBlk(sp,_DEQUPARST,(char*)SYM);
		NM=LL.GetRangeByIdx(sp,a-1);
		NM=NM.GetTrim();

		int b=sp;
		
//printf("\n**>sp=%d a=%d LS=[%s]",sp,a,(char*)LS);	
		if(a>-1 && (int)NM==0) { 
			sp=a+lpast;	
			int b=LL.InStrExSymBlk(sp,_DEQUPARED,(char*)SYM);
			int x=LL.InStrExSymBlk(sp,_DEQUPARST,(char*)SYM);
//printf("\n**>sp=%d b=%d x=%d",sp,b,x);	
			while(x>-1 && x<b) {
				sp=b+lpaed;
				b=LL.InStrExSymBlk(sp,_DEQUPARED,(char*)SYM);
				x=LL.InStrExSymBlk(sp,_DEQUPARST,(char*)SYM);
//printf("\n**>sp=%d b=%d x=%d",sp,b,x);	
			}
			if(b>0) {
				T=LL.GetRangeByIdx(a+lpast,b-1);
				sp=b+lpaed;
			}
		}
		LE=LL.GetRangeByIdx(sp,-1);
//printf("\n**>LE=[%s]",(char*)LE);	

	}
//printf("\n**>LS=[%s]",(char*)LS);	
//printf("\n**>T=[%s]",(char*)T);	
//printf("\n**>LE=[%s]",(char*)LE);	

	TMP=T;
    return (char*)TMP;
}
//===================================================
int DEQU_DB::AnalyzeParaCnt(MyStr &PA) {
//printf("\n*>AnalyzeParaCnt[%s]",(char*)PA);
	MyStr PX(_DEQUPARST);
	int l=(int)PX;
	PX=PA; ArrayNameStr ANS;
	AddExchgLineCmtWithExLineSymBlk(PX,ANS);
	//AddExchgLineSymBlkS(PX,ANS);
	AddExchgLineSymBlkA(PX,ANS);
	AddExchgSymChrCmtWithExLineSymBlk(PX,ANS);
	
	PX=GetRemoveAllExchgStr(PX,ANS);
	
//printf("\n*>PX[%s]",(char*)PX);
	MyStr SYM(_DEQUSYMS);
	MyStr NM(DEQU_Inside((char*)PX));
	while(NM!="") {
        MyStr LS,LE;
        MyStr PAX(PickupLineDequPara(PX,NM,SYM,LS,LE));
		PickupLineDequPara(PX,NM,SYM,LS,LE);
//printf("\n**>NM[%s],LS[%s],LE[%s],PAX[%s]",(char*)NM,(char*)LS,(char*)LE,(char*)PAX);
		PX=LS+LE;
		NM=DEQU_Inside((char*)PX);
	}
//printf("\n***>PX=[%s]",(char*)PX);
	int p=PX.InStr(_DEQUPARST);
	if(p>-1) PX=PX.GetRangeByIdx(p+l,-1);
	p=PX.InStr(_DEQUPARED);
	if(p>-1) { 
		if(p>0) PX=PX.GetRangeByIdx(-1,p-1); 
		else 	return 0; 
	}
	PX=PX.GetTrimA();
	if((int)PX<1) return 0;
	PX+=',';
//l=PX.WdCntInStr(',');
//printf("\n****>PX=[%s][%d]",(char*)PX,l);
	return PX.WdCntInStr(',');
}
//===================================================
const char *DEQU_DB::ParaAnalyze(MyStr &PA,const char *sym) { MyStr SYM(sym); return ParaAnalyze(PA,SYM); }
const char *DEQU_DB::ParaAnalyze(MyStr &PA,MyStr &SYM) {
	MyStr PX(_DEQUPARED);
	int lpaed=(int)PX;
	PX=_DEQUPARST;
	int lpast=(int)PX;
//printf("\n*>ParaAnalyze: PA=[%s],SYM=[%s]",(char*)PA,(char*)SYM);
	MyStr T;
	MyStr PAC(PA.GetRangeWithSpDelExSymBlk((char*)SYM));
	if(PAC!="") {
		int s=0;
		int p=PA.InStrExSymBlk(s,",",(char*)SYM);
		int x=PA.InStrExSymBlk(s,_DEQUPARST,(char*)SYM);
//printf("\n*> 1 s=%d p=%d x=%d",s,p,x);
		while(x>-1 && x<p) {
			s=x+lpast;
			int y=PA.InStrExSymBlk(s,-1,_DEQUPARED,(char*)SYM);
			int k=PA.InStrExSymBlk(s,y-1,_DEQUPARST,(char*)SYM);
//printf("\n*> 2 s=%d y=%d k=%d",s,y,k);
			while(y>-1) {
//printf("\n*> 3 s=%d y=%d k=%d",s,y,k);
				s=y+lpaed;
				if(k>-1) {
					y=PA.InStrExSymBlk(s,-1,_DEQUPARED,(char*)SYM);
					k=PA.InStrExSymBlk(s,y-1,_DEQUPARST,(char*)SYM);
				} else y=-1;
			}
			p=PA.InStrExSymBlk(s,",",(char*)SYM);
			x=PA.InStrExSymBlk(s,_DEQUPARST,(char*)SYM);
//printf("\n*> 4 s=%d p=%d",s,p);
		}
		if(p>0) T=PA.GetRangeByIdx(-1,p-1);  
//printf("\n*>T=[%s]",(char*)T);
		PA=PA.GetRangeByIdx(p+1,-1);
    }
    TMP=T;
    return (char*)TMP;
}

int DEQU_DB::DB_foutput(const char *filename) {
	
	MyStr FIL(filename);

	FILE *fp=fopen((char*)FIL,"w");
	if(fp==NULL) {
		printf("\n!!! Error : Open '%s' for write fail !!!\n",(char*)FIL);
		return -1;
	}
	
	if(DBP==NULL) { fclose(fp);  return 0; }
	
    MyStr T,PA,PX,BDY;
	int k , l=0;
	DQLINK *dp;
	DSLINK *ppa,*ppx;			

	//================ list ====================
	for(int n=0;n<CNT;n++) {
		T="";
		dp=DBP;
		while(dp!=NULL) {
			if(dp->SN==(n+1)) {
				T+=dp->NAME+_DEQUPARST;
				if(dp->PARN>0) T+=GetDEQUdefParaInDB((char*)dp->NAME);
				T+=_DEQUPARED;
				break;
			}
			dp=dp->nxt;
		}
		l++;
		fprintf(fp,"; %s\n",(char*)T);
	}

	//================= Declare & body =====================
	fprintf(fp,"\n");
				
	for(int n=0;n<CNT;n++) {		
		T=_DEQUKEY;
		T+=" ";
		dp=DBP;
		while(dp!=NULL) {
//printf("\n%s(%d) n=%d",(char*)dp->NAME,dp->SN,n);
			if(dp->SN==(n+1)) {
//printf("\n[%s]<",(char*)dp->NAME);
				ppa=NULL;
				T+=dp->NAME+_DEQUPARST;
				if(dp->PARN>0) {
					PA=GetDEQUdefParaInDB((char*)dp->NAME);
					T+=PA;
					//-----------------------------------
//printf("%s>",(char*)PA);
					PA+=",";
					k=0;
					int p=PA.InStr(k,',');
					while(p>-1) { 
						DSLINK *pd=new DSLINK;
						if(p>k) pd->data=PA.GetRangeByIdx(k,p-1);
						else	pd->data="";
						pd->nxt=NULL;
						if(ppa==NULL)  	ppa=pd;
						else			ppx->nxt=pd;
//printf(" %s",(char*)pd->data);
						ppx=pd;  k=p+1;
						p=PA.InStr(k,',');
					}
					//-----------------------------------
				}
//printf(">");
				T+=_DEQUPARED;
				break;
			}
			dp=dp->nxt;
		}
		//============================================

		T+=" ";
		T+=_DEQUBDYST;
		fprintf(fp,"%s",(char*)T);
		T=GetDEQUbodyInDB((char*)dp->NAME);

//printf("\n[%s]{{%s}}\n",(char*)dp->NAME,(char*)T);
		ppx=ppa; 
		k=1;
		while(ppx!=NULL) {
			PA="$"; PA+=k; PA+="$";
			PX="$"; PX+=ppx->data; PX+="$";
//printf("%d[%s]->[%s] ",k,(char*)PA,(char*)PX);
			T=T.GetRangeWithWdChg((char*)PA,(char*)PX);
			k++;
			ppx=ppx->nxt;
		}
		T+=_DEQUBDYED;
//printf("\n>>[%s]%s\n",(char*)dp->NAME,(char*)T);
		fprintf(fp,"%s\n",(char*)T);

		//============================================
		ReleaseDSLINK(&ppa);
	}
	
	fprintf(fp,"\n");
	
	fclose(fp);
	return l;
}
