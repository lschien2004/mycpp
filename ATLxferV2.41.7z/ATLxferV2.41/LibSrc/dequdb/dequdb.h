/*##############################################################################################
	v1.0@20191023	new dequ lib
	v1.1@20191024	+ enum DequCode
					WellFormatCheck return DequCode type
					Setup return DequCode type
					+GetErrMessage(DequCode)
	v1.5@20191030	Marge DEQU_DB
					_DEQUSYMS(?")->(") & _DEQUSYMU(?) for macro xferred symblk 
	v1.6@20191102	+ const char *Deuq::RemoveLineCmt(MyStr &)
					+ const char *Deuq::RemoveSymChrCmt(MyStr &)
					+ const char *Deuq::RemoveSymBlkS(MyStr &)
					+ const char *Deuq::RemoveSymBlkU(MyStr &)
					+ const char *Deuq::RemoveSymBlk(MyStr &)
					IsWellName modify
					 1) $ pair check
					 2) Need (one 'A'~'Z' + Special) if no 'a'~'z' chars
	v1.7@20191103   + GetErrDeuqMessage(DequCode)
					+ DEQU_DB::GetErrMessage(DequCode)
					int DEQU_DB::Add(..)->DequCode DEQU_DB::Add(..)
					+ Dequ::IsWellDyncContents for special Dync(Insided) #dequ macro name rule
					  >>Dync #dequ name MUST with $Para$ of Parent #dequ macro
					+ _err_dyncname ,_err_name_overlap ,_err_dbfile
					IsWellName remove $ pair check
					+ int Dequ::AnalyzeParaCnt(MyStr &PA)
					protected const char*Dequ::PickupLineDequPara(..) -> public
					protected const char*Dequ::ParaAnalyze(...) -> public
	v1.8@20191104	Modify PO2  Dequ::GetPointOfDequContents(MyStr &LL) -> support mask LineCmt & SymBlk
	v1.9@20191106	Modify Dequ::IsWellName :
					+ NM!=NM.GetTrimA() -> _err_name
					+ Add _DEQUKEY,_DEQUPARST,_DEQUPARED,_DEQUBDYST,_DEQUBDYED inside as _err_namerule
					+ Add %IFE %IFN EQUATE inside as _err_namerule
					+ Add #*** = Hex String -> _err_namerule
	v2.0@20191107	Fix DEQU_DB::AnalyzeParaCnt(..) for parameter using #dequ macro problem
	v2.1@20191108	+ void AddExchgWithSymlst(MyStr &LL,ArrayNameStr &Exchg,const char *symlst)
					+ void AddExchgSymBlkA(MyStr &LL,ArrayNameStr &Exchg)
					+ void AddExchgWithLineSymlst(MyStr &LL,ArrayNameStr &Exchg,const char *symlst)
					+ void AddExchgLineSymBlkA(MyStr &LL,ArrayNameStr &Exchg)
					+ const char *GetRemoveExchgStrByExkey(MyStr &LL,ArrayNameStr &Exchg,const char *Exkey)
					+ const char *GetRemoveAllExchgStr(MyStr &LL,ArrayNameStr &Exchg)
					Fix DEQU_DB::AnalyzeParaCnt(..) Sym('`) missing problem
	v2.12@20191111 	+ void AddExchgLineMessage(MyStr &LL,ArrayNameStr &Exchg)
	v2.2@20191112 	+ Exchange code definiton
	v2.3@20191114 	Fix AddExchgLineSymBlkX , AddExchgLineSymBlkA typo bug
					DEQU_DB::PickupLineDequPara(..) remove input parameter SYM
	v2.4@20191118 	DEQU_DB::DEQU_Inside skip the contents of insided #dequ to avoid insided #dequ name xfer
	v2.5@20191121	Extend DEQU_DB_MaxLineLen 128->256 for long #dequ line missing issue
	v2.6@20191121	1) DEQU_DB::DEQU_Inside remove AddExchgLineMessage for message content xfer
					2) Excluding [#dequ~{{] in AddExchgSymChrCmtWithExSymBlk & AddExchgSymChrCmtWithExLineSymBlk 
					for #dequ name to use @
					3) _DEQUNAME_exack_chars add '@'
	v2.7@20191122	+ _DEQUXLCMT -> "//"
					+ void AddExchgLineXCmtWithExSymBlk(MyStr &LL,ArrayNameStr &Exchg)
					+ const char *GetRemoveLineXCmtWithExSymBlkU(MyStr &LL)
	v2.8@20191122	+ DQLINK.CAT for Static(=0),Dync(=1)
	                DequCode::Add(Dequ& DQ) => DequCode::Add(Dequ& DQ,int Cat=0)
	                DEQU_DB::DB_foutput(const char *filename) => DEQU_DB::DB_foutput(const char *filename,const int Cat=0)
	                + int DEQU_DB::SetDEQUCAT(const char *dequname,const int Cat);
	                + int DEQU_DB::GetDEQUCAT(const char *dequname);
################################################################################################*/
#ifndef __DequDB__h__
    #define __DequDB__h__
    #define __DequDBVer__	"DequDB-v2.8@20191122"

    #define _dequFmtVer_	"V1.4"

#include "mystr.h"
#include "namestr.h"
#include "arraystr.h"
#include "arraynamestr.h"
#include "namearraystr.h"
#include "fileobj.h"


#ifndef __DequDef__
    #define __DequDef__ 4

 #define _DEQUKEY    		"#dequ"
 #define _DEQUPARST  		'<'
 #define _DEQUPARED  		'>'
 #define _DEQUBDYST  		"{{"
 #define _DEQUBDYED  		"}}"
 #define _DEQUSYMS   		"\""			// SymS+data+SymS willn't be xferred.
 #define _DEQUSYMU   		"?"				// SymU+data+SymU will be xferred.
 #define _DEQUSYMX   		"'`" 			// SymX+data+SymX->parameter xfer->data->data will be xferred .
 #define _DEQUSYMA   		"?\"'`" 		// SYMS+SYMU+SYMX
 #define _DEQULCMT   		';'
 #define _DEQUCMTC   		'@'
 #define _DEQUBDYVPAST 		'$'
 #define _DEQUBDYVPAED 		'$'
 
 #define _DEQUXLCMT   		"//"			// Un-xferred line comment
 
 #define _DEQUMSGKEY		"%MESSAGE"
 
 #define _DEQUNAME_exack_chars "-_+#~!@"


enum DequCode{_well=0,_none,_err_name,_err_dyncname,_err_namerule,_err_name_overlap,_err_para,_err_body,_err_dbfile};

#endif //#ifndef __DequDef__

//*******************************************************
//	Exchange code definition
//******************************************************
#ifndef _DEQU_ExKeyS
    #define _DEQU_ExKeyS ".~"
    #define _DEQU_ExKeyE "~."
    
    #define _DEQU_EC_XLineCmt	"xl"
    #define _DEQU_EC_LineCmt	"cl"
    #define _DEQU_EC_CmtChar	"cc"
    #define _DEQU_EC_SymBlkS	"ss"
    #define _DEQU_EC_SymBlkU	"su"
    #define _DEQU_EC_SymBlkX	"sx"
    #define _DEQU_EC_Message	"ml"
    
    #define _DEQU_EC_SymBlkChar 's'
#endif

//*******************************************************

//***********************************************
//		DEQU_DB used struct & function
//***********************************************
#define DEQU_DB_MaxLineLen    256

typedef struct dslink {
	MyStr data;
	dslink *nxt;
} DSLINK;

typedef struct dqlink {
	int CAT;
	int SN;
	int PARN;
	MyStr NAME;
	dqlink *nxt;
} DQLINK;

void ReleaseDSLINK(DSLINK **p);
//***********************************************
void AddExchgLineMessage(MyStr &LL,ArrayNameStr &Exchg);

void AddExchgLineXCmtWithExSymBlk(MyStr &LL,ArrayNameStr &Exchg);

void AddExchgLineCmtWithExSymBlk(MyStr &LL,ArrayNameStr &Exchg);
void AddExchgLineCmtWithExLineSymBlk(MyStr &LL,ArrayNameStr &Exchg);

void AddExchgSymChrCmtWithExSymBlk(MyStr &LL,ArrayNameStr &Exchg);
void AddExchgSymChrCmtWithExLineSymBlk(MyStr &LL,ArrayNameStr &Exchg);

void AddExchgWithSymlst(MyStr &LL,ArrayNameStr &Exchg,const char *symlst,const char *excode); 
void AddExchgSymBlk(MyStr &LL,ArrayNameStr &Exchg);
void AddExchgSymBlkS(MyStr &LL,ArrayNameStr &Exchg);
void AddExchgSymBlkU(MyStr &LL,ArrayNameStr &Exchg);
void AddExchgSymBlkX(MyStr &LL,ArrayNameStr &Exchg);
void AddExchgSymBlkA(MyStr &LL,ArrayNameStr &Exchg);

void AddExchgWithLineSymlst(MyStr &LL,ArrayNameStr &Exchg,const char *symlst,const char *excode); 
void AddExchgLineSymBlk(MyStr &LL,ArrayNameStr &Exchg);
void AddExchgLineSymBlkS(MyStr &LL,ArrayNameStr &Exchg);
void AddExchgLineSymBlkU(MyStr &LL,ArrayNameStr &Exchg);
void AddExchgLineSymBlkX(MyStr &LL,ArrayNameStr &Exchg);
void AddExchgLineSymBlkA(MyStr &LL,ArrayNameStr &Exchg);

const char *GetUnExchgStrByExkey(MyStr &LL,ArrayNameStr &Exchg,const char *Exkey);
const char *GetRemoveExchgStrByExkey(MyStr &LL,ArrayNameStr &Exchg,const char *Exkey);

const char *GetLineCmtUnExchgStr(MyStr &LL,ArrayNameStr &Exchg);
const char *GetSymChrCmtUnExchgStr(MyStr &LL,ArrayNameStr &Exchg);

const char *GetSymBlkUnExchgStr(MyStr &LL,ArrayNameStr &Exchg);
const char *GetSymBlkSUnExchgStr(MyStr &LL,ArrayNameStr &Exchg);
const char *GetSymBlkUUnExchgStr(MyStr &LL,ArrayNameStr &Exchg);
const char *GetSymBlkXUnExchgStr(MyStr &LL,ArrayNameStr &Exchg);
const char *GetSymBlkAUnExchgStr(MyStr &LL,ArrayNameStr &Exchg);

const char *GetAllUnExchgStr(MyStr &LL,ArrayNameStr &Exchg);
const char *GetRemoveAllExchgStr(MyStr &LL,ArrayNameStr &Exchg);
const char *GetRemoveLineXCmtWithExSymBlkU(MyStr &LL);

int CheckExkeyInside(MyStr &LL,const char *exkey);

const char *GetDequErrMessage(DequCode r);

class SDequ : public NameArrayStr {
protected:
//	 NameArrayStr	NAS;
	 MyStr		    BDY;
public:
virtual void Reset(void);
virtual SDequ& operator=(SDequ&);
};


class Dequ : public  SDequ {
private:
	 MyStr		 tmp;

protected:
	 ArrayNameStr	Exchg;

public:
			Dequ();
			Dequ(Dequ &DQ);
			
	 	   void 	Reset(void);

	        int 	GetParaCnt(void);
	 const char 	*GetParaList(void);
	 const char 	*GetBody(void);
	 
	 	    PO2 	GetPointOfDequContents(MyStr &LL);
	 
	   DequCode 	IsWellName(MyStr &NM);
	   DequCode 	IsWellContents(MyStr &LL);
	   
	   DequCode 	IsWellDyncContents(MyStr &LL,MyStr &PPA);
	   
	   DequCode 	ContentsToDequ(MyStr &InputStr,MyStr &OutputStr,Dequ &ODQ);
	 
	 
	        int 	IsExchgInStr(MyStr &LL);
	   DequCode 	Setup(MyStr &LL);

	       void 	ExchgAddLineCmt(MyStr &LL);
	       void 	ExchgAddSymChrCmt(MyStr &LL);
	       void 	ExchgAddSymBlk(MyStr &LL);

	 const char     *RemoveLineCmt(MyStr &LL);
	 const char     *RemoveSymChrCmt(MyStr &LL);
	 const char     *RemoveSymBlkS(MyStr &LL);
	 const char     *RemoveSymBlkU(MyStr &LL);
	 const char     *RemoveSymBlk(MyStr &LL);

	 const char 	*GetUnExchgAll(MyStr &LL);
	 
	 const char 	*GetErrMessage(DequCode r);
	 
virtual Dequ& operator=(Dequ&);

};

class DEQU_DB {
private:
	 int 			CNT;
	 MyStr			DBfile;
	 DQLINK			*DBP;
	 MyStr			TMP;
protected:
	 void			ReleaseDBP(void);
public:
	 const char*	ParaAnalyze(MyStr &PA,const char *sym);
	 const char*	ParaAnalyze(MyStr &PA,MyStr &SYM);
	 const char *	PickupLineDequPara(MyStr &LL,MyStr &DEQNM,MyStr &LS,MyStr &LE);

	 void 			SetDBfile(const char *dbfname);
	 const char* 	GetDBfile(void);
	 int			GetCNT(void);
	 
	 int 			GetDEQUSeqN(const char *dequname);
	 
	 int			SetDEQUCAT(const char *dequname,const int Cat);
	 int			GetDEQUCAT(const char *dequname);
	 
	 DequCode		Add(Dequ& DQ,const int Cat=0);

	 const char*	DEQU_Inside(MyStr &LL);
	 const char*	DEQU_Inside(const char *line);
	 
	 int 			SearchDEQUparN(const char *dequname);
	 const char*	GetDEQUdefParaInDB(const char *dequname);
	 const char*	GetDEQUbodyInDB(const char *dequname);
	 const char*	GetDEQUnameByDBIdx(const int si);

	 int			AnalyzeParaCnt(MyStr &PA);
	 
	 const char*	DEQU_xfer(const char *line);
	 
	 int			DB_foutput(const char *filename,const int Cat=0);

					DEQU_DB(const char *dbfname=NULL);
					~DEQU_DB();
					
	 const char 	*GetErrMessage(DequCode r);
};

#endif //#ifndef __DequDB__h__
