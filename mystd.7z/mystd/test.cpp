#include "mystr.h"
#include "namestr.h"
#include "mystd.h"

int main(int ac,char **av)
{
	namestr NS("NameStyr","Yes");
	MyStr S("Hello world");
	tout out;
	out << "\n"
	<< S
	<< "! "
	<< 123
	<<" "<< NS;
    return 0;
}

