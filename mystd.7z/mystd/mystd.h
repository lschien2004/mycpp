#include "mystr.h"
#include "namestr.h"
#include <iostream>

#ifndef __MyStd_H__
 #define __MyStd_H__
 #define __MyStdVer__	"MyStd-v1.0@20191020"
 
//namespace mystd {

class tout {
  public:
//  	void printf(const char *format);
//  	template<typename T0, typename... Targs0> void printf(const char* format, T0 value, Targs0... Fargs);
  	tout& operator<<(const int i);
  	tout& operator<<(const long l);
  	tout& operator<<(const char *s);
  	tout& operator<<(const char c);
  	tout& operator<<(MyStr &S);
  	tout& operator<<(namestr &NS);
 };

//} //namespace mystd

#endif
