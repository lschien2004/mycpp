#ifndef __DequDB_H__
#define __DequDB_H__

#include "mystr.h"
#include "strlink.h"
#include <unistd.h>

#define _DequDB_Ver_	"V1.3"

#define DEQUKEY    		"#dequ"
#define DEQUPARST  		'<'
#define DEQUPARED  		'>'
#define DEQUBDYST  		"{{"
#define DEQUBDYED  		"}}"
#define DEQUSYMS   		"?\""			// Parameter , body : SymS+data+SymS <- ���B�z
#define DEQUSYMX   		"'`" 			// Xfer�ɳB�z Parameter : SymX+data+SymX <- data ���B�z,SymX�h���ᵹBody�Axfer.
#define DEQULCMT   		';'
#define DEQUCMTC   		'@'
#define DEQUBDYVPAST 	'$'
#define DEQUBDYVPAED 	'$'

#define DequDB_MaxLineLen    128

class DequDB {
private:
	 int 			CNT;
	 MyStr			DBfile;
	 StrLink		DBP;
	 MyStr			TMP;
protected:
	 void			ReleaseDBP(void);
	 const char*	ParaAnalyze(MyStr &PA,MyStr &SYM);
	 const char *	PickupLineDequPara(MyStr &LL,MyStr &DEQNM,MyStr &SYM,MyStr &LS,MyStr &LE);
public:
	 const char* 	GetDBfile(void);
	 int			GetCNT(void);
	 
	 int 			GetDEQUSeqN(const char *dequname);
	 int 			Add(DEQU& DD);
	 const char*	DEQU_Inside(const char *line);
	 int 			SearchDEQUparN(const char *dequname);
	 const char*	GetDEQUdefParaInDB(const char *dequname);
	 const char*	GetDEQUbodyInDB(const char *dequname);
	 const char*	GetDEQUnameByDBIdx(const int si);

	 const char*	DEQU_xfer(const char *line);
	 
	 int			DB_foutput(const char *filename);

					DEQU_DB(const char *dbfname);
					DEQU_DB(const char *dbfname,DEQU& DD);
					~DEQU_DB();
};

#endif
