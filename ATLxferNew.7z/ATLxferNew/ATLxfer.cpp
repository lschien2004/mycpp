/* ###################################################################################################
	Ver.1.1   : (1) Xfer�� parameter TrimR+TrimL (except DEQUSYMS+DEQUSYMX)
	Ver.1.1   : (2) Xfer�� parameter �� SymX+data+SymX�� data ���B�z, ��SymX�h���ᵹBody�Axfer.(Symx='%)
	Ver.1.1   : (3) Xfer�O�d @x comment
	Ver.1.1   : (4) output file ��X ;@> + xfer�e�쫬 .
	Ver.1.1   : (5) Xfer��parameter �i�H��J dequ ���� ex. Titem<10,"FUNC 1",ClearArray<FDUT>,FUNSUB>
	
	Ver.1.2   : (1) Xfer��Parameter�ϥ� macro1<,macro2<>> �_����J���D�ѨM
	Ver.1.2   : (2) Xfer��Parameter�ϥΪ�macro�L�Ѽƥi�٥h<>. (FunPon<>��i�H��FunPon) 
	Ver.1.2   : (3) DEQU_DB v1.2 DEQU add �� FIFO �令 LIFO & DEQU body�a�JSeqN search,�᭱�P�W macro�u��.
	Ver.1.2   : (4) Xfer��Parameter�ϥ� SymX �_���p 'pon<TIM1,3MS,`IN1,IN2`>' ���D�ѨM
	Ver.1.2   : (5) output DEQU macro DB file �令 macro�쫬��X-> ODIR\m+ifile
	
	Ver.1.3   : (1) Fix Macro name including the other short macro name issue
	Ver.1.3   : (2) accept non-parameter macro definition without <> 
  ################################################################################################### */

#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>    //printf
#include <stdlib.h>   //malloc
#include <string.h>   //strncpy
#include <unistd.h>   //close
#include <iostream>
#include <ctime>

#define _DOS_

#include "mystr.h"
#include "dequ.h"

#define __PgmVer__ "Ver.1.3@2019-10-12"
#define __Author__ "L.S Chien"

#ifdef _DOS_
	#define __SYS__ "DOS"
    #define SymPath  '\\'
#else
	#define __SYS__ "UNIX"
    #define SymPath  '/'
#endif

#define FileInsertStatement "INSERT"

#define StrMaxLen 256

using namespace std;

void usage(char *pgmname)
{
	cout << endl;
	cout << "##################################################################" << endl;
	cout << "   [[[   ATL Pre-Compiler "<<__SYS__<<" "<< __PgmVer__<<" By "<<__Author__<< "   ]]]" << endl;
	cout << "==================================================================" << endl;
	cout << "     This tool is used to covert the source files which writed with " << endl;
	cout << DEQUKEY <<" macro to a .asc file for ADV tester's compiler ." << endl << endl;
	cout << " Usage : " << pgmname << "  main_src_file  [output_path]" << endl;
	cout << "       >> w/o output_path input -> output in current path ." << endl << endl;
	cout << "    Ex : " << pgmname << " wtmain.src ASCDIR" << endl;
	cout << "       >> Transfer wtmain.src to ASCDIR" << SymPath << "wtmain.asc" << endl;
	cout << "    Ex : " << pgmname << " .."<< SymPath <<"wtmain.src" << endl;
	cout << "       >> Transfer .." << SymPath << "wtmain.src to ." << SymPath << "wtmain.asc" << endl<< endl;
	cout << " Note :"<< endl;
	cout << "     1) All of inserted files must be lower-case file name !" << endl;
	cout << "     2) main_src_file and all of inserted files must be stored in"<<endl;
	cout << "        the same path !" << endl;
	cout << "     3) All of inserted files' att_name must as same as the att_name" << endl;
	cout << "        of main_src_file !" << endl;
	cout << "        Ex: main_src_file is main.s , the insertd files must be *.s" << endl;
	cout << "     4) If main_src_file's att_name is .asc and output_path is same" << endl;
	cout << "        as main_src_file's path, then output file's att_name will" << endl;
	cout << "        change to be .asc2 " << endl;
	 printf("==================================================================\n");
	 printf("  Regarding %s marco :\n",DEQUKEY);
	 printf("     1) If %s macro are re-defined, the last loaded macro\n",DEQUKEY);
	 printf("        before transfer will dominate !\n");
	 printf("     2) Name of %s macro must exist at the least one lower-case\n",DEQUKEY);
	 printf("        char .\n");
	 printf("##################################################################\n");
}

bool CheckDeclareStatmentInside(const char *line) {
	MyStr LL(line);
	LL=LL.GetDos2Unix();
	LL=LL.GetRangeWithDelBtwKeyExSymBlk(";","\n","\"?");
	LL=LL.GetRangeWithWdChgExSymBlk(";\n","\n","\"?");
	LL=LL.GetLineWithCmtChrDelNExSymBlk('@',1,"\"?");	
	LL=LL.GetLineTrim();
	LL=LL.GetRangeWithWdCmpressExSymBlk("\n","\"?");
	
	LL=LL.GetRangeWithSpDelExSymBlk("\"?");
	
	if(LL.InStr(DEQUKEY)==0) return true;
	if(LL.InStr("EQUAT")==0) return true;
	if(LL.InStr("DMACRO")==0) return true;
	if(LL.InStr("SDEF")==0) return true;
	if(LL.InStr("MODULE")==0) return true;
	return false;
}

void PickupInsertFileName(MyStr &LL,const char *line) {
	LL=line;
	LL=LL.GetRangeWithWdChg('\t',' ');
	LL=LL.GetRangeWithDelByKey(DEQULCMT,'\n');
	LL=LL.GetLineWithCmtChrDelN('@',1);
	LL=LL.GetRangeBtwKey(FileInsertStatement,"");
	LL=LL.GetRangeWithWdDel('\n');
	LL=LL.GetLineTrimA();
	LL=LL.GetLowerCase();
}

int FileXfer(DEQU_DB &QDB,MyStr &IDIR,MyStr &ifile,MyStr &iatt,FILE *ofp,int &state,MyStr &FF,int &LFn) {
	
	char line[StrMaxLen];
	FILE *ifp;

	sprintf(line,"%s%s",(char*)IDIR,(char*)ifile);	
	if((ifp=fopen(line,"r"))==NULL) {
		cout << endl << "\n Error ! Open '" << line << "' for read fail !\n" << endl;
		return -1;
	}
	
	MyStr SYMA(DEQUSYMS);
	SYMA+=DEQUSYMX;
	
	long llnn=0;
	MyStr ErrMsg;
	MyStr LL,X,T,LX;
	DEQU QQ;
	
	while(1) {
		if(fgets(line,StrMaxLen-1,ifp)==NULL) break;
		llnn++;
		LL=line;
		LL=LL.GetDos2Unix();
		LX=LL.GetLineDelByKey(DEQULCMT,'\n');
		if(state<1) {
			//************************************
			//*	Not during DEQU load
			//************************************
			//if(LL.InStr(DEQUKEY)>-1) {
			if(LX.InStr(DEQUKEY)>-1) {
				//***  DEQU definition detect ****
				state++; FF=LL;
				if(LL.InStr(DEQUBDYED)>-1) {
					//***  one line finish ***
					state=0;
					QQ=FF;
					QDB.Add(QQ);
				}
			} else {
			    //if(LL.InStr(FileInsertStatement)<0) {
				if(LX.InStr(FileInsertStatement)<0) {
					T=QDB.DEQU_Inside((char*)LL);
					if(T!="") {
						fprintf(ofp,";@>%s",(char*)LL);
						T=QDB.DEQU_xfer((char*)LL);
						//T=T.GetLineTrimRExSymBlk((char*)SYMA);
						T=T.GetRangeWithWdCmpressExSymBlk('\n',(char*)SYMA);
						//T=T.GetRangeWithSpCmpressExSymBlk((char*)SYMA);
						LL=T;
					}
					//-----------------------------------------
					T=LL.GetTrimA();
					if(T=="") {
						if(++LFn>1) { LFn=1; continue; }
					} else if(--LFn<0) LFn=0;
					//-----------------------------------------
					fprintf(ofp,"%s",(char*)LL);
				} else {
					//***	Insert statement detect  ***
					PickupInsertFileName(X,(char*)LL);
					X+=iatt;
					fprintf(ofp,";;;; insert(%s)\n",(char*)X);
					if(FileXfer(QDB,IDIR,X,iatt,ofp,state,FF,LFn)<0) {
						sprintf(line,"\n Error ! file'%s'@line(%d)->%s , stop !\n",(const char*)ifile,llnn,(char*)LL);
						ErrMsg=line; break; 
					}
				}
			}
		} else {
			//************************************
			//*	During DEQU load
			//************************************
			//if(LL.InStr(FileInsertStatement)<0) {
			if(LX.InStr(FileInsertStatement)<0) {
				if(LL.InStr(DEQUBDYED)<0) {
					state++;
					if(state>1000 || CheckDeclareStatmentInside((char*)LL)) {
						sprintf(line,"\n Error ! file'%s'@line(%d)->%s macro ending '}}' missing ,stop !\n",(const char*)ifile,llnn,DEQUKEY);
						ErrMsg=line; break; 
					}
					FF+=LL;
				} else {
					FF+=LL;
					state=0;
					QQ=FF;
					QDB.Add(QQ);
				}
			} else {
				//***	Insert statement detect  ***
				PickupInsertFileName(X,(char*)LL);
				X+=iatt;
				fprintf(ofp,";;;; insert(%s)\n",(char*)X);
				if(FileXfer(QDB,IDIR,X,iatt,ofp,state,FF,LFn)<0) {
						sprintf(line,"\n Error ! file'%s'@line(%d)->%s , stop !\n",(const char*)ifile,llnn,(char*)LL);
						ErrMsg=line; break; 
				}
			}
		}
	}
	fclose(ifp);
	
	if((int)ErrMsg>0) { 
		cout << (char*) ErrMsg;
		fprintf(ofp,"%s",(char*)ErrMsg);
		return -1;
	}
	return 0;
}

int main (int ac , char ** av )
{
	if(ac<2 || ac>3) { usage(av[0]); exit(-1); }

	time_t now = time(0);
	tm *lt = localtime(&now);
	MyStr DateTime;
	DateTime=(1900+lt->tm_year);
	DateTime+="/";
	DateTime+=(1+lt->tm_mon);
	DateTime+="/";
	DateTime+=(lt->tm_mday);
	DateTime+=" ";
	DateTime+=(1+lt->tm_hour);
	DateTime+=":";
	DateTime+=(1+lt->tm_min);
	DateTime+=":";
	DateTime+=(1+lt->tm_sec);
		
	char line[StrMaxLen];	
	MyStr ifile,ofile;
	MyStr iatt,oatt;
	MyStr IDIR(av[1]);
	MyStr ODIR('.');
	
	int n=IDIR.InStrRev(SymPath);
	if(n<0) { ifile=IDIR; IDIR='.'; IDIR+=SymPath; }
	else	{ ifile=IDIR.GetRangeByIdx(n+1,-1); IDIR=IDIR.GetRangeByIdx(-1,n); }
	
	n=ifile.InStrRev('.');
	if(n>-1) iatt=ifile.GetRangeByIdx(n,-1);
	ofile=ifile.GetRangeByIdx(-1,n);
	if(n<0) ofile+=".asc"; else ofile+="asc";

	if(ac>2) ODIR=av[2];
	n=ODIR.InStrRev(SymPath);
	if((int)ODIR!=n+1) ODIR+=SymPath;

	if(ifile==ofile && IDIR==ODIR) ofile+="2";
	
	printf("\n## Transfer '%s%s' with INSERTed *%s to '%s%s' ##",(char*)IDIR,(char*)ifile,(char*)iatt,(char*)ODIR,(char*)ofile);

	sprintf(line,"%s%s.dequ",(char*)ODIR,(char*)ifile);
	DEQU_DB QDB(line);

	sprintf(line,"%s%s",(char*)ODIR,(char*)ofile);

	FILE *ofp;

	if((ofp=fopen(line,"w"))==NULL) {
		cout << endl << "\n Error ! Open '" << (char*)line << "' for write fail !\n" << endl;
		exit(1);
	}

	fprintf(ofp,";This file converted from %s %s by %s %s_%s\n",(char*)ifile,(char*)DateTime,av[0],__SYS__,__PgmVer__);

	int state=0;
	int LFn=0;
	MyStr DEQBUF;
	LFn=FileXfer(QDB,IDIR,ifile,iatt,ofp,state,DEQBUF,LFn);
	fclose(ofp);
	
	if(LFn==0) 	printf("\n>> Transfer to '%s' complete !",line);

	sprintf(line,"%s%s.s",(char*)ODIR,(char*)ifile);
	QDB.DB_foutput(line);
	printf("\n>> Generated macro DB file '%s'\n",line);
	
	if(access(QDB.GetDBfile(),F_OK)==0) {
		sprintf(line,"rm %s",QDB.GetDBfile());
	    system(line);
	}

    exit(0);
}
