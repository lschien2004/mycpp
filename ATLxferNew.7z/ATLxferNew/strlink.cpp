#include "strlink.h"

static MyStr StrLinkTmp;

//******************************************************************************************
StrLink *StrLink::GetNode(MyStr &NM) {
	if((int)NM>0) {
		StrLink *cp=this;
		while(cp!=NULL) {
			if(cp->name!=NULL) {
				if(NM==*(cp->name)) return cp;
			}
			cp=cp->nxt;
		}
	}
	return NULL;
}
StrLink *StrLink::GetNode(const int sno) {
	if(sno>-1) {
		StrLink *cp=this;
		while(cp!=NULL) {
			if(sno==cp->sn) return cp;
			cp=cp->nxt;
		}
	}
	return NULL;
}
//******************************************************************************************
int	 StrLink::SetupName(StrLink *cp,const char *nm) {MyStr D(nm); return SetupName(cp,D);}
int	 StrLink::SetupName(StrLink *cp,MyStr &D) {
	int len=-1;
	if(cp!=NULL) {
		MyStr *p=cp->name;
		if(p!=NULL) { delete p; p=NULL; }
		if((int)D>0) { p=new MyStr(D); len=(int)(*p); }
		cp->name=p;
	}
	return len;
}
int	 StrLink::SetupData(StrLink *cp,const char *dat) {MyStr D(dat); return SetupData(cp,D);}
int	 StrLink::SetupData(StrLink *cp,MyStr &D) {
	int len=-1;
	if(cp!=NULL) {
		MyStr *p=cp->data;
		if(p!=NULL) { delete p; p=NULL; }
		if((int)D>0) { p=new MyStr(D); len=(int)(*p); }
		cp->data=p;
	}
	return len;
}
int	 StrLink::SetupExData(StrLink *cp,const char *exdat) {MyStr D(exdat); return SetupExData(cp,D);}
int	 StrLink::SetupExData(StrLink *cp,MyStr &D) {
	int len=-1;
	if(cp!=NULL) {
		MyStr *p=cp->extdata;
		if(p!=NULL) { delete p; p=NULL; }
		if((int)D>0) { p=new MyStr(D); len=(int)(*p); }
		cp->extdata=p;
	}
	return len;
}
//******************************************************************************************
int StrLink::Setup(StrLink *pp,StrLink *cp,const int sno,MyStr &NM,MyStr &DAT,MyStr &EXDAT,const int r,const int v) {
//printf("\nSetup(pp=%u,cp=%u,sno=%d,NM=%u,v=%d,DAT=%u,EXDAT=%u)",pp,cp,sno,nm,v,dat,exdat);
	if(cp!=NULL) {
		cp->sn=sno; cp->irec=r; cp->ival=v;
		if(SetupName(cp,NM)<0) 	{ SetupData(cp,NULL); 	SetupExData(cp,NULL); }
		else 					{ SetupData(cp,DAT); 	SetupExData(cp,EXDAT); }
		if(pp!=NULL) pp->nxt=cp;
		cp->pre=pp;
		cp->nxt=NULL;
		return cp->sn;
	}
	return -1;
}
//******************************************************************************************
int StrLink::Release(StrLink *cp) {
printf("\nStrLink::Release cp=%u",cp);
	int n=0;
	if(cp!=NULL) { 
		if(cp->pre!=NULL) cp->pre->nxt=NULL;
		StrLink *t=cp;
		while(t!=NULL) { 
			StrLink *p=t;
			t=t->nxt;
printf("->delete[%d] p=%u , nxt->t=%u",n,p,t);
			SetupName(p,NULL); SetupData(p,NULL); SetupExData(p,NULL); 
			free(p);
			n++;
		}
	}
printf(" , return %d",n);
	return n;
}
//******************************************************************************************
StrLink::StrLink(const char *nm,const char *dat,const char *exdat,const int r,const int v){
	MyStr NM(nm); MyStr DAT(dat); MyStr EXDAT(exdat);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(const char *nm,const char dc,const char *exdat,const int r,const int v){
	MyStr NM(nm); MyStr DAT(dc); MyStr EXDAT(exdat);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(const char *nm,const char dc,const char exdc,const int r,const int v){
	MyStr NM(nm); MyStr DAT(dc); MyStr EXDAT(exdc);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(const char *nm,const char dc,MyStr &EXDAT,const int r,const int v){
	MyStr NM(nm); MyStr DAT(dc); 
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(const char *nm,const char *dat,const char exdc,const int r,const int v){
	MyStr NM(nm); MyStr DAT(dat); MyStr EXDAT(exdc);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(const char *nm,const char *dat,MyStr &EXDAT,const int r,const int v){
	MyStr NM(nm); MyStr DAT(dat);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(const char *nm,MyStr &DAT,const char *exdat,const int r,const int v){
	MyStr NM(nm); MyStr EXDAT(exdat);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(const char *nm,MyStr &DAT,const char exdc,const int r,const int v){
	MyStr NM(nm); MyStr EXDAT(exdc);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(const char *nm,MyStr &DAT,MyStr &EXDAT,const int r,const int v){
	MyStr NM(nm);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}

StrLink::StrLink(const char nc,const char dc,const char *exdat,const int r,const int v){
	MyStr NM(nc); MyStr DAT(dc); MyStr EXDAT(exdat);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}	
StrLink::StrLink(const char nc,const char dc,const char exdc,const int r,const int v){
	MyStr NM(nc); MyStr DAT(dc); MyStr EXDAT(exdc);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(const char nc,const char dc,MyStr &EXDAT,const int r,const int v){
	MyStr NM(nc); MyStr DAT(dc); 
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(const char nc,const char *dat,const char *exdat,const int r,const int v){
	MyStr NM(nc); MyStr DAT(dat); MyStr EXDAT(exdat);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(const char nc,const char *dat,const char exdc,const int r,const int v){
	MyStr NM(nc); MyStr DAT(dat); MyStr EXDAT(exdc);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(const char nc,const char *dat,MyStr &EXDAT,const int r,const int v){
	MyStr NM(nc); MyStr DAT(dat);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(const char nc,MyStr &DAT,const char *exdat,const int r,const int v){
	MyStr NM(nc); MyStr EXDAT(exdat);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(const char nc,MyStr &DAT,const char exdc,const int r,const int v){
	MyStr NM(nc); MyStr EXDAT(exdc);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(const char nc,MyStr &DAT,MyStr &EXDAT,const int r,const int v){
	MyStr NM(nc);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(MyStr &NM,const char dc,const char *exdat,const int r,const int v){
	MyStr DAT(dc); MyStr EXDAT(exdat);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(MyStr &NM,const char dc,const char exdc,const int r,const int v){
	MyStr DAT(dc); MyStr EXDAT(exdc);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(MyStr &NM,const char dc,MyStr &EXDAT,const int r,const int v){
	MyStr DAT(dc);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(MyStr &NM,const char *dat,const char *exdat,const int r,const int v){
	MyStr DAT(dat); MyStr EXDAT(exdat);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(MyStr &NM,const char *dat,const char exdc,const int r,const int v){
	MyStr DAT(dat); MyStr EXDAT(exdc);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(MyStr &NM,const char *dat,MyStr &EXDAT,const int r,const int v){
	MyStr DAT(dat);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(MyStr &NM,MyStr &DAT,const char *exdat,const int r,const int v){
	MyStr EXDAT(exdat);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(MyStr &NM,MyStr &DAT,const char exdc,const int r,const int v){
	MyStr EXDAT(exdc);
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}
StrLink::StrLink(MyStr &NM,MyStr &DAT,MyStr &EXDAT,const int r,const int v){
	name=NULL; data=NULL; extdata=NULL;
	Setup(NULL,this,0,NM,DAT,EXDAT,r,v);
}

StrLink::~StrLink() { Release(this); }

//******************************************************************************************
const char* StrLink::GetName(const int sno) {
	StrLink *p=GetNode(sno);
	if(p!=NULL) StrLinkTmp=*(p->name);
	else		StrLinkTmp="";
	return (char*)StrLinkTmp;
}
//******************************************************************************************
const char* StrLink::GetData(const int sno) {
	StrLink *p=GetNode(sno);
	if(p!=NULL) StrLinkTmp=*(p->data);
	else		StrLinkTmp="";
	return (char*)StrLinkTmp;
}
const char* StrLink::GetData(MyStr &NM) { 
	StrLink *p=GetNode(NM);
	if(p!=NULL) StrLinkTmp=*(p->data);
	else		StrLinkTmp="";
	return (char*)StrLinkTmp;
}
const char* StrLink::GetData(const char *nm) {
	MyStr NM(nm); return GetData(NM);
}
//******************************************************************************************
const char* StrLink::GetExData(const int sno) {
	StrLink *p=GetNode(sno);
	if(p!=NULL) StrLinkTmp=*(p->extdata);
	else		StrLinkTmp="";
	return (char*)StrLinkTmp;
}
const char* StrLink::GetExData(MyStr &NM) { 
	StrLink *p=GetNode(NM);
	if(p!=NULL) StrLinkTmp=*(p->extdata);
	else		StrLinkTmp="";
	return (char*)StrLinkTmp;
}
const char* StrLink::GetExData(const char *nm) {
	MyStr NM(nm); return GetExData(NM); 
}
//******************************************************************************************
int StrLink::GetSN(const char *nm) {
	MyStr NM(nm); return GetSN(NM);
}
int StrLink::GetSN(MyStr &NM) { 
	StrLink *p=GetNode(NM);
	if(p!=NULL) return p->sn;
	return -1;
}
//******************************************************************************************
int StrLink::GetValue(const int sno) {
	StrLink *p=GetNode(sno);
	if(p!=NULL) return p->ival;
	return -1;
}
int StrLink::GetValue(const char *nm) {
	MyStr NM(nm); return GetValue(NM);
}
int StrLink::GetValue(MyStr &NM) { 
	StrLink *p=GetNode(NM);
	if(p!=NULL) return p->ival;
	return -1;
}
//******************************************************************************************
int StrLink::GetRec(const int sno) {
	StrLink *p=GetNode(sno);
	if(p!=NULL) return p->irec;
	return -1;
}
int StrLink::GetRec(const char *nm) {
	MyStr NM(nm); return GetRec(NM);
}
int StrLink::GetRec(MyStr &NM) { 
	StrLink *p=GetNode(NM);
	if(p!=NULL) return p->irec;
	return -1;
}
//******************************************************************************************
int StrLink::SetValue(const int sno,const int v) {
	StrLink *p=GetNode(sno);
	if(p!=NULL) {p->ival=v;  return p->ival;}
	return -1;
}
int StrLink::SetValue(const char *nm,const int v) {
	MyStr NM(nm); return SetValue(NM,v);
}
int StrLink::SetValue(MyStr &NM,const int v) { 
	StrLink *p=GetNode(NM);
	if(p!=NULL) {p->ival=v;  return p->ival;}
	return -1;
}
//******************************************************************************************
int StrLink::SetRec(const int sno,const int v) {
	StrLink *p=GetNode(sno);
	if(p!=NULL) {p->irec=v;  return p->irec;}
	return -1;
}
int StrLink::SetRec(const char *nm,const int v) {
	MyStr NM(nm); return SetRec(NM,v);
}
int StrLink::SetRec(MyStr &NM,const int v) { 
	StrLink *p=GetNode(NM);
	if(p!=NULL) {p->irec=v;  return p->irec;}
	return -1;
}
//******************************************************************************************
int StrLink::SetData(const char *dat) 		{return SetData(0,dat);}
int StrLink::SetData(const char dc) 		{return SetData(0,dc);}
int StrLink::SetData(MyStr &DAT) 			{return SetData(0,DAT);}
int StrLink::SetData(const int datav) 		{return SetData(0,datav);}
int StrLink::SetData(const long datalv) 	{return SetData(0,datalv);}

int	StrLink::SetData(const int sno,const char dc) {
	MyStr DAT(dc); return SetData(sno,(char*)DAT);
}
int	StrLink::SetData(const int sno,MyStr &DAT) {
	return SetData(sno,(char*)DAT);
}
int	StrLink::SetData(const int sno,const char *dat) {
	StrLink *p=GetNode(sno);
	if(p!=NULL) return SetupData(p,dat);
	return -1;
}
int	StrLink::SetData(const int sno,const int datav) {
	MyStr DAT(datav); return SetData(sno,(char*)DAT);
}
int	StrLink::SetData(const int sno,const long datalv) {
	MyStr DAT(datalv); return SetData(sno,(char*)DAT);
}

int	StrLink::SetData(const char* nm,const char dc) {
	MyStr NM(nm); MyStr DAT(dc); return SetData(NM,(char*)DAT);
}
int	StrLink::SetData(const char* nm,const char *dat) {
	MyStr NM(nm); return SetData(NM,dat);
}
int	StrLink::SetData(const char* nm,MyStr &DAT) {
	MyStr NM(nm); return SetData(NM,(char*)DAT);
}
int	StrLink::SetData(const char* nm,const int datav) {
	MyStr NM(nm); MyStr DAT(datav); return SetData(NM,(char*)DAT);
}
int	StrLink::SetData(const char* nm,const long datalv) {
	MyStr NM(nm); MyStr DAT(datalv); return SetData(NM,(char*)DAT);
}

int	StrLink::SetData(MyStr &NM,const char dc) {
	MyStr DAT(dc); return SetData(NM,(char*)DAT);
}
int	StrLink::SetData(MyStr &NM,const char *dat) {
	StrLink *p=GetNode(NM);
	if(p!=NULL) return SetupData(p,dat);
	return -1;
}
int	StrLink::SetData(MyStr &NM,MyStr &DAT) {
	return SetData(NM,(char*)DAT);
}
int	StrLink::SetData(MyStr &NM,const int datav) {
	MyStr DAT(datav); return SetData(NM,(char*)DAT);
}
int	StrLink::SetData(MyStr &NM,const long datalv) {
	MyStr DAT(datalv); return SetData(NM,(char*)DAT);
}

//******************************************************************************************
int StrLink::SetExData(const char *exdat) 			{return SetExData(0,exdat);}
int StrLink::SetExData(const char exdc) 			{return SetExData(0,exdc);}
int StrLink::SetExData(MyStr &EXDAT) 				{return SetExData(0,EXDAT);}
int StrLink::SetExData(const int exdatav) 			{return SetExData(0,exdatav);}
int StrLink::SetExData(const long exdatalv) 		{return SetExData(0,exdatalv);}

int	StrLink::SetExData(const int sno,const char exdc) {
	MyStr EXDAT(exdc); return SetExData(sno,(char*)EXDAT);
}
int	StrLink::SetExData(const int sno,MyStr &EXDAT) {
	return SetExData(sno,(char*)EXDAT);
}
int	StrLink::SetExData(const int sno,const char *exdat) {
	StrLink *p=GetNode(sno);
	if(p!=NULL) return SetupExData(p,exdat);
	return -1;
}
int	StrLink::SetExData(const int sno,const int exdatav) {
	MyStr EXDAT(exdatav);
	return SetExData(sno,(char*)EXDAT);
}
int	StrLink::SetExData(const int sno,const long exdatalv) {
	MyStr EXDAT(exdatalv);
	return SetExData(sno,(char*)EXDAT);
}

int	StrLink::SetExData(const char* nm,const char exdc) {
	MyStr NM(nm); MyStr EXDAT(exdc); return SetExData(NM,(char*)EXDAT);
}
int	StrLink::SetExData(const char* nm,const char *exdat) {
	MyStr NM(nm); return SetExData(NM,exdat);
}
int	StrLink::SetExData(const char* nm,MyStr &EXDAT) {
	MyStr NM(nm); return SetExData(NM,(char*)EXDAT);
}
int	StrLink::SetExData(const char* nm,const int exdatav) {
	MyStr NM(nm); MyStr EXDAT(exdatav); return SetExData(NM,(char*)EXDAT);
}
int	StrLink::SetExData(const char* nm,const long exdatalv) {
	MyStr NM(nm); MyStr EXDAT(exdatalv); return SetExData(NM,(char*)EXDAT);
}

int	StrLink::SetExData(MyStr &NM,const char exdc) {
	MyStr EXDAT(exdc); return SetExData(NM,(char*)EXDAT);
}
int	StrLink::SetExData(MyStr &NM,const char *exdat) {
	StrLink *p=GetNode(NM);
	if(p!=NULL) return SetupExData(p,exdat);
	return -1;
}
int	StrLink::SetExData(MyStr &NM,MyStr &EXDAT) {
	return SetExData(NM,(char*)EXDAT);
}
int	StrLink::SetExData(MyStr &NM,const int exdatav) {
	MyStr EXDAT(exdatav); return SetExData(NM,(char*)EXDAT);
}
int	StrLink::SetExData(MyStr &NM,const long exdatalv) {
	MyStr EXDAT(exdatalv); return SetExData(NM,(char*)EXDAT);
}

//******************************************************************************************
int	StrLink::Add(const char *nm,const char *dat,const char *exdat,const int r,const int v){			 
	MyStr NM(nm);  MyStr DAT(dat);  MyStr EXDAT(exdat); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(const char *nm,const char *dat,const char exdc,const int r,const int v){
	MyStr NM(nm);  MyStr DAT(dat);  MyStr EXDAT(exdc); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(const char *nm,const char *dat,MyStr &EXDAT,const int r,const int v){
	MyStr NM(nm);  MyStr DAT(dat);
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(const char *nm,const char dc,const char *exdat,const int r,const int v){
	MyStr NM(nm);  MyStr DAT(dc);  MyStr EXDAT(exdat); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(const char *nm,const char dc,const char exdc,const int r,const int v){
	MyStr NM(nm);  MyStr DAT(dc);  MyStr EXDAT(exdc); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(const char *nm,const char dc,MyStr &EXDAT,const int r,const int v){
	MyStr NM(nm);  MyStr DAT(dc);
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(const char *nm,MyStr &DAT,const char *exdat,const int r,const int v){
	MyStr NM(nm);  MyStr EXDAT(exdat); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(const char *nm,MyStr &DAT,const char exdc,const int r,const int v){
	MyStr NM(nm);  MyStr EXDAT(exdc); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(const char *nm,MyStr &DAT,MyStr &EXDAT,const int r,const int v){
	MyStr NM(nm);
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(const char nc,const char *dat,const char *exdat,const int r,const int v){
	MyStr NM(nc); MyStr DAT(dat);  MyStr EXDAT(exdat); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(const char nc,const char *dat,const char exdc,const int r,const int v){
	MyStr NM(nc); MyStr DAT(dat);  MyStr EXDAT(exdc); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(const char nc,const char *dat,MyStr &EXDAT,const int r,const int v){
	MyStr NM(nc); MyStr DAT(dat);  
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(const char nc,const char dc,const char *exdat,const int r,const int v){
	MyStr NM(nc); MyStr DAT(dc); MyStr EXDAT(exdat); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(const char nc,const char dc,const char exdc,const int r,const int v){
	MyStr NM(nc); MyStr DAT(dc); MyStr EXDAT(exdc); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(const char nc,const char dc,MyStr &EXDAT,const int r,const int v){
	MyStr NM(nc); MyStr DAT(dc); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(const char nc,MyStr &DAT,const char *exdat,const int r,const int v){
	MyStr NM(nc); MyStr EXDAT(exdat); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(const char nc,MyStr &DAT,const char exdc,const int r,const int v){
	MyStr NM(nc); MyStr EXDAT(exdc); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(const char nc,MyStr &DAT,MyStr &EXDAT,const int r,const int v){ 				 				 				 
	MyStr NM(nc);
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(MyStr &NM,const char *dat,const char *exdat,const int r,const int v){
	MyStr DAT(dat); MyStr EXDAT(exdat); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(MyStr &NM,const char *dat,const char exdc,const int r,const int v){
	MyStr DAT(dat); MyStr EXDAT(exdc); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(MyStr &NM,const char *dat,MyStr &EXDAT,const int r,const int v){
	MyStr DAT(dat);
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(MyStr &NM,const char dc,const char *exdat,const int r,const int v){
	MyStr DAT(dc); MyStr EXDAT(exdat); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(MyStr &NM,const char dc,const char exdc,const int r,const int v){
	MyStr DAT(dc); MyStr EXDAT(exdc); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(MyStr &NM,const char dc,MyStr &EXDAT,const int r,const int v){
	MyStr DAT(dc); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(MyStr &NM,MyStr &DAT,const char *exdat,const int r,const int v){
	MyStr EXDAT(exdat); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int	StrLink::Add(MyStr &NM,MyStr &DAT,const char exdc,const int r,const int v){
	MyStr EXDAT(exdc); 
	return Add(NM,DAT,EXDAT,r,v); 
}
int StrLink::Add(MyStr &NM,MyStr &DAT,MyStr &EXDAT,const int r,const int v){
	if(NM!="") {
		StrLink *p=this;
		int maxsn=-1;
		while(p->nxt!=NULL) { if(p->sn>maxsn) maxsn=p->sn; p=p->nxt; }
		if(p->sn>maxsn) maxsn=p->sn;
		StrLink *tp=p;
		if(p->name!=NULL) { 
			tp=new StrLink; 
			tp->sn=maxsn+1; 
			tp->pre=p;
			p->nxt=tp;  
		}
		Setup(tp->pre,tp,tp->sn,NM,DAT,EXDAT,r,v);
		return tp->sn;
	}
	return -1;
}
//******************************************************************************
int	StrLink::Del(const int sno) {
	StrLink *p=GetNode(sno);
	if(p!=NULL) {
		MyStr NM,DAT,EXDAT;
		if(p==this) {
printf("\nthis=%u,nxt=%u,nxt->nxt=%u",p,nxt,nxt->nxt);
			if(nxt!=NULL) {
				p=nxt;
printf(" , p=%u",p);
				NM=*(p->name); DAT=*(p->data); EXDAT=*(p->extdata); 
printf(" Setup ..");
				Setup(pre,this,p->sn,NM,DAT,EXDAT,p->irec,p->ival);
				nxt=p->nxt;
				p->nxt=NULL;
printf(" -> nxt=%u , p=%u",nxt,p);
				return Release(p);
			} else Setup(NULL,this,0,NM,DAT,EXDAT,0,-1);
			return 1;
		} else {
			if(p->pre!=NULL) p->pre->nxt=p->nxt;
			if(p->nxt!=NULL) p->nxt->pre=p->pre;
			p->nxt=NULL; p->pre=NULL;
			return Release(p);
	    }
	}
	return -1;
}
int	StrLink::Del(MyStr &NM) {
	StrLink *p=GetNode(NM);
	if(p!=NULL) {
		MyStr NM,DAT,EXDAT;
		if(p==this) {
			if(nxt!=NULL) {
				p=nxt;
				NM=*(p->name); DAT=*(p->data); EXDAT=*(p->extdata); 
				Setup(NULL,this,p->sn,NM,DAT,EXDAT,p->irec,p->ival);
				nxt=p->nxt;
				p->nxt=NULL;
				return Release(p);
			} else Setup(NULL,this,0,NM,DAT,EXDAT,0,-1);
			return 1;
		} else {
			if(p->pre!=NULL) p->pre->nxt=p->nxt;
			if(p->nxt!=NULL) p->nxt->pre=p->pre;
			p->nxt=NULL; p->pre=NULL;
			return Release(p);
	    }
	}
	return -1;
}
int	StrLink::Del(const char *nm) {
	MyStr NM(nm);  return Del(NM);
}
//******************************************************************************
int StrLink::GetNameLstFIFO(MyStr &OutStr,const char DivC){ MyStr D(DivC); return GetNameLstFIFO(OutStr,(char*)D); }
int StrLink::GetNameLstFIFO(MyStr &OutStr,const char* DivStr){
	MyStr DIV(DivStr);
	MyStr *OS=&OutStr;
	int n=0;
	*OS="";
	StrLink *p=this;
	while(p!=NULL) {
		if((int)*(p->name)>0) {
			if(n>0) *OS+=DIV;
			*OS+=*(p->name);
			n++;
		}
		p=p->nxt;
	}
	return n;
}
int StrLink::GetNameLstFILO(MyStr &OutStr,const char DivC){ MyStr D(DivC); return GetNameLstFILO(OutStr,(char*)D); }
int StrLink::GetNameLstFILO(MyStr &OutStr,const char* DivStr){
	MyStr DIV(DivStr);
	int n=0;
	OutStr="";
	StrLink *p=this;
	while(p->nxt!=NULL) p=p->nxt;
	while(p!=NULL) {
		if((int)*(p->name)>0) {
			if(n>0) OutStr+=DIV;
			OutStr+=*(p->name);
			n++;
		}
		p=p->pre;
	}
	return n;
}
const char* StrLink::GetNameLstFIFO(const char DivC){ MyStr D(DivC); return GetNameLstFIFO((char*)D); }
const char* StrLink::GetNameLstFIFO(const char* DivStr){
	MyStr DIV(DivStr);
	int n=0;
	StrLinkTmp="";
	StrLink *p=this;
	while(p!=NULL) {
		if((int)*(p->name)>0) {
			if(n>0) StrLinkTmp+=DIV;
			StrLinkTmp+=*(p->name);
			n++;
		} 
		p=p->nxt;
	}
	return (char*)StrLinkTmp;
}
const char* StrLink::GetNameLstFILO(const char DivC){ MyStr D(DivC); return GetNameLstFILO((char*)D); }
const char* StrLink::GetNameLstFILO(const char* DivStr){
	MyStr DIV(DivStr);
	int n=0;
	StrLinkTmp="";
	StrLink *t=NULL;
	while(t!=this) {
		StrLink *p=this;
		while(p->nxt!=t) p=p->nxt;
		if((int)*(p->name)>0) {
			if(n>0) StrLinkTmp+=DIV;
			StrLinkTmp+=*(p->name);
			n++;
		}
		t=p;
	}
	return (char*)StrLinkTmp;
}
