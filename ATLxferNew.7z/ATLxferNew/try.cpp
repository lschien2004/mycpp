
#include "mystr.h"
#include "dequ.h"
#include "strlink.h"

#include <unistd.h>

using namespace std;

int main(int ac,char** av)
{
 
	int n;
   	MyStr S,T;	
/*
	DEQU DD;
	DEQU_DB DB("dequ.tmp");
	
    S="@A@1	#dequ WTSTGEntry[TSFLG]={{ IF ($TSFLG$.AND.TSFLOW)<>0 ENTRY ;wt stage	}}";
 	DD=S;
	printf("\n\n NAME=[%s]",DD.GetName()); 
	printf("\n PARA=[%d] (%s)",DD.GetParN(),DD.GetPara()); 
	printf("\n BODY=[%s]",DD.GetBody()); 
	DB.Add(DD);

    S="@B #dequ WTSTGExit[]={{ EXIT }}\n";
 	DD=S;
	printf("\n\n NAME=[%s]",DD.GetName()); 
	printf("\n PARA=[%d] (%s)",DD.GetParN(),DD.GetPara()); 
	printf("\n BODY=[%s]",DD.GetBody()); 
	DB.Add(DD);

	S="#dequ ftest[TTNNOO,CCAATT,CCAA22,PPSSUU,SSCCRR,PRESUB,AAFFMM,SSUUBB,POSTSUB,QQCCLL,PPCC,TTPPHH,CCFFGG,ZZHH,ZZDD,TNAME,,,]={{\n";
	S+=";;;;;;;;;; wt stage check ;;;;;;;;;;;;;;;\n";
	S+="WTSTGEntry[WTGF]\n";
	S+="	READ TIMER TO TTT1 & TSTNO=$TTNNOO$ & CAT1=$CCAATT$ & CAT2=$CCAA22$ & GOSUB $PPSSUU$ &\n";
	S+="	QCLOG=$QQCCLL$ & PATPCN=$PPCC$ & PATTP=$TTPPHH$ & PCFLG=$CCFFGG$ & PZZHH=$ZZHH$ & PZZDD=$ZZDD$ &\n";
	S+="	TSTNM=TSTTMP & TSTNM=$TNAME$ & TSTNM(42,1)=? ? & TSTNM(43,8)=ASCII(VDDMAIN,1) & TSTNM(51,1)=?/? & TSTNM(52,8)=ASCII(VDCMAIN,1)\n";
	S+="	GOSUB TDISP1 & GOSUB $PRESUB$ & SCRFLG=$SSCCRR$ & GOSUB SCRSET & AFMFLG=$AAFFMM$ &\n";
	S+="	GOSUB $SSUUBB$ & GOSUB $POSTSUB$ & READ TIMER TO TTT2   &   GOSUB TDISP2\n";
	S+=";;\n";
	S+="@l@s	$17$ ;; bb\n";
	S+=" @l@s	$18$ ;; aa\n";
	S+="WTSTGExit[]\n";
	S+=";;;;;;;;;; wt stage check ;;;;;;;;;;;;;;;\n";
	S+="}}\n";
 	DD=S;
	printf("\n\n NAME=[%s]",DD.GetName()); 
	printf("\n PARA=[%d] (%s)",DD.GetParN(),DD.GetPara()); 
	printf("\n BODY=[%s]",DD.GetBody()); 
	DB.Add(DD);
	
	S="WTSTGEntry";
	n=DB.SearchDEQUparN((char*)S);
	printf("\nDB.SearchDEQUparN(%s) = %d",(char*)S,n);	
	S=DB.GetDEQUnameByDBIdx(n);
	printf("\nDB.GetDEQUnameByDBIdx(%d) = '%s'",n,(char*)S);

	
	S="WTSTGExit";
	n=DB.SearchDEQUparN((char*)S);
	printf("\nDB.SearchDEQUparN(%s) = %d",(char*)S,n);
	S=DB.GetDEQUnameByDBIdx(n);
	printf("\nDB.GetDEQUnameByDBIdx(%d) = '%s'",n,(char*)S);

	S="ftest";
	n=DB.SearchDEQUparN((char*)S);
	printf("\nDB.SearchDEQUparN(%s) = %d",(char*)S,n);
	S=DB.GetDEQUnameByDBIdx(n);
	printf("\nDB.GetDEQUnameByDBIdx(%d) = '%s'",n,(char*)S);

	n=DB.GetCNT();
	for(int i=0;i<n;i++) {
		S=DB.GetDEQUnameByDBIdx(i);
		printf("\n\n**> DB.GetDEQUnameByDBIdx(%d) = '%s'",i,(char*)S);
		printf("\n**> DB.SearchDEQUparN(%s) = %d",(char*)S,DB.SearchDEQUparN((char*)S));
		T=DB.GetDEQUbodyInDB((char*)S);
		printf("\n**> DB.GetDEQUbodyInDB(%s) = [%s]",(char*)S,(char*)T);
		printf("\n**> DB.DEQU_Inside(BODY) = [%s]",DB.DEQU_Inside((char*)T));
		T=DB.DEQU_xfer((char*)T);
		printf("\n**> DB.DEQU_xfer(BODY) = [%s]",(char*)T);
	}

	S="@a@1 ftest[100,1,2,sub1,scrflg,presub,afmflg,sub2,possub,qcflg,#111,#55aa,cflg,#00,#ff,\" [FUNC] TEST 1 \",,]\n";
	printf("\n\nS=[%s]",(char*)S);
	T=DB.DEQU_xfer((char*)S);
	printf("\nDB.DEQU_xfer(S)=[%s]",(char*)T);

	S="	QCLOG=$QCLOG$ & PATPCN=$PCPC$ & PATTP=$TPH$ & CFLG=$CFLG$\n";
	S+=";;    TSTNM=\"$tname$\"^ & TSTNM(42,1)=\" \" & TSTNM(43,8)=ASCII($vdd$,1) & TSTNM(51,1)=?/? & TSTNM(52,8)=ASCII($vdc$,1)\n";
	S+="SetupTestName<$TNAME$,VDDMAIN,VDCMAIN>\n";

	printf("\n\nS=[%s]",(char*)S);
	T=S.GetLineDelBtwKey(DEQULCMT,"\n");
	printf("\nS.GetLineDelBtwKeyExSymBlk()=[%s]",(char*)T);\
*/

	printf("\nStrLink DS;");
	StrLink DS;

	S=""; 	printf("\nDS.GetSN('%s')=%d",(char*)S,DS.GetSN((char*)S));
	n=0;	printf("\nDS.GetName(%d)='%s'",n,DS.GetName(n));
	n=0;	printf("\nDS.GetData(%d)='%s'",n,DS.GetData(n));
	n=0;	printf("\nDS.GetExData(%d)='%s'",n,DS.GetExData(n));
	n=0;	printf("\nDS.GetRec(%d)=%d",n,DS.GetRec(n));
	n=0;	printf("\nDS.GetValue(%d)=%d",n,DS.GetValue(n));


	S="Item0";
	printf("\nn=DS.Add('%s','data0','exdata0')",(char*)S);	
	n=DS.Add((char*)S,"data0","exdata0");
			printf("\nDS.GetSN('%s')=%d",(char*)S,DS.GetSN((char*)S));
			printf("\nDS.GetName(%d)='%s'",n,DS.GetName(n));
			printf("\nDS.GetData('%s')='%s'",(char*)S,DS.GetData((char*)S));
			printf("\nDS.GetExData(%d)='%s'",n,DS.GetExData(n));
			printf("\nDS.GetRec(%d)=%d",n,DS.GetRec(n));
			printf("\nDS.GetValue('%s')=%d",(char*)S,DS.GetValue((char*)S));
			printf("\nDS.GetNameLstFIFO()='%s'",DS.GetNameLstFIFO());
			printf("\nDS.GetNameLstFILO()='%s'",DS.GetNameLstFILO());

	S="Item 1";
	printf("\nn=DS.Add('%s','data 1','exdata 1',10)",(char*)S);	
	n=DS.Add((char*)S,"data 1","exdata 1",10);
			printf("\nDS.GetSN('%s')=%d",(char*)S,DS.GetSN((char*)S));
			printf("\nDS.GetName(%d)='%s'",n,DS.GetName(n));
			printf("\nDS.GetData('%s')='%s'",(char*)S,DS.GetData((char*)S));
			printf("\nDS.GetExData(%d)='%s'",n,DS.GetExData(n));
			printf("\nDS.GetRec(%d)=%d",n,DS.GetRec(n));
			printf("\nDS.GetValue('%s')=%d",(char*)S,DS.GetValue((char*)S));
			printf("\nDS.GetNameLstFIFO()='%s'",DS.GetNameLstFIFO());
			printf("\nDS.GetNameLstFILO()='%s'",DS.GetNameLstFILO());


	S="Item 2";
	printf("\nn=DS.Add('%s','data 2','exdata 2',20,2)",(char*)S);	
	n=DS.Add((char*)S,"data 2","exdata 2",20,2);
			printf("\nDS.GetSN('%s')=%d",(char*)S,DS.GetSN((char*)S));
			printf("\nDS.GetName(%d)='%s'",n,DS.GetName(n));
			printf("\nDS.GetData('%s')='%s'",(char*)S,DS.GetData((char*)S));
			printf("\nDS.GetExData(%d)='%s'",n,DS.GetExData(n));
			printf("\nDS.GetRec(%d)=%d",n,DS.GetRec(n));
			printf("\nDS.GetValue('%s')=%d",(char*)S,DS.GetValue((char*)S));
			printf("\nDS.GetNameLstFIFO()='%s'",DS.GetNameLstFIFO());
			printf("\nDS.GetNameLstFILO()='%s'",DS.GetNameLstFILO());

    T=";";  T=DS.GetNameLstFIFO((char*)T);
    printf("\nDS.GetNameLstFIFO(';')='%s'",(char*)T);
    
	n=DS.GetNameLstFIFO(S,",");
    printf("\nDS.GetNameLstFIFO(S,',')=%d S=[%s]",n,(char*)S);
    n=DS.GetNameLstFILO(S,",");
    printf("\nDS.GetNameLstFILO(S,',')=%d S=[%s]",n,(char*)S);
	
	n=DS.GetNameLstFIFO(S,";");
    printf("\nDS.GetNameLstFIFO(S,';')=%d S=[%s]",n,(char*)S);
    n=DS.GetNameLstFILO(S,";");
    printf("\nDS.GetNameLstFILO(S,';')=%d S=[%s]",n,(char*)S);
    
    printf("\nDS.GetNameLstFIFO()=[%s]",DS.GetNameLstFIFO());

	n=DS.Del(1);
	printf("\n\nDS.Del(1)=%d",n);
    printf("\nDS.GetNameLstFILO()=[%s]",DS.GetNameLstFILO());
    printf("\nDS.GetNameLstFIFO()=[%s]",DS.GetNameLstFIFO());


	S="Item 3";
	printf("\nn=DS.Add('%s','data 3','exdata 3',30,300)",(char*)S);	
	n=DS.Add((char*)S,"data 3","exdata 3",30,300);
			printf("\nDS.GetSN('%s')=%d",(char*)S,DS.GetSN((char*)S));
			printf("\nDS.GetName(%d)='%s'",n,DS.GetName(n));
			printf("\nDS.GetData('%s')='%s'",(char*)S,DS.GetData((char*)S));
			printf("\nDS.GetExData(%d)='%s'",n,DS.GetExData(n));
			printf("\nDS.GetRec(%d)=%d",n,DS.GetRec(n));
			printf("\nDS.GetValue('%s')=%d",(char*)S,DS.GetValue((char*)S));
			printf("\nDS.GetNameLstFIFO()='%s'",DS.GetNameLstFIFO());
			printf("\nDS.GetNameLstFILO()='%s'",DS.GetNameLstFILO());


	S="Item0";
	printf("\n\nDS.Del('%s')...",(char*)S);
	n=DS.Del(S);
    printf("\nDS.GetNameLstFILO()=[%s]",DS.GetNameLstFILO());
    printf("\nDS.GetNameLstFIFO()=[%s]",DS.GetNameLstFIFO());

	n=2;	printf("\nDS.GetName(%d)='%s' DS.GetData(%d)='%s' DS.GetExData(%d)='%s'",n,DS.GetName(n),n,DS.GetData(n),n,DS.GetExData(n));
	
	S="Item 2";
	printf("\n\nDS.Del('%s')...",(char*)S);
	n=DS.Del(S);
 
 	printf("\nDS.GetSN('%s')=%d",(char*)S,DS.GetSN((char*)S));
	n=2;	printf("\nDS.GetName(%d)='%s' DS.GetData(%d)='%s' DS.GetExData(%d)='%s'",n,DS.GetName(n),n,DS.GetData(n),n,DS.GetExData(n));
	n=0;	printf("\nDS.GetRec(%d)=%d",n,DS.GetRec(n));
	n=0;	printf("\nDS.GetValue(%d)=%d",n,DS.GetValue(n));
 
    printf("\nDS.GetNameLstFILO()=[%s]",DS.GetNameLstFILO());
    printf("\nDS.GetNameLstFIFO()=[%s]",DS.GetNameLstFIFO());

	n=3;	printf("\nDS.GetName(%d)='%s'",n,DS.GetName(n));
	n=3;	printf("\nDS.GetData(%d)='%s'",n,DS.GetData(n));
	n=3;	printf("\nDS.GetExData(%d)='%s'",n,DS.GetExData(n));
	n=3;	printf("\nDS.GetRec(%d)=%d",n,DS.GetRec(n));
	n=3;	printf("\nDS.GetValue(%d)=%d",n,DS.GetValue(n));


	exit(0);
}
