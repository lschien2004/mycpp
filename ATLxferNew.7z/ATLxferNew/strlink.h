
#include "mystr.h"

#ifndef __StrLink_H__
	#define __StrLink_H__
	#define __StrLinkVer__	"StrLink@20191015"

class StrLink {
private:
 	 int		 sn;
	 int         irec;
 	 MyStr 		 *name;
	 MyStr 		 *data;
	 MyStr 	 	 *exdata;
	 int         ival;
 	 StrLink 	 *nxt;
 	 StrLink 	 *pre;
 	 
protected:
		 StrLink *GetNode(const int sno);
		 StrLink *GetNode(MyStr &NM);

 virtual int	 DelNode(StrLink *p);
		 
         int	 SetupName(StrLink *cp,const char *nm);
         int	 SetupName(StrLink *cp,MyStr &NM);
         
         int	 SetupData(StrLink *cp,const char *dat);
         int	 SetupData(StrLink *cp,MyStr &DAT);
         
         int	 SetupExData(StrLink *cp,const char *extd);
         int	 SetupExData(StrLink *cp,MyStr &EXDAT);
         
 virtual int	 Setup(StrLink *pp,StrLink *cp,StrLink *np,const int sno,MyStr &NM,MyStr &DAT,MyStr &EXDAT,const int r,const int v);
 virtual int	 Release(StrLink *p);

public:
				 StrLink(const char *nm=NULL,const char *dat=NULL,const char *exdat=NULL,const int r=0,const int v=-1);
				 StrLink(const char *nm     ,const char *dat     ,const char exdc       ,const int r=0,const int v=-1);
				 StrLink(const char *nm     ,const char *dat     ,MyStr &EXDAT          ,const int r=0,const int v=-1);
				 StrLink(const char *nm     ,const char dc       ,const char *exdat=NULL,const int r=0,const int v=-1);
				 StrLink(const char *nm     ,const char dc       ,const char exdc       ,const int r=0,const int v=-1);
				 StrLink(const char *nm     ,const char dc       ,MyStr &EXDAT          ,const int r=0,const int v=-1);
				 StrLink(const char *nm     ,MyStr &DAT          ,const char *exdat=NULL,const int r=0,const int v=-1);
				 StrLink(const char *nm     ,MyStr &DAT          ,const char exdc       ,const int r=0,const int v=-1);
				 StrLink(const char *nm     ,MyStr &DAT          ,MyStr &EXDAT          ,const int r=0,const int v=-1);

				 StrLink(const char nc,const char *dat=NULL,const char *exdat=NULL,const int r=0,const int v=-1);
				 StrLink(const char nc,const char *dat     ,const char exdc       ,const int r=0,const int v=-1);
				 StrLink(const char nc,const char *dat     ,MyStr &EXDAT          ,const int r=0,const int v=-1);
				 StrLink(const char nc,const char dc       ,const char *exdat=NULL,const int r=0,const int v=-1);
				 StrLink(const char nc,const char dc       ,const char exdc       ,const int r=0,const int v=-1);
				 StrLink(const char nc,const char dc       ,MyStr &EXDAT          ,const int r=0,const int v=-1);
				 StrLink(const char nc,MyStr &DAT          ,const char *exdat=NULL,const int r=0,const int v=-1);
				 StrLink(const char nc,MyStr &DAT          ,const char exdc       ,const int r=0,const int v=-1);
				 StrLink(const char nc,MyStr &DAT          ,MyStr &EXDAT          ,const int r=0,const int v=-1);
				 	 				 				 				 
				 StrLink(MyStr &NM,const char *dat=NULL,const char *exdat=NULL,const int r=0,const int v=-1);
				 StrLink(MyStr &NM,const char *dat     ,const char exdc       ,const int r=0,const int v=-1);
				 StrLink(MyStr &NM,const char *dat     ,MyStr &EXDAT          ,const int r=0,const int v=-1);
				 StrLink(MyStr &NM,const char dc       ,const char *exdat=NULL,const int r=0,const int v=-1);
				 StrLink(MyStr &NM,const char dc       ,const char exdc       ,const int r=0,const int v=-1);
				 StrLink(MyStr &NM,const char dc       ,MyStr &EXDAT          ,const int r=0,const int v=-1);
				 StrLink(MyStr &NM,MyStr &DAT          ,const char *exdat=NULL,const int r=0,const int v=-1);
				 StrLink(MyStr &NM,MyStr &DAT          ,const char exdc       ,const int r=0,const int v=-1);
				 StrLink(MyStr &NM,MyStr &DAT          ,MyStr &EXDAT          ,const int r=0,const int v=-1);
				 
				 ~StrLink();
				 
		//******************************************************************************
		 int	 Add(const char *nm,const char *dat=NULL,const char *exdat=NULL,const int r=0,const int v=-1);			 
		 int	 Add(const char *nm,const char *dat     ,const char exdc       ,const int r=0,const int v=-1);
		 int	 Add(const char *nm,const char *dat     ,MyStr &EXDAT          ,const int r=0,const int v=-1);
		 int	 Add(const char *nm,const char dc       ,const char *exdat=NULL,const int r=0,const int v=-1);
		 int	 Add(const char *nm,const char dc       ,const char exdc       ,const int r=0,const int v=-1);
		 int	 Add(const char *nm,const char dc       ,MyStr &EXDAT          ,const int r=0,const int v=-1);
		 int	 Add(const char *nm,MyStr &DAT          ,const char *exdat=NULL,const int r=0,const int v=-1);
		 int	 Add(const char *nm,MyStr &DAT          ,const char exdc       ,const int r=0,const int v=-1);
		 int	 Add(const char *nm,MyStr &DAT          ,MyStr &EXDAT          ,const int r=0,const int v=-1);

		 int	 Add(const char nc,const char *dat=NULL,const char *exdat=NULL,const int r=0,const int v=-1);
		 int	 Add(const char nc,const char *dat     ,const char exdc       ,const int r=0,const int v=-1);
		 int	 Add(const char nc,const char *dat     ,MyStr &EXDAT          ,const int r=0,const int v=-1);
		 int	 Add(const char nc,const char dc       ,const char *exdat=NULL,const int r=0,const int v=-1);
		 int	 Add(const char nc,const char dc       ,const char exdc       ,const int r=0,const int v=-1);
		 int	 Add(const char nc,const char dc       ,MyStr &EXDAT          ,const int r=0,const int v=-1);
		 int	 Add(const char nc,MyStr &DAT          ,const char *exdat=NULL,const int r=0,const int v=-1);
		 int	 Add(const char nc,MyStr &DAT          ,const char exdc       ,const int r=0,const int v=-1);
		 int	 Add(const char nc,MyStr &DAT          ,MyStr &EXDAT          ,const int r=0,const int v=-1); 				 				 				 

		 int	 Add(MyStr &NM,const char *dat=NULL,const char *exdat=NULL,const int r=0,const int v=-1);
		 int	 Add(MyStr &NM,const char *dat     ,const char exdc       ,const int r=0,const int v=-1);
		 int	 Add(MyStr &NM,const char *dat     ,MyStr &EXDAT          ,const int r=0,const int v=-1);
		 int	 Add(MyStr &NM,const char dc       ,const char *exdat=NULL,const int r=0,const int v=-1);
		 int	 Add(MyStr &NM,const char dc       ,const char exdc       ,const int r=0,const int v=-1);
		 int	 Add(MyStr &NM,const char dc       ,MyStr &EXDAT          ,const int r=0,const int v=-1);
		 int	 Add(MyStr &NM,MyStr &DAT          ,const char *exdat=NULL,const int r=0,const int v=-1);
		 int	 Add(MyStr &NM,MyStr &DAT          ,const char exdc       ,const int r=0,const int v=-1);
		 int	 Add(MyStr &NM,MyStr &DAT          ,MyStr &EXDAT          ,const int r=0,const int v=-1);

		//******************************************************************************   	     
   	     int	 Del(const int sno);
   	     int	 Del(const char nc);
   	     int	 Del(const char *nm);
   	     int	 Del(MyStr &NM);
   	//************************************************************************	     
   	     int	 GetNameLstFIFO(MyStr &OutStr,const char DivC);
	     int	 GetNameLstFILO(MyStr &OutStr,const char DivC);
	//---------------------------------------------------------------------
   	     int	 GetNameLstFIFO(MyStr &OutStr,const char* DivStr);
	     int	 GetNameLstFILO(MyStr &OutStr,const char* DivStr);
   	//=======================================================================	     
   	const char	*GetNameLstFIFO(const char DivC);
   	const char	*GetNameLstFILO(const char DivC);
	//---------------------------------------------------------------------
   	const char	*GetNameLstFIFO(const char* DivStr=",");
   	const char	*GetNameLstFILO(const char* DivStr=",");
   	//************************************************************************	     
   	const char	*GetName(const int sno=0);
   	//************************************************************************	     
   	     int     GetCNT(void);
   	//************************************************************************
	     int 	 GetSN(const char nc);
	     int 	 GetSN(const char *nm);
	     int 	 GetSN(MyStr &NM);
   	//************************************************************************
	     int 	 GetValue(const int sno=0);
	     int 	 GetValue(const char nc);
	     int 	 GetValue(const char *nm);
	     int 	 GetValue(MyStr &NM);
   	//************************************************************************
	     int 	 GetRec(const int sno=0);
	     int 	 GetRec(const char nc);
	     int 	 GetRec(const char *nm);
	     int 	 GetRec(MyStr &NM);
   	//************************************************************************   	
   	const char	*GetData(const int sno=0);
   	const char	*GetData(const char nc);
   	const char	*GetData(const char *nm);
   	const char	*GetData(MyStr &NM);
   	//************************************************************************
   	const char	*GetExData(const int sno=0);
   	const char	*GetExData(const char nc);
   	const char	*GetExData(const char *nm);
   	const char	*GetExData(MyStr &NM);
   	//************************************************************************
	     int 	 SetValue(const int sno=0,const int v=-1);
	     int 	 SetValue(const char nc,const int v);
	     int 	 SetValue(const char *nm,const int v);
	     int 	 SetValue(MyStr &NM,const int v);
   	//************************************************************************
	     int 	 SetRec(const int sno=0,const int v=-1);
	     int 	 SetRec(const char nc,const int v);
	     int 	 SetRec(const char *nm,const int v);
	     int 	 SetRec(MyStr &NM,const int v);
   	//************************************************************************
         int 	 SetData(const char *dat=NULL);
         int 	 SetData(const char dc);
         int 	 SetData(MyStr &DAT);
         int 	 SetData(const int datav);
         int 	 SetData(const long datalv);
   	//---------------------------------------------------------------------    
   	     int 	 SetData(const int sno,const char *dat=NULL);
   	     int 	 SetData(const int sno,const char dc);
   	     int 	 SetData(const int sno,MyStr &DAT);
   	     int 	 SetData(const int sno,const int datav);
   	     int 	 SetData(const int sno,const long datalv);
	//---------------------------------------------------------------------
   	     int 	 SetData(const char *nm,const char *dat=NULL);
   	     int 	 SetData(const char *nm,const char dc);
   	     int 	 SetData(const char *nm,MyStr &DAT);
   	     int 	 SetData(const char *nm,const int datav);
   	     int 	 SetData(const char *nm,const long datalv);
   	//---------------------------------------------------------------------
   	     int 	 SetData(MyStr &NM,const char *dat=NULL);
   	     int 	 SetData(MyStr &NM,const char dc);
   	     int 	 SetData(MyStr &NM,MyStr &DAT);
   	     int 	 SetData(MyStr &NM,const int datav);
   	     int 	 SetData(MyStr &NM,const long datalv);
   	//************************************************************************
         int 	 SetExData(const char *exdat=NULL);
         int 	 SetExData(const char exdc);
         int 	 SetExData(MyStr &EXDAT);
         int 	 SetExData(const int exdatav);
         int 	 SetExData(const long exdatalv);
   	//---------------------------------------------------------------------    
   	     int 	 SetExData(const int sno,const char *exdat=NULL);
   	     int 	 SetExData(const int sno,const char exdc);
   	     int 	 SetExData(const int sno,MyStr &EXDAT);
   	     int 	 SetExData(const int sno,const int exdatav);
   	     int 	 SetExData(const int sno,const long exdatalv);
   	//---------------------------------------------------------------------
   	     int 	 SetExData(const char *nm,const char *exdat=NULL);
   	     int 	 SetExData(const char *nm,const char exdc);
   	     int 	 SetExData(const char *nm,MyStr &EXDAT);
   	     int 	 SetExData(const char *nm,const int exdatav);
   	     int 	 SetExData(const char *nm,const long exdatalv);
   	//---------------------------------------------------------------------
   	     int 	 SetExData(MyStr &NM,const char *exdat=NULL);
   	     int 	 SetExData(MyStr &NM,const char exdc);
   	     int 	 SetExData(MyStr &NM,MyStr &EXDAT);
   	     int 	 SetExData(MyStr &NM,const int exdatav);
   	     int 	 SetExData(MyStr &NM,const long exdatalv);
};
#endif
