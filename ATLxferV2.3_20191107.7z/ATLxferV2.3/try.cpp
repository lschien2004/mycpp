
#include "mystr.h"
#include "dequ.h"

#include <unistd.h>

using namespace std;

int main(int ac,char** av)
{
 
	int n;
   	MyStr S,T;	
/*
	DEQU DD;
	DEQU_DB DB("dequ.tmp");
	
    S="@A@1	#dequ WTSTGEntry[TSFLG]={{ IF ($TSFLG$.AND.TSFLOW)<>0 ENTRY ;wt stage	}}";
 	DD=S;
	printf("\n\n NAME=[%s]",DD.GetName()); 
	printf("\n PARA=[%d] (%s)",DD.GetParN(),DD.GetPara()); 
	printf("\n BODY=[%s]",DD.GetBody()); 
	DB.Add(DD);

    S="@B #dequ WTSTGExit[]={{ EXIT }}\n";
 	DD=S;
	printf("\n\n NAME=[%s]",DD.GetName()); 
	printf("\n PARA=[%d] (%s)",DD.GetParN(),DD.GetPara()); 
	printf("\n BODY=[%s]",DD.GetBody()); 
	DB.Add(DD);

	S="#dequ ftest[TTNNOO,CCAATT,CCAA22,PPSSUU,SSCCRR,PRESUB,AAFFMM,SSUUBB,POSTSUB,QQCCLL,PPCC,TTPPHH,CCFFGG,ZZHH,ZZDD,TNAME,,,]={{\n";
	S+=";;;;;;;;;; wt stage check ;;;;;;;;;;;;;;;\n";
	S+="WTSTGEntry[WTGF]\n";
	S+="	READ TIMER TO TTT1 & TSTNO=$TTNNOO$ & CAT1=$CCAATT$ & CAT2=$CCAA22$ & GOSUB $PPSSUU$ &\n";
	S+="	QCLOG=$QQCCLL$ & PATPCN=$PPCC$ & PATTP=$TTPPHH$ & PCFLG=$CCFFGG$ & PZZHH=$ZZHH$ & PZZDD=$ZZDD$ &\n";
	S+="	TSTNM=TSTTMP & TSTNM=$TNAME$ & TSTNM(42,1)=? ? & TSTNM(43,8)=ASCII(VDDMAIN,1) & TSTNM(51,1)=?/? & TSTNM(52,8)=ASCII(VDCMAIN,1)\n";
	S+="	GOSUB TDISP1 & GOSUB $PRESUB$ & SCRFLG=$SSCCRR$ & GOSUB SCRSET & AFMFLG=$AAFFMM$ &\n";
	S+="	GOSUB $SSUUBB$ & GOSUB $POSTSUB$ & READ TIMER TO TTT2   &   GOSUB TDISP2\n";
	S+=";;\n";
	S+="@l@s	$17$ ;; bb\n";
	S+=" @l@s	$18$ ;; aa\n";
	S+="WTSTGExit[]\n";
	S+=";;;;;;;;;; wt stage check ;;;;;;;;;;;;;;;\n";
	S+="}}\n";
 	DD=S;
	printf("\n\n NAME=[%s]",DD.GetName()); 
	printf("\n PARA=[%d] (%s)",DD.GetParN(),DD.GetPara()); 
	printf("\n BODY=[%s]",DD.GetBody()); 
	DB.Add(DD);
	
	S="WTSTGEntry";
	n=DB.SearchDEQUparN((char*)S);
	printf("\nDB.SearchDEQUparN(%s) = %d",(char*)S,n);	
	S=DB.GetDEQUnameByDBIdx(n);
	printf("\nDB.GetDEQUnameByDBIdx(%d) = '%s'",n,(char*)S);

	
	S="WTSTGExit";
	n=DB.SearchDEQUparN((char*)S);
	printf("\nDB.SearchDEQUparN(%s) = %d",(char*)S,n);
	S=DB.GetDEQUnameByDBIdx(n);
	printf("\nDB.GetDEQUnameByDBIdx(%d) = '%s'",n,(char*)S);

	S="ftest";
	n=DB.SearchDEQUparN((char*)S);
	printf("\nDB.SearchDEQUparN(%s) = %d",(char*)S,n);
	S=DB.GetDEQUnameByDBIdx(n);
	printf("\nDB.GetDEQUnameByDBIdx(%d) = '%s'",n,(char*)S);

	n=DB.GetCNT();
	for(int i=0;i<n;i++) {
		S=DB.GetDEQUnameByDBIdx(i);
		printf("\n\n**> DB.GetDEQUnameByDBIdx(%d) = '%s'",i,(char*)S);
		printf("\n**> DB.SearchDEQUparN(%s) = %d",(char*)S,DB.SearchDEQUparN((char*)S));
		T=DB.GetDEQUbodyInDB((char*)S);
		printf("\n**> DB.GetDEQUbodyInDB(%s) = [%s]",(char*)S,(char*)T);
		printf("\n**> DB.DEQU_Inside(BODY) = [%s]",DB.DEQU_Inside((char*)T));
		T=DB.DEQU_xfer((char*)T);
		printf("\n**> DB.DEQU_xfer(BODY) = [%s]",(char*)T);
	}

	S="@a@1 ftest[100,1,2,sub1,scrflg,presub,afmflg,sub2,possub,qcflg,#111,#55aa,cflg,#00,#ff,\" [FUNC] TEST 1 \",,]\n";
	printf("\n\nS=[%s]",(char*)S);
	T=DB.DEQU_xfer((char*)S);
	printf("\nDB.DEQU_xfer(S)=[%s]",(char*)T);

	S="	QCLOG=$QCLOG$ & PATPCN=$PCPC$ & PATTP=$TPH$ & CFLG=$CFLG$\n";
	S+=";;    TSTNM=\"$tname$\"^ & TSTNM(42,1)=\" \" & TSTNM(43,8)=ASCII($vdd$,1) & TSTNM(51,1)=?/? & TSTNM(52,8)=ASCII($vdc$,1)\n";
	S+="SetupTestName<$TNAME$,VDDMAIN,VDCMAIN>\n";

	printf("\n\nS=[%s]",(char*)S);
	T=S.GetLineDelBtwKey(DEQULCMT,"\n");
	printf("\nS.GetLineDelBtwKeyExSymBlk()=[%s]",(char*)T);\
*/
	S="pwd";
	printf("\nsystem(%s)",(char*)S);
	int r=system((char*)S);
	printf(" -> retcode=%d",r);
	
	S="cp try.log try.logy";
	printf("\nsystem(%s)",(char*)S);
	r=system((char*)S);
	printf(" -> retcode=%d",r);

	S="rm try.logy";
	printf("\nsystem(%s)",(char*)S);
	r=system((char*)S);
	printf(" -> retcode=%d",r);
	
	S="try.log";
	r=access((char*)S,F_OK);
	printf("\naccess(%s,F_OK)=%d",(char*)S,r);
	
	S="try.logx";
	r=access((char*)S,F_OK);
	printf("\naccess(%s,F_OK)=%d",(char*)S,r);
	
	exit(0);

}
