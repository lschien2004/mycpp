/*
	Ver.1.1 : (1) Xfer �� parameter TrimR+TrimL (except _DEQUSYMS+_DEQUSYMX)
	Ver.1.1 : (2) Xfer �� parameter �� SymX+data+SymX�� data ���B�z, ��SymX�h���ᵹBody�Axfer.
	Ver.1.2 : (1) ODequ :: add �� LIFO ���c
	Ver.1.3 : (1) DSlinkRelease(Para)�L�kupdate Para ,�諾���s�� ReleaseDSLINK(&Para)
*/

#ifndef __ODequ_H__
#define __ODequ_H__

#define _dequVer_		"ODequ-v1.3@20191016"

#define _dequFmtVer_	"V1.3"

#include <unistd.h>
#include "mystr.h"
#include "dequdb.h"


#ifndef __DequDef__
    #define __DequDef__ 2

 #define _DEQUKEY    		"#dequ"
 #define _DEQUPARST  		'<'
 #define _DEQUPARED  		'>'
 #define _DEQUBDYST  		"{{"
 #define _DEQUBDYED  		"}}"
 #define _DEQUSYMS   		"\""			// SymS+data+SymS willn't be xferred.
 #define _DEQUSYMU   		"?"				// SymU+data+SymU will be xferred.
 #define _DEQUSYMX   		"'`" 			// SymX+data+SymX->parameter xfer->data->data will be xferred .
 #define _DEQUSYMA   		"?\"'`" 		// SYMS+SYMU+SYMX
 #define _DEQULCMT   		';'
 #define _DEQUCMTC   		'@'
 #define _DEQUBDYVPAST 		'$'
 #define _DEQUBDYVPAED 		'$'
 
enum DequCode{_well=0,_none,_err_name,_err_namerule,_err_para,_err_body};

#endif //#ifndef __DequDef__

typedef struct dslink {
	MyStr data;
	dslink *nxt;
} DSLINK;

void ReleaseDSLINK(DSLINK **p);

class ODequ {
private:
          MyStr      NAME;
          MyStr      BODY;
          int        PARN;
          DSLINK*	 Para;
          MyStr      TMP;
protected:
                void  Setup(const char *s);
public:
//		  	    void DSlinkRelease(DSLINK *p); �L�k update release�᪺ p
          const char *GetTrimDEQU(const char *dequstr);
          const char *GetNameFromTrimDEQU(const char *trimdequ);
          const char *GetBodyFromTrimDEQU(const char *trimdequ);
          const char *GetParaFromTrimDEQU(const char *trimdequ);
		  		  		  
          const char *GetName(void);
          const char *GetBody(void);
                 int  GetParN(void);
          const char *GetPara(void);

          ODequ();
          ODequ(MyStr &S);
          ODequ(const char *s);
          ~ODequ();
          
		  ODequ& operator=(const char *s);
		  ODequ& operator=(MyStr &S);
		  ODequ& operator=(Dequ &DQ);

		  bool  operator==(const char* name);
		  bool  operator==(MyStr &S);
		  bool  operator!=(const char* name);
		  bool  operator!=(MyStr &S);

};
//###############################################################################

typedef struct dqlink {
	int SN;
	int PARN;
	MyStr NAME;
	dqlink *nxt;
} DQLINK;

//###############################################################################

#define DEQU_DB_MaxLineLen    128

class DEQU_DB {
private:
	 int 			CNT;
	 MyStr			DBfile;
	 DQLINK			*DBP;
	 MyStr			TMP;
protected:
	 void			ReleaseDBP(void);
	 const char*	ParaAnalyze(MyStr &PA,const char *sym);
	 const char*	ParaAnalyze(MyStr &PA,MyStr &SYM);
	 const char *	PickupLineDequPara(MyStr &LL,MyStr &DEQNM,MyStr &SYM,MyStr &LS,MyStr &LE);
public:
	 const char* 	GetDBfile(void);
	 int			GetCNT(void);
	 
	 int 			GetDEQUSeqN(const char *dequname);

	 int 			Add(ODequ& DD);
	 int 			Add(Dequ& DQ);

	 const char*	DEQU_Inside(const char *line);
	 int 			SearchDEQUparN(const char *dequname);
	 const char*	GetDEQUdefParaInDB(const char *dequname);
	 const char*	GetDEQUbodyInDB(const char *dequname);
	 const char*	GetDEQUnameByDBIdx(const int si);

	 const char*	DEQU_xfer(const char *line);
	 
	 int			DB_foutput(const char *filename);

					DEQU_DB(const char *dbfname);
					DEQU_DB(const char *dbfname,ODequ& DD);
					~DEQU_DB();
};

#endif

