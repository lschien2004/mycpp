/* ###################################################################################################
	Ver.1.1   : (1) Xfer�� parameter TrimR+TrimL (except _DEQUSYMS+_DEQUSYMX)
	Ver.1.1   : (2) Xfer�� parameter �� SymX+data+SymX�� data ���B�z, ��SymX�h���ᵹBody�Axfer.(Symx='%)
	Ver.1.1   : (3) Xfer�O�d @x comment
	Ver.1.1   : (4) output file ��X ;@> + xfer�e�쫬 .
	Ver.1.1   : (5) Xfer��parameter �i�H��J dequ ���� ex. Titem<10,"FUNC 1",ClearArray<FDUT>,FUNSUB>
	
	Ver.1.2   : (1) Xfer��Parameter�ϥ� macro1<,macro2<>> �_����J���D�ѨM
	Ver.1.2   : (2) Xfer��Parameter�ϥΪ�macro�L�Ѽƥi�٥h<>. (FunPon<>��i�H��FunPon) 
	Ver.1.2   : (3) DEQU_DB v1.2 DEQU add �� FIFO �令 LIFO & DEQU body�a�JSeqN search,�᭱�P�W macro�u��.
	Ver.1.2   : (4) Xfer��Parameter�ϥ� SymX �_���p 'pon<TIM1,3MS,`IN1,IN2`>' ���D�ѨM
	Ver.1.2   : (5) output DEQU macro DB file �令 macro�쫬��X-> ODIR\m+ifile
	
	Ver.1.3   : (1) Fix Macro name including the other short macro name issue
	Ver.1.3   : (2) accept non-parameter macro definition without <> 
  ################################################################################################### */

#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>    //printf
#include <stdlib.h>   //malloc
#include <string.h>   //strncpy
#include <unistd.h>   //close
#include <iostream>
#include <ctime>

#define _DOS_

#include "mystr.h"
#include "mystd.h"
#include "fileobj.h"
#include "dequ.h"
#include "dequdb.h"

#define __PgmVer__ "ATLxfer-v1.5@20191029"
#define __Author__ "L.S Chien"

#ifdef _DOS_
	#define __SYS__ "DOS"
    #define SymPath  '\\'
#else
	#define __SYS__ "UNIX"
    #define SymPath  '/'
#endif

#define FileInsertStatement "INSERT"

#define StrMaxLen 256

using namespace std;


void usage(char *pgmname);
//bool CheckDeclareStatmentInside(const char *line);
void PickupInsertFileName(MyStr &Fname,MyStr &LS,MyStr &LE,const char *line);
void SpCtlWrite(FileObj &FO,const char *ll,int &LFcnt);
void SpCtlWrite(FileObj &FO,MyStr &LL,int &LFcnt);
void DequXfer(DEQU_DB &QDB,MyStr &LL);
int InsertCheckXferWrite(DEQU_DB &QDB,FnameObj &INF,FileObj &FO,MyStr &LL,int &LFcnt);
int FileXfer(DEQU_DB &QDB,FnameObj &INF,FileObj &FO,int &state,MyStr &FF,int &LFcnt);
void GetTimeStr(MyStr &RtnStr);

void usage(char *pgmname)
{
	tout out;
	out.prt("\n##################################################################");
	out.prt("\n[[[ ATL Xfer % % By % (DequDef=%)]]]",__SYS__, __PgmVer__,__Author__,__DequDef__);
	out.prt("\n Related lib :");
	out.prt("\n   %\t\t%",__MyStdVer__,__FileObjVer__);
	out.prt("\n   %\t\t%",__MyStrVer__,_dequVer_);
	out.prt("\n==================================================================");
	out.prt("\n     This tool is used to covert the source files which writed with");
	out.prt("\n% macro to a .asc file for ADV tester's compiler .\n",_DEQUKEY);
	out.prt("\n Usage : %  main_src_file  [output_path]",pgmname);
	out.prt("\n       >> w/o output_path -> output in current path .\n");
	out.prt("\n    Ex : % wtmain.src ASCDIR",pgmname);
	out.prt("\n       >> Transfer wtmain.src to ASCDIR%wtmain.asc",SymPath);
	out.prt("\n    Ex : % ..%wtmain.src",pgmname,SymPath);
	out.prt("\n       >> Transfer ..%wtmain.src to .%wtmain.asc\n",SymPath,SymPath);
	out.prt("\n Note :");
	out.prt("\n     1) All of inserted files must be lower-case file name !");
	out.prt("\n     2) main_src_file and all of inserted files must be stored in");
	out.prt("\n        the same path !");
	out.prt("\n     3) All of inserted files' att_name must as same as the att_name");
	out.prt("\n        of main_src_file !");
	out.prt("\n        Ex: main_src_file is main.s , the insertd files must be *.s");
	out.prt("\n     4) If main_src_file's att_name is .asc and output_path is same");
	out.prt("\n        as main_src_file's path, then output file's att_name will");
	out.prt("\n        change to be .asc2)");
	out.prt("\n==================================================================");
	out.prt("\n  Regarding % marco :",_DEQUKEY);
	out.prt("\n     1) If % macro are re-defined, the last loaded macro",_DEQUKEY);
	out.prt("\n        before transfer will dominate !");
	out.prt("\n     2) Name of % macro must exist at the least one lower-case",_DEQUKEY);
	out.prt("\n        char .");
	out.prt("\n##################################################################\n");
}
/*
bool CheckDeclareStatmentInside(const char *line) {
	MyStr LL(line);
	LL=LL.GetDos2Unix();
	LL=LL.GetRangeWithDelBtwKeyExSymBlk(";","\n","\"?");
	LL=LL.GetRangeWithWdChgExSymBlk(";\n","\n","\"?");
	LL=LL.GetLineWithCmtChrDelNExSymBlk('@',1,"\"?");	
	LL=LL.GetLineTrim();
	LL=LL.GetRangeWithWdCmpressExSymBlk("\n","\"?");
	
	LL=LL.GetRangeWithSpDelExSymBlk("\"?");
	
	if(LL.InStr(_DEQUKEY)==0) return true;
//	if(LL.InStr("EQUAT")==0) return true;
	if(LL.InStr("DMACRO")==0) return true;
	if(LL.InStr("SDEF")==0) return true;
	if(LL.InStr("MODULE")==0) return true;
	return false;
}
*/
void PickupInsertFileName(MyStr &Fname,MyStr &LS,MyStr &LE,const char *line) {
	LS=line;
	ArrayNameStr Exchg;
	AddExchgLineCmtWithExSymBlk(LS,Exchg);
	AddExchgSymBlk(LS,Exchg);
	AddExchgSymChrCmtWithExSymBlk(LS,Exchg);
	LE=LS.GetRangeWithWdChg('\t',' ');
	LE=LE.GetRangeWithWdChg('\n',' ');
	Fname=FileInsertStatement;
	Fname+=" ";

	int p=LE.InStr(Fname);
	if(p<0) {LS=line; LE=""; Fname=""; return; }
	MyStr T;
	if(p>0) T=LS.GetRangeByIdx(-1,p-1);
	p=p+(int)Fname;
	
	int l=LE.InStr(p,_DEQU_ExKeyS); // ExKeyStart
	if(l<0) l=(int)LE;
	
	while(p<l && LE[p]==' ') p++;
	int q=p;
	while(q<l && LE[q]!=' ') q++;
	Fname=LE.GetRangeByIdx(p,q-1);
	Fname=Fname.GetLowerCase();
	LE=LS.GetRangeByIdx(q,-1);
	LS=GetAllUnExchgStr(T,Exchg);
	LE=GetAllUnExchgStr(LE,Exchg);
}

void DequXfer(DEQU_DB &QDB,MyStr &LL) {
//printf("\nInput LL(%s)",(char*)LL);
	ArrayNameStr Exchg;
	AddExchgLineCmtWithExSymBlk(LL,Exchg);
	AddExchgSymChrCmtWithExSymBlk(LL,Exchg);
	AddExchgSymBlkS(LL,Exchg);
	MyStr T(QDB.DEQU_Inside((char*)LL));
	if(T!="") {
		T=";@>"; T+=LL; T+='\n';
		T+=QDB.DEQU_xfer((char*)LL);
		LL=T.GetRangeWithWdCmpressExSymBlk('\n',_DEQUSYMA);
		DequXfer(QDB,LL);
	}
	LL=GetAllUnExchgStr(LL,Exchg);
//printf("\nOutput LL(%s)",(char*)LL);
}
void SpCtlWrite(FileObj &FO,const char *ll,int &LFcnt) { MyStr LL(ll); return SpCtlWrite(FO,LL,LFcnt); }
void SpCtlWrite(FileObj &FO,MyStr &LL,int &LFcnt) {
	MyStr S(LL.GetTrimA());
	if((int)S<1) { 
		if(++LFcnt>1) { LFcnt=1; return; }
	} else LFcnt=0;
	FO.FileWrite(LL);
}

int InsertCheckXferWrite(DEQU_DB &QDB,FnameObj &INF,FileObj &FO,MyStr &LL,int &LFcnt) {
	char line[StrMaxLen];
	FnameObj XNF;
	MyStr LS,LE,X;
	int s=0;
	
	DequXfer(QDB,LL);

	ArrayNameStr Exchg;
	MyStr LX=LL;
	
	AddExchgLineCmtWithExSymBlk(LX,Exchg);
	AddExchgSymBlk(LX,Exchg);
	AddExchgSymChrCmtWithExSymBlk(LX,Exchg);

	PickupInsertFileName(X,LS,LE,LX);
	//====== w/o INSERT comment =============
	if((int)X<1) { SpCtlWrite(FO,LL,LFcnt); return 0; }
	//======	Insert statement detect  ======
	if((int)LS>0) { LS=GetAllUnExchgStr(LS,Exchg); SpCtlWrite(FO,LS,LFcnt); }
	//----------------------------------------------------------------
	sprintf(line,"%s%s%s",INF.GetFilePath(),(char*)X,INF.GetFileAtt());
	XNF.NameSetByFullFileName(line);
	sprintf(line,";;;; insert(%s)\n",XNF.GetFileName());
	SpCtlWrite(FO,line,LFcnt);
	LX=""; s=0;
	s=FileXfer(QDB,XNF,FO,s,LX,LFcnt);
	if(s<0) return s;
	//------------------------------------------------------------------
	if((int)LE>0) { LS=GetAllUnExchgStr(LE,Exchg); SpCtlWrite(FO,LE,LFcnt); }
	return 0;
}

int FileXfer(DEQU_DB &QDB,FnameObj &INF,FileObj &FO,int &state,MyStr &FF,int &LFcnt) {
	tout out;
	char line[StrMaxLen];
	
	FnameObj XNF;
	FileObj FI(INF,_read_mode);
	if(!FI.IsFileExist()) { out.prt("\n\n Error ! file % not found !\n\n",FI.GetFullFileName()); return -1;}
	
	//FI.SetBuffer(StrMaxLen);
	if(FI.FileOpen()!=_reading) { out.prt("\n\n Error ! Open '%' for read fail !\n\n",FI.GetFullFileName()); return -1; }

	MyStr SYMA(_DEQUSYMA);
	
	long llnn=0;
	MyStr ErrMsg;
	MyStr LL,X,T,LX;
	MyStr LS,LE;
	ODequ QQ;
	
	Dequ DQ;
	DequCode r;
	ArrayNameStr Exchg;
		
	while(1) {
		
		if(FI.GetFileState()==_onclose) break;
		
		FI.FileRead(LL);
		llnn++;
		LL=LL.GetDos2Unix();
		LX=LL; Exchg.Reset();
		AddExchgLineCmtWithExSymBlk(LX,Exchg);
		AddExchgSymBlk(LX,Exchg);
		AddExchgSymChrCmtWithExSymBlk(LX,Exchg);
//out.prt("<%>%",state,(char*)LL);

		if(state<1) {
			//************************************
			//*	Not during DEQU load
			//************************************
			PO2 pp=DQ.GetPointOfDequContents(LX);
			if(pp.p1<0) {
				if(InsertCheckXferWrite(QDB,INF,FO,LL,LFcnt)<0) break;
				FF=""; continue;
			} else {
				if(pp.p2<0) { state++; FF=LL; continue; }	// not yet complete
				r=DQ.IsWellContents(LL);
				if(r==_well) {
					DQ.Setup(LL);
					T=LL.GetTrim();
					if((int)T>0) { if(InsertCheckXferWrite(QDB,INF,FO,LL,LFcnt)<0) break; }
					QDB.Add(DQ);  
					FF=""; continue;
				}
				sprintf(line,"\n Error ! file'%s'@line(%d)-> bad #dequ format , stop !\n",INF.GetFileName(),llnn);
				ErrMsg=line; break; 
			}
		} else {
			//************************************
			//*	During DEQU load
			//************************************
			FF+=LL;
			LX=FF; Exchg.Reset();
			AddExchgLineCmtWithExSymBlk(LX,Exchg);
			AddExchgSymBlk(LX,Exchg);
			AddExchgSymChrCmtWithExSymBlk(LX,Exchg);
			
			PO2 pp=DQ.GetPointOfDequContents(LX);
			if(pp.p2<0) {
				state++;
				if((int)FF>50000 || state>1000 ) {
					sprintf(line,"\n Error ! file'%s'@line(%d)-> #dequ over size , stop !\n",INF.GetFileName(),llnn);
					ErrMsg=line; break; 
				}
			    continue;
			} else {
				r=DQ.IsWellContents(FF);
				if(r==_well) {
					DQ.Setup(FF);
					T=FF.GetTrim();
					if((int)T>0) { 
						if(InsertCheckXferWrite(QDB,INF,FO,FF,LFcnt)<0) break;
					}
					QDB.Add(DQ);  
					state=0; continue;
				}
				sprintf(line,"\n Error ! file'%s'@line(%d)-> bad #dequ format , stop !\n",INF.GetFileName(),llnn);
				ErrMsg=line; break; 
			}
		}
	}
	
	if((int)ErrMsg>0) { 
		out << (char*) ErrMsg;
		FO.FileWrite(ErrMsg);
		return -1;
	}
	
	return 0;
}

void GetTimeStr(MyStr &RtnStr) {
	time_t now = time(0);
	tm *lt = localtime(&now);
	RtnStr=(1900+lt->tm_year);
	RtnStr+="/";
	RtnStr+=(1+lt->tm_mon);
	RtnStr+="/";
	RtnStr+=(lt->tm_mday);
	RtnStr+=" ";
	RtnStr+=(lt->tm_hour);
	RtnStr+=":";
	RtnStr+=(1+lt->tm_min);
	RtnStr+=":";
	RtnStr+=(1+lt->tm_sec);
}

int main (int ac , char ** av )
{
	tout out;
	if(ac<2 || ac>3) { usage(av[0]); exit(-1); }
	
	FnameObj INF(av[1]);
	if(!INF.IsFileExist()) { out.prt("\n\n!!! Error : file '%' not found !!!\n\n",INF.GetFullFileName()); exit(1); }

	FnameObj ONF;
	MyStr S,F;
	if(ac>2) S=av[2];
	
	if(ONF.IsPathExist((char*)S)) {
		//**********************************
		//	av[2] = output path
		//**********************************
		if( (int)S>0 && (S[(int)S-1]!=_SymDir) ) S+=_SymDir;
		F=S+INF.GetFileName();
		F=F.GetRangeWithWdDel(INF.GetFileAtt());
		//--------------------------------
		S=".asc";
		if(S==INF.GetFileAtt()) S=S+"2";
		F+=S;
		ONF.NameSetByFullFileName(F);
	} else {
		//**********************************
		//	av[2] = output file
		//**********************************
		ONF.NameSetByFullFileName(S);
	}
	
	if(!ONF.IsPathExist()) {
		out.prt("\n\n!!! Error : output path '%' not found !!!!\n\n",ONF.GetFilePath()); exit(1); 
	}

	MyStr DateTime;
	GetTimeStr(DateTime);
		
	char line[StrMaxLen];
			
	printf("\n## Transfer '%s' with INSERTed *%s to '%s' ##\n",INF.GetFullFileName(),INF.GetFileAtt(),ONF.GetFullFileName());

	sprintf(line,"%s.dequ",ONF.GetFullFileName());
	DEQU_DB QDB(line);

	FileObj FO(ONF,_write_mode);
	if(FO.FileOpen()!=_writing) { out.prt("\n\n!!! Error : Open '%' for write fail !!!\n\n",FO.GetFullFileName()); return -1; }

	sprintf(line,";This file converted from %s %s by %s %s_%s\n",INF.GetFileName(),(char*)DateTime,av[0],__SYS__,__PgmVer__);

	int state=0;
	int LFcnt=0;
	SpCtlWrite(FO,line,LFcnt);

	MyStr DEQBUF;
	LFcnt=FileXfer(QDB,INF,FO,state,DEQBUF,LFcnt);
	FO.FileClose();
	
	if(LFcnt==0) 	printf("\n>> Transfer to '%s' complete !",FO.GetFullFileName());

	sprintf(line,"%s.s",FO.GetFullFileName());
	QDB.DB_foutput(line);
	printf("\n>> Generated macro DB file '%s'\n",line);
	
	if(access(QDB.GetDBfile(),F_OK)==0) {
#ifdef _DOS_
		sprintf(line,"del %s",QDB.GetDBfile());
#else
		sprintf(line,"rm %s",QDB.GetDBfile());
#endif
//	    system(line);
	}

    exit(0);
}
