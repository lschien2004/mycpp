#include <iostream>
#include "mystr.h"

namespace mystd {
	
 class tout {
  public:
  	void printf(const char *format);
  	template<typename T0, typename... Targs0> void printf(const char* format, T0 value, Targs0... Fargs);
  	tout& operator<<(const int i);
  	tout& operator<<(const long l);
  	tout& operator<<(const char *s);
  	tout& operator<<(const char c);
  	tout& operator<<(MyStr &S);
 };
 
 tout& tout::operator<<(const int i){ tout::printf("%",i); return *this; }
 tout& tout::operator<<(const long l){ tout::printf("%",l); return *this; }
 tout& tout::operator<<(const char *s){ tout::printf("%",s); return *this; }
 tout& tout::operator<<(MyStr &S){ tout::printf("%",(char*)S); return *this; }
 
 void tout::printf(const char *format) { std::cout << format; }
 template<typename T1, typename... Targs1>
 void tout::printf(const char* format, T1 value, Targs1... Fargs)
 {
/*	MyStr S(format);
	if((int)S>0) {
		int p=S.InStr('%');
		if(p<0){ std::cout << (char*)S; return; }
		if(p>0) {
			if(S[p-1]=='/') {
				if(p>1) std::cout << S.GetRangeByIdx(0,p-2);
				std::cout << S[p];
				return tout::printf(format+p+1,value,Fargs...);
			}
			std::cout << S.GetRangeByIdx(0,p-1);
		}
		std::cout << value;
		return tout::printf(format+p+1,Fargs...);
	}
*/
 	for (;*format != '\0'; format++){
 		if(*format=='/' && *(format+1)=='%') { 
 			std::cout<<*(format+1); 
 			return tout::printf(format+2,value,Fargs...); 
 		}
 		else if(*format=='%') { 
 			std::cout << value;
 			return tout::printf(format+1,Fargs...); 
 		}
 		std::cout<<*format;
 	}
 }

}

using namespace mystd;

int main()
{
	MyStr S("Hello word");
	tout out;
	//out << "\n\n" << S << "!" << 123;
	out.printf("\n/%%%%%",(char*)S,'!',123);
	out.printf("\n/%%%/%/%%%",(char*)S,'!',123,-5);
 /*
    tprintf("% world% %\n","Hello",'!',123);
    tprintf("% world% %\n","Hello",'!');
    tprintf("%%% world% %\n","Hello",'!',123);
*/
    return 0;
}

