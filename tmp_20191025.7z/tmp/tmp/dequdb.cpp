#include "dequdb.h"

static MyStr TmpStr;

void AddExchgLineCmtWithExSymBlk(MyStr &LL,ArrayNameStr &Exchg) {
	PO2 pp;
	pp.p1=LL.InStrExSymBlk(_DEQULCMT,_DEQUSYMS);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		pp.p2=LL.InStrExSymBlk(pp.p1,"\n",_DEQUSYMS);
		MyStr T(".~cl"); T+=n; T+="~.";
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2-1));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp.p1=LL.InStrExSymBlk(_DEQULCMT,_DEQUSYMS);
	}
}
void AddExchgSymChrCmtWithExSymBlk(MyStr &LL,ArrayNameStr &Exchg) {
	PO2 pp;
	pp.p1=LL.InStrExSymBlk(_DEQUCMTC,_DEQUSYMS);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		pp.p2=pp.p1+1;
		MyStr T(".~cc"); T+=n; T+="~.";
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp.p1=LL.InStrExSymBlk(_DEQUCMTC,_DEQUSYMS);
	}
}
void AddExchgSymBlk(MyStr &LL,ArrayNameStr &Exchg) {	
	PO2 pp;
	pp=LL.SymBlkIdxInStr(0,-1,_DEQUSYMS);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		MyStr T(".~sm"); T+=n; T+="~.";
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp=LL.SymBlkIdxInStr(0,-1,_DEQUSYMS);
	}
}
const char *GetUnExchgStrByExkey(MyStr &LL,ArrayNameStr &Exchg,const char *Exkey) {
	TmpStr=LL; MyStr K(Exkey);
	if((int)K>0) {
		for(int n=Exchg.GetArrayCnt()-1;n>-1;n--) {
			if(WdIdxInStr(Exchg[n].GetName(),(char*)K)>-1)
				TmpStr=TmpStr.GetRangeWithWdChg(Exchg.GetNameByIdx(n),(char*)Exchg[n]);
		}
	} else {
		for(int n=Exchg.GetArrayCnt()-1;n>-1;n--) {
			TmpStr=TmpStr.GetRangeWithWdChg(Exchg.GetNameByIdx(n),(char*)Exchg[n]);
		}
	}
	return (char*)TmpStr;
}
int CheckExkeyInside(MyStr &LL,const char *exkey) {
	MyStr K(exkey); if((int)K<1) return -1; else return LL.InStr(K); 
}
const char *GetLineCmtUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { return GetUnExchgStrByExkey(LL,Exchg,".~cl"); }
const char *GetSymChrCmtUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { return GetUnExchgStrByExkey(LL,Exchg,".~cc"); }
const char *GetSymBlkUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { return GetUnExchgStrByExkey(LL,Exchg,".~sm"); }
const char *GetAllUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { return GetUnExchgStrByExkey(LL,Exchg,""); }

//##################################################################
//				SDequ	SDequ	SDequ	SDequ	
//##################################################################

void SDequ::Reset(void) { NAS.Reset(); BDY=""; }
	
//##################################################################
//				Dequ	Dequ	Dequ	Dequ	
//##################################################################
void Dequ::Reset(void) {
	SDequ::Reset(); Exchg.Reset(); 
	OutputStr="";	BDY="";
}

const char* Dequ::GetName(void) { return NAS.GetName(); }
int Dequ::GetParaCnt(void) { return NAS.GetArrayCNT(); }
const char *Dequ::GetParaList(void) { return NAS.List(','); }
const char *Dequ::GetBody(void) { return (char*)BDY; }

void Dequ::ExchgAddLineCmt(MyStr &LL) 				{ return AddExchgLineCmtWithExSymBlk(LL,Exchg); }
void Dequ::ExchgAddSymChrCmt(MyStr &LL) 			{ return AddExchgSymChrCmtWithExSymBlk(LL,Exchg); }
void Dequ::ExchgAddSymBlk(MyStr &LL) 				{ return AddExchgSymBlk(LL,Exchg); }

const char *Dequ::GetUnExchgAll(MyStr &LL) 			{ return GetAllUnExchgStr(LL,Exchg); }

PO2  Dequ::GetPointOfDequContents(MyStr &LL) {
	PO2 pp=LL.GetPointOfStackPairKey(_DEQUKEY,_DEQUBDYED);
	return pp;
}

int Dequ::ExchgInStr(MyStr &LL) { return CheckExkeyInside(LL,".~"); }

DequCode Dequ::WellNameRuleCheck(MyStr &NM) {
	if((int)NM>0 && ExchgInStr(NM)<0) {
		if(NM.LowerCaseInside()>0) return _well;
		for(int n=0;n<(int)NM;n++) {
			if(WdIdxInStr(_DEQUNAME_exack_chars,NM[n])>-1) return _well;
		}
		return _err_namerule;
	}
	return _err_name;
}

DequCode Dequ::IsWellDefinition(MyStr &LL) {
	ArrayNameStr TmpExchg;
	MyStr FF(LL);
	//--------------------------------------------------------------------
	AddExchgLineCmtWithExSymBlk(FF,TmpExchg);
	AddExchgSymChrCmtWithExSymBlk(FF,TmpExchg);
	AddExchgSymBlk(FF,TmpExchg);
	PO2 pp=GetPointOfDequContents(FF);
	if(pp.p1<0) return _none;			//error format : no #dequ found
	if(pp.p2<0) return _err_body;		//error format : no }} found
	//--------------------------------------------------------------------
	FF=FF.GetRangeByIdx(pp.p1,pp.p2);
	FF=FF.GetRangeWithWdChg('\t',' ');
	MyStr T(_DEQUKEY); T+=' ';
	int p=FF.InStr(T);
	if(p<0) return _err_name;			//error format :  #dequ+<space> or #dequ+<tab>
	//--------------------------------------------------------------------
	p+=(int)T;
	FF=FF.GetRangeByIdx(p,(int)FF-strlen(_DEQUBDYED)-1);
	FF=FF.GetLineTrim();
	
	int k=FF.InStr(_DEQUBDYST);
	if(k<0) return _err_body;						//error format : '{{' missing
	if(k<1) return _err_name;						//error format : NAME missing

	MyStr PA,BDY;
	int q1=FF.InStr(-1,k-1,_DEQUPARST);
	int q2=FF.InStr(-1,k-1,_DEQUPARED);
	//--------------------------------------------------------------------
	if(q1>-1 && q2<0) 	return _err_para;			//error format : parameter > missing before {{
	if(q1<0  && q2>-1) 	return _err_para;			//error format : parameter < missing before {{
	if(q1>-1) { 
		T=FF.GetRangeByIdx(-1,q1-1);
		PA=FF.GetRangeByIdx(q1+1,q2-1);
		PA=PA.GetLineTrimA();
	} else T=FF.GetRangeByIdx(-1,k-1); 
	T=T.GetTrim();
	//--------------------------------------------------------------------
	DequCode r=WellNameRuleCheck(T);
	if(r!=_well) return r;							//error format : NAME MUST w/i LowCase or exack chars
	//--------------------------------------------------------------------
	if(ExchgInStr(PA)>-1) return _err_para;			//error format : Parameters w/i Exchg contents
	//--------------------------------------------------------------------
	k+=strlen(_DEQUBDYST);
	BDY=FF.GetRangeByIdx(k,-1);
	BDY=BDY.GetLineTrim();
	BDY=GetAllUnExchgStr(BDY,TmpExchg);
	//--------------------------------------------------------------------	
	pp=GetPointOfDequContents(BDY);
	if(pp.p1<0 && pp.p2<0) return _well;
	if(pp.p1>-1 && pp.p2>pp.p1) return IsWellDefinition(BDY);
	return _err_body;								//error format : bad #dequ inside
}


DequCode Dequ::WellDefinition(Dequ &ODQ) {
//printf("\n#ODQ.InputStr=[%s]",(char*)ODQ.InputStr);
	ODQ.Reset();	MyStr FF(ODQ.InputStr);	
	//--------------------------------------------------------------------
	AddExchgLineCmtWithExSymBlk(FF,ODQ.Exchg);
	AddExchgSymChrCmtWithExSymBlk(FF,ODQ.Exchg);
	AddExchgSymBlk(FF,ODQ.Exchg);
	PO2 pp=GetPointOfDequContents(FF);
//printf("\npp.p1=%d pp.p2=%d",pp.p1,pp.p2);
	if(pp.p1<0) return _none;		//error format : no #dequ found
	if(pp.p2<0) return _err_body;	//error format : no }} found
	//--------------------------------------------------------------------
	if(pp.p1>0)	ODQ.OutputStr=FF.GetRangeByIdx(-1,pp.p1-1);
	ODQ.OutputStr+=FF.GetRangeByIdx(pp.p2+1,-1);
	ODQ.OutputStr=GetAllUnExchgStr(ODQ.OutputStr,ODQ.Exchg);
//printf("\n#ODQ.OutputStr=[%s]",(char*)ODQ.OutputStr);
	//--------------------------------------------------------------------
	FF=FF.GetRangeByIdx(pp.p1,pp.p2);
	MyStr S(FF.GetRangeWithWdChg('\t',' '));
	MyStr T(_DEQUKEY); T+=' ';
	int p=S.InStr(T);
	if(p<0) return _err_name;			//error format :  #dequ+<space> or #dequ+<tab>
	//--------------------------------------------------------------------
	p+=(int)T;
	FF=FF.GetRangeByIdx(p,(int)FF-strlen(_DEQUBDYED)-1);
	FF=FF.GetLineTrim();

	int k=FF.InStr(_DEQUBDYST);
	if(k<0) return _err_body;						//error format : '{{' missing

	MyStr PA;
	int q1=FF.InStr(-1,k-1,_DEQUPARST);
	int q2=FF.InStr(-1,k-1,_DEQUPARED);
	//--------------------------------------------------------------------
	if(q1>-1 && q2<0) 	return _err_para;			//error format : parameter > missing before {{
	if(q1<0  && q2>-1) 	return _err_para;			//error format : parameter < missing before {{
	if(q1>-1) { 
		S=FF.GetRangeByIdx(-1,q1-1); S=S.GetTrim();
		PA=FF.GetRangeByIdx(q1+1,q2-1);
		PA=PA.GetLineTrimA();
	} else {
		S=FF.GetRangeByIdx(-1,k-1); S=S.GetTrim();
	}
	//--------------------------------------------------------------------
	DequCode r=WellNameRuleCheck(S);
	if(r!=_well) return r;	//error format : NAME MUST w/i LowCase or exack chars
	ODQ.NAS.SetName(S);
	//--------------------------------------------------------------------
	if(ExchgInStr(PA)>-1) return _err_para;			//error format : Parameters w/i Exchg contents
	//--------------------------------------------------------------------
	k+=strlen(_DEQUBDYST);
	ODQ.BDY=FF.GetRangeByIdx(k,-1);
	ODQ.BDY=ODQ.BDY.GetLineTrim();
	ODQ.BDY=GetAllUnExchgStr(ODQ.BDY,ODQ.Exchg);
	//--------------------------------------------------------------------	
//printf("\n#PA=[%s]",(char*)PA);
	if((int)PA>0) {
		PA+=","; k=0; q1=0;
		p=PA.InStr(k,",");
		while(p>-1) {
			q1++;
			if(p>0) S=PA.GetRangeByIdx(k,p-1);
			else	S=q1;
			ODQ.NAS+=S;
			k=p+1;
			p=PA.InStr(k,",");
		}
	}
	//--------------------------------------------------------------------	
	pp=GetPointOfDequContents(ODQ.BDY);
	if(pp.p1<0 && pp.p2<0) return _well;
	if(pp.p1>-1 && pp.p2>pp.p1) return IsWellDefinition(ODQ.BDY);
	return _err_body;								//error format : bad #dequ inside
}

DequCode Dequ::Setup(MyStr &LL) {
	Dequ ODQ;
	ODQ.InputStr=LL;
	DequCode rcode=WellDefinition(ODQ);
	if(rcode==_well) {
		NAS=ODQ.NAS;
		BDY=ODQ.BDY;
		Exchg=ODQ.Exchg;
		LL=ODQ.OutputStr;
	}
	return rcode;
}

const char *Dequ::GetErrMessage(DequCode r){
	switch (r) {
		case _well:
			tmp="";
			break;
		case _none:
			tmp="No DEQU defintion !";
			break;
		case _err_name:
			tmp="! Error : bad DEQU name format !";
			break;
		case _err_namerule:
			tmp="! Error : DEQU name rule (w/o lcase or exack chars) !";
			break;
		case _err_para:
			tmp="! Error : DEQU parameter < > missing !";
			break;
		case _err_body:
			tmp="! Error : DEQU body {{ }} missing !";
			break;
		default:
			tmp="! Error : Unknow DEQU format problem !";
			break;
	}
	return (char*)tmp;
}


