#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>    //printf
#include <stdlib.h>   //malloc
#include <string.h>   //strncpy
#include <unistd.h>   //close
#include <iostream>
#include <ctime>

#include "mystd.h"

#include "sstr.h"

class NameSStr : public SStr {
protected:
			char	*name;
public:
			NameSStr();
			NameSStr(const char *nm,const char *s);
			NameSStr(const char *nm,const char c);
			
			~NameSStr();
			
			void	SetName(const char *nm);
	const 	char	*GetName(void);
			
			void 	operator=(const NameSStr &NS);
			
	virtual	void 	operator=(const char c);
	virtual	void	operator=(const int i);
	virtual	void	operator=(const long l);
	virtual	void 	operator=(const char *s);
	virtual	void	operator=(const SStr &S);

};

NameSStr::NameSStr(){ name=Emptystr; }
NameSStr::NameSStr(const char *nm,const char c){
	SStr Tmp(c);
	str=Emptystr; 		name=Emptystr; 
	resize(Tmp);		resizeX(&name,nm);
}
NameSStr::NameSStr(const char *nm,const char *s){ 
	str=Emptystr; 		name=Emptystr; 
	resize(s);			resizeX(&name,nm);
}
NameSStr::~NameSStr(){ releaseX(&name); }

void NameSStr::SetName(const char *nm){ resizeX(&name,nm); }
const char *NameSStr::GetName(void){ return name; }

void NameSStr::operator=(const NameSStr &NS){ SetName(NS.name); resize(NS.str); }
void NameSStr::operator=(const char c){ SStr::operator=(c); }
void NameSStr::operator=(const int i){ SStr::operator=(i); }
void NameSStr::operator=(const long l){ SStr::operator=(l); }
void NameSStr::operator=(const char *s){ SStr::operator=(s); }
void NameSStr::operator=(const SStr &S){ SStr::operator=(S); }


int main(int ac,char **av) {
	tout out;
	SStr S("I'm SStr");
	out.prt("\n% len=%",(char*)S,(int)S);
	S+=" , Hello world!";
	out.prt("\n% len=%",(char*)S,(int)S);
	S="Bye Bye!";
	out.prt("\n% len=%",(char*)S,(int)S);
	
	NameSStr NS("NameSStr-A","I'm NameSStr");
	NS=S;
	NS+=S;
	NS+=500;
	out.prt("\nNS.name=\"%\" NS.str=\"%\" len=%",NS.GetName(),(char*)NS,(int)NS);

	return 0;
}
