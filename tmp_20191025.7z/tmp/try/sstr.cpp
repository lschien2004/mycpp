#include "sstr.h"

char SStr::Emptystr[2] = "";

const char *SStr::resize(SStr &IStr){ resizeX(&str,(char*)IStr); len=strlen(str); return str;}
const char *SStr::resize(const char *istr){ resizeX(&str,istr); len=strlen(str); return str;}
const char *SStr::resizeX(char **pstr,const char *istr){
	int ll=0;
	if(*pstr==NULL) *pstr=Emptystr;
	else			ll=strlen(*pstr);
	int ii=0;
	if(istr!=NULL) ii=strlen(istr);
	if(ii!=ll) {
		if(*pstr!=Emptystr) delete [] *pstr;
		if(ii<1)	*pstr=Emptystr;
		else		*pstr=strdup(istr);
	} else if(ii>0) 	strcpy(*pstr,istr);
	return *pstr;
}
void SStr::release(void){ releaseX(&str); len=0; }
void SStr::releaseX(char **pstr){ 
	if(*pstr!=Emptystr) delete [] *pstr; 
	*pstr=Emptystr;
}

SStr::SStr(){ str=Emptystr; len=0; }
SStr::SStr(const char c){ char s[2]; s[0]=c; s[1]='\0'; str=Emptystr; resize(s); }
SStr::SStr(const char* s){ str=Emptystr; resize(s); }
SStr::~SStr(){ resizeX(&str,NULL); }

SStr::operator int(){ return len; }
SStr::operator char*(){ return str; }
SStr::operator const char*(){ return str; }

void SStr::operator=(const char c){ char s[2]; s[0]=c; s[1]='\0'; resize(s); }
void SStr::operator=(const int i){ char s[32]; sprintf(s,"%d",i); resize(s); }
void SStr::operator=(const long l){ char s[32]; sprintf(s,"%ld",l); resize(s); }
void SStr::operator=(const char *s){ resize(s); }
void SStr::operator=(const SStr &S){ resize(S.str); }

void SStr::operator+=(const char c){ char s[2]; s[0]=c; s[1]='\0'; operator+=(s); }
void SStr::operator+=(const int i){ char s[32]; sprintf(s,"%d",i); operator+=(s); }
void SStr::operator+=(const long l){ char s[32]; sprintf(s,"%ld",l); operator+=(s); }
void SStr::operator+=(const SStr &S){ operator+=(S.str); }
void SStr::operator+=(const char *s){
	if(s!=NULL) {
		int ls=0;
		if(s!=NULL) ls=strlen(s);
		if(ls>0) {
			ls+=len;
			char *t=new char[ls+1];
			strncpy(t,str,len);
			strcpy(t+len,s);
			release();
			str=t; len=strlen(str);
		}
	}
}
