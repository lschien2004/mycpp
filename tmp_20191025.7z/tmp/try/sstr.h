
#ifndef __SStr__h__
    #define __SStr__h__
	#define __SStrVer__	"SStr-v1.0@20191026"
	
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <iostream>

class SStr {
protected:
	static 	char 	Emptystr[];
	
			char 	*str;
			int 	len;
			
	const 	char	*resizeX(char **pstr,const char *istr);
	const 	char	*resize(const char *istr);
	const 	char	*resize(SStr &IStr);
			void 	releaseX(char **pstr);
			void	release(void);
public:
			SStr();
			SStr(const char c);
			SStr(const char *s);

			~SStr();
			
	virtual			operator int();			
	virtual			operator const char*();
	virtual			operator char*();
	
	virtual	void 	operator=(const char c);
	virtual	void	operator=(const int i);
	virtual	void	operator=(const long l);
	virtual	void 	operator=(const char *s);
	virtual	void	operator=(const SStr &S);

	virtual	void 	operator+=(const char c);
	virtual	void	operator+=(const int i);
	virtual	void	operator+=(const long l);
	virtual	void 	operator+=(const char *s);
	virtual	void 	operator+=(const SStr &S);
	
};

#endif
