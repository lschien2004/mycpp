#include "mystr.h"
#include "namestr.h"
#include "arraystr.h"
#include "arraynamestr.h"
#include "namearraystr.h"
#include "mystd.h"

#define DEQUKEY    		"#dequ"
#define DEQUPARST  		'<'
#define DEQUPARED  		'>'
#define DEQUBDYST  		"{{"
#define DEQUBDYED  		"}}"
#define DEQUSYMS   		"?\""			// Parameter , body : SymS+data+SymS <- ���B�z
#define DEQUSYMX   		"'`" 			// Xfer�ɳB�z Parameter : SymX+data+SymX <- data ���B�z,SymX�h���ᵹBody�Axfer.
#define DEQULCMT   		';'
#define DEQUCMTC   		'@'
#define DEQUBDYVPAST 	'$'
#define DEQUBDYVPAED 	'$'

class Dequ {
private:
	MyStr			tmp;
public:
	MyStr			Src;
	NameArrayStr	me;
	MyStr			RawBDY;
	MyStr		    BDY;
	ArrayNameStr	Exchg;
//	void LoadDequContent(MyStr &LL,MyStr &LS,MyStr &LE);
//	Dequ& operator=(MyStr &LL);
};


int main(int ac,char **av) {
	tout out; 
	Dequ DQ;
	

	exit(0);
}
