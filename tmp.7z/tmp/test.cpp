#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>    //printf
#include <stdlib.h>   //malloc
#include <string.h>   //strncpy
#include <unistd.h>   //close
#include <iostream>
#include <ctime>

#include "mystr.h"
#include "namestr.h"
#include "arraystr.h"
#include "arraynamestr.h"
#include "namearraystr.h"
#include "dequdb.h"
#include "mystd.h"

#define __ATLXferVer__ "ATLxfer-v2.0@20191024"

#define __Author__ "L.S Chien"

#define _DOS_

#ifdef _DOS_
	#define __SYS__ "DOS"
    #define SymPath  '\\'
#else
	#define __SYS__ "UNIX"
    #define SymPath  '/'
#endif

#define FileInsertStatement "INSERT"

#define StrMaxLen 256


//########################################
//		Global Variables
//========================================
MyStr iatt,oatt;
MyStr IDIR,ODIR;
//########################################

const char *GetTimeStr(void) {
	time_t now = time(0);
	tm *lt = localtime(&now);
	MyStr DateTime;
	DateTime=(1900+lt->tm_year);
	DateTime+="/";
	DateTime+=(1+lt->tm_mon);
	DateTime+="/";
	DateTime+=(lt->tm_mday);
	DateTime+=" ";
	DateTime+=(1+lt->tm_hour);
	DateTime+=":";
	DateTime+=(1+lt->tm_min);
	DateTime+=":";
	DateTime+=(1+lt->tm_sec);
	return (char*)DateTime;
}

void usage(char *pgmname)
{
	tout out;
	 out << "\n";
	 out << "##################################################################" << "\n";
	 out << "[[[ ATLxfer "<<__SYS__<<" "<<__ATLXferVer__<<" By "<<__Author__<< " ]]]" << "\n";
	 out << " Related lib : "<<__MyStdVer__<<" "<<__DequDBVer__<<"\n";
	 out << "               "<<__MyStrVer__<<" "<<__NameStrVer__<<"\n";
	 out << "               "<<__ArrayStrVer__<<" "<<__ArrayNameStrVer__<<"\n";
	 out << "               "<<__NameArrayStrVer__<<"\n";
	 out << "==================================================================" << "\n";
	 out << "     This tool is used to covert the source files which writed with " << "\n";
	 out << _DEQUKEY <<" macro to a .asc file for ADV tester's compiler ." << "\n\n";
	 out << "Usage : " << pgmname << "  main_src_file  [output_path]" << "\n";
	 out << "       >> w/o output_path input -> output in current path ." << "\n\n";
	 out << "    Ex : " << pgmname << " wtmain.src ASCDIR" << "\n";
	 out << "       >> Transfer wtmain.src to ASCDIR" << SymPath << "wtmain.asc" << "\n";
	 out << "    Ex : " << pgmname << " .."<< SymPath <<"wtmain.src" << "\n";
	 out << "       >> Transfer .." << SymPath << "wtmain.src to ." << SymPath << "wtmain.asc" << "\n\n";
	 out.prt("Note :\n");
	 out.prt("  1) All of inserted files must be lower-case file name !\n");
	 out.prt("  2) main_src_file and all of inserted files must be stored in\n");
	 out.prt("     the same path !\n");
	 out.prt("  3) All of inserted files' att_name must as same as the att_name\n");
	 out.prt("     of main_src_file !\n");
	 out.prt("     Ex: main_src_file is main.s , the insertd files must be *.s\n");
	 out.prt("  4) If main_src_file's att_name is .asc and output_path is same\n");
	 out.prt("     as main_src_file's path, then output file's att_name will\n");
	 out.prt("     change to be .asc2 \n");
	 out.prt("  5) If % macro are re-defined, the last loaded macro\n",_DEQUKEY);
	 out.prt("     before transfer will dominate !\n");
	 out.prt("  6) Name of % macro must exist at the least one lower-case\n",_DEQUKEY);
	 out.prt("     char .\n");
	 out.prt("##################################################################\n");
}


int main(int ac,char **av) {
	if(ac<2 || ac>3) { usage(av[0]); exit(-1); }
	
	tout out; 

	char line[StrMaxLen];	
	MyStr ifile,ofile;

	IDIR=av[1];
	ODIR='.';
	
	int n=IDIR.InStrRev(SymPath);
	if(n<0) { ifile=IDIR; IDIR='.'; IDIR+=SymPath; }
	else	{ ifile=IDIR.GetRangeByIdx(n+1,-1); IDIR=IDIR.GetRangeByIdx(-1,n); }
	
	n=ifile.InStrRev('.');
	if(n>-1) iatt=ifile.GetRangeByIdx(n,-1);
	ofile=ifile.GetRangeByIdx(-1,n);
	if(n<0) ofile+=".asc"; else ofile+="asc";

	if(ac>2) ODIR=av[2];
	n=ODIR.InStrRev(SymPath);
	if((int)ODIR!=n+1) ODIR+=SymPath;

	if(ifile==ofile && IDIR==ODIR) ofile+="2";
	
	out.prt("\n## Transfer '%s%s' with INSERTed *%s to '%s%s' ##",(char*)IDIR,(char*)ifile,(char*)iatt,(char*)ODIR,(char*)ofile);



	MyStr S;
	Dequ DQ;
	
	S+="@A@1 ;##### #dequ fun<TNO,QC> {{ TEST $TNO$ }} ###########\n";
	S+="@L@S 	#dequ 	_FUN <	TNO ,	QC > = {{ \n";
	S+="@A@1	TNO=$TNO$ & TEST $TNO$ ;;set tno\n";
	S+="@A@0	#dequ +QC$TNO$ {{$QC$}} EQUATE QC$TNO$ = \"$QC$\"\n";
	S+=" 		WRITE[1] \"TEST ?\",[1],TNO,\"?\"  ;; show TNO\n";
	S+="@A@0	GOSUB QCSET(QCN$TNO$) & GOTO CONT\n";
	S+="}} ;;tno setting";
	S=S.GetDos2Unix();
	out.prt("##line[\n%\n]",(char*)S);
	
	DequCode f=DQ.Setup(S);
	out.prt("\n\n##DQ.Name=[%]",DQ.GetName());
	out.prt("\n##DQ.Para[%]=<%>",DQ.GetParaCnt(),DQ.GetParaList());
	out.prt("\n##DQ.Body={%}",DQ.GetBody());

	if(f==_well) {
		out << "\n setup ok !\n";
	} else {
		out << "\n setup fail : " << DQ.GetErrMessage(f) << "\n";
	}
	exit(0);
}
