#include "mystr.h"
#include "namestr.h"
#include "arraystr.h"
#include "arraynamestr.h"
#include "namearraystr.h"
#include "mystd.h"

#define DEQUKEY    		"#dequ"
#define DEQUPARST  		'<'
#define DEQUPARED  		'>'
#define DEQUBDYST  		"{{"
#define DEQUBDYED  		"}}"
#define DEQUSYMS   		"?\""			// Parameter , body : SymS+data+SymS <- ¤£³B²z
#define DEQUSYMX   		"'`" 			// Xfer®ɳB²z Parameter : SymX+data+SymX <- data ¤£³B²z,SymX¥h±¼«ᵹBody¦Axfer.
#define DEQULCMT   		';'
#define DEQUCMTC   		'@'
#define DEQUBDYVPAST 	'$'
#define DEQUBDYVPAED 	'$'

class Dequ {
private:
	MyStr			tmp;
public:
	MyStr			Src;
	NameArrayStr	me;
	MyStr			RawBDY;
	MyStr		    BDY;
	ArrayNameStr	Exchg;
//	void LoadDequContent(MyStr &LL,MyStr &LS,MyStr &LE);
//	Dequ& operator=(MyStr &LL);
};


int main(int ac,char **av) {
	tout out; 
	ArrayNameStr Exchg;
	NameStr NS;
	MyStr S,T;
	PO2 PP;
	int n;
	
	S+="@A@1 ;##### #dequ fun<TNO> {{ TEST $TNO$ }} ###########\n";
	S+="@L@S 	#dequ 	fun<TNO> 	{{ \n";
	S+="@A@1	TNO=$TNO$ & TEST $TNO$ ;;set tno\n";
	S+=" 		WRITE[1] \"TEST ?\",[1],TNO,\"?\"  ;; show TNO\n";
	S+=" }} ;;tno setting";
	S=S.GetDos2Unix();
	out.prt("##line[\n%\n]",(char*)S);
	MyStr S1(S);
	
	
	PP=S1.SymBlkIdxInStr(0,-1,DEQUSYMS);
	n=0;
	while(PP.p1>-1) {
		n++;
		T=".~sm"; T+=n; T+="~.";
		NS.SetName(T); NS=S1.GetRangeByIdx(PP.p1,PP.p2);
		Exchg+=NS;
		S1=S1.GetRangeWithWdChg((char*)NS,(char*)T);
		PP=S1.SymBlkIdxInStr(0,-1,DEQUSYMS);
	}
	out.prt("\n##S1[\n%\n]\n",(char*)S1);	
	for(n=0;n<Exchg.GetArrayCnt();n++) out.prt("\n[%]=[%]->[%]",n,Exchg.GetNameByIdx(n),Exchg.GetStrByIdx(n));
	
	PP.p1=S1.InStrExSymBlk(DEQULCMT,DEQUSYMS);
	n=0;
	while(PP.p1>-1) {
		n++;
		T=".~cl"; T+=n; T+="~.";
		NS.SetName(T); 
		PP.p2=S1.InStrExSymBlk(PP.p1,"\n",DEQUSYMS);
		NS=S1.GetRangeByIdx(PP.p1,PP.p2);
		Exchg+=NS;
		S1=S1.GetRangeWithWdChg((char*)NS,(char*)T);
		PP.p1=S1.InStrExSymBlk(DEQULCMT,DEQUSYMS);
	}
	out.prt("\n##S1[\n%\n]\n",(char*)S1);	
	for(n=0;n<Exchg.GetArrayCnt();n++) out.prt("\n[%]=[%]->[%]",n,Exchg.GetNameByIdx(n),Exchg.GetStrByIdx(n));

	n=0;
	PP.p1=S1.InStrExSymBlk(DEQUCMTC,DEQUSYMS);
	while(PP.p1>-1) {
		n++;
		T=".~cc"; T+=n; T+="~.";
		NS.SetName(T); 
		PP.p2=PP.p1+1;
		NS=S1.GetRangeByIdx(PP.p1,PP.p2);
		Exchg+=NS;
		S1=S1.GetRangeWithWdChg((char*)NS,(char*)T);
		PP.p1=S1.InStrExSymBlk(DEQUCMTC,DEQUSYMS);
	}
	out.prt("\n##S1[\n%\n]\n",(char*)S1);	
	for(n=0;n<Exchg.GetArrayCnt();n++) out.prt("\n[%]=[%]->[%]",n,Exchg.GetNameByIdx(n),Exchg.GetStrByIdx(n));

	//======= Uncompress back ==========
	for(n=Exchg.GetArrayCnt()-1;n>-1;n--) {
		S1=S1.GetRangeWithWdChg(Exchg.GetNameByIdx(n),(char*)Exchg[n]);
	}
	out.prt("\n\n##S1[\n%\n]\n",(char*)S1);
	exit(0);
}
