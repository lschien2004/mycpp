#include "mystr.h"
#include "namestr.h"
#include "arraystr.h"
#include "arraynamestr.h"
#include "namearraystr.h"
#include "dequdb.h"
#include "mystd.h"

int main(int ac,char **av) {
	tout out; 
	NameStr NS;
	MyStr S,T;
	PO2 pp;
	int n;
	Dequ DQ;
	
	S+="@A@1 ;##### #dequ fun<TNO,QC> {{ TEST $TNO$ }} ###########\n";
	S+="@L@S 	#dequ 	fun<	TNO ,	QC > = {{ \n";
	S+="@A@1	TNO=$TNO$ & TEST $TNO$ ;;set tno\n";
	S+="@A@0	#dequ qc$TNO$ {{$QC$}} EQUATE QC$TNO$ = \"$QC$\"\n";
	S+=" 		WRITE[1] \"TEST ?\",[1],TNO,\"?\"  ;; show TNO\n";
	S+="@A@0	GOSUB QCSET(QCN$TNO$) & GOTO CONT\n";
	S+="}} ;;tno setting";
	S=S.GetDos2Unix();
	out.prt("##line[\n%\n]",(char*)S);
	
	bool f=DQ.Setup(S);
	out.prt("\n\n##DQ.Name=[%]",DQ.NAS.GetName());
	out.prt("\n##DQ.Para=<%>",DQ.NAS.List());
	out.prt("\n##DQ.Body=<%>",(char *)DQ.BDY);

	if(f) {
		out << "\n setup ok !\n";
	} else {
		out << "\n setup fail !\n";
	}
	exit(0);
}
