#include "strarray.h"

int main(int ac,char **av) {
	int n;
	
	MyStr S("S-1");
	StrArray SA(S);
	printf("\nSA.GetCNT()=%d",SA.GetCNT());
	n=0; printf("\nSA[%d]='%s' GetSTR(%d)='%s'",n,(char*)SA[n],n,SA.GetSTR(n));
	printf("\nSA.List()=%s",SA.List());
	printf("\nSA.GetSNO('%s')=%d",(char*)S,SA.GetSNO(S));

	S="S-2";
	SA.Add(S);
	printf("\nSA.GetCNT()=%d",SA.GetCNT());
	n=0; printf("\nSA[%d]='%s' GetSTR(%d)='%s'",n,(char*)SA[n],n,SA.GetSTR(n));
	n=1; printf("\nSA[%d]='%s' GetSTR(%d)='%s'",n,(char*)SA[n],n,SA.GetSTR(n));
	printf("\nSA.List()=%s",SA.List());
	printf("\nSA.GetSNO('%s')=%d",(char*)S,SA.GetSNO(S));

	n=SA.Add("S-3");
	printf("\nSA.Add('S-3')=%d",n);
	printf("\nSA.GetCNT()=%d",SA.GetCNT());
	n=0; printf("\nSA[%d]='%s' GetSTR(%d)='%s'",n,(char*)SA[n],n,SA.GetSTR(n));
	n=1; printf("\nSA[%d]='%s' GetSTR(%d)='%s'",n,(char*)SA[n],n,SA.GetSTR(n));
	n=2; printf("\nSA[%d]='%s' GetSTR(%d)='%s'",n,(char*)SA[n],n,SA.GetSTR(n));
	printf("\nSA.List()=%s",SA.List());
	printf("\nSA.GetSNO('%s')=%d",(char*)S,SA.GetSNO(S));

	S="S-4";
	SA+=S;
	printf("\nSA.GetCNT()=%d",SA.GetCNT());
	n=0; printf("\nSA[%d]='%s' GetSTR(%d)='%s'",n,(char*)SA[n],n,SA.GetSTR(n));
	n=1; printf("\nSA[%d]='%s' GetSTR(%d)='%s'",n,(char*)SA[n],n,SA.GetSTR(n));
	n=2; printf("\nSA[%d]='%s' GetSTR(%d)='%s'",n,(char*)SA[n],n,SA.GetSTR(n));
	n=3; printf("\nSA[%d]='%s' GetSTR(%d)='%s'",n,(char*)SA[n],n,SA.GetSTR(n));
	printf("\nSA.List()=%s",SA.List());
	printf("\nSA.GetSNO('%s')=%d",(char*)S,SA.GetSNO(S));

	SA+="S-5";
	printf("\nSA.GetCNT()=%d",SA.GetCNT());
	n=0; printf("\nSA[%d]='%s' GetSTR(%d)='%s'",n,(char*)SA[n],n,SA.GetSTR(n));
	n=1; printf("\nSA[%d]='%s' GetSTR(%d)='%s'",n,(char*)SA[n],n,SA.GetSTR(n));
	n=2; printf("\nSA[%d]='%s' GetSTR(%d)='%s'",n,(char*)SA[n],n,SA.GetSTR(n));
	n=3; printf("\nSA[%d]='%s' GetSTR(%d)='%s'",n,(char*)SA[n],n,SA.GetSTR(n));
	n=4; printf("\nSA[%d]='%s' GetSTR(%d)='%s'",n,(char*)SA[n],n,SA.GetSTR(n));
	printf("\nSA.List()=%s",SA.List());
	printf("\nSA.GetSNO('S-5')=%d",SA.GetSNO("S-5"));
	printf("\nSA.GetSNO('S-0')=%d",SA.GetSNO("S-0"));

	n=SA.Del("S-3");
	printf("\nSA.Del('S-3')=%d",n);
	printf("\nSA.GetCNT()=%d",SA.GetCNT());
	printf("\nSA.List()=%s",SA.List());
	
	n=SA.Del(1);
	printf("\nSA.Del(1)=%d",n);
	printf("\nSA.GetCNT()=%d",SA.GetCNT());
	printf("\nSA.List()=%s",SA.List());
	
	SA+="S-6";
	printf("\nSA.GetCNT()=%d",SA.GetCNT());
	printf("\nSA.List()=%s",SA.List());

	
	
	exit(0);
}
