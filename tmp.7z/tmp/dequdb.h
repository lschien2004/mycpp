/*##############################################################################################
	v1.0@20191023	new dequ lib
################################################################################################*/
#ifndef __DequDB__h__
    #define __DequDB__h__
    #define __DequDBVer__	"DequDB-v1.0@20191023"


#include "mystr.h"
#include "namestr.h"
#include "arraystr.h"
#include "arraynamestr.h"
#include "namearraystr.h"
//#include "mystd.h"


#ifndef __DequDef__
    #define __DequDef__ 0

 #define _DEQUKEY    		"#dequ"
 #define _DEQUPARST  		'<'
 #define _DEQUPARED  		'>'
 #define _DEQUBDYST  		"{{"
 #define _DEQUBDYED  		"}}"
 #define _DEQUSYMS   		"?\""			// Parameter , body : SymS+data+SymS <- ?�G3B2z
 #define _DEQUSYMX   		"'`" 			// XferR?B2z Parameter : SymX+data+SymX <- data ?�G3B2z,SymX�Dh��???Body|Axfer.
 #define _DEQUSYMA   		"?\"'`" 		// SYMS+SYMX
 #define _DEQULCMT   		';'
 #define _DEQUCMTC   		'@'
 #define _DEQUBDYVPAST 		'$'
 #define _DEQUBDYVPAED 		'$'

#endif //#ifndef __DequDef__


void AddExchgLineCmtWithExSymBlk(MyStr &LL,ArrayNameStr &Exchg);
void AddExchgSymChrCmtWithExSymBlk(MyStr &LL,ArrayNameStr &Exchg);
void AddExchgSymBlk(MyStr &LL,ArrayNameStr &Exchg);

const char *GetUnExchgStrByExkey(MyStr &LL,ArrayNameStr &Exchg,const char *Exkey);

const char *GetLineCmtUnExchgStr(MyStr &LL,ArrayNameStr &Exchg);
const char *GetSymChrCmtUnExchgStr(MyStr &LL,ArrayNameStr &Exchg);
const char *GetSymBlkUnExchgStr(MyStr &LL,ArrayNameStr &Exchg);
const char *GetAllUnExchgStr(MyStr &LL,ArrayNameStr &Exchg);

int CheckExkeyInside(MyStr &LL,const char *exkey);

class OneDequ {
public:
	 MyStr			InputStr;
	 MyStr			OutputStr;
	 NameArrayStr	NAS;
	 MyStr		    BDY;
	 ArrayNameStr	Exchg;
	 
	 void 			Reset(void);
};

class Dequ {
private:
	 MyStr			tmp;
public:
	 NameArrayStr	NAS;
	 MyStr		    BDY;
	 ArrayNameStr	Exchg;

	 PO2     	 GetPointOfDequContents(MyStr &LL);
	 bool 		 WellFormatCheck(OneDequ &ODQ);
	 
	 int 		 ExchgInStr(MyStr &LL);
	 bool 		 Setup(MyStr &LL);

	 void 		 ExchgAddLineCmt(MyStr &LL);
	 void 		 ExchgAddSymChrCmt(MyStr &LL);
	 void 		 ExchgAddSymBlk(MyStr &LL);
	
	 const char *GetUnExchgAll(MyStr &LL);
};

#endif //#ifndef __DequDB__h__
