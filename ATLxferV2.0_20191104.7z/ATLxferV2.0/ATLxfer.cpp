/* ###################################################################################################
	v1.1   : (1) Xfer�� parameter TrimR+TrimL (except _DEQUSYMS+_DEQUSYMX)
	v1.1   : (2) Xfer�� parameter �� SymX+data+SymX�� data ���B�z, ��SymX�h���ᵹBody�Axfer.(Symx='%)
	v1.1   : (3) Xfer�O�d @x comment
	v1.1   : (4) output file ��X ;@> + xfer�e�쫬 .
	v1.1   : (5) Xfer��parameter �i�H��J dequ ���� ex. Titem<10,"FUNC 1",ClearArray<FDUT>,FUNSUB>

	v1.2   : (1) Xfer��Parameter�ϥ� macro1<,macro2<>> �_����J���D�ѨM
	v1.2   : (2) Xfer��Parameter�ϥΪ�macro�L�Ѽƥi�٥h<>. (FunPon<>��i�H��FunPon) 
	v1.2   : (3) DEQU_DB v1.2 DEQU add �� FIFO �令 LIFO & DEQU body�a�JSeqN search,�᭱�P�W macro�u��.
	v1.2   : (4) Xfer��Parameter�ϥ� SymX �_���p 'pon<TIM1,3MS,`IN1,IN2`>' ���D�ѨM
	v1.2   : (5) output DEQU macro DB file �令 macro�쫬��X-> ODIR\m+ifile

	v1.3   : (1) Fix Macro name including the other short macro name issue
	v1.3   : (2) accept non-parameter macro definition without <> 
	
	v1.6@20191031 	
		1)change to dequdb
		2)remove Statement EQUATE,SDEF,...check during #dequ load
		3)Add _DEQUSYMU '?' , and it can be xferred if macro inside
		4)Accept #dequ inside #dequ ( insided #dequ willn't be load still defined #dequ is used )
		5)#dequ inside INSERT statement will be executed still defined #dequ is used .
		6)Reject to load the same #dequ name again
	v2.0@20191103
		+ #dequ name rule (any A~Z + any exack chars) if no a~z chars
		+ Global setting/Err message : SC
		+ Argument : -c ATLcompileOption , -f fulloutputfilename
		+ ATL compile Option analyizer
		+ Dync(Insided) #dequ name rule (MUST includeing parent $para$)
		+ DequXfer modify <-  #dequ macro xfer parameter cnt mis-match check
  ################################################################################################### */

#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>    //printf
#include <stdlib.h>   //malloc
#include <string.h>   //strncpy
#include <unistd.h>   //close
#include <iostream>
#include <ctime>

#define _DOS_

#include "mystr.h"
#include "mystd.h"
#include "fileobj.h"
#include "namestr.h"
#include "arraystr.h"
#include "arraynamestr.h"
#include "namearraystr.h"
#include "dequdb.h"

#define __ATLXferVer__ "ATLxfer-v2.0@20191103"
#define __Author__ "L.S Chien"

#ifdef _DOS_
	#define __SYS__ "DOS"
    #define SymPath  '\\'
#else
	#define __SYS__ "UNIX"
    #define SymPath  '/'
#endif

#define FileInsertStatement "INSERT"

#define StrMaxLen 256

using namespace std;

//#######################################################
class IntStack {
protected:
	int	state;
	IntStack	*nxt;
public:
	IntStack(const int is=1);
	~IntStack();
	void	  Reset(const int is=1);
	const int Push(const int v);
	const int Pop(void);
	const int StackCnt(void);
	const int GetVal(void);
	const int SetVal(const int v);
};

IntStack::IntStack(const int is) { state=is; nxt=NULL; }
IntStack::~IntStack() { Reset(); }

void IntStack::Reset(const int is) {
	IntStack *pp=this->nxt;
	while(pp!=NULL) { 
		IntStack *cp=pp;
		pp=pp->nxt;  delete cp;
	}
	state=is;
}

const int IntStack::StackCnt(void) {
	int n=0;
	IntStack *pp=this;
	while(pp->nxt!=NULL) { n++; pp=pp->nxt; }
	return n;
}

const int IntStack::Push(const int v) {
	IntStack *np=new IntStack(state);
	if(np==NULL) return -1;
	np->nxt=nxt; state=v; nxt=np;
	return StackCnt();
}
const int IntStack::Pop(void) {
	IntStack *np=this->nxt;
	if(np!=NULL) { state=np->state; nxt=np->nxt; delete np; }
	return StackCnt();
}

const int IntStack::GetVal(void) { return state; }
const int IntStack::SetVal(const int v) { state=v; return state; }
//########################################
//		Global Variables
//========================================
struct setting {
	FileObj 	FO;			//output file information & operation
	FnameObj	INF;		//input file information
	FnameObj	ONF;		//Dequ output file information
	DEQU_DB 	QDB;		//DEQU_DB
	ArrayStr	OPC;		//Compile option list
	IntStack	ops;		//Compile option nest stack
	MyStr		Me;			//my name AV[0]
	int			err;
	MyStr		ErrMsg;
};

static setting SC;
//########################################
static char line[StrMaxLen];

void usage(void);
void ShowInformation(void);
int SetupINF(MyStr &S);
int SetupONF(MyStr &O);
int SetupCompileOption(MyStr &OPCS);
void ArgAnalyzer(const int ac,char **av);
int Err_ATL_OptAnalyzer(const int err,FnameObj &INF,long llnn);
int ATL_OptAnalyzer(MyStr &LX,FnameObj &INF,long llnn);
int ATL_CmpOptFilter(MyStr &LL,FnameObj &INF,long llnn);

void PickupInsertFileName(MyStr &Fname,MyStr &LS,MyStr &LE,const char *line);
void SpCtlWrite(FileObj &FO,const char *ll,int &LFcnt);
void SpCtlWrite(FileObj &FO,MyStr &LL,int &LFcnt);
int DequXfer(DEQU_DB &QDB,MyStr &LL,FnameObj &INF,long llnn);
int InsertCheckXferWrite(DEQU_DB &QDB,FnameObj &INF,FileObj &FO,MyStr &LL,int &LFcnt,long llnn);
int FileXfer(DEQU_DB &QDB,FnameObj &INF,FileObj &FO,int &state,MyStr &FF,int &LFcnt);
void GetTimeStr(MyStr &RtnStr);

void GeneralExchgLineStr(MyStr &LL,ArrayNameStr &Exchg) {
	AddExchgLineCmtWithExSymBlk(LL,Exchg);
	AddExchgSymBlk(LL,Exchg);
	AddExchgSymChrCmtWithExSymBlk(LL,Exchg);
}

void usage(void)
{
	tout out;
	out.prt("\n Usage: %  main_src_file [output_path or -f output_pathfilename] [-c ATLcompileOption]",(char*)SC.Me);
	out.prt("\n       >> w/o output_path & output_pathfilename -> output in current path .");
	out.prt("\n       >> w/i -c ATLcompileOption : Ex. -c A,B -> transfer with %IFE condition check .");
	out.prt("\n          Note : the ATLcompileOption will be transferred to Upper-Case when option condition checking.\n");
}

void ShowInformation(void)
{
	tout out;
	out.prt("\n##################################################################");
	out.prt("\n[[[ ATL Xfer % % By % (DequDef=%)]]]",__SYS__,__ATLXferVer__,__Author__,__DequDef__);
	out.prt("\n==================================================================");
	out.prt("\n     This tool is used to convert the source files which writed with");
	out.prt("\n% macro to a .asc file for ADV tester's compiler .\n",_DEQUKEY);
	out.prt("\n Note :");
	out.prt("\n     1) Except DOS ver. ,all of inserted files must be lower-case file name !");
	out.prt("\n     2) main_src_file and all of inserted files must be stored in the same");
	out.prt("\n        path !");
	out.prt("\n     3) All of inserted files' att_name must use the same att_name of ");
	out.prt("\n        main_src_file !");
	out.prt("\n        Ex: main_src_file is main.s , the insertd files must be *.s");
	out.prt("\n     4) If main_src_file's att_name is .asc and output_path is same");
	out.prt("\n        as main_src_file's path, then output file's att_name will");
	out.prt("\n        change to be .asc2)");
	out.prt("\n  Regarding % marco :",_DEQUKEY);
	out.prt("\n     1) Re-define the same % macro name will be rejected since V1.6",_DEQUKEY);
	out.prt("\n     2) Name of % macro must exist at the least one lower-case or",_DEQUKEY);
	out.prt("\n        inclinding one of % chars.",_DEQUNAME_exack_chars);
	out.prt("\n     3) Don't support ATL compile option for % macro transfer now !",_DEQUKEY);
	out.prt("\n==================================================================");
	out.prt("\n Related lib :");
	out.prt("\n   %\t \t%",__MyStdVer__,__FileObjVer__);
	out.prt("\n   %\t \t%",__MyStrVer__,__NameStrVer__);
	out.prt("\n   %\t%",__ArrayStrVer__,__ArrayNameStrVer__);
	out.prt("\n   %\t%",__NameArrayStrVer__,__DequDBVer__);
	out.prt("\n##################################################################\n");
	usage();
}

int SetupINF(MyStr &S) {
	SC.err=0;
	SC.INF.NameSetByFullFileName(S);
	if(!SC.INF.IsFileExist()) {
		SC.ErrMsg="!!! Error : file '";
		SC.ErrMsg+=SC.INF.GetFullFileName();
		SC.ErrMsg+="' not found !!!"; 
		SC.err=-1;
	}
	return SC.err;
}

int SetupONF(MyStr &O) {
	MyStr S(O),F;
	SC.err=0;	
	if(SC.ONF.IsPathExist((char*)S)) {
//printf("\n#>path S=[%s]",(char*)S);
		//**********************************
		//	user specify output path
		//**********************************
		if( S[(int)S-1]!=_SymDir ) S+=_SymDir;
		F=S+SC.INF.GetFileName();
		F=F.GetRangeWithWdDel(SC.INF.GetFileAtt());
		//--------------------------------
		S=".asc";
		if(S==SC.INF.GetFileAtt()) S=S+"2";
		S=F+S;
	}
//printf("\n#>S=[%s]",(char*)S);
	SC.ONF.NameSetByFullFileName(S);
	if(!SC.ONF.IsLegalFileName()) {
		SC.ErrMsg="!!! Error : bad output filename '";
		SC.ErrMsg+=SC.ONF.GetFullFileName();
		SC.ErrMsg+="' !!!"; 
		SC.err=-1;
	}
	return SC.err;
}

int SetupCompileOption(MyStr &OPCS) {
	MyStr F(OPCS);
	MyStr S;
	SC.err=0;

	F=F.GetUpperCase();
	int p=F.InStr(',');
	while(p>0) {
		S=F.GetRangeByIdx(-1,p-1); S=S.GetTrim();
		if((int)S<1) { SC.err=-1; break; }
		SC.OPC.Add(S);
		F=F.GetRangeByIdx(p+1,-1);
		p=F.InStr(',');
	}
	if((int)F>0) { 
		F=F.GetTrim(); 
		if((int)F<1) 	SC.err=-1;
		else			SC.OPC.Add(F); 
	}	
	if(SC.err!=0) {
		SC.ErrMsg="!!! Error : bad option usage '";
		SC.ErrMsg+=OPCS;
		SC.ErrMsg+="' !!!"; 
	}
	return SC.err; 
}

void ArgAnalyzer(const int ac,char **av) {
//	tout out;
	
	SC.err=0;
	SC.Me = av[0];
	if(ac<2) { SC.err=-1; SC.ErrMsg="!!! Error : bad usage !!!"; return; }
	
	MyStr S,F;
	int n;
	int state=0;
	
	for(n=1;n<ac;n++) {
		if(SC.err<0) break;
		S=av[n];
		if(state==0) {
			if(S[0]!='-') {
				//-----------------------------------
				F=SC.INF.GetFileName();
				if((int)F<1) { SetupINF(S); continue; }
				//-----------------------------------
				F=SC.ONF.GetFileName();
				if((int)F<1) { SetupONF(S); continue; }
				//---------------------------------------
				SC.ErrMsg="!!! Error : Unknown argument '";
				SC.ErrMsg+=S;
				SC.ErrMsg+="' !!!"; 
				SC.err=-1; 
				continue;
			} else {
				//----------------------------------------------------
				if((int)S<2) {
					SC.ErrMsg="!!! Error : bad option usage '";
					SC.ErrMsg+=S;
					SC.ErrMsg+="' !!!"; 
					SC.err=-1; return; 
				}
				//----------------------------------------------------
				if(S[1]=='c') {
					F=S.GetRangeByIdx(2,-1);
					F=F.GetRangeWithWdDel('=');
					if((int)F>0) { SetupCompileOption(F); state=0; }
					else		state=1; 
					continue;
				}
				//----------------------------------------------------
				if(S[1]=='f') {
					F=S.GetRangeByIdx(2,-1);
					F=F.GetRangeWithWdDel('=');
					if((int)F>0) { SetupONF(F); state=0; }
					else		state=2; 
					continue;
				}
				//----------------------------------------------------
				SC.ErrMsg="!!! Error : unknown option '";
				SC.ErrMsg+=S;
				SC.ErrMsg+="' !!!"; 
				SC.err=-1; return; 
			}
		}
		if(state==1) { state=0; SetupCompileOption(S); continue; }
		if(state==2) { state=0; SetupONF(S); continue; }
	} // for
	
	if(SC.err==0) {
		F=SC.ONF.GetFileName();
		if((int)F<1) { F='.'; SetupONF(F); }
	}
}

int Err_ATL_OptAnalyzer(const int err,FnameObj &INF,long llnn) {
//tout out;
//	char line[StrMaxLen];
	SC.err=err;
	switch (err) {
		case -2:
			sprintf(line,"!!! Error : file'%s'@line(%ld)-> bad .XXX. operator in ATL compile option command !",INF.GetFileName(),llnn);
			SC.ErrMsg=line;	break;
		case -3:
			sprintf(line,"!!! Error : file'%s'@line(%ld)-> bad () sets in ATL compile option command !",INF.GetFileName(),llnn);
			SC.ErrMsg=line;	break;
		case -4:
			sprintf(line,"!!! Error : file'%s'@line(%ld)-> Null option in ATL compile option command !",INF.GetFileName(),llnn);
			SC.ErrMsg=line;	break;
		case -5:
			sprintf(line,"!!! Error : file'%s'@line(%ld)-> In-corrected %I**/%E** ATL compile option command !",INF.GetFileName(),llnn);
			SC.ErrMsg=line;	break;
		case -6:
			sprintf(line,"!!! Error : file'%s'@line(%ld)-> %ENDC w/o %IF* !",INF.GetFileName(),llnn);
			SC.ErrMsg=line;	break;
		default:
			sprintf(line,"!!! Error : file'%s'@line(%ld)-> bad format in ATL compile option command !",INF.GetFileName(),llnn);
			SC.ErrMsg=line;	break;	
	}
//out.prt(" ->Err(%)",SC.err);
	return SC.err;
}

int ATL_OptAnalyzer(MyStr &LX,FnameObj &INF,long llnn) {
//tout out;
//out.prt("\nIn LX=\"%\"",(char*)LX);
//MyStr Z(LX);
//	SC.err=0; SC.ErrMsg="";
	MyStr F,S,T;
	int p,q;
	LX=LX.GetTrimA();
	if((LX.WdCntInStr('.')%2)>0) return Err_ATL_OptAnalyzer(-2,INF,llnn);
	if(LX.WdCntInStr('(')!=LX.WdCntInStr(')')) return Err_ATL_OptAnalyzer(-3,INF,llnn);
	if((int)LX<1) return Err_ATL_OptAnalyzer(-4,INF,llnn);
	PO2 pp=LX.GetPointOfStackPairKey('(',')');
//out.prt("\nLX[%]<-'()' : pp.p1=% pp.p2=%",(char*)LX,pp.p1,pp.p2);
	while(pp.p1>-1) {
		if(pp.p2>pp.p1) { 
			if(pp.p1>0) S=LX.GetRangeByIdx(-1,pp.p1-1);
			else		S="";
			T=LX.GetRangeByIdx(pp.p2+1,-1);
			F=LX.GetRangeByIdx(pp.p1+1,pp.p2-1);
//out.prt("\n[%],F=\"%\"",(char*)LX,(char*)F);
			if((int)F<1) return Err_ATL_OptAnalyzer(-4,INF,llnn);
//out.prt("->F=\"%\"",(char*)F);
			p=ATL_OptAnalyzer(F,INF,llnn);
			if(p<0) return p;
			if((int)S>0 || (int)T>0) { 
				F=S+F; F+=T; p=ATL_OptAnalyzer(F,INF,llnn); 
				if(p<0) return p; 
			}
			LX=F;
			pp=LX.GetPointOfStackPairKey('(',')');
		} else return Err_ATL_OptAnalyzer(-1,INF,llnn);
	}
	if(pp.p2>-1) return Err_ATL_OptAnalyzer(-1,INF,llnn);
	//---------------------------------------------------------
	ArrayNameStr ANS; 
	NameStr NS;
	NS.SetName(".NOT."); 	NS=".!"; 	ANS.Add(NS);
	NS.SetName(".AND."); 	NS=".&"; 	ANS.Add(NS);
	NS.SetName(".OR."); 	NS=".+"; 	ANS.Add(NS);
	NS.SetName(".XOR."); 	NS=".^"; 	ANS.Add(NS);
	for(p=0;p<ANS.GetArrayCnt();p++) {
		LX=LX.GetRangeWithWdChg(ANS.GetNameByIdx(p),(char*)ANS[p]);
	}
//out.prt("\n#>LX=\"%\"",(char*)LX);
	p=0;
	q=LX.InStr(p,'.');
	F="";
	while(q>-1) {
		if(q>p) T=LX.GetRangeByIdx(p,q-1);
		else	T="";
		p=q+2;
		if(p>=(int)LX) return Err_ATL_OptAnalyzer(-4,INF,llnn);
//out.prt("\n##>T=\"%\"",(char*)T);
		if((int)T>0) {
			if(T!='1' && T!='0') { 
				T=T.GetUpperCase(); S='0';
				for(int n=0;n<SC.OPC.GetArrayCnt();n++) {
//out.prt("\n>SC.OPC[%]=\"%\"",n,(char*)SC.OPC[n]);
					if(T==SC.OPC[n]) {S='1'; break;}
				}
//out.prt("\n>S=[%]",(char*)S);
				F+=S;
			} else F+=T;
		}
		F+=LX.GetRangeByIdx(q,q+1);
//out.prt(" -> F=\"%\"",(char*)F);
		q=LX.InStr(p,'.');
	}
	T=LX.GetRangeByIdx(p,-1);
//out.prt("->#>F=\"%\" ,T=\"%\"",(char*)F,(char*)T);
	if((int)T>0) {
		if(T!='1' && T!='0') { 
			T=T.GetUpperCase(); S='0';
			for(int n=0;n<SC.OPC.GetArrayCnt();n++) { 
//out.prt("\n>SC.OPC[%]=\"%\"",n,(char*)SC.OPC[n]);
				if(T==SC.OPC[n]) {S='1'; break;}
			}
//out.prt("\n>S=[%]",(char*)S);
			F+=S;
		} else F+=T;
	}
//out.prt("\nIn LX[%]-> F=[%]",(char*)Z,(char*)F);
	LX=F.GetRangeWithWdChg(".!0","1");
	LX=LX.GetRangeWithWdChg(".!1","0");
	LX=LX.GetRangeWithWdChg("0.&0","0");
	LX=LX.GetRangeWithWdChg("0.&1","0");
	LX=LX.GetRangeWithWdChg("1.&0","0");
	LX=LX.GetRangeWithWdChg("1.&1","1");
	LX=LX.GetRangeWithWdChg("0.+0","0");
	LX=LX.GetRangeWithWdChg("0.+1","1");
	LX=LX.GetRangeWithWdChg("1.+0","1");
	LX=LX.GetRangeWithWdChg("1.+1","1");
	LX=LX.GetRangeWithWdChg("0.^0","0");
	LX=LX.GetRangeWithWdChg("0.^1","1");
	LX=LX.GetRangeWithWdChg("1.^0","1");
	LX=LX.GetRangeWithWdChg("1.^1","0");
//out.prt("-> Out LX=[%]",(char*)LX);
	if(LX=='1') return 1;
	return 0;
}

int ATL_CmpOptFilter(MyStr &LL,FnameObj &INF,long llnn) {
//tout out;
//	SC.err=0; SC.ErrMsg="";
	
	if(SC.ops.GetVal()<0) return 1;			// ATL Compile Option Analyize disable
	
	Dequ DQ;

	MyStr S(DQ.RemoveLineCmt(LL));
	S=DQ.RemoveSymChrCmt(S);
	S=DQ.RemoveSymBlk(S);
	S=S.GetRangeWithSpCmpress();
	S=S.GetTrim();

	int p=S.InStr("%I");
	int q=S.InStr("%E");
	
	if(p<0 && q<0) return SC.ops.GetVal();	// None %I*** , %E*** return

//out.prt("\nATL_CmpOptFilter LL=[%]\n",(char*)LL);
	
	if(q>-1) { // %E*** entry
		if(q!=S.InStr("%ENDC")) return Err_ATL_OptAnalyzer(-5,INF,llnn);
		if(SC.ops.StackCnt()>0) {
			SC.ops.Pop(); 
			LL="";	return SC.ops.GetVal(); 
		}
		return Err_ATL_OptAnalyzer(-6,INF,llnn);
	}
	
	// %I** statement
	q=S.InStr(' ');
	if(q<0) return Err_ATL_OptAnalyzer(-5,INF,llnn);
	MyStr T=S.GetRangeByIdx(p,q-1);
	if(T!="%IFE" && T!="%IFN") Err_ATL_OptAnalyzer(-5,INF,llnn);
	if(T=="%IFN") T=".NOT.(";
	else		  T="(";
	S=S.GetRangeByIdx(q,-1); S=S.GetTrim();
	T+=S; T+=")";
//out.prt("\nT=[%]",(char*)T);
	int n=ATL_OptAnalyzer(T,INF,llnn);
	if(n<0) return n;
	SC.ops.Push(n);
	
	LL="";
	return SC.ops.GetVal();
}

void PickupInsertFileName(MyStr &Fname,MyStr &LS,MyStr &LE,const char *line) {
	LS=line;  ArrayNameStr Exchg;
	GeneralExchgLineStr(LS,Exchg);
	//AddExchgLineCmtWithExSymBlk(LS,Exchg);
	//AddExchgSymBlk(LS,Exchg);
	//AddExchgSymChrCmtWithExSymBlk(LS,Exchg);
	LE=LS.GetRangeWithWdChg('\t',' ');
	LE=LE.GetRangeWithWdChg('\n',' ');
	Fname=FileInsertStatement;
	Fname+=" ";

	int p=LE.InStr(Fname);
	if(p<0) {LS=line; LE=""; Fname=""; return; }
	MyStr T;
	if(p>0) T=LS.GetRangeByIdx(-1,p-1);
	p=p+(int)Fname;
	
	int l=LE.InStr(p,_DEQU_ExKeyS); // ExKeyStart
	if(l<0) l=(int)LE;
	
	while(p<l && LE[p]==' ') p++;
	int q=p;
	while(q<l && LE[q]!=' ') q++;
	Fname=LE.GetRangeByIdx(p,q-1);
	Fname=Fname.GetLowerCase();
	LE=LS.GetRangeByIdx(q,-1);
	LS=GetAllUnExchgStr(T,Exchg);
	LE=GetAllUnExchgStr(LE,Exchg);
}

int DequXfer(DEQU_DB &QDB,MyStr &LL,FnameObj &INF,long llnn) {
//printf("\nDequXfer LL[%s]",(char*)LL);
	ArrayNameStr Exchg;
	AddExchgLineCmtWithExSymBlk(LL,Exchg);
	AddExchgSymChrCmtWithExSymBlk(LL,Exchg);
	AddExchgSymBlkS(LL,Exchg);
	
	MyStr T(QDB.DEQU_Inside((char*)LL));
	if(T!="") {
		MyStr LS,LE,SYM(_DEQUSYMA);
		int n=QDB.SearchDEQUparN((char*)T);
		MyStr PA(QDB.PickupLineDequPara(LL,T,SYM,LS,LE));
		int x=QDB.AnalyzeParaCnt(PA);
//printf("\nDequXfer LL[%s]NM[%s]PA[%s],n=%d,x=%d",(char*)LL,(char*)T,(char*)PA,n,x);
		if(x!=n) {
			//char line[StrMaxLen];
			sprintf(line,"!!! Error : file'%s'@line(%ld) %s '%s' parameters mis-match !",INF.GetFileName(),llnn,_DEQUKEY,(char*)T); 
			SC.err=-1; SC.ErrMsg=line; return -1;
		}
		T=";@>"; T+=LL; T+='\n';
//printf("\n#>DequXfer LL[%s],T[%s] ..",(char*)LL,(char*)T);
		T+=QDB.DEQU_xfer((char*)LL);
		LL=T.GetRangeWithWdCmpressExSymBlk('\n',_DEQUSYMA);
//printf("=>LL[%s]",(char*)LL);
		if(DequXfer(QDB,LL,INF,llnn)<0) return -1;
	}
	LL=GetAllUnExchgStr(LL,Exchg);
//printf("\n##>DequXfer LL(%s)",(char*)LL);
	return 0;
}

void SpCtlWrite(FileObj &FO,const char *ll,int &LFcnt) { MyStr LL(ll); return SpCtlWrite(FO,LL,LFcnt); }
void SpCtlWrite(FileObj &FO,MyStr &LL,int &LFcnt) {
	MyStr S(LL.GetTrimA());
	if((int)S<1) { 
		if(++LFcnt>1) { LFcnt=1; return; }
	} else LFcnt=0;
	FO.FileWrite(LL);
}

int InsertCheckXferWrite(DEQU_DB &QDB,FnameObj &INF,FileObj &FO,MyStr &LL,int &LFcnt,long llnn) {
//tout out;	
	//char line[StrMaxLen];
	FnameObj XNF;
	MyStr LS,LE,X;
	DequCode R;
	
//	SC.err=0;
	if(DequXfer(QDB,LL,INF,llnn)<0) return -1;
	
	Dequ DQ;
	//*********************************************************
	//	inside #dequ check
	//*********************************************************
//printf("\nInsertCheckXferWrite#LL=[%s]",(char*)LL);
	PO2 pp=DQ.GetPointOfDequContents(LL);
	if(pp.p1>0) {
		if(pp.p2>0) {
			R=DQ.IsWellContents(LL);
			if(R!=_well) {
				sprintf(line,"!!! Error : file'%s'@line(%ld) %s <- %s",INF.GetFileName(),llnn,_DEQUKEY,GetDequErrMessage(R)); 
				SC.err=-1; SC.ErrMsg=line; return -1;
			}
			R=DQ.Setup(LL);
			if(R!=_well) {
				sprintf(line,"!!! Error : file'%s'@line(%ld) %s <- %s",INF.GetFileName(),llnn,_DEQUKEY,GetDequErrMessage(R)); 
				SC.err=-1; SC.ErrMsg=line; return -1;
			}
			R=QDB.Add(DQ);
			if(R!=_well) {
				sprintf(line,"!!! Error : file'%s'@line(%ld) %s '%s' <- %s",INF.GetFileName(),llnn,_DEQUKEY,DQ.GetName(),GetDequErrMessage(R));
				SC.err=-1; SC.ErrMsg=line; return -1;
			}
			X=LL.GetTrim();
			if((int)X>0) return InsertCheckXferWrite(QDB,INF,FO,LL,LFcnt,llnn);
			return 0;
		}
		sprintf(line,"!!! Error : file'%s'@line(%ld)-> in-completed %s definition !",INF.GetFileName(),llnn,_DEQUKEY); 
		SC.err=-1; SC.ErrMsg=line; return -1;
	}

	//*********************************************************
	//	without #dequ
	//*********************************************************
	ArrayNameStr Exchg;
	MyStr LX=LL;
	GeneralExchgLineStr(LX,Exchg);
	//AddExchgLineCmtWithExSymBlk(LX,Exchg);
	//AddExchgSymBlk(LX,Exchg);
	//AddExchgSymChrCmtWithExSymBlk(LX,Exchg);

	PickupInsertFileName(X,LS,LE,LX);
	//====== w/o INSERT comment =============
	if((int)X<1) { SpCtlWrite(FO,LL,LFcnt); return 0; }
	//======	Insert statement detect  ======
	if((int)LS>0) { LS=GetAllUnExchgStr(LS,Exchg); SpCtlWrite(FO,LS,LFcnt); }
	//----------------------------------------------------------------
	sprintf(line,"%s%s%s",INF.GetFilePath(),(char*)X,INF.GetFileAtt());
	XNF.NameSetByFullFileName(line);
	sprintf(line,";;;; insert(%s)\n",XNF.GetFileName());
	SpCtlWrite(FO,line,LFcnt);
	int s=0;	LX="";
	if(FileXfer(QDB,XNF,FO,s,LX,LFcnt)<0) return -1;
	//------------------------------------------------------------------
	if((int)LE>0) { LS=GetAllUnExchgStr(LE,Exchg); SpCtlWrite(FO,LE,LFcnt); }
	return 0;
}

int FileXfer(DEQU_DB &QDB,FnameObj &INF,FileObj &FO,int &state,MyStr &FF,int &LFcnt) {
tout out;
	//char line[StrMaxLen];
	
	FnameObj XNF;
	FileObj FI(INF,_read_mode);
	if(!FI.IsFileExist()) { 
		sprintf(line,"!!! Error : file '%s' not found !!!",FI.GetFullFileName());
		SC.err=-1; SC.ErrMsg=line; return -1;
	}
	
	//FI.SetBuffer(StrMaxLen);
	if(FI.FileOpen()!=_reading) { 
		sprintf(line,"!!! Error : Open '%s' for read fail !!!",FI.GetFullFileName()); 
		SC.err=-1; SC.ErrMsg=line; return -1;
	}

	MyStr SYMA(_DEQUSYMA);
	
	long llnn=0;
	MyStr LL,X,T,LX;
	MyStr LS,LE;
//	ODequ QQ;
	
	Dequ DQ;
	DequCode r;
	ArrayNameStr Exchg;
		
	while(1) {
		
		if(SC.err!=0) break;
		if(FI.GetFileState()==_onclose) break;
		
		FI.FileRead(LL);
		llnn++;

out.prt("<%>[%]%",INF.GetFileName(),llnn,(char*)LL);

		LL=LL.GetDos2Unix();
		LX=LL; Exchg.Reset();
		
		int n=ATL_CmpOptFilter(LX,INF,llnn);

//out.prt("ATL_CmpOptFilter return LX=[%]\n",(char*)LX);

		if(n<0) break;
		if(n==0) continue;
		if((int)LX<1) continue;
//out.prt("=>(int)LX=% ..\n",(int)LX);		
		GeneralExchgLineStr(LX,Exchg);
		//AddExchgLineCmtWithExSymBlk(LX,Exchg);
		//AddExchgSymBlk(LX,Exchg);
		//AddExchgSymChrCmtWithExSymBlk(LX,Exchg);
//out.prt("<%>%",state,(char*)LL);

		if(state<1) {
			//************************************
			//*	Not during DEQU load
			//************************************
			PO2 pp=DQ.GetPointOfDequContents(LX);
			if(pp.p1<0) {
				if(InsertCheckXferWrite(QDB,INF,FO,LL,LFcnt,llnn)<0) break;
				FF=""; continue;
			} else {
				if(pp.p2<0) { state++; FF=LL; continue; }	// not yet complete
				r=DQ.IsWellContents(LL);
				if(r!=_well) {
					sprintf(line,"!!! Error : file'%s'@line(%ld) %s <- %s",INF.GetFileName(),llnn,_DEQUKEY,GetDequErrMessage(r)); 
					SC.err=-1; SC.ErrMsg=line; break;
				}
				r=DQ.Setup(LL);
				if(r!=_well) {
					sprintf(line,"!!! Error : file'%s'@line(%ld) %s <- %s",INF.GetFileName(),llnn,_DEQUKEY,GetDequErrMessage(r)); 
					SC.err=-1; SC.ErrMsg=line; break;
				}
				T=LL.GetTrim();
				if((int)T>0) { 
					if(InsertCheckXferWrite(QDB,INF,FO,LL,LFcnt,llnn)<0) break;
				}
				r=QDB.Add(DQ);
				if(r!=_well) {
					sprintf(line,"!!! Error : file'%s'@line(%ld) %s '%s' <- %s",INF.GetFileName(),llnn,_DEQUKEY,DQ.GetName(),GetDequErrMessage(r)); 
					SC.err=-1; SC.ErrMsg=line; break;
				}  
				FF=""; continue;
			}
		} else {
			//************************************
			//*	During DEQU load
			//************************************
			FF+=LL;
			LX=FF; Exchg.Reset();
			GeneralExchgLineStr(LX,Exchg);
			//AddExchgLineCmtWithExSymBlk(LX,Exchg);
			//AddExchgSymBlk(LX,Exchg);
			//AddExchgSymChrCmtWithExSymBlk(LX,Exchg);
			
			PO2 pp=DQ.GetPointOfDequContents(LX);
			if(pp.p2<0) {
				state++;
				if((int)FF>50000 || state>1000 ) {
					sprintf(line,"!!! Error : file'%s'@line(%ld)-> %s over size , stop !",INF.GetFileName(),llnn,_DEQUKEY);
					SC.err=-1; SC.ErrMsg=line; break; 
				}
			    continue;
			} else {
				r=DQ.IsWellContents(FF);
				if(r!=_well) {
					sprintf(line,"!!! Error : file'%s'@line(%ld) %s <- %s",INF.GetFileName(),llnn,_DEQUKEY,GetDequErrMessage(r)); 
					SC.err=-1; SC.ErrMsg=line; break;
				}
				DQ.Setup(FF);
				T=FF.GetTrim();
				if((int)T>0) { 
					if(InsertCheckXferWrite(QDB,INF,FO,FF,LFcnt,llnn)<0) break;
				}
				r=QDB.Add(DQ);
				if(r!=_well) {
					sprintf(line,"!!! Error : file'%s'@line(%ld) %s '%s' <- %s",INF.GetFileName(),llnn,_DEQUKEY,DQ.GetName(),GetDequErrMessage(r)); 
					SC.err=-1; SC.ErrMsg=line; break;
				}
				state=0; continue;
			}
		}
	}
	
	if(SC.err!=0) return SC.err;	
	return 0;
}

void GetTimeStr(MyStr &RtnStr) {
	time_t now = time(0);
	tm *lt = localtime(&now);
	RtnStr=(1900+lt->tm_year);
	RtnStr+="/";
	RtnStr+=(1+lt->tm_mon);
	RtnStr+="/";
	RtnStr+=(lt->tm_mday);
	RtnStr+=" ";
	RtnStr+=(lt->tm_hour);
	RtnStr+=":";
	RtnStr+=(1+lt->tm_min);
	RtnStr+=":";
	RtnStr+=(1+lt->tm_sec);
}

int main (int ac , char ** av )
{
	tout out;
	//char line[StrMaxLen];

	if(ac<2) { ShowInformation(); exit(-1); }
	
	ArgAnalyzer(ac,av);
	if(SC.err<0) { out.prt("\n\n%",(char*)SC.ErrMsg); usage(); exit(1); }

	if(SC.OPC.GetArrayCnt()>0) 	SC.ops.SetVal(1);	// option enable state for beginning
	else						SC.ops.SetVal(-1);	// none option checking

//out.prt("\nSC.INF FullFileName[%]",SC.INF.GetFullFileName());
//out.prt("\n >FilePath[%] FileName[%] FileAtt[%]",SC.INF.GetFilePath(),SC.INF.GetFileName(),SC.INF.GetFileAtt());
//out.prt("\n\nSC.ONF FullFileName[%]",SC.ONF.GetFullFileName());
//out.prt("\n >FilePath[%] FileName[%] FileAtt[%]",SC.ONF.GetFilePath(),SC.ONF.GetFileName(),SC.ONF.GetFileAtt());
//out.prt("\n\nSC.OPC ArrayCnt=[%] List=[%]",SC.OPC.GetArrayCnt(),SC.OPC.List());
//out.prt("\n\nSC.ops StackCnt=[%] GetVal=[%]",SC.ops.StackCnt(),SC.ops.GetVal());

	MyStr DateTime;
	GetTimeStr(DateTime);
			
	out.prt("\n## Transfer '%' with INSERTed *% to '%' ##\n",SC.INF.GetFullFileName(),SC.INF.GetFileAtt(),SC.ONF.GetFullFileName());

	sprintf(line,"%s.dequ",SC.ONF.GetFullFileName());
	SC.QDB.SetDBfile(line);

	SC.FO.NameSetByFullFileName(SC.ONF.GetFullFileName()); SC.FO.SetFileMode(_write_mode);
	if(SC.FO.FileOpen()!=_writing) { out.prt("!!! Error : Open '%' for write fail !!!",SC.FO.GetFullFileName()); return -1; }

	sprintf(line,";This file converted from %s %s by %s %s_%s\n",SC.INF.GetFileName(),(char*)DateTime,av[0],__SYS__,__ATLXferVer__);

	int state=0;
	int LFcnt=0;
	SpCtlWrite(SC.FO,line,LFcnt);

	MyStr DEQBUF;
	LFcnt=FileXfer(SC.QDB,SC.INF,SC.FO,state,DEQBUF,LFcnt);
	if(LFcnt!=0) {
		out.prt("\n\n%\n\n",(char*)SC.ErrMsg);
		SC.FO.FileWrite((char*)SC.ErrMsg);
	}
	SC.FO.FileClose();
	
	if(LFcnt==0) out.prt("\n>> Transfer to '%' complete !",SC.FO.GetFullFileName());

	sprintf(line,"%s.s",SC.FO.GetFullFileName());
	SC.QDB.DB_foutput(line);
	out.prt("\n>> Generated macro DB file '%'\n",line);
	
	if(access(SC.QDB.GetDBfile(),F_OK)==0) {
#ifdef _DOS_
		sprintf(line,"del %s",SC.QDB.GetDBfile());
#else
		sprintf(line,"rm %s",SC.QDB.GetDBfile());
#endif
	    system(line);
	}

    exit(0);
}
