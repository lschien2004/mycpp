#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>    //printf
#include <stdlib.h>   //malloc
#include <string.h>   //strncpy
#include <unistd.h>   //close
#include <iostream>
#include <ctime>

#include "mystr.h"
#include "namestr.h"
#include "arraystr.h"
#include "arraynamestr.h"
#include "namearraystr.h"
#include "dequdb.h"
#include "mystd.h"

#define __ATLXferVer__ "ATLxfer-v2.0@20191024"

#define __Author__ "L.S Chien"

#define _DOS_

#ifdef _DOS_
	#define __SYS__ "DOS"
    #define SymPath  '\\'
#else
	#define __SYS__ "UNIX"
    #define SymPath  '/'
#endif

#define FileInsertStatement "INSERT"

#define StrMaxLen 256

struct intstack {
	int state;
	intstack	*nxt;
};

class IntStack {
protected:
	int	state;
	IntStack	*nxt;
public:
	IntStack(const int is=1);
	~IntStack();
	void	  Reset(const int is=1);
	const int Push(const int v);
	const int Pop(void);
	const int StackCnt(void);
	const int GetVal(void);
	const int SetVal(const int v);
};

IntStack::IntStack(const int is) { state=is; nxt=NULL; }
IntStack::~IntStack() { Reset(); }

void IntStack::Reset(const int is) {
	IntStack *pp=this->nxt;
	while(pp!=NULL) { 
		IntStack *cp=pp;
		pp=pp->nxt;  delete cp;
	}
	state=is;
}

const int IntStack::StackCnt(void) {
	int n=0;
	IntStack *pp=this;
	while(pp->nxt!=NULL) { n++; pp=pp->nxt; }
	return n;
}

const int IntStack::Push(const int v) {
	IntStack *np=new IntStack(state);
	if(np==NULL) return -1;
	np->nxt=nxt; state=v; nxt=np;
	return StackCnt();
}
const int IntStack::Pop(void) {
	IntStack *np=this->nxt;
	if(np!=NULL) { state=np->state; nxt=np->nxt; delete np; }
	return StackCnt();
}

const int IntStack::GetVal(void) { return state; }
const int IntStack::SetVal(const int v) { state=v; return state; }
//########################################
//		Global Variables
//========================================
struct setting {
	FileObj 	FO;			//output file information & operation
	FnameObj	INF;		//input file information
	FnameObj	ONF;		//Dequ output file information
	FnameObj	DBF;		//DB store file information
	ArrayStr	OPC;		//Compile option list
	IntStack	ops;		//Compile option nest stack
	MyStr		Me;			//my name AV[0]
	int			err;
	MyStr		ErrMsg;
};

static setting SC;
//########################################
//static char line[StrMaxLen];
static int k;

const char *GetTimeStr(void) {
	time_t now = time(0);
	tm *lt = localtime(&now);
	MyStr DateTime;
	DateTime=(1900+lt->tm_year);
	DateTime+="/";
	DateTime+=(1+lt->tm_mon);
	DateTime+="/";
	DateTime+=(lt->tm_mday);
	DateTime+=" ";
	DateTime+=(1+lt->tm_hour);
	DateTime+=":";
	DateTime+=(1+lt->tm_min);
	DateTime+=":";
	DateTime+=(1+lt->tm_sec);
	return (char*)DateTime;
}

void usage(void)
{
	tout out;
	out.prt("\n Usage: %  main_src_file [output_path or -f output_pathfilename] [-c ATLcompileOption]",(char*)SC.Me);
	out.prt("\n       >> w/o output_path & output_pathfilename -> output in current path .");
	out.prt("\n       >> w/i -c ATLcompileOption : Ex. -c A,B -> transfer with %IFE condition check .");
	out.prt("\n          Note : the ATLcompileOption will be transferred to Upper-Case when option condition checking.\n");
}

void ShowInformation(void)
{
	tout out;
	out.prt("\n##################################################################");
	out.prt("\n[[[ ATL Xfer % % By % (DequDef=%)]]]",__SYS__, __ATLXferVer__,__Author__,__DequDef__);
	out.prt("\n==================================================================");
	out.prt("\n     This tool is used to convert the source files which writed with");
	out.prt("\n% macro to a .asc file for ADV tester's compiler .\n",_DEQUKEY);
	out.prt("\n Note :");
	out.prt("\n     1) Except DOS ver. ,all of inserted files must be lower-case file name !");
	out.prt("\n     2) main_src_file and all of inserted files must be stored in the same");
	out.prt("\n        path !");
	out.prt("\n     3) All of inserted files' att_name must use the same att_name of ");
	out.prt("\n        main_src_file !");
	out.prt("\n        Ex: main_src_file is main.s , the insertd files must be *.s");
	out.prt("\n     4) If main_src_file's att_name is .asc and output_path is same");
	out.prt("\n        as main_src_file's path, then output file's att_name will");
	out.prt("\n        change to be .asc2)");
	out.prt("\n  Regarding % marco :",_DEQUKEY);
	out.prt("\n     1) Re-define the same % macro name will be rejected since V1.6",_DEQUKEY);
	out.prt("\n     2) Name of % macro must exist at the least one lower-case or",_DEQUKEY);
	out.prt("\n        inclinding one of % chars.",_DEQUNAME_exack_chars);
	out.prt("\n     3) Don't support ATL compile option for % macro transfer now !",_DEQUKEY);
	out.prt("\n==================================================================");
	out.prt("\n Related lib :");
	out.prt("\n   %\t \t%",__MyStdVer__,__FileObjVer__);
	out.prt("\n   %\t \t%",__MyStrVer__,__NameStrVer__);
	out.prt("\n   %\t%",__ArrayStrVer__,__ArrayNameStrVer__);
	out.prt("\n   %\t%",__NameArrayStrVer__,__DequDBVer__);
	out.prt("\n##################################################################\n");
	usage();
}

int SetupINF(MyStr &S) {
	SC.err=0;
	SC.INF.NameSetByFullFileName(S);
	if(!SC.INF.IsFileExist()) {
		SC.ErrMsg="!!! Error : file '";
		SC.ErrMsg+=SC.INF.GetFullFileName();
		SC.ErrMsg+="' not found !!!"; 
		SC.err=-1;
	}
	return SC.err;
}

int SetupONF(MyStr &O) {
	MyStr S(O),F;
	SC.err=0;	
	if(SC.ONF.IsPathExist((char*)S)) {
		//**********************************
		//	user specify output path
		//**********************************
		if( S[(int)S-1]!=_SymDir ) S+=_SymDir;
		F=S+SC.INF.GetFileName();
		F=F.GetRangeWithWdDel(SC.INF.GetFileAtt());
		//--------------------------------
		S=".asc";
		if(S==SC.INF.GetFileAtt()) S=S+"2";
		S=F+S;
	}
	SC.ONF.NameSetByFullFileName(S);
	if(!SC.ONF.IsLegalFileName()) {
		SC.ErrMsg="!!! Error : bad output filename '";
		SC.ErrMsg+=SC.ONF.GetFullFileName();
		SC.ErrMsg+="' !!!"; 
		SC.err=-1;
	}
	return SC.err;
}

int SetupCompileOption(MyStr &OPCS) {
	MyStr F(OPCS);
	MyStr S;
	SC.err=0;

	F=F.GetUpperCase();
	int p=F.InStr(',');
	while(p>0) {
		S=F.GetRangeByIdx(-1,p-1); S=S.GetTrim();
		if((int)S<1) { SC.err=-1; break; }
		SC.OPC.Add(S);
		F=F.GetRangeByIdx(p+1,-1);
		p=F.InStr(',');
	}
	if((int)F>0) { 
		F=F.GetTrim(); 
		if((int)F<1) 	SC.err=-1;
		else			SC.OPC.Add(F); 
	}	
	if(SC.err!=0) {
		SC.ErrMsg="!!! Error : bad option usage '";
		SC.ErrMsg+=OPCS;
		SC.ErrMsg+="' !!!"; 
	}
	return SC.err; 
}

void ArgAnalyzer(const int ac,char **av) {
	tout out;
	
	SC.err=0;
	SC.Me = av[0];
	if(ac<2) { SC.err=-1; SC.ErrMsg="!!! Error : bad usage !!!"; return; }
	
	MyStr S,F;
	int n;
	int state=0;
	
	for(n=1;n<ac;n++) {
		if(SC.err<0) break;
		S=av[n];
		if(state==0) {
			if(S[0]!='-') {
				//-----------------------------------
				F=SC.INF.GetFileName();
				if((int)F<1) { SetupINF(S); continue; }
				//-----------------------------------
				F=SC.ONF.GetFileName();
				if((int)F<1) { SetupONF(S); continue; }
				//---------------------------------------
				SC.ErrMsg="!!! Error : Unknown argument '";
				SC.ErrMsg+=S;
				SC.ErrMsg+="' !!!"; 
				SC.err=-1; 
				continue;
			} else {
				//----------------------------------------------------
				if((int)S<2) {
					SC.ErrMsg="!!! Error : bad option usage '";
					SC.ErrMsg+=S;
					SC.ErrMsg+="' !!!"; 
					SC.err=-1; return; 
				}
				//----------------------------------------------------
				if(S[1]=='c') {
					F=S.GetRangeByIdx(2,-1);
					F=F.GetRangeWithWdDel('=');
					if((int)F>0) { SetupCompileOption(F); state=0; }
					else		state=1; 
					continue;
				}
				//----------------------------------------------------
				if(S[1]=='f') {
					F=S.GetRangeByIdx(2,-1);
					F=F.GetRangeWithWdDel('=');
					if((int)F>0) { SetupONF(F); state=0; }
					else		state=2; 
					continue;
				}
				//----------------------------------------------------
				SC.ErrMsg="!!! Error : unknown option '";
				SC.ErrMsg+=S;
				SC.ErrMsg+="' !!!"; 
				SC.err=-1; return; 
			}
		}
		if(state==1) { state=0; SetupCompileOption(S); continue; }
		if(state==2) { state=0; SetupONF(S); continue; }
	} // for
	
	if(SC.err==0) {
		F=SC.ONF.GetFileName();
		if((int)F<1) { F='.'; SetupONF(F); }
	}
}

void AddExchgWd2Key(MyStr &LL,const char *wd,const char *ky,ArrayNameStr &ANS) {
	NameStr NS(wd,ky); ANS.Add(NS);
	LL=LL.GetRangeWithWdChg(wd,ky);
}

int Err_ATL_OptAnalyzer(const int err) {
tout out;
	SC.err=err;
	switch (err) {
		case -2:
			SC.ErrMsg="!!! Error : bad .XXX. operator in ATL compile option command !!!";
			break;
		case -3:
			SC.ErrMsg="!!! Error : bad () sets in ATL compile option command !!!";
			break;
		case -4:
			SC.ErrMsg="!!! Error : Null option in ATL compile option command !!!";
			break;
		case -5:
			SC.ErrMsg="!!! Error : bad format in ATL compile option command !!!";
			break;			
		default:
			SC.err=-1;
			SC.ErrMsg="!!! Error : bad format in ATL compile option command !!!";
			break;
	}
out.prt(" ->Err(%)",SC.err);
	return SC.err;
}

int ATL_OptAnalyzer(MyStr &LX) {
tout out;
out.prt("\nIn LX=\"%\"",(char*)LX);
MyStr Z(LX);
	SC.err=0; SC.ErrMsg="";
	MyStr F,S,T;
	int p,q;
	LX=LX.GetTrimA();
	if((LX.WdCntInStr('.')%2)>0) return Err_ATL_OptAnalyzer(-2);
	if(LX.WdCntInStr('(')!=LX.WdCntInStr(')')) return Err_ATL_OptAnalyzer(-3);
	if((int)LX<1) return Err_ATL_OptAnalyzer(-4);
	PO2 pp=LX.GetPointOfStackPairKey('(',')');
//out.prt("\nLX[%]<-'()' : pp.p1=% pp.p2=%",(char*)LX,pp.p1,pp.p2);
	while(pp.p1>-1) {
		if(pp.p2>pp.p1) { 
			if(pp.p1>0) S=LX.GetRangeByIdx(-1,pp.p1-1);
			else		S="";
			T=LX.GetRangeByIdx(pp.p2+1,-1);
			F=LX.GetRangeByIdx(pp.p1+1,pp.p2-1);
//out.prt("\n[%],F=\"%\"",(char*)LX,(char*)F);
			if((int)F<1) return Err_ATL_OptAnalyzer(-4);
//out.prt("->F=\"%\"",(char*)F);
			p=ATL_OptAnalyzer(F);
			if(p<0) return p;
			if((int)S>0 || (int)T>0) { 
				F=S+F; F+=T; p=ATL_OptAnalyzer(F); 
				if(p<0) return p; 
			}
			LX=F;
			pp=LX.GetPointOfStackPairKey('(',')');
		} else return Err_ATL_OptAnalyzer(-1);
	}
	if(pp.p2>-1) return Err_ATL_OptAnalyzer(-1);
	//---------------------------------------------------------
	ArrayNameStr ANS; 
	NameStr NS;
	NS.SetName(".NOT."); 	NS=".!"; 	ANS.Add(NS);
	NS.SetName(".AND."); 	NS=".&"; 	ANS.Add(NS);
	NS.SetName(".OR."); 	NS=".+"; 	ANS.Add(NS);
	NS.SetName(".XOR."); 	NS=".^"; 	ANS.Add(NS);
	for(p=0;p<ANS.GetArrayCnt();p++) {
		LX=LX.GetRangeWithWdChg(ANS.GetNameByIdx(p),(char*)ANS[p]);
	}
//out.prt("\n#>LX=\"%\"",(char*)LX);
	p=0;
	q=LX.InStr(p,'.');
	F="";
	while(q>-1) {
		if(q>p) T=LX.GetRangeByIdx(p,q-1);
		else	T="";
		p=q+2;
		if(p>=(int)LX) return Err_ATL_OptAnalyzer(-4);
//out.prt("\n##>T=\"%\"",(char*)T);
		if((int)T>0) {
			if(T!='1' && T!='0') { 
				T=T.GetUpperCase(); S='0';
				for(int n=0;n<SC.OPC.GetArrayCnt();n++) {
//out.prt("\n>SC.OPC[%]=\"%\"",n,(char*)SC.OPC[n]);
					if(T==SC.OPC[n]) {S='1'; break;}
				}
//out.prt("\n>S=[%]",(char*)S);
				F+=S;
			} else F+=T;
		}
		F+=LX.GetRangeByIdx(q,q+1);
//out.prt(" -> F=\"%\"",(char*)F);
		q=LX.InStr(p,'.');
	}
	T=LX.GetRangeByIdx(p,-1);
//out.prt("->#>F=\"%\" ,T=\"%\"",(char*)F,(char*)T);
	if((int)T>0) {
		if(T!='1' && T!='0') { 
			T=T.GetUpperCase(); S='0';
			for(int n=0;n<SC.OPC.GetArrayCnt();n++) { 
//out.prt("\n>SC.OPC[%]=\"%\"",n,(char*)SC.OPC[n]);
				if(T==SC.OPC[n]) {S='1'; break;}
			}
//out.prt("\n>S=[%]",(char*)S);
			F+=S;
		} else F+=T;
	}
out.prt("\nIn LX[%]-> F=[%]",(char*)Z,(char*)F);
	LX=F.GetRangeWithWdChg(".!0","1");
	LX=LX.GetRangeWithWdChg(".!1","0");
	LX=LX.GetRangeWithWdChg("0.&0","0");
	LX=LX.GetRangeWithWdChg("0.&1","0");
	LX=LX.GetRangeWithWdChg("1.&0","0");
	LX=LX.GetRangeWithWdChg("1.&1","1");
	LX=LX.GetRangeWithWdChg("0.+0","0");
	LX=LX.GetRangeWithWdChg("0.+1","1");
	LX=LX.GetRangeWithWdChg("1.+0","1");
	LX=LX.GetRangeWithWdChg("1.+1","1");
	LX=LX.GetRangeWithWdChg("0.^0","0");
	LX=LX.GetRangeWithWdChg("0.^1","1");
	LX=LX.GetRangeWithWdChg("1.^0","1");
	LX=LX.GetRangeWithWdChg("1.^1","0");
out.prt("-> Out LX=[%]",(char*)LX);
	if(LX=='1') return 1;
	return 0;
}

int ATL_CmpOptFilter(MyStr &LL) {
//tout out;
	SC.err=0; SC.ErrMsg="";
	Dequ DQ;
//out.prt("\nLL=[%]",(char*)LL);
	MyStr S(DQ.RemoveLineCmt(LL));
	S=DQ.RemoveSymChrCmt(S);
	S=DQ.RemoveSymBlk(S);
	S=S.GetRangeWithSpCmpress();
	S=S.GetTrim();
//out.prt("=>S=[%]",(char*)S);
	int p=S.InStr("%I");
	int q=S.InStr("%E");
	if(p<0 && q<0) return SC.ops.GetVal();
	if(q>-1) {
		if(q!=S.InStr("%ENDC")) {
			SC.ErrMsg="!!! Error : Unknown %E** ATL compile option command !!!";
			SC.err=-1; return SC.err=-1;
		}
		if(SC.ops.StackCnt()>0) { SC.ops.Pop(); return SC.ops.GetVal(); }
		SC.ErrMsg="!!! Error : find %ENDC w/o %IF !!!";
		SC.err=-1; return SC.err=-1;
	}
	MyStr T;
	if(p>-1) {
		q=S.InStr(' ');
		if(q<0) { SC.ErrMsg="!!! Error : In-corrected %I* statement !!!"; SC.err=-1; return SC.err=-1; }
		T=S.GetRangeByIdx(p,q-1);
		if(T!="%IFE" && T!="%IFN") {
			SC.ErrMsg="!!! Error : Unknown "; SC.ErrMsg+=T; SC.ErrMsg+=" ATL compile option command !!!"; 
			SC.err=-1; return SC.err=-1;
		}
		if(T=="%IFN") T=".NOT.(";
		else		  T="(";
		S=S.GetRangeByIdx(q,-1); S=S.GetTrim();
		T+=S; T+=")";
//out.prt("\nT=[%]",(char*)T);
		int n=ATL_OptAnalyzer(T);
		if(n<0) return SC.err;
		SC.ops.Push(n);
	}
	return SC.ops.GetVal();
}

int main(int ac,char **av) {
	tout out;
	
	if(ac<1) { ShowInformation(); exit(1); }
	
	ArgAnalyzer(ac,av);
	if(SC.err<0) { out.prt("\n\n%",(char*)SC.ErrMsg); usage(); exit(1); }
out.prt("\nArgAnalyzer()....");	
	if(SC.OPC.GetArrayCnt()>0) 	SC.ops.SetVal(1);	// option enable state for beginning
	else						SC.ops.SetVal(-1);	// none option checking
out.prt("\nSC.OPC.GetArrayCnt()=% SC.OPC.List()=\"%\"",SC.OPC.GetArrayCnt(),SC.OPC.List());	

	MyStr S;
	int n;

	S="%IFE ((A.AND.(.NOT.G)).OR.(B.AND.(.NOT.G))).AND.M";
	out.prt("\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);

	S="%MESSAGE AAA";
	out.prt("\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);

	S="%IF";
	out.prt("\n\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);

	S="%END";
	out.prt("\n\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);

	S="%ENDC";
	out.prt("\n\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);

	S="%IFX";
	out.prt("\n\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);

	S="%IFE";
	out.prt("\n\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);

	S="%IFN";
	out.prt("\n\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);

	S="%IFE .NOT";
	out.prt("\n\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);

	S="%IFN ()";
	out.prt("\n\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);

	S="%IFE .NOT.";
	out.prt("\n\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);

	S="%IFE	(A)";
	out.prt("\n\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);

	S="%IFN A";
	out.prt("\n\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);
	
	S="%IFE		.NOT.A";
	out.prt("\n\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);

	S="%IFN			.NOT.(A)";
	out.prt("\n\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);

	S="%IFE .NOT.A.AND.M";
	out.prt("\n\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);

	S="%IFE A.AND.M";
	out.prt("\n\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);

	S="%IFE	A.AND.M.AND.(.NOT.G)";
	out.prt("\n\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);

	S="@a@a%IFN	A.AND.M.AND.(.NOT.G).OR.H ;####";
	out.prt("\n\nSC.OPC.List()=\"%\" , S=\"%\"",SC.OPC.List(),(char*)S);
	n=ATL_CmpOptFilter(S);
	out.prt("\n>>S=[%] Ret(%) %",(char*)S,n,(char*)SC.ErrMsg);

	exit(0);
}
