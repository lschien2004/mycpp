/*************************************************************************************
	v1.1@20191021 initial ver.
	v1.2@20191022 Change for namestr -> NameStr
	v1.3@20191026 operator<<(const char *s) add if(NULL) -> show (null)
***************************************************************************************/
#include <iostream>

#ifndef __MyStd_H__
 #define __MyStd_H__
 #define __MyStdVer__	"MyStd-v1.3@20191026"
 
#include "mystr.h"
#include "namestr.h"

//namespace mystd {

class tout {
  public:
  	void prt(const char *format);
  	template<typename T0, typename... Targs0> void prt(const char* format, T0 value, Targs0... Fargs);
  	tout& operator<<(const int i);
  	tout& operator<<(const long l);
  	tout& operator<<(const char *s);
  	tout& operator<<(const char c);
  	tout& operator<<(MyStr &S);
  	tout& operator<<(NameStr &NS);
 };

template<typename T1, typename... Targs1>
void tout::prt(const char* format, T1 value, Targs1... Fargs)
{
/*
	MyStr S(format);
	if((int)S>0) {
		int p=S.InStr('%');
		if(p<0){ std::cout << (char*)S; return; }
		if(p>0) {
			if(S[p-1]=='/') {
				if(p>1) std::cout << S.GetRangeByIdx(0,p-2);
				std::cout << S[p];
				return tout::prt(format+p+1,value,Fargs...);
			}
			std::cout << S.GetRangeByIdx(0,p-1);
		}
		std::cout << value;
		return tout::prt(format+p+1,Fargs...);
	}
*/
 	for (;*format != '\0'; format++){
 		if(*format=='/' && *(format+1)=='%') { 
 			std::cout<<*(format+1); 
 			return tout::prt(format+2,value,Fargs...); 
 		}
 		else if(*format=='%') { 
 			std::cout<< value;
 			return tout::prt(format+1,Fargs...); 
 		}
 		std::cout<<*format;
 	}
}


//} //namespace mystd

#endif
