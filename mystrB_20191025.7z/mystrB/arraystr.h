/*########################################################################################
	v1.1@20191018 	initial ver.
	v1.2@20191019 	rename GetCNT -> GetArrayCnt
					rename GetSNO -> GetIdx
					+ ArrayStr&  operator+=(ArrayStr &IA);
					+ ArrayStr(ArrayStr &A);
					+ ArrayStr(const int v);
					+ ArrayStr(const long lv);
					+ Add(ArrayStr &A);
					+ Add(const int v);
					+ Add(const long lv);
	v1.3@20191021	+ ArrayStr& operator=(ArrayStr &)
					+ ListRev(const char)		
					+ ListRev(const char*)	
					+ ListRev(MyStr&)	
##########################################################################################*/

#include "mystr.h"

#ifndef __ArrayStr_h__
    #define __ArrayStr_h__
	#define __ArrayStrVer__	"ArrayStr-v1.3@20191021"

class ArrayStr {
private:
 			MyStr 		*pstr;
 			ArrayStr	*nxt;
protected:
	 void 	Release(ArrayStr *nd);
  ArrayStr *GetNode(MyStr &S);
  ArrayStr *GetNode(int idx);
public:
			ArrayStr();
			ArrayStr(const char *s);
			ArrayStr(MyStr &S);
			ArrayStr(ArrayStr &A);
			ArrayStr(const int v);
			ArrayStr(const long lv);
			
			~ArrayStr();
			
	 int 	GetIdx(const char *s);
	 int 	GetIdx(MyStr &S);
	 
	 int 	GetArrayCnt(void);

	 int 	Add(const char *s);
	 int 	Add(MyStr &S);
	 int 	Add(ArrayStr &A);
	 int 	Add(const int v);
	 int 	Add(const long lv);
	 
	 int 	Del(int idx);
	 int 	Del(MyStr &S);
	 int 	Del(const char *s);

const char*	GetStr(int idx);

const char*	List(const char *d=",");
const char*	List(const char c);
const char*	List(MyStr &DIV);

const char*	ListRev(const char *d=",");
const char*	ListRev(const char c);
const char*	ListRev(MyStr &DIV);
	 
 ArrayStr&  operator=(ArrayStr &A);

 ArrayStr&  operator+=(const char *s);
 ArrayStr&  operator+=(MyStr &S);
 ArrayStr&  operator+=(ArrayStr &A);
 
 	MyStr&  operator[](int idx);

};

#endif

