#include "fileobj.h"

//#############################################
//	FnameObj	FnameObj	FnameObj
//#############################################
bool FnameObj::IsLegalFileName(const char *fullfilename){
	MyStr Fname;
	if(fullfilename==NULL) 	Fname=GetFullFileName();
	else 					Fname=fullfilename;
#ifdef _DOS_
	Fname=Fname.GetLowerCase();
#endif
	Fname=Fname.GetTrim();
	if((int)Fname<1) return false;
	if(Fname.ChrOfLstInStr(_Illegal_FileNameChars)>-1) return false;
#ifdef _DOS_
	if(Fname.WdCntInStr(':')>1) return false;
#endif
	return true;
}
//---------------------------------------------------------------------
bool FnameObj::NameSetByFullFileName(MyStr &Fname){
printf("\nFnameObj::NameSetByFullFileName(%s)",(char*)Fname);
	if((int)Fname<1) return false;
	if(!IsLegalFileName((char*)Fname)) return false;
	FileName=Fname.GetTrim(); FilePath=""; FileAtt="";
//printf("\nFnameObj::NameSetByFullFileName FileName='%s'",(char*)FileName);
#ifdef _DOS_
	FileName=FileName.GetLowerCase();
#endif
	int flen=(int)FileName;
	int p=FileName.InStrRev(_SymDir);
	if(p>0 && (flen-1-p)>0) {
		FilePath=FileName.GetRangeByIdx(-1,p);
		FileName=FileName.GetRangeByIdx(p+1,-1);
	}
	p=FileName.InStrRev('.');
	if(p>0) FileAtt=FileName.GetRangeByIdx(p,-1);
	return true;
}
bool FnameObj::NameSetByFullFileName(const char *fullfilename){
	MyStr Fname(fullfilename);	return NameSetByFullFileName(Fname);
}
//---------------------------------------------------------------------
FnameObj::FnameObj(MyStr &FFNAME){
	NameSetByFullFileName(FFNAME);
}
FnameObj::FnameObj(const char *fullfilename){
	NameSetByFullFileName(fullfilename);
}
FnameObj::FnameObj(FnameObj &NF){
	NameSetByFullFileName(NF.GetFullFileName());
}
//---------------------------------------------------------------------
const char* FnameObj::GetFullFileName(void){
	tmp=FileName;
	if((int)FilePath>0) {
		if(FilePath[(int)FilePath-1]!=_SymDir) 	{ tmp=FilePath+_SymDir; tmp+=FileName; }
		else									tmp=FilePath+FileName;
	}
	return (char*)tmp;
}
//---------------------------------------------------------------------
const char *FnameObj::GetFilePath(void) { return (char*) FilePath; }
//---------------------------------------------------------------------
const char *FnameObj::GetFileName(void) { return (char*) FileName; }
//---------------------------------------------------------------------
const char *FnameObj::GetFileAtt(void) { return (char*) FileAtt; }
//---------------------------------------------------------------------
long FnameObj::GetFileSize(const char *fullfilename) {
	long flen=-1;
	if(IsFileExist(fullfilename)) {
		MyStr F;
		if(fullfilename==NULL) 	F=GetFullFileName();
		else 					F=fullfilename;
		F=F.GetTrim();
		if((int)F>0) {
    		struct stat stat_buf;
    		if(stat((char*)F, &stat_buf)==0) flen=stat_buf.st_size;
    	}
    }
	return flen;
}
//---------------------------------------------------------------------
bool FnameObj::IsPathExist(const char *fullpath) {
    //struct stat stat_buf;  
	//MyStr F('.');  F+=_SymDir;
	//int f=stat((char*)F,&stat_buf);
	//=====================================================
	MyStr F;
	if(fullpath==NULL) 	F=GetFilePath();
	else 				F=fullpath;
	F=F.GetTrim();

	if((int)F<1) return true;

#ifdef _DOS_
	if(F[(int)F-1]!=_SymDir) F+=_SymDir;
#else
	if(F[(int)F-1]!=_SymDir) { F+=_SymDir; F+='.'; }
#endif
    //if(f==0) { if(stat((char*)F, &stat_buf)!=0) return false; }

    if(!access((char*)F,F_OK)) return true;
	return false;
}
//---------------------------------------------------------------------
bool FnameObj::IsPathForRead(const char *fullpath) {
	MyStr F;
	if(fullpath==NULL) 	F=GetFilePath();
	else 				F=fullpath;
	F=F.GetTrim();
	if((int)F<1) return true;
	if(F[(int)F-1]!=_SymDir) F+=_SymDir;
    struct stat stat_buf;
    if(stat((char*)F, &stat_buf)!=0) return false;
    if(!access((char*)F,R_OK)) return true;
	return false;
}
//---------------------------------------------------------------------
bool FnameObj::IsPathForWrite(const char *fullpath) {
	MyStr F;
	if(fullpath==NULL) 	F=GetFilePath();
	else 				F=fullpath;
	F=F.GetTrim();
	if((int)F<1) return true;
	if(F[(int)F-1]!=_SymDir) F+=_SymDir;
    struct stat stat_buf;
    if(stat((char*)F, &stat_buf)!=0) return false;
    if(!access((char*)F,W_OK)) return true;
	return false;
}
//---------------------------------------------------------------------
bool FnameObj::IsPathForRun(const char *fullpath) {
	MyStr F;
	if(fullpath==NULL) 	F=GetFilePath();
	else 				F=fullpath;
	F=F.GetTrim();
	if((int)F<1) return true;
	if(F[(int)F-1]!=_SymDir) F+=_SymDir;
    struct stat stat_buf;
    if(stat((char*)F, &stat_buf)!=0) return false;
    if(!access((char*)F,X_OK)) return true;
	return false;
}
//---------------------------------------------------------------------
bool FnameObj::IsFileExist(const char *fullfilename) {
	MyStr F;
	if(fullfilename==NULL) 	F=GetFullFileName();
	else 					F=fullfilename;
	F=F.GetTrim();
//printf("\nFnameObj::IsFileExist(%s)=>'%s'",fullfilename,(char*)F);
	if((int)F>0) { 
		if( !access((char*)F,F_OK) && !IsPathExist((char*)F) ) return true;
	}
//printf("...return false");
	return false;
}
bool FnameObj::IsFileForRead(const char *fullfilename) {
	if(IsFileExist(fullfilename)) {
		MyStr F;
		if(fullfilename==NULL) 	F=GetFullFileName();
		else 					F=fullfilename;
		F=F.GetTrim();
		if((int)F>0) { if(!access((char*)F,R_OK)) return true; }
	}
	return false;
}
bool FnameObj::IsFileForWrite(const char *fullfilename) {
	if(IsFileExist(fullfilename)) {
		MyStr F;
		if(fullfilename==NULL) 	F=GetFullFileName();
		else 					F=fullfilename;
		F=F.GetTrim();
		if((int)F>0) { if(!access((char*)F,W_OK)) return true; }
	}
	return false;
}
bool FnameObj::IsFileForRun(const char *fullfilename) {
	if(IsFileExist(fullfilename)) {
		MyStr F;
		if(fullfilename==NULL) 	F=GetFullFileName();
		else 					F=fullfilename;
		F=F.GetTrim();
		if((int)F>0) { if(!access((char*)F,X_OK)) return true; }
	}
	return false;
}
//#############################################
//	FileObj		FileObj		FileObj
//#############################################
FileObj::FileObj(FnameObj &Fname,FileMode m) {
	buff=NULL;	bsize=-1;	fp=NULL;
	mode=m;	state=_onclose;
	NameSetByFullFileName(Fname.GetFullFileName());
}
FileObj::FileObj(const char *fullfilename,FileMode m) {
	buff=NULL;	bsize=-1;	fp=NULL;
	mode=m;	state=_onclose;
	NameSetByFullFileName(fullfilename);
}
FileObj::FileObj(MyStr &FFNAME,FileMode m) {
	buff=NULL;	bsize=-1;	fp=NULL;
	mode=m;	state=_onclose;
	NameSetByFullFileName(FFNAME);
}

FileObj::~FileObj() { 
	if(fp!=NULL) fclose(fp);
	ReleaseBuffer();
}
//====================================================================================
FileMode 	FileObj::GetFileMode(void)	{ return mode; }
FileState 	FileObj::GetFileState(void)	{ return state; }

//====================================================================================
void FileObj::ReleaseBuffer(void) { if(buff!=NULL) {delete [] buff; buff=NULL;} }

FileObjRetCode FileObj::AllocBuffer(void) {
//printf("\nAllocBuffer: bsize=%d , buff=%u",bsize,buff);
	if(buff==NULL && bsize>0) buff=new char[bsize];
	if(buff!=NULL) return _ok;
	return _opErr;
}

FileObjRetCode FileObj::SetBuffer(const int nsize) {
	int n=default_buffer_size;
	if(n<nsize) n=nsize;
	if(buff!=NULL && bsize!=n) ReleaseBuffer();
	bsize=n;  return AllocBuffer();
}

int FileObj::GetBufferSize(void) { return bsize; }
//====================================================================================
FileObjRetCode FileObj::SetFileMode(FileMode m) {
	if(m!=mode) {
		if(state!=_onclose) return _cmdErr;
		mode=m;
	}
	return _ok;
}
//====================================================================================
FileState FileObj::FileOpen(void) { return FileOpen(mode); }
FileState FileObj::FileOpen(FileMode m) {
	if(SetFileMode(m)!=_ok) return state;
	if(state==_onclose) {
		MyStr F(GetFullFileName());
		//------------------------------------------------	
		switch (mode){
			case _read_mode :
				fp=fopen((char*)F,"r");	state=_reading;	break;
			case _write_mode :
				fp=fopen((char*)F,"w");	state=_writing;	break;
			case _append_mode:
				fp=fopen((char*)F,"a");	state=_writing;	break;
			default:									break;
		}
		//------------------------------------------------	
		if(fp==NULL) state=_onclose;
		//------------------------------------------------	
	}
	return state;
}
//====================================================================================
FileState FileObj::FileRead(MyStr &RtnStr) {
	RtnStr="";
	if(state==_reading) {
		if(buff==NULL) {
			if(bsize<default_buffer_size) {
				if(SetBuffer()!=_ok) return FileClose(); 
			} else if(AllocBuffer()!=_ok) return FileClose(); 
		}
		if(fgets(buff,bsize,fp)==NULL) return FileClose();
		RtnStr=buff; 
	}
//printf("\nbuff=%u RtnStr=\"%s\"",buff,(char*)RtnStr);
	return state;
}
//====================================================================================
FileState FileObj::FileWrite(MyStr &OutStr) {
	if(mode!=_read_mode || state!=_writing) fprintf(fp,"%s",(char*)OutStr);
	return state;
}

FileState FileObj::FileWrite(const char *s) { MyStr S(s); return FileWrite(S); }
//====================================================================================
FileState FileObj::FileObj::FileClose(void) { 
	fclose(fp); state=_onclose;
	ReleaseBuffer();
	return state; 
}
