#ifndef __MyStr__h__
    #define __MyStr__h__

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <iostream>

typedef struct {
	int p1;
	int p2;
} PO2;

int WdIdxInStr(const char *str,const char *word);
int WdIdxInStr(const int si,const char *str,const char *word);
int WdIdxInStr(const int si,const int ei,const char *str,const char *word);
int WdIdxInStrRev(const char *str,const char *word);
int WdIdxInStrRev(const int si,const char *str,const char *word);
int WdIdxInStrRev(const int si,const int ei,const char *str,const char *word);

int WdIdxInStr(const char *str,const char c);
int WdIdxInStr(const int si,const char *str,const char c);
int WdIdxInStr(const int si,const int ei,const char *str,const char c);
int WdIdxInStrRev(const char *str,const char c);
int WdIdxInStrRev(const int si,const char *str,const char c);
int WdIdxInStrRev(const int si,const int ei,const char *str,const char c);


class MyStr {
private:
static 		 char 		Emptystr[];
static 		 PO2		sp2;
			 int  		len;
			 char 		*str;
			 char 		*tmp;
protected:
			 const char*	resizeX(char **pstr,const char *istr);
virtual 	 const char*	resize(const char *istr);
virtual 	 const char*	resizetmp(const char *istr);
virtual 	 void		release(void);
virtual 	 void		releasetmp(void);

public:
			 MyStr();
			 MyStr(const char c);
			 MyStr(const char *s);
			 MyStr(MyStr &S);
			 ~MyStr();
//====================================================================================================================================
virtual 	 operator int();
virtual 	 operator char();
virtual 	 operator char*();
virtual 	 operator const char*();
//====================================================================================================================================
virtual 	 MyStr& operator=(const char *s);
virtual 	 MyStr& operator=(const char c);
virtual 	 MyStr& operator=(MyStr &S);
virtual 	 MyStr& operator=(const int n);
virtual 	 MyStr& operator=(const long l);

virtual 	 MyStr& operator+=(const char *s);
virtual 	 MyStr& operator+=(const char c);
virtual 	 MyStr& operator+=(MyStr &S);
virtual 	 MyStr& operator+=(const int n);
virtual 	 MyStr& operator+=(const long l);

virtual 	 bool operator==(const char *s);
virtual 	 bool operator==(const char c);
virtual 	 bool operator==(MyStr &S);
 
virtual 	 bool operator!=(const char *s);
virtual 	 bool operator!=(const char c);
virtual 	 bool operator!=(MyStr &S);

virtual 	 const char* operator+(const char *s);
virtual 	 const char* operator+(const char c);
virtual 	 const char* operator+(MyStr &S);
virtual 	 const char* operator+(const int n);
virtual 	 const char* operator+(const long l);
//====================================================================================================================================
			 PO2 		SymBlkIdxInStr(const int si,const int ei,const char *SymChrLst);
			 PO2 		SymBlkIdxInStr(const int si,const int ei,const char *str,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetDos2Unix(void);
virtual 	 const char* GetDos2UnixExSymBlk(const char *SymChrLst);

virtual 	 const char* GetLowerCase(void);
virtual 	 const char* GetUpperCase(void);

virtual 	 int 		LowerCaseInside(void);
virtual 	 int 		LowerCaseInside(const int si);
virtual 	 int 		LowerCaseInside(const int si,const int ei);
//====================================================================================================================================
virtual 	 int 		InStr(const char c);
virtual 	 int 		InStr(const char *w);
virtual 	 int 		InStr(const int si,const char c);
virtual 	 int 		InStr(const int si,const char *w);
virtual 	 int 		InStr(const int si,const int ei,const char c);
virtual 	 int 		InStr(const int si,const int ei,const char *w);
//====================================================================================================================================
virtual 	 int 		InStrExSymBlk(const char c,const char *SymChrLst);
virtual 	 int 		InStrExSymBlk(const char *w,const char *SymChrLst);
virtual 	 int 		InStrExSymBlk(const int si,const char c,const char *SymChrLst);
virtual 	 int 		InStrExSymBlk(const int si,const char *w,const char *SymChrLst);
virtual 	 int 		InStrExSymBlk(const int si,const int ei,const char c,const char *SymChrLst);
virtual 	 int 		InStrExSymBlk(const int si,const int ei,const char *w,const char *SymChrLst);
//====================================================================================================================================
virtual 	 int 		InStrRev(const char c);
virtual 	 int 		InStrRev(const char *w);
virtual 	 int 		InStrRev(const int si,const char c);                                              
virtual 	 int 		InStrRev(const int si,const char *w);
virtual 	 int 		InStrRev(const int si,const int ei,const char c);
virtual 	 int 		InStrRev(const int si,const int ei,const char *w);
//====================================================================================================================================
virtual 	 int 		InStrRevExSymBlk(const char c,const char *SymChrLst);
virtual 	 int 		InStrRevExSymBlk(const char *w,const char *SymChrLst);
virtual 	 int 		InStrRevExSymBlk(const int si,const char c,const char *SymChrLst);
virtual 	 int 		InStrRevExSymBlk(const int si,const char *w,const char *SymChrLst);
virtual 	 int 		InStrRevExSymBlk(const int si,const int ei,const char c,const char *SymChrLst);
virtual 	 int 		InStrRevExSymBlk(const int si,const int ei,const char *w,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeByIdx(const int si,const int ei);
virtual 	 const char* GetRangeBtwIdx(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetRangeByKey(const char c1,const char c2);
virtual 	 const char* GetRangeByKey(const char *k1,const char c2);
virtual 	 const char* GetRangeByKey(const char c1,const char *k2);
virtual 	 const char* GetRangeByKey(const char *k1,const char *k2);
//====================================================================================================================================
virtual 	 const char* GetRangeByKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExSymBlk(const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeBtwKey(const char c1,const char c2);
virtual 	 const char* GetRangeBtwKey(const char *k1,const char c2);
virtual 	 const char* GetRangeBtwKey(const char c1,const char *k2);
virtual 	 const char* GetRangeBtwKey(const char *k1,const char *k2);

virtual 	 const char* GetRangeBtwKey(const int si,const char c1,const char c2);
virtual 	 const char* GetRangeBtwKey(const int si,const char *k1,const char c2);
virtual 	 const char* GetRangeBtwKey(const int si,const char c1,const char *k2);
virtual 	 const char* GetRangeBtwKey(const int si,const char *k1,const char *k2);

virtual 	 const char* GetRangeBtwKey(const int si,const int ei,const char c1,const char c2);
virtual 	 const char* GetRangeBtwKey(const int si,const int ei,const char *k1,const char c2);
virtual 	 const char* GetRangeBtwKey(const int si,const int ei,const char c1,const char *k2);
virtual 	 const char* GetRangeBtwKey(const int si,const int ei,const char *k1,const char *k2);
//====================================================================================================================================
virtual 	 const char* GetRangeBtwKeyExSymBlk(const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdChg(const char och,const char nch);
virtual 	 const char* GetRangeWithWdChg(const char och,const char *nwd);
virtual 	 const char* GetRangeWithWdChg(const char *owd,const char nch);
virtual 	 const char* GetRangeWithWdChg(const char *owd,const char *nwd);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdChg(const int si,const char och,const char nch);  
virtual 	 const char* GetRangeWithWdChg(const int si,const char och,const char *nwd); 
virtual 	 const char* GetRangeWithWdChg(const int si,const char *owd,const char nch); 
virtual 	 const char* GetRangeWithWdChg(const int si,const char *owd,const char *nwd);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdChg(const int si,const int ei,const char och,const char nch);  
virtual 	 const char* GetRangeWithWdChg(const int si,const int ei,const char och,const char *nwd); 
virtual 	 const char* GetRangeWithWdChg(const int si,const int ei,const char *owd,const char nch); 
virtual 	 const char* GetRangeWithWdChg(const int si,const int ei,const char *owd,const char *nwd);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdChgExSymBlk(const char och,const char nch,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdChgExSymBlk(const char och,const char *nwd,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdChgExSymBlk(const char *owd,const char nch,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdChgExSymBlk(const char *owd,const char *nwd,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdChgExSymBlk(const int si,const char och,const char nch,const char *SymChrLst);  
virtual 	 const char* GetRangeWithWdChgExSymBlk(const int si,const char och,const char *nwd,const char *SymChrLst); 
virtual 	 const char* GetRangeWithWdChgExSymBlk(const int si,const char *owd,const char nch,const char *SymChrLst); 
virtual 	 const char* GetRangeWithWdChgExSymBlk(const int si,const char *owd,const char *nwd,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdChgExSymBlk(const int si,const int ei,const char och,const char nch,const char *SymChrLst);  
virtual 	 const char* GetRangeWithWdChgExSymBlk(const int si,const int ei,const char och,const char *nwd,const char *SymChrLst); 
virtual 	 const char* GetRangeWithWdChgExSymBlk(const int si,const int ei,const char *owd,const char nch,const char *SymChrLst); 
virtual 	 const char* GetRangeWithWdChgExSymBlk(const int si,const int ei,const char *owd,const char *nwd,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdDel(const char c);
virtual 	 const char* GetRangeWithWdDel(const char *wd);
virtual 	 const char* GetRangeWithWdDel(const int si,const char c);
virtual 	 const char* GetRangeWithWdDel(const int si,const char *wd);
virtual 	 const char* GetRangeWithWdDel(const int si,const int ei,const char c);
virtual 	 const char* GetRangeWithWdDel(const int si,const int ei,const char *wd);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdDelExSymBlk(const char c,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdDelExSymBlk(const char *wd,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdDelExSymBlk(const int si,const char c,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdDelExSymBlk(const int si,const char *wd,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdDelExSymBlk(const int si,const int ei,const char *wd,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdDelExSymBlk(const int si,const int ei,const char c,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithSpDel(void);
virtual 	 const char* GetRangeWithSpDel(const int si);
virtual 	 const char* GetRangeWithSpDel(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetRangeWithSpDelExSymBlk(const char *SymChrLst);
virtual 	 const char* GetRangeWithSpDelExSymBlk(const int si,const char *SymChrLst);
virtual 	 const char* GetRangeWithSpDelExSymBlk(const int si,const int ei,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdCmpress(const char c);
virtual 	 const char* GetRangeWithWdCmpress(const char *wd);
virtual 	 const char* GetRangeWithWdCmpress(const int si,const char c);
virtual 	 const char* GetRangeWithWdCmpress(const int si,const char *wd);
virtual 	 const char* GetRangeWithWdCmpress(const int si,const int ei,const char c);
virtual 	 const char* GetRangeWithWdCmpress(const int si,const int ei,const char *wd);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdCmpressExSymBlk(const char c,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdCmpressExSymBlk(const char *wd,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdCmpressExSymBlk(const int si,const char c,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdCmpressExSymBlk(const int si,const char *wd,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdCmpressExSymBlk(const int si,const int ei,const char c,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdCmpressExSymBlk(const int si,const int ei,const char *wd,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithSpCmpress(void);
virtual 	 const char* GetRangeWithSpCmpress(const int si);
virtual 	 const char* GetRangeWithSpCmpress(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetRangeWithSpCmpressExSymBlk(const char *SymChrLst);
virtual 	 const char* GetRangeWithSpCmpressExSymBlk(const int si,const char *SymChrLst);
virtual 	 const char* GetRangeWithSpCmpressExSymBlk(const int si,const int ei,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithDelByKey(const char c1,const char c2);
virtual 	 const char* GetRangeWithDelByKey(const char c1,const char *k2);
virtual 	 const char* GetRangeWithDelByKey(const char *k1,const char c2);
virtual 	 const char* GetRangeWithDelByKey(const char *k1,const char *k2);

virtual 	 const char* GetRangeWithDelByKey(const int si,const char c1,const char c2);
virtual 	 const char* GetRangeWithDelByKey(const int si,const char c1,const char *k2);
virtual 	 const char* GetRangeWithDelByKey(const int si,const char *k1,const char c2);
virtual 	 const char* GetRangeWithDelByKey(const int si,const char *k1,const char *k2);

virtual 	 const char* GetRangeWithDelByKey(const int si,const int ei,const char c1,const char c2);
virtual 	 const char* GetRangeWithDelByKey(const int si,const int ei,const char c1,const char *k2);
virtual 	 const char* GetRangeWithDelByKey(const int si,const int ei,const char *k1,const char c2);
virtual 	 const char* GetRangeWithDelByKey(const int si,const int ei,const char *k1,const char *k2);
//====================================================================================================================================
virtual 	 const char* GetRangeWithDelBtwKey(const char c1,const char c2);
virtual 	 const char* GetRangeWithDelBtwKey(const char c1,const char *k2);
virtual 	 const char* GetRangeWithDelBtwKey(const char *k1,const char c2);
virtual 	 const char* GetRangeWithDelBtwKey(const char *k1,const char *k2);

virtual 	 const char* GetRangeWithDelBtwKey(const int si,const char c1,const char c2);
virtual 	 const char* GetRangeWithDelBtwKey(const int si,const char c1,const char *k2);
virtual 	 const char* GetRangeWithDelBtwKey(const int si,const char *k1,const char c2);
virtual 	 const char* GetRangeWithDelBtwKey(const int si,const char *k1,const char *k2);

virtual 	 const char* GetRangeWithDelBtwKey(const int si,const int ei,const char c1,const char c2);
virtual 	 const char* GetRangeWithDelBtwKey(const int si,const int ei,const char c1,const char *k2);
virtual 	 const char* GetRangeWithDelBtwKey(const int si,const int ei,const char *k1,const char c2);
virtual 	 const char* GetRangeWithDelBtwKey(const int si,const int ei,const char *k1,const char *k2);
//====================================================================================================================================
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetLineDelByKey(const char c1,const char c2);
virtual 	 const char* GetLineDelByKey(const char c1,const char *k2);
virtual 	 const char* GetLineDelByKey(const char *k1,const char c2);
virtual 	 const char* GetLineDelByKey(const char *k1,const char *k2);

virtual 	 const char* GetLineDelByKey(const int si,const char c1,const char c2);
virtual 	 const char* GetLineDelByKey(const int si,const char c1,const char *k2);
virtual 	 const char* GetLineDelByKey(const int si,const char *k1,const char c2);
virtual 	 const char* GetLineDelByKey(const int si,const char *k1,const char *k2);

virtual 	 const char* GetLineDelByKey(const int si,const int ei,const char c1,const char c2);
virtual 	 const char* GetLineDelByKey(const int si,const int ei,const char c1,const char *k2);
virtual 	 const char* GetLineDelByKey(const int si,const int ei,const char *k1,const char c2);
virtual 	 const char* GetLineDelByKey(const int si,const int ei,const char *k1,const char *k2);
//====================================================================================================================================
virtual 	 const char* GetLineDelByKeyExSymBlk(const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelByKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetLineDelByKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelByKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetLineDelByKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelByKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetLineDelByKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelByKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetLineDelByKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelByKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetLineDelByKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelByKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetLineDelBtwKey(const char c1,const char c2);
virtual 	 const char* GetLineDelBtwKey(const char c1,const char *k2);
virtual 	 const char* GetLineDelBtwKey(const char *k1,const char c2);
virtual 	 const char* GetLineDelBtwKey(const char *k1,const char *k2);

virtual 	 const char* GetLineDelBtwKey(const int si,const char c1,const char c2);
virtual 	 const char* GetLineDelBtwKey(const int si,const char c1,const char *k2);
virtual 	 const char* GetLineDelBtwKey(const int si,const char *k1,const char c2);
virtual 	 const char* GetLineDelBtwKey(const int si,const char *k1,const char *k2);

virtual 	 const char* GetLineDelBtwKey(const int si,const int ei,const char c1,const char c2);
virtual 	 const char* GetLineDelBtwKey(const int si,const int ei,const char c1,const char *k2);
virtual 	 const char* GetLineDelBtwKey(const int si,const int ei,const char *k1,const char c2);
virtual 	 const char* GetLineDelBtwKey(const int si,const int ei,const char *k1,const char *k2);
//====================================================================================================================================
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetLineDelBtwKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetLineDelBtwKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetLineTrim(void);
virtual 	 const char* GetLineTrim(const int si);
virtual 	 const char* GetLineTrim(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetLineTrimL(void);
virtual 	 const char* GetLineTrimL(const int si);
virtual 	 const char* GetLineTrimL(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetLineTrimR(void);
virtual 	 const char* GetLineTrimR(const int si);
virtual 	 const char* GetLineTrimR(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetLineTrimA(void);
virtual 	 const char* GetLineTrimA(const int si);
virtual 	 const char* GetLineTrimA(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetLineTrimExSymBlk(const char *SymChrLst);
virtual 	 const char* GetLineTrimExSymBlk(const int si,const char *SymChrLst);
virtual 	 const char* GetLineTrimExSymBlk(const int si,const int ei,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetLineTrimLExSymBlk(const char *SymChrLst);
virtual 	 const char* GetLineTrimLExSymBlk(const int si,const char *SymChrLst);
virtual 	 const char* GetLineTrimLExSymBlk(const int si,const int ei,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetLineTrimRExSymBlk(const char *SymChrLst);
virtual 	 const char* GetLineTrimRExSymBlk(const int si,const char *SymChrLst);
virtual 	 const char* GetLineTrimRExSymBlk(const int si,const int ei,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetLineTrimAExSymBlk(const char *SymChrLst);
virtual 	 const char* GetLineTrimAExSymBlk(const int si,const char *SymChrLst);
virtual 	 const char* GetLineTrimAExSymBlk(const int si,const int ei,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetLineWithCmtChrDelN(const char CmtChr,const int N);
virtual 	 const char* GetLineWithCmtChrDelN(const int si,const char CmtChr,const int N);
virtual 	 const char* GetLineWithCmtChrDelN(const int si,const int ei,const char CmtChr,const int N);
//====================================================================================================================================
virtual 	 const char* GetLineWithCmtChrDelNExSymBlk(const char CmtChr,const int N,const char *SymChrLst);
virtual 	 const char* GetLineWithCmtChrDelNExSymBlk(const int si,const char CmtChr,const int N,const char *SymChrLst);
virtual 	 const char* GetLineWithCmtChrDelNExSymBlk(const int si,const int ei,const char CmtChr,const int N,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetTrim(void);
virtual 	 const char* GetTrim(const int si);
virtual 	 const char* GetTrim(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetTrimL(void);
virtual 	 const char* GetTrimL(const int si);
virtual 	 const char* GetTrimL(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetTrimR(void);
virtual 	 const char* GetTrimR(const int si);
virtual 	 const char* GetTrimR(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetTrimA(void);
virtual 	 const char* GetTrimA(const int si);
virtual 	 const char* GetTrimA(const int si,const int ei);

};

#endif
