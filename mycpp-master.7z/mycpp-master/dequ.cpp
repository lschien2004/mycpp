#include "dequ.h"

DEQU::DEQU() { PARN=0; NAME=""; BODY=""; Para=NULL; }
DEQU::DEQU(MyStr &S) { PARN=0; Para=NULL; Setup((const char*)S); }
DEQU::DEQU(const char *s) { PARN=0; Para=NULL; Setup(s); }
DEQU::~DEQU(void) { ParaRelease(); }

void DEQU::ParaRelease(void) {
//printf("\nDEQU::ParaRelease Para=%u PARN=%d",Para,PARN);
	while(Para!=NULL) { 
		DSLINK *t=Para;
		Para=Para->nxt;
		delete t;
		PARN--;
	}
//printf("-> Para=%u PARN=%d\n",Para,PARN);
	PARN=0;
}

const char *DEQU::CheckTrimDEQU(const char *dequstr)
{
	int klen=strlen(DEQUKEY);
	int minlen = klen+8;
	MyStr T(dequstr);
//printf("\nDEQU::CheckTrimDEQU(%s)",(char*)T);
	MyStr S;
	if((int)T<minlen) { TMP=""; return (const char*)TMP; }
	T=T.GetLineDelBtwKeyExSymBlk(DEQUBDYED,"",DEQUSYMS);
//printf("\nDEQU::CheckTrimDEQU 0 T='%s'",(char*)T);

	T=T.GetLineWithCmtChrDelNExSymBlk(DEQUCMTC,1,DEQUSYMS);
//printf("\nDEQU::CheckTrimDEQU 0 T='%s'",(char*)T);
	T=T.GetLineDelBtwKeyExSymBlk(DEQULCMT,"\n",DEQUSYMS);
//printf("\nDEQU::CheckTrimDEQU 0 T='%s'",(char*)T);
	S=DEQULCMT; S+="\n";
	T=T.GetRangeWithWdChgExSymBlk((char*)S,"\n",DEQUSYMS);
	T=T.GetRangeWithWdChgExSymBlk("\n\n","\n",DEQUSYMS);
	T=T.GetRangeWithSpCmpressExSymBlk(DEQUSYMS);
	T=T.GetLineTrimLExSymBlk(DEQUSYMS);
//printf("\nDEQU::CheckTrimDEQU 1 T='%s'",(char*)T);
	
	if(T.InStr(DEQUKEY)==0 && T.InStr(' ')==klen) {
		S=T.GetRangeBtwKey(DEQUKEY,DEQUPARST);
		S=S.GetLineTrim();
//printf("\nDEQU::CheckTrimDEQU 2 S='%s'",(char*)S);
		if((int)S>0) {
			TMP=DEQUKEY;
			TMP+=' ';
			TMP+=S;
			int p=T.InStr(klen,DEQUPARST);
			int q=T.InStr(klen,DEQUPARED);
			if(p>-1 && q>p) {
				S=T.GetRangeByIdx(p,q);
				S=S.GetLineTrimA();
//printf("\nDEQU::CheckTrimDEQU 3 S='%s'",(char*)S);
				TMP+=S;
				p=T.InStr(q,DEQUBDYST);
				q=T.InStr(q,DEQUBDYED);
				if(p>-1 && q>p) {
					S=T.GetRangeByIdx(p+strlen(DEQUBDYST),q-1);
					S=S.GetLineDelBtwKeyExSymBlk(DEQULCMT,"",DEQUSYMS);
					S=S.GetLineTrim();
//printf("\nDEQU::CheckTrimDEQU 4 S='%s'",(char*)S);
					TMP+=DEQUBDYST;
					TMP+=S;
					TMP+=DEQUBDYED;
//printf("\nDEQU::CheckTrimDEQU 5 TMP='%s'",(char*)TMP);
					return (const char*)TMP;
				}
			}
		}
	}
	TMP="";
	return (const char*)TMP;
}

void DEQU::Setup(const char *s) {
	ParaRelease();
	MyStr S(CheckTrimDEQU(s));
	PARN=0;
	BODY="";
	NAME=CheckNameOfDEQU((char*)S);
//printf("\nDEQU::Setup NAME='%s'",(char*)NAME);
	if(NAME!="") {
		BODY=CheckBodyOfDEQU((char*)S);
//printf("\nDEQU::Setup BODY='%s'",(char*)BODY);
		MyStr PA(CheckParaStrOfDEQU((char*)S));
//printf("\nDEQU::Setup Para=%u PA='%s'",Para,(char*)PA);
		DSLINK *dp;
		if((int)PA>0) {
			PA+=',';
			int k=0;
			int p=PA.InStr(k,-1,',');
//printf("\nDEQU::Setup 0 k=%d p=%d",k,p);
			while(p>-1) {
				PARN++;
				DSLINK *nd=new DSLINK[1];
				if(p>k) nd->data=PA.GetRangeByIdx(k,p-1);
				else	nd->data=PARN;
//printf("\nDEQU::Setup 1 PARN=%d '%s'",PARN,(char*)nd->data);
				nd->nxt=NULL;
				if(Para==NULL) 	Para=nd;
				else			dp->nxt=nd;
				dp=nd;
				k=p+1;
				p=PA.InStr(k,-1,',');;
			}
		} 
	}
//printf("\nDEQU::Setup PARN=%d",PARN);
}

const char *DEQU::CheckNameOfDEQU(const char *dequstr) 
{
	MyStr S(CheckTrimDEQU(dequstr));
	TMP=S;
	if((int)S<1) return (char *)TMP;
	TMP=TMP.GetRangeBtwKey(DEQUKEY,DEQUPARST);
	TMP=TMP.GetLineTrim();
//printf("\nDEQU::CheckNameOfDEQU ->[%s]",(char*)TMP);
	return (char*)TMP;
}
const char *DEQU::CheckBodyOfDEQU(const char *dequstr) 
{
	MyStr S(CheckTrimDEQU(dequstr));
	TMP=S;
	if((int)TMP<1) return (const char *)TMP;
	TMP=TMP.GetRangeBtwKey(DEQUBDYST,DEQUBDYED);
	TMP=TMP.GetLineTrim();
//printf("\nDEQU::CheckBodyOfDEQU ->[%s]",(char*)TMP);
	return (const char*)TMP;
}
const char *DEQU::CheckParaStrOfDEQU(const char *dequstr) 
{
	MyStr S(CheckTrimDEQU(dequstr));
	TMP=S;
	if((int)TMP<1) return (const char *)TMP;
	TMP=TMP.GetRangeBtwKey(DEQUPARST,DEQUPARED);
	TMP=TMP.GetLineTrimA();
//printf("\nDEQU::CheckParaStrOfDEQU ->[%s]",(char*)TMP);
	return (const char*)TMP;
}

const char *DEQU::GetName(void) { return (const char*)NAME; }
const char *DEQU::GetBody(void) { return (const char*)BODY; }
int  		DEQU::GetParN(void) { return PARN; }
const char *DEQU::GetPara(void) {
	MyStr S("");
	int n=0;
	DSLINK *dp=Para;
	while(dp!=NULL) {
		if(n>0) S+=','; 
		S+=dp->data;
		dp=dp->nxt;
		n++;
	}
	TMP=S;
	return (const char*)TMP;
}

DEQU& DEQU::operator=(const char *s) {ParaRelease(); Setup(s);}
DEQU& DEQU::operator=(MyStr &S) {ParaRelease();  Setup((const char*)S);}
