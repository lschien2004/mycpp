#include "dequ.h"

DEQU::DEQU() { PARN=0; NAME=""; BODY=""; Para=NULL; }
DEQU::DEQU(MyStr &S) { PARN=0; Para=NULL; Setup((const char*)S); }
DEQU::DEQU(const char *s) { PARN=0; Para=NULL; Setup(s); }
DEQU::~DEQU(void) { ParaRelease(); }

void DEQU::ParaRelease(void) {
	while(Para!=NULL) { 
		DSLINK *t=Para;
		Para=Para->nxt;
		delete t;
		PARN--;
	}
	PARN=0;
}

const char *DEQU::GetTrimDEQU(const char *dequstr)
{
	int klen=strlen(DEQUKEY);
	int minlen = klen+8;
	MyStr T(dequstr);
	MyStr S;
	if((int)T<minlen) { TMP=""; return (const char*)TMP; }
	T=T.GetLineDelBtwKeyExSymBlk(DEQUBDYED,"",DEQUSYMS);
	T=T.GetLineWithCmtChrDelNExSymBlk(DEQUCMTC,1,DEQUSYMS);
//printf("\n#T=[%s]",(char*)T);
    //T=T.GetLineDelBtwKeyExSymBlk(DEQULCMT,"\n",DEQUSYMS);
	//S=DEQULCMT; S+="\n";
	//T=T.GetRangeWithWdChgExSymBlk((char*)S,"\n",DEQUSYMS);
	T=T.GetLineDelByKey(DEQULCMT,"");
	T=T.GetRangeWithWdChgExSymBlk("\n\n","\n",DEQUSYMS);
	T=T.GetRangeWithSpCmpressExSymBlk(DEQUSYMS);
//	T=T.GetLineTrimLExSymBlk(DEQUSYMS);
	T=T.GetLineTrimExSymBlk(DEQUSYMS);
	
	if(T.InStr(DEQUKEY)==0 && T.InStr(' ')==klen) {
		S=T.GetRangeBtwKey(DEQUKEY,DEQUPARST);
		S=S.GetLineTrim();
		if((int)S>0) {
			TMP=DEQUKEY;
			TMP+=' ';
			TMP+=S;
			int p=T.InStr(klen,DEQUPARST);
			int q=T.InStr(klen,DEQUPARED);
			if(p>-1 && q>p) {
				S=T.GetRangeByIdx(p,q);
				//S=S.GetLineTrimA();
				S=S.GetLineTrimAExSymBlk(DEQUSYMS);
				TMP+=S;
				p=T.InStr(q,DEQUBDYST);
				q=T.InStr(q,DEQUBDYED);
				if(p>-1 && q>p) {
					S=T.GetRangeByIdx(p+strlen(DEQUBDYST),q-1);
					S=S.GetLineDelByKeyExSymBlk(DEQULCMT,"",DEQUSYMS);
					S=S.GetLineTrim();
					TMP+=DEQUBDYST;
					TMP+=S;
					TMP+=DEQUBDYED;
					return (const char*)TMP;
				}
			}
		}
	}
	TMP="";
	return (const char*)TMP;
}

void DEQU::Setup(const char *s) {
	ParaRelease();
	MyStr S(GetTrimDEQU(s));
	PARN=0;
	BODY="";
	NAME=GetNameFromTrimDEQU((char*)S);
	if(NAME.LowerCaseInside()<1) NAME="";
	if(NAME!="") {
		BODY=GetBodyFromTrimDEQU((char*)S);
		BODY=BODY.GetRangeWithWdCmpress('\n');
		MyStr PA(GetParaFromTrimDEQU((char*)S));
		DSLINK *dp;
		if((int)PA>0) {
			PA+=',';
			int k=0;
			int p=PA.InStr(k,-1,',');
			while(p>-1) {
				PARN++;
				DSLINK *nd=new DSLINK[1];
				if(p>k) nd->data=PA.GetRangeByIdx(k,p-1);
				else	nd->data=PARN;
				//===============================
				MyStr T(DEQUBDYVPAST);
				T+=nd->data;
				T+=DEQUBDYVPAED;
				MyStr N(DEQUBDYVPAST);
				N+=PARN;
				N+=DEQUBDYVPAED;
				BODY=BODY.GetRangeWithWdChg((char*)T,(char*)N);
				//===============================
				nd->nxt=NULL;
				if(Para==NULL) 	Para=nd;
				else			dp->nxt=nd;
				dp=nd;
				k=p+1;
				p=PA.InStr(k,-1,',');;
			}
		} 
	}
}

const char *DEQU::GetNameFromTrimDEQU(const char *trimdequ) 
{
	MyStr S(trimdequ);
	TMP=S;
	if((int)S<1) return (char *)TMP;
	TMP=TMP.GetRangeBtwKey(DEQUKEY,DEQUPARST);
	TMP=TMP.GetTrim();
	return (char*)TMP;
}
const char *DEQU::GetBodyFromTrimDEQU(const char *trimdequ) 
{
	MyStr S(trimdequ);
	TMP=S;
	if((int)TMP<1) return (const char *)TMP;
	TMP=TMP.GetRangeBtwKey(DEQUBDYST,DEQUBDYED);
	TMP=TMP.GetTrim();
	TMP=TMP.GetLineTrim();
	return (const char*)TMP;
}
const char *DEQU::GetParaFromTrimDEQU(const char *trimdequ) 
{
	MyStr S(trimdequ);
	TMP=S;
	if((int)TMP<1) return (const char *)TMP;
	TMP=TMP.GetRangeBtwKey(DEQUPARST,DEQUPARED);
	TMP=TMP.GetLineTrimA();
	return (const char*)TMP;
}

const char *DEQU::GetName(void) { return (const char*)NAME; }
const char *DEQU::GetBody(void) { return (const char*)BODY; }
int  		DEQU::GetParN(void) { return PARN; }
const char *DEQU::GetPara(void) {
	MyStr S("");
	int n=0;
	DSLINK *dp=Para;
	while(dp!=NULL) {
		if(n>0) S+=','; 
		S+=dp->data;
		dp=dp->nxt;
		n++;
	}
	TMP=S;
	return (const char*)TMP;
}

DEQU& DEQU::operator=(const char *s) {ParaRelease(); Setup(s);}
DEQU& DEQU::operator=(MyStr &S) {ParaRelease();  Setup((const char*)S);}
bool DEQU::operator==(const char *name) { return NAME==name; }
bool DEQU::operator==(MyStr &S) { return NAME==S; }
bool DEQU::operator!=(const char *name) { if(NAME==name) return false; else return true; }
bool DEQU::operator!=(MyStr &S) { if(NAME==S) return false; else return true; }


//####################################################################
//#		DEQU_DB
//####################################################################
void DEQU_DB::ReleaseDBP(void) {
	while(DBP!=NULL) {
		DQLINK *tp=DBP;
		DBP=DBP->nxt;
		delete tp;
		CNT--;
	}
}
//===================================================
void DEQU_DB::Add(DEQU& DD) {
	if(DD.GetName()!="") {
		CNT++;
		DQLINK *dp = new DQLINK;
		dp->NAME=DD.GetName();
		dp->PARN=DD.GetParN();
		dp->nxt=NULL;
		if(DBP==NULL) DBP=dp;
		else {
			DQLINK *tp=DBP;
			while(tp->nxt!=NULL) tp=tp->nxt;
			tp->nxt=dp;
		}
		FILE *fp;
		MyStr WTP("a");
		if(CNT==1) WTP="w";
		if((fp=fopen((char*)DBfile,(char*)WTP))==NULL) {
			printf("\n Error ! Open '%s' for write(%s) fail !\n",(char*)DBfile,(char*)WTP);
			return;
		}
		//---------------------------------------------
		int mxlen=DEQU_DB_MaxLineLen;
		MyStr B(DD.GetBody());
		B=B.GetRangeWithWdChg("\n","\\n");
		int l=(int)B;
		int n=0;
		while(l>mxlen) { n++; l-=mxlen;}
		if(l>0) n++;
		fprintf(fp,"_{%s}_(%d)_[%d]_<%s>_@%s@_\n",DD.GetName(),DD.GetParN(),n,DD.GetPara(),_dequVer_);
		for(l=1;l<n;l++) {
			fprintf(fp,"%s\n",B.GetRangeByIdx((l-1)*mxlen,(l-1)*mxlen+mxlen-1));
		}	
		fprintf(fp,"%s\n",B.GetRangeByIdx((n-1)*mxlen,-1));
		fclose(fp);
	}
}
//===================================================
int DEQU_DB::SearchDEQUparN(const char *dequname) {
	MyStr DQ(dequname);
	if(CNT>0 || (int)DQ>0) {
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			if(dp->NAME==DQ) return dp->PARN;
			dp=dp->nxt;
		}
	}
	return -1;
}
//===================================================
const char*  DEQU_DB::GetDEQUnameByDBIdx(const int si) {
	TMP="";
	if(CNT>0 && si>-1 && si<CNT) {
		int n=-1;
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			n++;
			if(n==si) { TMP=dp->NAME; break; }
			dp=dp->nxt;
		}
	}
	return (char*)TMP;
}
//===================================================
const char* DEQU_DB::DEQU_Inside(const char *line) {
	TMP="";
	MyStr LL(line);
	if(CNT>0 || (int)LL>0) {
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			if(LL.InStr((char*)dp->NAME)>-1) { TMP=dp->NAME; break; }
			dp=dp->nxt;
		}
	}
	return (char*)TMP;
}
//===================================================
const char *DEQU_DB::GetDEQUbodyInDB(const char *dequname) {
	TMP="";
	if(SearchDEQUparN(dequname)<0) return (char*)TMP;
	FILE *fp;
	char line[DEQU_DB_MaxLineLen+5];
	if((fp=fopen((char*)DBfile,"r"))==NULL) {
		printf("\n Error ! Open '%s' for read fail !\n",(char*)DBfile);
		return (char*)TMP;
	}
	MyStr DQ("_{");
	DQ+=dequname;
	DQ+="}_";
	while(1) {
		if(fgets(line,DEQU_DB_MaxLineLen+2,fp)==NULL) { fclose(fp); break; }
		MyStr LL(line);
		if(LL.InStr((char*)DQ)>-1) {
//printf("\nline='%s'",line);
			LL=LL.GetRangeBtwKey("_[","]_");
			int n=atoi((char*)LL);
//printf(" => LL='%s' , n=%d",(char*)LL,n);
			LL="";
			for(int x=0;x<n;x++) {
				if(fgets(line,DEQU_DB_MaxLineLen+2,fp)==NULL) break;
//printf("\n>> line='%s'",line);
				LL+=line;
			}
			fclose(fp);
//printf("\n##>LL='%s'",(char*)LL);
			LL=LL.GetRangeWithWdDel('\n');
			TMP=LL.GetRangeWithWdChg("\\n","\n");
			break;
		}
	}
	return (char*)TMP;
}
//===================================================
const char *DEQU_DB::DEQU_xfer(const char *line) {
	MyStr T;
	MyStr LL(line);
	MyStr NM(DEQU_Inside((char*)LL));
	MyStr PX(DEQUPARED);
	int lpaed=(int)PX;
//printf("\n#>len=%d LL=[%s]",(int)LL,(char*)LL);
	if(NM!="") {
		MyStr BDY(GetDEQUbodyInDB((char*)NM));
//printf("\n#>BODY=[%s]",(char*)BDY);
		int p=LL.InStr((char*)NM);
		if(p>0) T+=LL.GetRangeByIdx(-1,p-1);
		int k=p+(int)NM;
		int a=LL.InStrExSymBlk(k,DEQUPARST,DEQUSYMS);
		int b=LL.InStrExSymBlk(k,DEQUPARED,DEQUSYMS);
	    if(a>0 && b>a) {
			MyStr PA(LL.GetRangeBtwKeyExSymBlk(k,DEQUPARST,DEQUPARED,DEQUSYMS));
			MyStr PAC(PA.GetRangeWithSpDelExSymBlk(DEQUSYMS));
			if(PAC!="") { 
				PA+=',';
				int c=SearchDEQUparN((char*)NM);
				int s=0;
				for(a=0;a<c;a++) {
					int q=PA.InStr(s,",");
					PX="";
					MyStr NX('$');
					NX+=(a+1);
					NX+='$';
					if(q>s) PX=PA.GetRangeByIdx(s,q-1);
					BDY=BDY.GetRangeWithWdChg((char*)NX,(char*)PX);
//printf("\n#>BDY1=[%s]",(char*)BDY);
					BDY=BDY.GetLineTrimExSymBlk(DEQUSYMS);
//printf("\n#>BDY2=[%s]",(char*)BDY);
					BDY=BDY.GetRangeWithSpCmpressExSymBlk(DEQUSYMS);
//printf("\n#>BDY3=[%s]",(char*)BDY);
					BDY=BDY.GetRangeWithWdCmpressExSymBlk('\n',DEQUSYMS);
//printf("\n#>BDY4=[%s]",(char*)BDY);
					if(q>-1) s=q+1;
				}
			}
//printf("\n#>BDY5=[%s]",(char*)BDY);
			T+=BDY;
//printf("\n#>T 1 =[%s]",(char*)T);
			p=b+lpaed;
			PX=LL.GetRangeByIdx(p,-1);
			T+=PX.GetLineTrimLExSymBlk(DEQUSYMS);
			T=T.GetDos2Unix();
			T=T.GetRangeWithWdCmpressExSymBlk('\n',DEQUSYMS);
//printf("\n#>b=%d p=%d LL.len=%d T=[%s]",b,p,(int)LL,(char*)T);
			return DEQU_xfer((char*)T);
		}
	}
	TMP=LL;
	return (char*)TMP;
}

//===================================================
DEQU_DB::DEQU_DB(const char *dbfname) { DBfile=dbfname; CNT=0; DBP=NULL; }
DEQU_DB::DEQU_DB(const char *dbfname,DEQU& DD) { DBfile=dbfname; CNT=0; DBP=NULL; Add(DD); }
DEQU_DB::~DEQU_DB() { ReleaseDBP(); }
