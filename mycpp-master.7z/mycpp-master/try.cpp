
#include "mystr.h"
#include "dequ.h"

using namespace std;

/*
void po2check(const char *s,const char *sym)
{
    MyStr S;
    S=s;
	int k=-1;
	PO2 p=S.SymBlkIdxInStr(k,-1,sym);
	printf("\n     012345678901234567890");
	printf("\nstr='%s' len=%d Sym='%s'\n",(char*)S,(int)S,sym);
	while(p.p1>-1) {
		printf("k=%d , p.p1=%d p.p2=%d\n",k,p.p1,p.p2);
		k=p.p2+1;
		p=S.SymBlkIdxInStr(k,-1,sym);
	}
}
*/

int main(int ac,char** av)
{
    MyStr S;

	DEQU DD;

	printf("\n\n NAME=[%s]",DD.GetName()); 
	printf("\n PARA=[%d] (%s)",DD.GetParN(),DD.GetPara()); 
	printf("\n BODY=[%s]",DD.GetBody()); 
 
    S="@A@1	#DEQU WTSTGENTY(AA)={{ IF (TSFLG.AND.TSFLOW)<>0 ENTRY ;wt stage	}}";
 	DD=S;
	printf("\n\n NAME=[%s]",DD.GetName()); 
	printf("\n PARA=[%d] (%s)",DD.GetParN(),DD.GetPara()); 
	printf("\n BODY=[%s]",DD.GetBody()); 

    S="@B #DEQU WTSTGEXIT()={{ EXIT }}\n";
 	DD=S;
	printf("\n\n NAME=[%s]",DD.GetName()); 
	printf("\n PARA=[%d] (%s)",DD.GetParN(),DD.GetPara()); 
	printf("\n BODY=[%s]",DD.GetBody()); 

	S="#DEQU FCTES(TTNNOO,CCAATT,CCAA22,PPSSUU,SSCCRR,PRESUB,AAFFMM,SSUUBB,POSTSUB,QQCCLL,PPCC,TTPPHH,CCFFGG,ZZHH,ZZDD,TNAME,,,)={{\n";
	S+=";;;;;;;;;; wt stage check ;;;;;;;;;;;;;;;\n";
	S+="WTSTGENTY()\n";
	S+="	READ TIMER TO TTT1 & TSTNO=${TTNNOO}$ & CAT1=${CCAATT}$ & CAT2=${CCAA22}$ & GOSUB ${PPSSUU}$ &\n";
	S+="	QCLOG=${QQCCLL}$ & PATPCN=$(PPCC)$ & PATTP=${TTPPHH}$ & PCFLG=${CCFFGG}$ & PZZHH=${ZZHH}$ & PZZDD=${ZZDD}$ &\n";
	S+="	TSTNM=TSTTMP & TSTNM=?${TNAME}$? & TSTNM(42,1)=? ? & TSTNM(43,8)=ASCII(VDDMAIN,1) & TSTNM(51,1)=?/? & TSTNM(52,8)=ASCII(VDCMAIN,1)\n";
	S+="	GOSUB TDISP1 & GOSUB ${PRESUB}$ & SCRFLG=${SSCCRR}$ & GOSUB SCRSET & AFMFLG=${AAFFMM}$ &\n";
	S+="	GOSUB ${SSUUBB}$ & GOSUB $(POSTSUB)$ & READ TIMER TO TTT2   &   GOSUB TDISP2\n";
	S+=";;\n";
	S+="@l@s	${17}$ ;; bb\n";
	S+=" @l@s	${18}$ ;; aa\n";
	S+="WTSTGEXIT()\n";
	S+=";;;;;;;;;; wt stage check ;;;;;;;;;;;;;;;\n";
	S+="}}\n";

 	DD=S;
	printf("\n\n NAME=[%s]",DD.GetName()); 
	printf("\n PARA=[%d] (%s)",DD.GetParN(),DD.GetPara()); 
	printf("\n BODY=[%s]",DD.GetBody()); 
   
	exit(0);

}
