#ifndef __DEQU_H__
#define __DEQU_H__

#include "mystr.h"

typedef struct dslink {
	MyStr data;
	dslink *nxt;
} DSLINK;

/*
static char DEQUKEY[]="#DEQU";
static char DEQUPARST[]="(";
static char DEQUPARED[]=")";
static char DEQUBDYST[]="{{";
static char DEQUBDYED[]="}}";
static char DEQUSYMS[]="?\"";
static char DEQULCMT[]=";";
static char DEQUCMTC='@';
*/
#define DEQUKEY    "#DEQU"
#define DEQUPARST  '['
#define DEQUPARED  ']'
#define DEQUBDYST  "{{"
#define DEQUBDYED  "}}"
#define DEQUSYMS   "?\""
#define DEQULCMT   ';'
#define DEQUCMTC   '@'


class DEQU {
private:
          MyStr      NAME;
          MyStr      BODY;
          int        PARN;
          DSLINK*	 Para;
          MyStr      TMP;
protected:
		  void ParaRelease(void);
public:
          const char *CheckTrimDEQU(const char *dequstr);
          const char *CheckNameOfDEQU(const char *dequstr);
          const char *CheckBodyOfDEQU(const char *dequstr);
          const char *CheckParaStrOfDEQU(const char *dequstr);

          const char *GetName(void);
          const char *GetBody(void);
                 int  GetParN(void);
          const char *GetPara(void);

                void  Setup(const char *s);

          DEQU();
          DEQU(MyStr &S);
          DEQU(const char *s);
          ~DEQU();
          
		  DEQU& operator=(const char *s);
		  DEQU& operator=(MyStr &S);

		  bool  operator==(const char* name);
		  bool  operator==(MyStr &S);
		  bool  operator!=(const char* name);
		  bool  operator!=(MyStr &S);

};

#endif

