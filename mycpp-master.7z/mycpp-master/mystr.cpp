
#include "mystr.h"
//#######################################################################################################################
int WdIdxInStr(const int si,const int ei,const char *str,const char *word) {
    int wl=-1;
    int ll=-1;
    if(str!=NULL) ll=strlen(str);
    if(word!=NULL) wl=strlen(word);
    int sp=si;
    if(sp<0) sp=0;
    int el=ei+1;
    if(ei<0) el=ll;
    
    if( !(ll<1 || wl<1 || ll<wl || sp>=el || el>ll)) {  
    	for(int i=sp;i<el;i++) {
        	if((el-i)<wl) return -1;
        	if(str[i]==word[0]) if(strncmp(str+i,word,wl)==0) return i;
    	}
    }
    return -1;
}
int WdIdxInStr(const char *str,const char *word) {
	return WdIdxInStr(-1,-1,str,word);
}
int WdIdxInStr(const int si,const char *str,const char *word) {
	return WdIdxInStr(si,-1,str,word);
}
int WdIdxInStr(const int si,const int ei,const char *str,const char c) {
	char s[2]; s[0]=c; s[1]='\0'; 
	return WdIdxInStr(si,ei,str,s);
}
int WdIdxInStr(const char *str,const char c) {
	return WdIdxInStr(-1,-1,str,c);
}
int WdIdxInStr(const int si,const char *str,const char c) {
	return WdIdxInStr(si,-1,str,c);
}
//#######################################################################################################################
int WdIdxInStrRev(const int si,const int ei,const char *str,const char *word) {
    int wl=-1;
    int ll=-1;
    if(str!=NULL) ll=strlen(str);
    if(word!=NULL) wl=strlen(word);
    int sp=si;
    if(sp<0) sp=0;
    int el=ei+1;
    if(ei<0) el=ll;
    
    if( !(ll<1 || wl<1 || ll<wl || sp>=el || el>ll)) {  
    	for(int i=el-wl;i>=sp;i--) {
        	if(str[i]==word[0]) if(strncmp(str+i,word,wl)==0) return i;
    	}
    }
    return -1;
}
int WdIdxInStrRev(const char *str,const char *word) {
	return WdIdxInStrRev(-1,-1,str,word);
}
int WdIdxInStrRev(const int si,const char *str,const char *word) {
	return WdIdxInStrRev(si,-1,str,word);
}
int WdIdxInStrRev(const int si,const int ei,const char *str,const char c) {
	char s[2]; s[0]=c; s[1]='\0'; 
	return WdIdxInStrRev(si,ei,str,s);
}
int WdIdxInStrRev(const char *str,const char c) {
	return WdIdxInStrRev(-1,-1,str,c);
}
int WdIdxInStrRev(const int si,const char *str,const char c) {
	return WdIdxInStrRev(si,-1,str,c);
}
//#######################################################################################################################


char MyStr::Emptystr[2]="";
PO2	MyStr::sp2;

//#######################################################################################################################
PO2 MyStr::SymBlkIdxInStr(const int si,const int ei,const char *str,const char *SymChrLst) {
	sp2.p1=-1; sp2.p2=-1;
	int ll=-1;
	if(str!=NULL) ll=strlen(str);
	int lsym=-1;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	int sp=si;
	if(sp<0) sp=0;
	int ep=ei;
	if(ei<0) ep=ll-1;
	if(ll>0 || lsym>0 || sp<=ep || ep<ll) {
		for(int n=0;n<lsym;n++) {
			int p=WdIdxInStr(sp,ep,str,SymChrLst[n]);
			int q=WdIdxInStr(p+1,ep,str,SymChrLst[n]);
			if(p>-1 && q>-1) {
				if(sp2.p1<0) {sp2.p1=p; sp2.p2=q;}
				else if(p<sp2.p1) {sp2.p1=p; sp2.p2=q;}
			}
		}
	}
	return sp2;
}
PO2 MyStr::SymBlkIdxInStr(const int si,const int ei,const char *SymChrLst) {
	return SymBlkIdxInStr(si,ei,str,SymChrLst);
}
//#######################################################################################################################
const char* MyStr::GetDos2Unix() {
	char CRLF[3]; CRLF[0]=0xd; CRLF[1]=0xa; CRLF[2]='\0';
	char LF[2]; LF[0]=0xa; LF[1]='\0';
	return GetRangeWithWdChg(CRLF,LF);
}
const char* MyStr::GetDos2UnixExSymBlk(const char *SymChrLst) {
	char CRLF[3]; CRLF[0]=0xd; CRLF[1]=0xa; CRLF[2]='\0';
	char LF[2]; LF[0]=0xa; LF[1]='\0';
	return GetRangeWithWdChgExSymBlk(CRLF,LF,SymChrLst);
}
//#######################################################################################################################
const char*	MyStr::resizeX(char **pstr,const char *istr) {
//printf("\n** str=%u tmp=%u Emptystr=%u *pstr=%u istr='%s'",str,tmp,Emptystr,*pstr,istr);
	int ll=0;
	if(*pstr==NULL) *pstr=Emptystr;
	else			ll=strlen(*pstr);
	int ii=0;
	if(istr!=NULL) ii=strlen(istr);
	if(ii!=ll) {
		if(*pstr!=Emptystr) delete [] *pstr;
		if(ii<1)	*pstr=Emptystr;
		else		*pstr=strdup(istr);
	} else if(ii>0) 	strcpy(*pstr,istr);
	return *pstr;
}
const char*	MyStr::resize(const char *istr) { 
	resizeX(&str,istr); len=strlen(str); return str;
}
const char*	MyStr::resizetmp(const char *istr) {
	return resizeX(&tmp,istr);
}
//#######################################################################################################################
void MyStr::release(void) { 
	len=0; 
	if(str!=Emptystr) delete [] str; 
	str=Emptystr;
}
void MyStr::releasetmp(void) { 
	if(tmp!=Emptystr) delete [] tmp;
	tmp=Emptystr;
}
//#######################################################################################################################
MyStr::MyStr() { 
	tmp=Emptystr; str=Emptystr; len=0;
}
MyStr::MyStr(const char c) {
	char cc[2]; cc[0]=c; cc[1]='\0';
	tmp=Emptystr;
	str=Emptystr; resize(cc); len=strlen(str);
}
MyStr::MyStr(const char *s) {
	tmp=Emptystr;
	str=Emptystr; resize(s); len=strlen(str);
}
MyStr::MyStr(MyStr &S) {
	tmp=Emptystr;
	str=Emptystr; resize(S.str); len=strlen(str); 
}
MyStr::~MyStr() {
	releasetmp(); release();
}
//#######################################################################################################################
MyStr::operator int() 				{ return len; }
MyStr::operator char() 				{ return str[0]; }
MyStr::operator char*() 			{ return str; }
MyStr::operator const char*() 		{ return str; }
//#######################################################################################################################
MyStr&	MyStr::operator=(const char *s)	{ resize(s); return *this; }
MyStr&	MyStr::operator=(const char c)	{ char s[2]; s[0]=c; s[1]='\0'; resize(s); return *this; }
MyStr&	MyStr::operator=(MyStr &S)		{ resize(S.str); return *this; }
MyStr&	MyStr::operator=(const int n)	{ char t[32]; sprintf(t,"%d",n); resize(t); return *this; }
MyStr&	MyStr::operator=(const long l)	{ char t[32]; sprintf(t,"%ld",l); resize(t); return *this; }
//#######################################################################################################################
MyStr& MyStr::operator+=(const char *s) {
	if(s!=NULL) {
		int ls=0;
		if(s!=NULL) ls=strlen(s);
		if(ls>0) {
			ls+=len;
			char *t=new char[ls+1];
			strncpy(t,str,len);
			strcpy(t+len,s);
			release();
			str=t;
			len=strlen(str);
		}
	}
	return *this;
}
MyStr&	MyStr::operator+=(const char c)	{ char s[2]; s[0]=c; s[1]='\0'; return operator+=(s); }
MyStr&	MyStr::operator+=(MyStr &S)		{ return operator+=(S.str); }
MyStr&	MyStr::operator+=(const int n)	{ char t[32]; sprintf(t,"%d",n); return operator+=(t); }
MyStr&	MyStr::operator+=(const long l)	{ char t[32]; sprintf(t,"%ld",l); return operator+=(t); }
//#######################################################################################################################
bool MyStr::operator==(const char *s) {
	int ls=-1;
	if(s!=NULL) ls=strlen(s);
	if(len==ls) {
		if(strcmp(str,s)==0) return true;
	}
	return false;
}
bool	MyStr::operator==(const char c)	{ char s[2]; s[0]=c; s[1]='\0'; return operator==(s); }
bool	MyStr::operator==(MyStr &S)		{ return operator==(S.str); }
 //#######################################################################################################################
bool	MyStr::operator!=(const char *s)	{ if(operator==(s)) return false; else return true; }
bool	MyStr::operator!=(const char c) 	{ char s[2]; s[0]=c; s[1]='\0'; return operator!=(s); }
bool	MyStr::operator!=(MyStr &S) 		{ return operator!=(S.str); }
//#######################################################################################################################
const char*	MyStr::operator+(const char *s) {
	int ls=0;
	if(s!=NULL) ls=strlen(s);
	if(ls>0) {
		char *t=new char[len+ls+1];
		strncpy(t,str,len);
		strcpy(t+len,s);
		releasetmp();
		tmp=t;
	} else resizetmp(str);
	return tmp;
}
const char*	MyStr::operator+(const char c)	{ char s[2]; s[0]=c; s[1]='\0'; return operator+(s); }
const char*	MyStr::operator+(MyStr &S)		{ return operator+(S.str); }
const char*	MyStr::operator+(const int n)	{ char t[32]; sprintf(t,"%d",n); return operator+(t); }
const char*	MyStr::operator+(const long l)	{ char t[32]; sprintf(t,"%ld",l); return operator+(t); }

//#######################################################################################################################
int		MyStr::InStr(const char *w) 							{ return WdIdxInStr(-1,-1,str,w); }
int		MyStr::InStr(const int si,const char *w) 				{ return WdIdxInStr(si,-1,str,w); }
int		MyStr::InStr(const int si,const int ei,const char *w) 	{ return WdIdxInStr(si,ei,str,w); }

int		MyStr::InStr(const char c) 								{ return WdIdxInStr(-1,-1,str,c); }
int		MyStr::InStr(const int si,const char c) 				{ return WdIdxInStr(si,-1,str,c); }
int		MyStr::InStr(const int si,const int ei,const char c) 	{ return WdIdxInStr(si,ei,str,c); }

//#######################################################################################################################
int		MyStr::InStrExSymBlk(const char c,const char *SymChrLst){ return InStrExSymBlk(-1,-1,c,SymChrLst); }
int		MyStr::InStrExSymBlk(const char *w,const char *SymChrLst){ return InStrExSymBlk(-1,-1,w,SymChrLst); }
int		MyStr::InStrExSymBlk(const int si,const char c,const char *SymChrLst){ return InStrExSymBlk(si,-1,c,SymChrLst); }
int		MyStr::InStrExSymBlk(const int si,const char *w,const char *SymChrLst){ return InStrExSymBlk(si,-1,w,SymChrLst); }
int		MyStr::InStrExSymBlk(const int si,const int ei,const char c,const char *SymChrLst){
	char s[2]; s[0]=c; s[1]='\0'; 
	return InStrExSymBlk(si,ei,s,SymChrLst);
}
int		MyStr::InStrExSymBlk(const int si,const int ei,const char *w,const char *SymChrLst){
    int lw=-1;
    if(w!=NULL) lw=strlen(w);
    int sp=si;
    if(si<0) sp=0;
    int ep=ei;
    if(ei<0) ep=len-1;
    
    if(len<1 || lw<1 || len<lw || sp>ep || ep>=len) return -1; 
	
	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return InStr(si,ei,w);
	
	int n=-1;
	PO2 pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	while(pp.p1>-1) {
		if(pp.p1>sp) {
			n=InStr(sp,pp.p1-1,w);
			if(n>-1) return n;
		}
		sp=pp.p2+1;
		pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	}
	if(sp<=ep) n=InStr(sp,ep,w);
	return n;
}
//#######################################################################################################################
int		MyStr::InStrRev(const char *w) 								{ return WdIdxInStrRev(-1,-1,str,w); }
int		MyStr::InStrRev(const int si,const char *w) 				{ return WdIdxInStrRev(si,-1,str,w); }
int		MyStr::InStrRev(const int si,const int ei,const char *w) 	{ return WdIdxInStrRev(si,ei,str,w); }

int		MyStr::InStrRev(const char c) 								{ return WdIdxInStrRev(-1,-1,str,c); }
int		MyStr::InStrRev(const int si,const char c) 					{ return WdIdxInStrRev(si,-1,str,c); }
int		MyStr::InStrRev(const int si,const int ei,const char c) 	{ return WdIdxInStrRev(si,ei,str,c); }

//#######################################################################################################################
int		MyStr::InStrRevExSymBlk(const char c,const char *SymChrLst) { return InStrRevExSymBlk(-1,-1,c,SymChrLst); }
int		MyStr::InStrRevExSymBlk(const char *w,const char *SymChrLst) { return InStrRevExSymBlk(-1,-1,w,SymChrLst); }

int		MyStr::InStrRevExSymBlk(const int si,const char c,const char *SymChrLst) { return InStrRevExSymBlk(si,-1,c,SymChrLst); }
int		MyStr::InStrRevExSymBlk(const int si,const char *w,const char *SymChrLst) { return InStrRevExSymBlk(si,-1,w,SymChrLst); }

int		MyStr::InStrRevExSymBlk(const int si,const int ei,const char c,const char *SymChrLst) {
	char w[2]; w[0]=c; w[1]='\0';
	return InStrRevExSymBlk(si,ei,w,SymChrLst);
}
int		MyStr::InStrRevExSymBlk(const int si,const int ei,const char *w,const char *SymChrLst) {
    int lw=-1;
    if(w!=NULL) lw=strlen(w);
    int sp=si;
    if(si<0) sp=0;
    int ep=ei;
    if(ei<0) ep=len-1;
    
    if(len<1 || lw<1 || len<lw || sp>ep || ep>=len) return -1; 
	
	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return InStrRev(si,ei,w);
	
	int p;
	int n=-1;
	PO2 pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	while(pp.p1>-1) {
		if(pp.p1>sp) {
			p=InStrRev(sp,pp.p1-1,w);
			if(p>n) n=p;
		}
		sp=pp.p2+1;
		pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	}
	if(sp<=ep) {
		p=InStrRev(sp,ep,w);
		if(p>n) n=p;
	}
	return n;
}

//#######################################################################################################################
const char* MyStr::GetRangeByIdx(const int si,const int ei) {
//printf("\nMyStr::GetRangeByIdx(%d,%d) ..",si,ei);
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	if(len>0 && sp<=ep && ep<len) {
		int ll=ep-sp+1;
		char *t=new char[ll+1];
		strncpy(t,str+sp,ll);
		t[ll]='\0';
		releasetmp();
		tmp=t;
//printf("sp=%d ep=%d tmp=[%s]",sp,ep,tmp);
		return tmp;
	}
	return resizetmp(NULL);
}
//#######################################################################################################################
const char* MyStr::GetRangeBtwIdx(const int si,const int ei) {
	int sp=si+1;
	if(si<0) sp=0;
	int ep=-1;
	if(ei<0) ep=len-1;
	else if(ei<len) ep=ei-1;
	
	if(len>0 && sp<=ep && ep<len) {
		int ll=ep-sp+1;
		char *t=new char[ll+1];
		strncpy(t,str+sp,ll);
		t[ll]='\0';
		releasetmp();
		tmp=t;
		return tmp;
	}
	return resizetmp(NULL);
}
//#######################################################################################################################

const char* MyStr::GetRangeByKey(const char *k1,const char *k2) {
	int lk1=0;
	if(k1!=NULL) lk1=strlen(k1);
	int lk2=0;
	if(k2!=NULL) lk2=strlen(k2);
	if( (lk1<1 && lk2<1) || len<1 ) return resizetmp(str);
	
	int p=0;
	int q=len-1;
	if(lk1>0) { 
		p=InStr(k1);
		if(p>-1 && lk2>0) q=InStr(p+lk1,k2);
	} else if(lk2>0) q=InStr(k2);
	if(p>-1 && q>-1) {
		lk1=q-p+lk2;
		char *t=new char[lk1+1];
		strncpy(t,str+p,lk1);
		t[lk1]='\0';
		releasetmp();
		tmp=t;
		return tmp;
	}
	return resizetmp(NULL);
}
const char* MyStr::GetRangeByKey(const char c1,const char c2) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeByKey(k1,k2);
}
const char* MyStr::GetRangeByKey(const char *k1,const char c2) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeByKey(k1,k2);
}
const char* MyStr::GetRangeByKey(const char c1,const char *k2) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeByKey(k1,k2);
}

//#######################################################################################################################

const char* MyStr::GetRangeByKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst) {
	int lk1=0;
	if(k1!=NULL) lk1=strlen(k1);
	int lk2=0;
	if(k2!=NULL) lk2=strlen(k2);
	if( (lk1<1 && lk2<1) || len<1 ) return resizetmp(str);
	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeByKey(k1,k2);
	
	int k=0 ,p=-1 ,q=-1;
	if(lk1<1) p=k;
	if(lk2<1) q=len;
	PO2 pp=SymBlkIdxInStr(k,-1,SymChrLst);
	while(pp.p1>-1) {
		if(lk1>0 && p<0) {
			p=InStr(k,pp.p1-1,k1);
			if(p>-1) k=p+lk1;
		}
		if(lk2>0) q=InStr(k,pp.p1-1,k2);
		if(p>-1 && q>-1) break;
		k=pp.p2+1;
		pp=SymBlkIdxInStr(k,-1,SymChrLst);
	}
	if(lk1>0 && p<0) {
		p=InStr(k,-1,k1);
		if(p>-1) k=p+lk1;
	}
	if(lk2>0 && q<0 ) q=InStr(k,-1,k2);
	if(p>-1 && q>-1) {
		lk1=q+lk2-p;
		char *t=new char[lk1+1];
		strncpy(t,str+p,lk1);
		t[lk1]='\0';
		releasetmp();
		tmp=t;
		return tmp;
	}	
	return resizetmp(NULL);
}
const char* MyStr::GetRangeByKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeByKeyExSymBlk(k1,k2,SymChrLst);
}
const char* MyStr::GetRangeByKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeByKeyExSymBlk(k1,k2,SymChrLst);
}
const char* MyStr::GetRangeByKeyExSymBlk(const char c1,const char c2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeByKeyExSymBlk(k1,k2,SymChrLst);
}

//#######################################################################################################################
const char* MyStr::GetRangeBtwKey(const char c1,const char c2) { return GetRangeBtwKey(-1,-1,c1,c2); }
const char* MyStr::GetRangeBtwKey(const char *k1,const char c2) { return GetRangeBtwKey(-1,-1,k1,c2); }
const char* MyStr::GetRangeBtwKey(const char c1,const char *k2) { return GetRangeBtwKey(-1,-1,c1,k2); }
const char* MyStr::GetRangeBtwKey(const char *k1,const char *k2) { return GetRangeBtwKey(-1,-1,k1,k2); }
/*const char* MyStr::GetRangeBtwKey(const char *k1,const char *k2) {
	int lk1=0;
	if(k1!=NULL) lk1=strlen(k1);
	int lk2=0;
	if(k2!=NULL) lk2=strlen(k2);
	if( (lk1<1 && lk2<1) || len<1 ) return resizetmp(str);
	
	int p=0;
	int q=len-1;
	if(lk1>0) { 
		p=InStr(k1);
		if(p>-1) {
			p+=lk1;
			if(lk2>0) q=InStr(p,k2)-1;
		}
	} else if(lk2>0) q=InStr(k2)-1;
	if(p>-1 && q>-1) {
		lk1=q-p+1;
		char *t=new char[lk1+1];
		strncpy(t,str+p,lk1);
		t[lk1]='\0';
		releasetmp();
		tmp=t;
		return tmp;
	}
	return resizetmp(NULL);
}*/

const char* MyStr::GetRangeBtwKey(const int si,const char c1,const char c2) { return GetRangeBtwKey(si,-1,c1,c2); }
const char* MyStr::GetRangeBtwKey(const int si,const char *k1,const char c2) { return GetRangeBtwKey(si,-1,k1,c2); }
const char* MyStr::GetRangeBtwKey(const int si,const char c1,const char *k2) { return GetRangeBtwKey(si,-1,c1,k2); }
const char* MyStr::GetRangeBtwKey(const int si,const char *k1,const char *k2) { return GetRangeBtwKey(si,-1,k1,k2); }

const char* MyStr::GetRangeBtwKey(const int si,const int ei,const char c1,const char c2) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeBtwKey(si,ei,k1,k2);
}
const char* MyStr::GetRangeBtwKey(const int si,const int ei,const char c1,const char *k2) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeBtwKey(si,ei,k1,k2);
}
const char* MyStr::GetRangeBtwKey(const int si,const int ei,const char *k1,const char c2) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeBtwKey(si,ei,k1,k2);
}
const char* MyStr::GetRangeBtwKey(const int si,const int ei,const char *k1,const char *k2) {
	int lk1=0;
	if(k1!=NULL) lk1=strlen(k1);
	int lk2=0;
	if(k2!=NULL) lk2=strlen(k2);
	
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if( (lk1<1 && lk2<1) || len<1 ) return resizetmp(str);
	if(sp>ep || ep>=len) return resizetmp(NULL);

	int p=sp;
	int q=ep;

	if(lk1>0) { 
		p=InStr(sp,ep,k1);
		if(p>-1) {
			p+=lk1;
			if(lk2>0) q=InStr(p,ep,k2)-1;
		}
	} else if(lk2>0) q=InStr(sp,ep,k2)-1;
	if(p>-1 && q>-1) {
		lk1=q-p+1;
		char *t=new char[lk1+1];
		strncpy(t,str+p,lk1);
		t[lk1]='\0';
		releasetmp();
		tmp=t;
		return tmp;
	}
	return resizetmp(NULL);
}

//#######################################################################################################################
const char* MyStr::GetRangeBtwKeyExSymBlk(const char c1,const char c2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(-1,-1,c1,c2,SymChrLst); }
//	char k1[2]; k1[0]=c1; k1[1]='\0';
//	char k2[2]; k2[0]=c2; k2[1]='\0';
//	return GetRangeBtwKeyExSymBlk(k1,k2,SymChrLst);
//}
const char* MyStr::GetRangeBtwKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(-1,-1,c1,k2,SymChrLst); }
//	char k1[2]; k1[0]=c1; k1[1]='\0';
//	return GetRangeBtwKeyExSymBlk(k1,k2,SymChrLst);
//}
const char* MyStr::GetRangeBtwKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(-1,-1,k1,c2,SymChrLst); }
//	char k2[2]; k2[0]=c2; k2[1]='\0';
//	return GetRangeBtwKeyExSymBlk(k1,k2,SymChrLst);
//}
const char* MyStr::GetRangeBtwKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(-1,-1,k1,k2,SymChrLst); }
/*const char* MyStr::GetRangeBtwKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst) {
	int lk1=0;
	if(k1!=NULL) lk1=strlen(k1);
	int lk2=0;
	if(k2!=NULL) lk2=strlen(k2);
	if( (lk1<1 && lk2<1) || len<1 ) return resizetmp(str);
	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeBtwKey(k1,k2);
	
	int k=0 ,p=-1 ,q=-1;
	if(lk1<1) p=k;
	if(lk2<1) q=len;
	PO2 pp=SymBlkIdxInStr(k,-1,SymChrLst);
	while(pp.p1>-1) {
		if(lk1>0 && p<0) {
			p=InStr(k,pp.p1-1,k1);
			if(p>-1) k=p+lk1;
		}
		if(lk2>0) q=InStr(k,pp.p1-1,k2);
		if(p>-1 && q>-1) break;
		k=pp.p2+1;
		pp=SymBlkIdxInStr(k,-1,SymChrLst);
	}
	if(lk1>0 && p<0) {
		p=InStr(k,-1,k1);
		if(p>-1) k=p+lk1;
	}
	if(lk2>0 && q<0 ) q=InStr(k,-1,k2);
	if(p>-1 && q>-1) {
		if(lk1>0) p+=lk1;
		if(lk2>0) q--;
		lk1=q-p+1;
		char *t=new char[lk1+1];
		strncpy(t,str+p,lk1);
		t[lk1]='\0';
		releasetmp();
		tmp=t;
		return tmp;
	}	
	return resizetmp(NULL);
}*/

const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(si,-1,c1,c2,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(si,-1,c1,k2,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(si,-1,k1,c2,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(si,-1,k1,k2,SymChrLst);}

const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeBtwKeyExSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeBtwKeyExSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeBtwKeyExSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst) {
	int lk1=0;
	if(k1!=NULL) lk1=strlen(k1);
	int lk2=0;
	if(k2!=NULL) lk2=strlen(k2);
	if( (lk1<1 && lk2<1) || len<1 ) return resizetmp(str);

	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeBtwKey(si,ei,k1,k2);
	
	int k=sp ,p=-1 ,q=-1;
	if(lk1<1) p=k;
	if(lk2<1) q=ep+1;
	
	PO2 pp=SymBlkIdxInStr(k,ep,SymChrLst);
	while(pp.p1>-1) {
		if(lk1>0 && p<0) {
			p=InStr(k,pp.p1-1,k1);
			if(p>-1) k=p+lk1;
		}
		if(lk2>0) q=InStr(k,pp.p1-1,k2);
		if(p>-1 && q>-1) break;
		k=pp.p2+1;
		pp=SymBlkIdxInStr(k,ep,SymChrLst);
	}
	if(lk1>0 && p<0) {
		p=InStr(k,ep,k1);
		if(p>-1) k=p+lk1;
	}
	if(lk2>0 && q<0 ) q=InStr(k,ep,k2);
	if(p>-1 && q>-1) {
		if(lk1>0) p+=lk1;
		if(lk2>0) q--;
		lk1=q-p+1;
		char *t=new char[lk1+1];
		strncpy(t,str+p,lk1);
		t[lk1]='\0';
		releasetmp();
		tmp=t;
		return tmp;
	}	
	return resizetmp(NULL);
}
//#######################################################################################################################

const char* MyStr::GetRangeWithWdChg(const int si,const int ei,const char *owd,const char *nwd) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ep<0) ep=len-1;
	
	MyStr OWD(owd);
	MyStr oNWD,NWD(nwd);
		
	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);
	if((int)OWD<1 || OWD==NWD) return resizetmp(str);

	int xp=NWD.InStr((char*)OWD);
	if(xp>-1) {
		char bb=0x7;
		oNWD=nwd;
		if(xp>0) 	{ NWD=oNWD.GetRangeByIdx(-1,xp-1); NWD+=bb; NWD+=oNWD.GetRangeByIdx(xp+1,-1); }
		else		{ NWD=bb; NWD+=oNWD.GetRangeByIdx(xp+1,-1); }
	}
//printf("\n*** xp=%d NWD=[%s] oNWD=[%s]",xp,(char*)NWD,(char*)oNWD);

	int isp=sp;
	MyStr T;
	int p=InStr(sp,ep,(char*)OWD);
	while(p>-1) {
		if(p>sp) T+=GetRangeByIdx(sp,p-1);
		if((int)NWD>0) T+=(char*)NWD;
		sp=p+(int)OWD;
		p=InStr(sp,ep,(char*)OWD);
	}
	if(sp==isp) return resizetmp(str);
	if(sp<=ep) T+=GetRangeByIdx(sp,ep);
	T=T.GetRangeWithWdChg((char*)OWD,(char*)NWD);
//printf("\n>>> T=[%s]",T.str);
	if(xp>-1) T=T.GetRangeWithWdChg((char*)NWD,(char*)oNWD);
//printf("\n### T=[%s]",T.str);
	return resizetmp(T.str);
}

const char* MyStr::GetRangeWithWdChg(const int si,const int ei,const char och,const char nch) { 
	char owd[2]; owd[0]=och; owd[1]='\0';
	char nwd[2]; nwd[0]=nch; nwd[1]='\0';
	return GetRangeWithWdChg(si,ei,owd,nwd);
}
const char* MyStr::GetRangeWithWdChg(const int si,const int ei,const char och,const char *nwd) { 
	char owd[2]; owd[0]=och; owd[1]='\0';
	return GetRangeWithWdChg(si,ei,owd,nwd);
}
const char* MyStr::GetRangeWithWdChg(const int si,const int ei,const char *owd,const char nch) { 
	char nwd[2]; nwd[0]=nch; nwd[1]='\0';
	return GetRangeWithWdChg(si,ei,owd,nwd);
}

const char* MyStr::GetRangeWithWdChg(const int si,const char och,const char nch) { 
	return GetRangeWithWdChg(si,-1,och,nch);
}
const char* MyStr::GetRangeWithWdChg(const int si,const char och,const char *nwd) { 
	return GetRangeWithWdChg(si,-1,och,nwd);
}
const char* MyStr::GetRangeWithWdChg(const int si,const char *owd,const char nch) { 
	return GetRangeWithWdChg(si,-1,owd,nch);
}
const char* MyStr::GetRangeWithWdChg(const int si,const char *owd,const char *nwd) { 
	return GetRangeWithWdChg(si,-1,owd,nwd);
}

const char* MyStr::GetRangeWithWdChg(const char och,const char nch) { 
	return GetRangeWithWdChg(-1,-1,och,nch);
}
const char* MyStr::GetRangeWithWdChg(const char och,const char *nwd) { 
	return GetRangeWithWdChg(-1,-1,och,nwd);
}
const char* MyStr::GetRangeWithWdChg(const char *owd,const char nch) { 
	return GetRangeWithWdChg(-1,-1,owd,nch);
}
const char* MyStr::GetRangeWithWdChg(const char *owd,const char *nwd) { 
	return GetRangeWithWdChg(-1,-1,owd,nwd); 
}

//#######################################################################################################################

const char* MyStr::GetRangeWithWdChgExSymBlk(const int si,const int ei,const char *owd,const char *nwd,const char *SymChrLst) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ep<0) ep=len-1;
	int lowd=0;
	if(owd!=NULL) lowd=strlen(owd);
	int lnwd=0;
	if(nwd!=NULL) lnwd=strlen(nwd);
//printf("\nstr='%s'",str);
	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);
	if(lowd<1) return resizetmp(str);
	if(lowd>0 && lowd==lnwd) if(strcmp(owd,nwd)==0) return resizetmp(str);

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeWithWdChg(si,ei,owd,nwd);

//printf("\nowd='%s' nwd='%s'  SymChrLst='%s'",owd,nwd,SymChrLst);

	MyStr T,S;
	PO2 pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	while(pp.p1>-1) {
		int p=InStr(sp,pp.p1-1,owd);
		if(p>0) {
			T+=GetRangeByIdx(sp,p-1);
//printf("\n>>T.str='%s'",T.str);
			if(lnwd>0) { T+=nwd; T=T.GetRangeWithWdChg(owd,nwd); }
//printf("\n>>>T.str='%s'",T.str);
			sp=p+lowd;
		} else	{T+=GetRangeByIdx(sp,pp.p2); sp=pp.p2+1;}
		pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	}
//printf("\n>>>>sp=%d ep=%d T.str='%s'",sp,ep,T.str);
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		T+=S.GetRangeWithWdChg(owd,nwd);
	}
//printf("\n##>T.str='%s'",T.str);
	return resizetmp(T.str);
}
const char* MyStr::GetRangeWithWdChgExSymBlk(const int si,const int ei,const char och,const char *nwd,const char *SymChrLst) {
	char owd[2]; owd[0]=och; owd[1]='\0';
	return GetRangeWithWdChgExSymBlk(si,ei,owd,nwd,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExSymBlk(const int si,const int ei,const char *owd,const char nch,const char *SymChrLst) {
	char nwd[2]; nwd[0]=nch; nwd[1]='\0';
	return GetRangeWithWdChgExSymBlk(si,ei,owd,nwd,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExSymBlk(const int si,const int ei,const char och,const char nch,const char *SymChrLst) {
	char owd[2]; owd[0]=och; owd[1]='\0';
	char nwd[2]; nwd[0]=nch; nwd[1]='\0';
	return GetRangeWithWdChgExSymBlk(si,ei,owd,nwd,SymChrLst);
}

const char* MyStr::GetRangeWithWdChgExSymBlk(const int si,const char *owd,const char *nwd,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(si,-1,owd,nwd,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExSymBlk(const int si,const char och,const char *nwd,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(si,-1,och,nwd,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExSymBlk(const int si,const char *owd,const char nch,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(si,-1,owd,nch,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExSymBlk(const int si,const char och,const char nch,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(si,-1,och,nch,SymChrLst);
}

const char* MyStr::GetRangeWithWdChgExSymBlk(const char *owd,const char *nwd,const char *SymChrLst) { 
	return GetRangeWithWdChgExSymBlk(-1,-1,owd,nwd,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExSymBlk(const char och,const char *nwd,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(-1,-1,och,nwd,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExSymBlk(const char *owd,const char nch,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(-1,-1,owd,nch,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExSymBlk(const char och,const char nch,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(-1,-1,och,nch,SymChrLst);
}

//#######################################################################################################################

const char* MyStr::GetRangeWithWdDel(const int si,const int ei,const char *wd) { 
	return GetRangeWithWdChg(si,ei,wd,""); 
}
const char* MyStr::GetRangeWithWdDel(const int si,const int ei,const char c) { 
	return GetRangeWithWdChg(si,ei,c,""); 
}

const char* MyStr::GetRangeWithWdDel(const int si,const char c) { 
	return GetRangeWithWdChg(si,-1,c,""); 
}
const char* MyStr::GetRangeWithWdDel(const int si,const char *wd) { 
	return GetRangeWithWdChg(si,-1,wd,""); 
}

const char* MyStr::GetRangeWithWdDel(const char c) { 
	return GetRangeWithWdChg(-1,-1,c,""); 
}
const char* MyStr::GetRangeWithWdDel(const char *wd) { 
	return GetRangeWithWdChg(-1,-1,wd,""); 
}

//#######################################################################################################################

const char* MyStr::GetRangeWithWdDelExSymBlk(const char c,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(-1,-1,c,"",SymChrLst);
}
const char* MyStr::GetRangeWithWdDelExSymBlk(const int si,const char c,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(si,-1,c,"",SymChrLst);
}
const char* MyStr::GetRangeWithWdDelExSymBlk(const int si,const int ei,const char c,const char *SymChrLst){
	return GetRangeWithWdChgExSymBlk(si,ei,c,"",SymChrLst);
}	

const char* MyStr::GetRangeWithWdDelExSymBlk(const char *wd,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(-1,-1,wd,"",SymChrLst);
}
const char* MyStr::GetRangeWithWdDelExSymBlk(const int si,const char *wd,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(si,-1,wd,"",SymChrLst);
}
const char* MyStr::GetRangeWithWdDelExSymBlk(const int si,const int ei,const char *wd,const char *SymChrLst){
	return GetRangeWithWdChgExSymBlk(si,ei,wd,"",SymChrLst);
}	

//#######################################################################################################################

const char* MyStr::GetRangeWithSpDel(const int si,const int ei) {
	MyStr T(GetRangeWithWdDelExSymBlk(si,ei,'\t',""));
	return resizetmp(T.GetRangeWithWdDelExSymBlk(si,ei,' ',""));
}
const char* MyStr::GetRangeWithSpDel(const int si) {
	return GetRangeWithSpDel(si,-1);
}
const char* MyStr::GetRangeWithSpDel(void) {
	return GetRangeWithSpDel(-1,-1);
}

//#######################################################################################################################

const char* MyStr::GetRangeWithSpDelExSymBlk(const int si,const int ei,const char *SymChrLst) {
	MyStr T(GetRangeWithWdDelExSymBlk(si,ei,'\t',SymChrLst));
	return resizetmp(T.GetRangeWithWdDelExSymBlk(si,ei,' ',SymChrLst));
}
const char* MyStr::GetRangeWithSpDelExSymBlk(const int si,const char *SymChrLst) {
	return GetRangeWithSpDelExSymBlk(si,-1,SymChrLst);
}
const char* MyStr::GetRangeWithSpDelExSymBlk(const char *SymChrLst) {
	return GetRangeWithSpDelExSymBlk(-1,-1,SymChrLst);
}

//#######################################################################################################################

const char* MyStr::GetRangeWithWdCmpress(const int si,const int ei,const char *wd) {
	int lwd=0;
	if(wd!=NULL) lwd=strlen(wd);
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	
	if(sp>ep || ep>=len) resizetmp(NULL);
	if(len<(lwd*2) || lwd<1) return resizetmp(str);
	
	MyStr T;
	int p=InStr(sp,ep,wd);
	while(p>-1) {
		T+=GetRangeByIdx(sp,p+lwd-1);
		sp=p+lwd;  p=InStr(sp,ep,wd);
		while(p==sp) { sp=p+lwd; p=InStr(sp,ep,wd); }
	}
	if(sp<=ep) T+=GetRangeByIdx(sp,ep);
	return resizetmp(T.str);
}
const char* MyStr::GetRangeWithWdCmpress(const int si,const char *wd) {
	return GetRangeWithWdCmpress(si,-1,wd);
}
const char* MyStr::GetRangeWithWdCmpress(const char *wd) {
	return GetRangeWithWdCmpress(-1,-1,wd);
}
const char* MyStr::GetRangeWithWdCmpress(const int si,const int ei,const char c) {
	char cc[2]; cc[0]=c; cc[1]='\0';
	return GetRangeWithWdCmpress(si,ei,cc);
}
const char* MyStr::GetRangeWithWdCmpress(const int si,const char c) {
	return GetRangeWithWdCmpress(si,-1,c);
}
const char* MyStr::GetRangeWithWdCmpress(const char c) {
	return GetRangeWithWdCmpress(-1,-1,c);
}

//#######################################################################################################################

const char* MyStr::GetRangeWithWdCmpressExSymBlk(const int si,const int ei,const char *wd,const char *SymChrLst) {
	int lwd=0;
	if(wd!=NULL) lwd=strlen(wd);
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	
	if(sp>ep || ep>=len) resizetmp(NULL);
	if(len<(lwd*2) || lwd<1) return resizetmp(str);

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeWithWdCmpress(si,ei,wd);
	
	MyStr T,S;
	PO2 pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	while(pp.p1>-1) {
		if(pp.p1>sp) {
			S=GetRangeByIdx(sp,pp.p1-1);
			T+=S.GetRangeWithWdCmpress(-1,-1,wd);
		}
		T+=GetRangeByIdx(pp.p1,pp.p2);
		sp=pp.p2+1;
		pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	}
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		T+=S.GetRangeWithWdCmpress(-1,-1,wd);
	}
	return resizetmp(T.str);
}
const char* MyStr::GetRangeWithWdCmpressExSymBlk(const int si,const char *wd,const char *SymChrLst) {
	return GetRangeWithWdCmpressExSymBlk(si,-1,wd,SymChrLst);
}
const char* MyStr::GetRangeWithWdCmpressExSymBlk(const char *wd,const char *SymChrLst) {
	return GetRangeWithWdCmpressExSymBlk(-1,-1,wd,SymChrLst);
}
const char* MyStr::GetRangeWithWdCmpressExSymBlk(const int si,const int ei,const char c,const char *SymChrLst) {
	char cc[2]; cc[0]=c; cc[1]='\0';
	return GetRangeWithWdCmpressExSymBlk(si,ei,cc,SymChrLst);
}
const char* MyStr::GetRangeWithWdCmpressExSymBlk(const int si,const char c,const char *SymChrLst) {
	return GetRangeWithWdCmpressExSymBlk(si,-1,c,SymChrLst);
}
const char* MyStr::GetRangeWithWdCmpressExSymBlk(const char c,const char *SymChrLst) {
	return GetRangeWithWdCmpressExSymBlk(-1,-1,c,SymChrLst);
}

//#######################################################################################################################

const char* MyStr::GetRangeWithSpCmpress(const int si,const int ei) {
	MyStr S(GetRangeWithWdChg(si,ei,'\t',' '));
	return resizetmp(S.GetRangeWithWdCmpress(' '));
}
const char* MyStr::GetRangeWithSpCmpress(const int si) {
	return GetRangeWithSpCmpress(si,-1);
}
const char* MyStr::GetRangeWithSpCmpress(void) {
	return GetRangeWithSpCmpress(-1,-1);
}

//#######################################################################################################################

const char* MyStr::GetRangeWithSpCmpressExSymBlk(const int si,const int ei,const char *SymChrLst) {
	MyStr S(GetRangeWithWdChgExSymBlk(si,ei,'\t',' ',SymChrLst));
	return resizetmp(S.GetRangeWithWdCmpressExSymBlk(-1,-1,' ',SymChrLst));
}
const char* MyStr::GetRangeWithSpCmpressExSymBlk(const int si,const char *SymChrLst) {
	return GetRangeWithSpCmpressExSymBlk(si,-1,SymChrLst);
}
const char* MyStr::GetRangeWithSpCmpressExSymBlk(const char *SymChrLst) {
	return GetRangeWithSpCmpressExSymBlk(-1,-1,SymChrLst);
}


//#######################################################################################################################
const char* MyStr::GetTrimL(const int si,const int ei) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);

	MyStr T;
	MyStr S(GetRangeByIdx(sp,ep));
	for(int n=0;n<S.len;n++) {
		if(S.str[n]>32 && S.str[n]<127) { T=S.GetRangeByIdx(n,-1); break; }
	}
	return resizetmp(T.str);
}
const char* MyStr::GetTrimL(const int si) {
	return GetTrimL(si,-1);
}
const char* MyStr::GetTrimL(void) {
	return GetTrimL(-1,-1);
}
//#######################################################################################################################
const char* MyStr::GetTrimR(const int si,const int ei) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);

	MyStr T;
	MyStr S(GetRangeByIdx(sp,ep));
	for(int n=S.len-1;n>=0;n--) {
		if(S.str[n]>32 && S.str[n]<127) { T=S.GetRangeByIdx(-1,n); break; }
	}
	return resizetmp(T.str);
}
const char* MyStr::GetTrimR(const int si) {
	return GetTrimR(si,-1);
}
const char* MyStr::GetTrimR(void) {
	return GetTrimR(-1,-1);
}
//#######################################################################################################################
const char* MyStr::GetTrim(const int si,const int ei) {
	MyStr S(GetRangeByIdx(si,ei));
	S=S.GetTrimL(-1,-1);
	return resizetmp(S.GetTrimR(-1,-1));
}
const char* MyStr::GetTrim(const int si) {
	return GetTrim(si,-1);
}
const char* MyStr::GetTrim(void) {
	return GetTrim(-1,-1);
}
//#######################################################################################################################
const char* MyStr::GetTrimA(const int si,const int ei) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	
	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);

	resizetmp(str);
	int p=0;
	for(int n=sp;n<=ep;n++) {
		if(str[n]>32 && str[n]<127) tmp[p++]=str[n];
	}
	tmp[p]='\0';
	return tmp;
}
const char* MyStr::GetTrimA(const int si) {
	return GetTrimA(si,-1);
}
const char* MyStr::GetTrimA(void) {
	return GetTrimA(-1,-1);
}
//#######################################################################################################################

const char* MyStr::GetLineTrimL(const int si,const int ei) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);

	MyStr T,S;
	int p=InStr(sp,ep,'\n');
	while(p>-1) {
		if(p>sp) {
			S=GetRangeByIdx(sp,p-1);
			T+=S.GetLineTrimL(-1,-1);
		}
		T+='\n';
		sp=p+1;
		p=InStr(sp,ep,'\n');
	}
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		for(int n=0;n<S.len;n++) {
			if(S.str[n]>32 && S.str[n]<127) { T+=S.GetRangeByIdx(n,-1); break; }
		}
	}
	return resizetmp(T.str);
}
const char* MyStr::GetLineTrimL(const int si) {
	return GetLineTrimL(si,-1);
}
const char* MyStr::GetLineTrimL(void) {
	return GetLineTrimL(-1,-1);
}

//#######################################################################################################################

const char* MyStr::GetLineTrimR(const int si,const int ei) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);

	MyStr T,S;
	int p=InStr(sp,ep,'\n');
	while(p>-1) {
		if(p>sp) {
			S=GetRangeByIdx(sp,p-1);
			T+=S.GetLineTrimR(-1,-1);
		}
		T+='\n';
		sp=p+1;
		p=InStr(sp,ep,'\n');
	}
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		for(int n=S.len-1;n>=0;n--) {
			if(S.str[n]>32 && S.str[n]<127) { T+=S.GetRangeByIdx(-1,n); break; }
		}
	}
	return resizetmp(T.str);
}
const char* MyStr::GetLineTrimR(const int si) {
	return GetLineTrimR(si,-1);
}
const char* MyStr::GetLineTrimR(void) {
	return GetLineTrimR(-1,-1);
}

//#######################################################################################################################

const char* MyStr::GetLineTrim(const int si,const int ei) {
	MyStr S(GetRangeByIdx(si,ei));
	S=S.GetLineTrimL(-1,-1);
	return resizetmp(S.GetLineTrimR(-1,-1));
}
const char* MyStr::GetLineTrim(const int si) {
	return GetLineTrim(si,-1);
}
const char* MyStr::GetLineTrim(void) {
	return GetLineTrim(-1,-1);
}

//#######################################################################################################################

const char* MyStr::GetLineTrimA(const int si,const int ei) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	
	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);

	resizetmp(str);
	int p=0;
	for(int n=sp;n<=ep;n++) {
		if(str[n]=='\n' || (str[n]>32 && str[n]<127)) tmp[p++]=str[n];
	}
	tmp[p]='\0';
	return tmp;
}
const char* MyStr::GetLineTrimA(const int si) {
	return GetLineTrimA(si,-1);
}
const char* MyStr::GetLineTrimA(void) {
	return GetLineTrimA(-1,-1);
}

//#######################################################################################################################

const char* MyStr::GetLineTrimLExSymBlk(const int si,const int ei,const char *SymChrLst) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetLineTrimL(sp,ep);
	
	MyStr T,S;
	int p=InStr(sp,ep,'\n');
	while(p>-1) {	
		int k=sp;
		PO2 pp=SymBlkIdxInStr(k,ep,SymChrLst);
		while(pp.p1>-1) {
			if(pp.p1<=p && pp.p2>=p) {
				pp.p2=InStr(pp.p2+1,ep,'\n');
				if(pp.p2<0) pp.p2=ep;
				break;
			}
			k=pp.p2+1;
			pp=SymBlkIdxInStr(k,ep,SymChrLst);
		}
		if(pp.p1<0) {
			S=GetRangeByIdx(sp,p);
			T+=S.GetLineTrimL();
			sp=p+1;
		} else {
			if(pp.p1>sp) { 
				S=GetRangeByIdx(sp,pp.p1-1);
				T+=S.GetLineTrimL();
				T+=GetRangeByIdx(pp.p1,pp.p2);
			} else T+=GetRangeByIdx(sp,pp.p2);
			sp=pp.p2+1;
		}
		p=InStr(sp,ep,'\n');
	}
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		T+=S.GetLineTrimL();
	}
	return resizetmp(T.str);
}
const char* MyStr::GetLineTrimLExSymBlk(const int si,const char *SymChrLst) {
	return GetLineTrimLExSymBlk(si,-1,SymChrLst);
}
const char* MyStr::GetLineTrimLExSymBlk(const char *SymChrLst) {
	return GetLineTrimLExSymBlk(-1,-1,SymChrLst);
}

//#######################################################################################################################

const char* MyStr::GetLineTrimRExSymBlk(const int si,const int ei,const char *SymChrLst) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetLineTrimR(sp,ep);
	
	MyStr T,S;
	int p=InStr(sp,ep,'\n');
	while(p>-1) {	
		int k=sp;
		PO2 pp=SymBlkIdxInStr(k,ep,SymChrLst);
		while(pp.p1>-1) {
			if(pp.p1<=p && pp.p2>=p) break;
			k=pp.p2+1;
			pp=SymBlkIdxInStr(k,ep,SymChrLst);
		}
		if(pp.p1<0) {
			S=GetRangeByIdx(sp,p);
			T+=S.GetLineTrimR();
			sp=p+1;
		} else {
			T+=GetRangeByIdx(sp,pp.p2);
			sp=pp.p2+1;
		}
		p=InStr(sp,ep,'\n');
	}
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		T+=S.GetLineTrimR();
	}
	return resizetmp(T.str);
}
const char* MyStr::GetLineTrimRExSymBlk(const int si,const char *SymChrLst) {
	return GetLineTrimRExSymBlk(si,-1,SymChrLst);
}
const char* MyStr::GetLineTrimRExSymBlk(const char *SymChrLst) {
	return GetLineTrimRExSymBlk(-1,-1,SymChrLst);
}

//#######################################################################################################################

const char* MyStr::GetLineTrimExSymBlk(const int si,const int ei,const char *SymChrLst) {
	MyStr S(GetRangeByIdx(si,ei));
	S=S.GetLineTrimLExSymBlk(SymChrLst);
	return resizetmp(S.GetLineTrimRExSymBlk(SymChrLst));
}
const char* MyStr::GetLineTrimExSymBlk(const int si,const char *SymChrLst) {
	return GetLineTrimExSymBlk(si,-1,SymChrLst);
}
const char* MyStr::GetLineTrimExSymBlk(const char *SymChrLst) {
	return GetLineTrimExSymBlk(-1,-1,SymChrLst);
}

//#######################################################################################################################

const char* MyStr::GetLineTrimAExSymBlk(const int si,const int ei,const char *SymChrLst) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	
	if(lsym<1) return GetLineTrimA(sp,ep);
	
	MyStr T,S;
	PO2 pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	while(pp.p1>-1) {
		if(pp.p1>sp) {
			S=GetRangeByIdx(sp,pp.p1-1);
			T+=S.GetLineTrimA(-1,-1);
		}
		T+=GetRangeByIdx(pp.p1,pp.p2);
		sp=pp.p2+1;
		pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	}
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		T+=S.GetLineTrimA(-1,-1);
	}
	return resizetmp(T.str);
}
const char* MyStr::GetLineTrimAExSymBlk(const int si,const char *SymChrLst) {
	return GetLineTrimAExSymBlk(si,-1,SymChrLst);
}
const char* MyStr::GetLineTrimAExSymBlk(const char *SymChrLst) {
	return GetLineTrimAExSymBlk(-1,-1,SymChrLst);
}

//#######################################################################################################################

const char* MyStr::GetRangeWithDelByKey(const char c1,const char c2) {
	return GetRangeWithDelByKey(-1,-1,c1,c2);
}
const char* MyStr::GetRangeWithDelByKey(const char c1,const char *k2) {
	return GetRangeWithDelByKey(-1,-1,c1,k2);
}
const char* MyStr::GetRangeWithDelByKey(const char *k1,const char c2) {
	return GetRangeWithDelByKey(-1,-1,k1,c2);
}
const char* MyStr::GetRangeWithDelByKey(const char *k1,const char *k2) {
	return GetRangeWithDelByKey(-1,-1,k1,k2);
}

const char* MyStr::GetRangeWithDelByKey(const int si,const char c1,const char c2) {
	return GetRangeWithDelByKey(si,-1,c1,c2);
}
const char* MyStr::GetRangeWithDelByKey(const int si,const char c1,const char *k2) {
	return GetRangeWithDelByKey(si,-1,c1,k2);
}
const char* MyStr::GetRangeWithDelByKey(const int si,const char *k1,const char c2) {
	return GetRangeWithDelByKey(si,-1,k1,c2);
}
const char* MyStr::GetRangeWithDelByKey(const int si,const char *k1,const char *k2) {
	return GetRangeWithDelByKey(si,-1,k1,k2);
}

const char* MyStr::GetRangeWithDelByKey(const int si,const int ei,const char *k1,const char *k2) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);
	
	int l1=0;
	if(k1!=NULL) l1=strlen(k1);
	int l2=0;
	if(k2!=NULL) l2=strlen(k2);

	int p=-1;
	int q=-1;
	if(l1<1) {
		if(l2>0) q=InStr(sp,ep,k2);
		if(q>-1) return GetRangeByIdx(q,ep);
	} else if(l2<1) {
		p=InStr(sp,ep,k1);
		if(p>-1) {
			if(p>sp) return GetRangeByIdx(sp,p-1);
			else	 return resizetmp(NULL);
		}
	} else {
		p=InStr(sp,ep,k1);
		if(p>-1) q=InStr(p+l1,ep,k2);
		if(p>-1 && q>-1) {
			MyStr T;
			if(p>sp) T=GetRangeByIdx(sp,p-1);
			MyStr S(GetRangeByIdx(q+l2,ep));
			T+=S.GetRangeWithDelByKey(-1,-1,k1,k2);
			return resizetmp(T.str);
		}
	}
	return GetRangeByIdx(sp,ep);
}
const char* MyStr::GetRangeWithDelByKey(const int si,const int ei,const char c1,const char c2) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelByKey(si,ei,k1,k2);
}
const char* MyStr::GetRangeWithDelByKey(const int si,const int ei,const char c1,const char *k2) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeWithDelByKey(si,ei,k1,k2);
}
const char* MyStr::GetRangeWithDelByKey(const int si,const int ei,const char *k1,const char c2) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelByKey(si,ei,k1,k2);
}

//#######################################################################################################################

const char* MyStr::GetRangeWithDelBtwKey(const char c1,const char c2) {
	return GetRangeWithDelBtwKey(-1,-1,c1,c2);
}
const char* MyStr::GetRangeWithDelBtwKey(const char c1,const char *k2) {
	return GetRangeWithDelBtwKey(-1,-1,c1,k2);
}
const char* MyStr::GetRangeWithDelBtwKey(const char *k1,const char c2) {
	return GetRangeWithDelBtwKey(-1,-1,k1,c2);
}
const char* MyStr::GetRangeWithDelBtwKey(const char *k1,const char *k2) {
	return GetRangeWithDelBtwKey(-1,-1,k1,k2);
}

const char* MyStr::GetRangeWithDelBtwKey(const int si,const char c1,const char c2) {
	return GetRangeWithDelBtwKey(si,-1,c1,c2);
}
const char* MyStr::GetRangeWithDelBtwKey(const int si,const char c1,const char *k2) {
	return GetRangeWithDelBtwKey(si,-1,c1,k2);
}
const char* MyStr::GetRangeWithDelBtwKey(const int si,const char *k1,const char c2) {
	return GetRangeWithDelBtwKey(si,-1,k1,c2);
}
const char* MyStr::GetRangeWithDelBtwKey(const int si,const char *k1,const char *k2) {
	return GetRangeWithDelBtwKey(si,-1,k1,k2);
}

const char* MyStr::GetRangeWithDelBtwKey(const int si,const int ei,const char *k1,const char *k2) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);
	
	int l1=0;
	if(k1!=NULL) l1=strlen(k1);
	int l2=0;
	if(k2!=NULL) l2=strlen(k2);

	int p=-1;
	int q=-1;
	if(l1<1) {
		if(l2>0) q=InStr(sp,ep,k2);
		if(q>-1) return GetRangeByIdx(q,ep);
	} else if(l2<1) {
		p=InStr(sp,ep,k1);
		if(p>-1) return GetRangeByIdx(sp,p+l1-1);
	} else {
		p=InStr(sp,ep,k1);
		if(p>-1) q=InStr(p+l1,ep,k2);
		if(p>-1 && q>-1) {
			MyStr T(GetRangeByIdx(sp,p+l1-1));
			T+=k2;
			MyStr S(GetRangeByIdx(q+l2,ep));
			T+=S.GetRangeWithDelBtwKey(-1,-1,k1,k2);
			return resizetmp(T.str);
		}
	}
	return GetRangeByIdx(sp,ep);
}
const char* MyStr::GetRangeWithDelBtwKey(const int si,const int ei,const char c1,const char c2) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelBtwKey(si,ei,k1,k2);
}
const char* MyStr::GetRangeWithDelBtwKey(const int si,const int ei,const char c1,const char *k2) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeWithDelBtwKey(si,ei,k1,k2);
}
const char* MyStr::GetRangeWithDelBtwKey(const int si,const int ei,const char *k1,const char c2) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelBtwKey(si,ei,k1,k2);
}

//#######################################################################################################################

const char* MyStr::GetRangeWithDelByKeyExSymBlk(const char c1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExSymBlk(-1,-1,c1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExSymBlk(-1,-1,c1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExSymBlk(-1,-1,k1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExSymBlk(-1,-1,k1,k2,SymChrLst);
}

const char* MyStr::GetRangeWithDelByKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExSymBlk(si,-1,c1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExSymBlk(si,-1,c1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExSymBlk(si,-1,k1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExSymBlk(si,-1,k1,k2,SymChrLst);
}

const char* MyStr::GetRangeWithDelByKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst) {
	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeWithDelByKey(si,ei,k1,k2);
	
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);
	
	int l1=0;
	if(k1!=NULL) l1=strlen(k1);
	int l2=0;
	if(k2!=NULL) l2=strlen(k2);
	
	int p=sp;
	int q=ep;
	if(l1>0) p=InStr(sp,ep,k1);
	if(l2>0) {
		if(l1>0) 	q=InStr(p+l1,ep,k2);
	    else		q=InStr(sp,ep,k2);
	}

	if(p>-1 && q>-1) {
		int k=sp;
		PO2 pp=SymBlkIdxInStr(k,ep,SymChrLst);
		while(pp.p1>-1) {
			k=pp.p2+1;
			if(l1>0 && (p>=pp.p1 && p<=pp.p2)) {
				p=InStr(k,ep,k1);
				if(l2>0) q=InStr(p+l1,ep,k2);
			}
			if(l2>0 && (q>=pp.p1 && q<=pp.p2)) q=InStr(k,ep,k2);
			if(p<0 || q<0) break;
			pp=SymBlkIdxInStr(k,ep,SymChrLst);
		}	
		if(p>-1 && q>=p) {
			MyStr T;
			if(p>sp) T+=GetRangeByIdx(sp,p-1);
			if(l2>0) {
				q+=l2;
				if(q<ep) { MyStr S(GetRangeByIdx(q,ep)); T+=S.GetRangeWithDelByKeyExSymBlk(-1,-1,k1,k2,SymChrLst); }
			}
			return resizetmp(T.str);
		}
	}
	return resizetmp(GetRangeByIdx(sp,ep));
}
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelByKeyExSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeWithDelByKeyExSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelByKeyExSymBlk(si,ei,k1,k2,SymChrLst);
}

//#######################################################################################################################

const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const char c1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExSymBlk(-1,-1,c1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExSymBlk(-1,-1,c1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExSymBlk(-1,-1,k1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExSymBlk(-1,-1,k1,k2,SymChrLst);
}

const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExSymBlk(si,-1,c1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExSymBlk(si,-1,c1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExSymBlk(si,-1,k1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExSymBlk(si,-1,k1,k2,SymChrLst);
}

const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst) {
	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeWithDelBtwKey(si,ei,k1,k2);
	
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);
	
	int l1=0;
	if(k1!=NULL) l1=strlen(k1);
	int l2=0;
	if(k2!=NULL) l2=strlen(k2);
	
	int p=sp;
	int q=ep;
	if(l1>0) p=InStr(sp,ep,k1);
	if(l2>0) {
		if(l1>0) 	q=InStr(p+l1,ep,k2);
	    else		q=InStr(sp,ep,k2);
	}

	if(p>-1 && q>-1) {
		int k=sp;
		PO2 pp=SymBlkIdxInStr(k,ep,SymChrLst);
		while(pp.p1>-1) {
			k=pp.p2+1;
			if(l1>0 && (p>=pp.p1 && p<=pp.p2)) {
				p=InStr(k,ep,k1);
				if(l2>0) q=InStr(p+l1,ep,k2);
			}
			if(l2>0 && (q>=pp.p1 && q<=pp.p2)) q=InStr(k,ep,k2);
			if(p<0 || q<0) break;
			pp=SymBlkIdxInStr(k,ep,SymChrLst);
		}	
		if(p>-1 && q>=p) {
			MyStr T;
			if(p>sp) T+=GetRangeByIdx(sp,p-1);
			if(l1>0) T+=k1;
			if(l2>0) {
				T+=k2;  q+=l2;
				if(q<ep) { MyStr S(GetRangeByIdx(q,ep)); T+=S.GetRangeWithDelBtwKeyExSymBlk(-1,-1,k1,k2,SymChrLst); }
			}
			return resizetmp(T.str);
		}
	}
	return resizetmp(GetRangeByIdx(sp,ep));
}
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelBtwKeyExSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelBtwKeyExSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeWithDelBtwKeyExSymBlk(si,ei,k1,k2,SymChrLst);
}

//#######################################################################################################################
const char* MyStr::GetLineWithCmtChrDelN(const char CmtChr,const int N) {
	return GetLineWithCmtChrDelN(-1,-1,CmtChr,N);
}
const char* MyStr::GetLineWithCmtChrDelN(const int si,const char CmtChr,const int N) {
	return GetLineWithCmtChrDelN(si,-1,CmtChr,N);
}
const char* MyStr::GetLineWithCmtChrDelN(const int si,const int ei,const char CmtChr,const int N) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);
	
	if(CmtChr=='\0') return resizetmp(str);

	MyStr T;
	int k=sp;
	int p=InStr(k,ep,'\n');
	while(p>-1) {
		if(p>k) {
			MyStr S(GetRangeByIdx(k,p-1));
			T+=S.GetLineWithCmtChrDelN(CmtChr,N);
			k=p;			
		}
		if(k<=p) T+=GetRangeByIdx(k,p);
		k=p+1;
		p=InStr(k,ep,'\n');
	}
	if(k<=ep) {
		int q=InStr(k,ep,CmtChr);
		while(q>-1) {
			if(q>k) T+=GetRangeByIdx(k,q-1);
			k=q+1;
			if(N>0) k+=N;
			q=InStr(k,ep,CmtChr);
		}
		if(k<=ep) T+=GetRangeByIdx(k,ep);
	}
	return resizetmp(T.str);
}
//#######################################################################################################################
const char* MyStr::GetLineWithCmtChrDelNExSymBlk(const char CmtChr,const int N,const char *SymChrLst){
	return GetLineWithCmtChrDelNExSymBlk(-1,-1,CmtChr,N,SymChrLst);
}
const char* MyStr::GetLineWithCmtChrDelNExSymBlk(const int si,const char CmtChr,const int N,const char *SymChrLst){
	return GetLineWithCmtChrDelNExSymBlk(si,-1,CmtChr,N,SymChrLst);
}
const char* MyStr::GetLineWithCmtChrDelNExSymBlk(const int si,const int ei,const char CmtChr,const int N,const char *SymChrLst){
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);
	
	if(CmtChr=='\0') return resizetmp(str);
	
	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	
	if(lsym<1) return GetLineWithCmtChrDelN(si,ei,CmtChr,N);

	MyStr T,S;
	int k=sp;
	PO2 pp=SymBlkIdxInStr(k,ep,SymChrLst);
	
	while(pp.p1>-1) {
		if(pp.p1>k) { S=GetRangeByIdx(k,pp.p1-1); T+=S.GetLineWithCmtChrDelN(CmtChr,N); }
		T+=GetRangeByIdx(pp.p1,pp.p2);
		k=pp.p2+1;
		pp=SymBlkIdxInStr(k,ep,SymChrLst);
	}
	if(k<=ep) {
		S=GetRangeByIdx(k,ep);
		T+=S.GetLineWithCmtChrDelN(CmtChr,N);
	}
	return resizetmp(T.str);
}
//#######################################################################################################################
const char* MyStr::GetLineDelByKey(const char c1,const char c2) { return GetLineDelByKey(-1,-1,c1,c2); }
const char* MyStr::GetLineDelByKey(const char c1,const char *k2) { return GetLineDelByKey(-1,-1,c1,k2); }
const char* MyStr::GetLineDelByKey(const char *k1,const char c2) { return GetLineDelByKey(-1,-1,k1,c2); }
const char* MyStr::GetLineDelByKey(const char *k1,const char *k2){ return GetLineDelByKey(-1,-1,k1,k2); }

const char* MyStr::GetLineDelByKey(const int si,const char c1,const char c2) { return GetLineDelByKey(si,-1,c1,c2); }
const char* MyStr::GetLineDelByKey(const int si,const char c1,const char *k2) { return GetLineDelByKey(si,-1,c1,k2); }
const char* MyStr::GetLineDelByKey(const int si,const char *k1,const char c2) { return GetLineDelByKey(si,-1,k1,c2); }
const char* MyStr::GetLineDelByKey(const int si,const char *k1,const char *k2){ return GetLineDelByKey(si,-1,k1,k2); }

const char* MyStr::GetLineDelByKey(const int si,const int ei,const char c1,const char c2) { 
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetLineDelByKey(si,ei,k1,k2); 
}
const char* MyStr::GetLineDelByKey(const int si,const int ei,const char c1,const char *k2) { 
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetLineDelByKey(si,ei,k1,k2); 
}
const char* MyStr::GetLineDelByKey(const int si,const int ei,const char *k1,const char c2) { 
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetLineDelByKey(si,ei,k1,k2); 
}
const char* MyStr::GetLineDelByKey(const int si,const int ei,const char *k1,const char *k2){
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);
	
	MyStr S(k2);
	if(S=="\n") return GetLineDelByKey(si,ei,k1,"");
	S=k1;
	if(S=="\n") return GetLineDelByKey(si,ei,"",k2);
		
	MyStr T;
	int p=InStr(sp,ep,'\n');
	while(p>-1) {
		if(p>sp) {
			S=GetRangeByIdx(sp,p-1);
			T+=S.GetRangeWithDelByKey(k1,k2);
		}
		T+='\n';
		sp=p+1;
		p=InStr(sp,ep,'\n');
	}
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		T+=S.GetRangeWithDelByKey(k1,k2);
	}
	return resizetmp(T.str);
}
//#######################################################################################################################
const char* MyStr::GetLineDelBtwKey(const char c1,const char c2) { return GetLineDelBtwKey(-1,-1,c1,c2); }
const char* MyStr::GetLineDelBtwKey(const char c1,const char *k2) { return GetLineDelBtwKey(-1,-1,c1,k2); }
const char* MyStr::GetLineDelBtwKey(const char *k1,const char c2) { return GetLineDelBtwKey(-1,-1,k1,c2); }
const char* MyStr::GetLineDelBtwKey(const char *k1,const char *k2){ return GetLineDelBtwKey(-1,-1,k1,k2); }

const char* MyStr::GetLineDelBtwKey(const int si,const char c1,const char c2) { return GetLineDelBtwKey(si,-1,c1,c2); }
const char* MyStr::GetLineDelBtwKey(const int si,const char c1,const char *k2) { return GetLineDelBtwKey(si,-1,c1,k2); }
const char* MyStr::GetLineDelBtwKey(const int si,const char *k1,const char c2) { return GetLineDelBtwKey(si,-1,k1,c2); }
const char* MyStr::GetLineDelBtwKey(const int si,const char *k1,const char *k2){ return GetLineDelBtwKey(si,-1,k1,k2); }

const char* MyStr::GetLineDelBtwKey(const int si,const int ei,const char c1,const char c2) { 
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetLineDelBtwKey(si,ei,k1,k2); 
}
const char* MyStr::GetLineDelBtwKey(const int si,const int ei,const char c1,const char *k2) { 
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetLineDelBtwKey(si,ei,k1,k2); 
}
const char* MyStr::GetLineDelBtwKey(const int si,const int ei,const char *k1,const char c2) { 
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetLineDelBtwKey(si,ei,k1,k2); 
}
const char* MyStr::GetLineDelBtwKey(const int si,const int ei,const char *k1,const char *k2){
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);

	MyStr S(k2);
	if(S=="\n") return GetLineDelBtwKey(si,ei,k1,"");
	S=k1;
	if(S=="\n") return GetLineDelBtwKey(si,ei,"",k2);

//printf("\nGetLineDelBtwKey k1=[%s] k2=[%s] str=[%s]",k1,k2,str);
	
	MyStr T;
	int p=InStr(sp,ep,'\n');
	while(p>-1) {
		if(p>sp) {
			S=GetRangeByIdx(sp,p-1);
//printf("\nGetLineDelBtwKey 0 S=[%s]",(char*)S);
			T+=S.GetRangeWithDelBtwKey(k1,k2);
		}
		T+='\n';
		sp=p+1;
		p=InStr(sp,ep,'\n');
	}
//printf("\nGetLineDelBtwKey 1 T=[%s]",(char*)T);
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		T+=S.GetRangeWithDelBtwKey(k1,k2);
	}
//printf("\nGetLineDelBtwKey 2 T=[%s]",(char*)T);
	return resizetmp(T.str);
}
//#######################################################################################################################
const char* MyStr::GetLineDelByKeyExSymBlk(const char c1,const char c2,const char *SymChrLst){return GetLineDelByKeyExSymBlk(-1,-1,c1,c2,SymChrLst);}
const char* MyStr::GetLineDelByKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst){return GetLineDelByKeyExSymBlk(-1,-1,c1,k2,SymChrLst);}
const char* MyStr::GetLineDelByKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst){return GetLineDelByKeyExSymBlk(-1,-1,k1,c2,SymChrLst);}
const char* MyStr::GetLineDelByKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst){return GetLineDelByKeyExSymBlk(-1,-1,k1,k2,SymChrLst);}

const char* MyStr::GetLineDelByKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst){return GetLineDelByKeyExSymBlk(si,-1,c1,c2,SymChrLst);}
const char* MyStr::GetLineDelByKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst){return GetLineDelByKeyExSymBlk(si,-1,c1,k2,SymChrLst);}
const char* MyStr::GetLineDelByKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst){return GetLineDelByKeyExSymBlk(si,-1,k1,c2,SymChrLst);}
const char* MyStr::GetLineDelByKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst){return GetLineDelByKeyExSymBlk(si,-1,k1,k2,SymChrLst);}

const char* MyStr::GetLineDelByKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst){
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetLineDelByKeyExSymBlk(si,ei,k1,k2,SymChrLst); 
}
const char* MyStr::GetLineDelByKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst){
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetLineDelByKeyExSymBlk(si,ei,k1,k2,SymChrLst); 
}
const char* MyStr::GetLineDelByKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst){
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetLineDelByKeyExSymBlk(si,ei,k1,k2,SymChrLst); 
}
const char* MyStr::GetLineDelByKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst){
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetLineDelByKey(si,ei,k1,k2);

	MyStr T,S;
	int k=sp;
	PO2 pp=SymBlkIdxInStr(k,ep,SymChrLst);
	
	while(pp.p1>-1) {
		if(pp.p1>k) { S=GetRangeByIdx(k,pp.p1-1); T+=S.GetLineDelByKey(k1,k2); }
		T+=GetRangeByIdx(pp.p1,pp.p2);
		k=pp.p2+1;
		pp=SymBlkIdxInStr(k,ep,SymChrLst);
	}
	if(k<=ep) {
		S=GetRangeByIdx(k,ep);
		T+=S.GetLineDelByKey(k1,k2);
	}
	return resizetmp(T.str);
}

//#######################################################################################################################
const char* MyStr::GetLineDelBtwKeyExSymBlk(const char c1,const char c2,const char *SymChrLst){return GetLineDelBtwKeyExSymBlk(-1,-1,c1,c2,SymChrLst);}
const char* MyStr::GetLineDelBtwKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst){return GetLineDelBtwKeyExSymBlk(-1,-1,c1,k2,SymChrLst);}
const char* MyStr::GetLineDelBtwKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst){return GetLineDelBtwKeyExSymBlk(-1,-1,k1,c2,SymChrLst);}
const char* MyStr::GetLineDelBtwKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst){return GetLineDelBtwKeyExSymBlk(-1,-1,k1,k2,SymChrLst);}

const char* MyStr::GetLineDelBtwKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst){return GetLineDelBtwKeyExSymBlk(si,-1,c1,c2,SymChrLst);}
const char* MyStr::GetLineDelBtwKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst){return GetLineDelBtwKeyExSymBlk(si,-1,c1,k2,SymChrLst);}
const char* MyStr::GetLineDelBtwKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst){return GetLineDelBtwKeyExSymBlk(si,-1,k1,c2,SymChrLst);}
const char* MyStr::GetLineDelBtwKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst){return GetLineDelBtwKeyExSymBlk(si,-1,k1,k2,SymChrLst);}

const char* MyStr::GetLineDelBtwKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst){
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetLineDelBtwKeyExSymBlk(si,ei,k1,k2,SymChrLst); 
}
const char* MyStr::GetLineDelBtwKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst){
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetLineDelBtwKeyExSymBlk(si,ei,k1,k2,SymChrLst); 
}
const char* MyStr::GetLineDelBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst){
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetLineDelBtwKeyExSymBlk(si,ei,k1,k2,SymChrLst); 
}
const char* MyStr::GetLineDelBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst){
//printf("\nGetLineDelBtwKeyExSymBlk ...");
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return resizetmp(NULL);

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetLineDelBtwKey(si,ei,k1,k2);

	MyStr T,S;
	int k=sp;
	PO2 pp=SymBlkIdxInStr(k,ep,SymChrLst);
	
	while(pp.p1>-1) {
//printf("\nGetLineDelBtwKeyExSymBlk 1 k=%d pp.p1=%d ep=%d T=[%s]",k,pp.p1,ep,(char*)T);
		if(pp.p1>k) { 
			int m=pp.p1-1;
			S=GetRangeByIdx(k,pp.p1-1); 
			T+=S.GetLineDelBtwKey(k1,k2); 
		}
		T+=GetRangeByIdx(pp.p1,pp.p2);
//printf("\nGetLineDelBtwKeyExSymBlk 2 k=%d pp.p2=%d T=[%s]",k,pp.p2,(char*)T);
		k=pp.p2+1;
		pp=SymBlkIdxInStr(k,ep,SymChrLst);
	}
//printf("\nGetLineDelBtwKeyExSymBlk 3 k=%d T=[%s]",k,(char*)T);
	if(k<=ep) {
		S=GetRangeByIdx(k,ep);
		T+=S.GetLineDelBtwKey(k1,k2);
	}
//printf("\nGetLineDelBtwKeyExSymBlk end T=[%s]",(char*)T);
	return resizetmp(T.str);
}

//#######################################################################################################################
const char* MyStr::GetLowerCase(void) {
	resizetmp(str);
	for(int n=0;n<len;n++) {
		if(tmp[n]>='A' && tmp[n]<='Z') tmp[n]=tmp[n]+('a'-'A');
	}
	return tmp;
}
//#######################################################################################################################
const char* MyStr::GetUpperCase(void) {
	resizetmp(str);
	for(int n=0;n<len;n++) {
		if(tmp[n]>='a' && tmp[n]<='z') tmp[n]=tmp[n]-('a'-'A');
	}
	return tmp;
}
//#######################################################################################################################
int MyStr::LowerCaseInside(void) { return LowerCaseInside(-1,-1); }
int MyStr::LowerCaseInside(const int si) { return LowerCaseInside(si,-1); }
int MyStr::LowerCaseInside(const int si,const int ei) {
//printf("\nstr=[%s]",str);
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	if(sp>ep || ep>=len) return -1;
	int n=0;
	if(len>0) {
		for(int p=sp;p<=ep;p++) if(str[p]>='a' && str[p]<='z') n++;
	}
//printf(" n=%d",n);
	return n;
}
