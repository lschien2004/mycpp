#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>    //printf
#include <stdlib.h>   //malloc
#include <string.h>   //strncpy
#include <unistd.h>   //close
#include <iostream>

//#define StrMaxLen 512

#include "mylibc.h" 
#include "strbase.h"
#include "statementstr.h"

StrBase SymDEQU("DEQU");

typedef struct pdata {
	char *word;
	struct pdata *nxt;
} PDATA;

typedef struct sdequ {
	int 			Num;
	StrBase 		Name;
	StatementStr	Body;
	int				paraN;
	PDATA 			*Para;
	struct sdequ	*nxt;
} SDEQU;


class DEQU {
private:
	int 	cnt;
	SDEQU	*rp;
	StrBase tmp;
	PDATA*	newPDATA(char *parastr);
	SDEQU*	newSDEQU(char *namestr);
	char*	DEQU_PickupName(char* line);
	char*	DEQU_PickupPara(char* line);

public:
			DEQU(void);
	int		DEQU_define_check(char* line);
	int 	InDEQU(char *DEQUstr);
	char* 	Xfr(char *line);
	int 	Add(char *line);
	void 	Show(void);
			~DEQU();
};

char* DEQU::DEQU_PickupName(char* line){
	StatementStr S;
	int l;
	
	S=line;
	S.SelfTrim();
	S.SelfTrimMouseSym();
	S.TrimEndl();
	//============= Name check ===============
	tmp=S.PickupStr("#DEQU","(");
	tmp.SelfTrim();
	l=(int)tmp;
	if(l>0) {
		tmp.SelfTrimA();
		if(l!=(int)tmp) tmp="";
	}
	return tmp;
}

int	DEQU::DEQU_define_check(char* line) {
	StatementStr S;
	StrBase T,P;
	int l;
	
	S=line;
	S.SelfTrim();
	S.SelfTrimMouseSym();
	S.TrimEndl();
	//============= Name check ===============
	T=S.PickupStr("#DEQU","(");
	T.SelfTrim();
	l=(int)T;
	if(l==0) return -1;
	T.SelfTrimA();
	if(l!=(int)T) return -1;
	//============= Parameters check =========
	P=S.PickupStr("(","=");
	P.SelfTrimA();
	l=(int)P;
	if(l<1) return -1;
	if(P.InStr(")")!=(l-1)) return -1;
	//=========================================
	return (int)P-1;
}

PDATA* DEQU::newPDATA(char *parastr) {
	int l=0;
	if(parastr!=NULL) l=strlen(parastr);
	PDATA *pd=new PDATA;
	pd->nxt=NULL;
	pd->word=new char[l+1];
	pd->word[l]='\0';
	if(l>0) strcpy(pd->word,parastr);
	return pd;
}

SDEQU* DEQU::newSDEQU(char *namestr) {
	SDEQU *D=new SDEQU;
	D->Num=cnt;
	D->Para=NULL;
	D->nxt=NULL;
	D->paraN=0;
	if(namestr!=NULL) 	D->Name=namestr;
	else				D->Name="";
	return D;
}

int DEQU::InDEQU(char *DEQUstr) {
	int n=-1;
	if(rp==NULL) return n;
	StrBase S;
	S=DEQUstr;
	if((int)S<1) return n;
	SDEQU *p=rp;
	while(p!=NULL) {
		if(S==p->Name) n=p->paraN;
		p=p->nxt;
	}
	return n;
}

char* DEQU::Xfr(char *line){

}

void DEQU::Show(void) {
	PDATA *dp;
	int n=0;
	SDEQU	*p=rp;
	while(p!=NULL) {
		printf("\n<<DEQU %d >> '%s'(",++n,(const char*)p->Name);
		dp=p->Para;
		while(dp!=NULL) {
			if(dp!=p->Para) printf(",");
			printf("%s",dp->word);
			dp=dp->nxt;
		}
		printf(")=\n%s",(const char *)p->Body);
		printf("\n<<DEQU>>\n");
		p=p->nxt;
	}
}

DEQU::DEQU(void) { cnt=0; rp=NULL;}

int DEQU::Add(char *line)
{
	int p,q,n,l;
	StatementStr S,T;
	PDATA *pd,*cd;
	SDEQU *D,*d;
	char tmp[30];	
	
	if(DEQU_define_check(line)<0) return -1;
	
	S=line;
	n=S.InStr("="); p=S.InStr("{{"); q=S.InStr("}}");
	if(!(n>0 && n<p && p<q)) return -1;
	
	T=S.PickupStr("#DEQU","(");
	T.SelfTrim();
	if((int)T==0) return -1;	// Name =''
	
	cnt++;
	D=newSDEQU((char*)T);
	
	if(rp==NULL) rp=D;
	else { d=rp; while(d->nxt!=NULL) d=d->nxt; d->nxt=D; }

	T=S.PickupStr("(",")");
	T.SelfTrimA();
	p=0; n=0;
	while(!(p<0)) {
		p=T.InStr(",");
		if(p>=0) {
			n++;	sprintf(tmp,"%d",n);
			if(p>0) pd=newPDATA(T.PartOfStr(0,p-1));
			else	pd=newPDATA(tmp);
			if(D->Para==NULL)	{ D->Para=pd; cd=D->Para; }
			else				{ cd->nxt=pd; cd=pd; }
			T=T.PickupStr(",","");
		} else {
			if((int)T>0) {
				n++;
				pd=newPDATA((char*)T);
				if(D->Para==NULL)  	D->Para=pd;
				else				cd->nxt=pd;
			} else if(n>2) {
				n++;	sprintf(tmp,"%d",n);
				pd=newPDATA(tmp);
				if(D->Para==NULL)  	D->Para=pd;
				else				cd->nxt=pd;
			}
		}
	}
	D->paraN=n;

//printf("\n*S*>%s",(const char*)S);
	p=S.InStr("{{")+2; q=S.RevInStr("}}")-1;
//printf("\n* p=%d q=%d",p,q);
	D->Body=S.PartOfStr(p,q);
//printf("\n*Body*>%s",(const char*)D->Body);
	
	D->Body.SelfReplaceStrExStrBlock("\t"," ");
	D->Body.SelfCompressCharExStrBlock(" ");

	D->Body.SelfTrimComment();
	D->Body.SelfTrimMouseSym();
	
	tmp[0]=0x0a; tmp[1]='\0';
//	D->Body.SelfCompressCharExStrBlock(tmp);
	D->Body.SelfCompressChar(tmp);
	D->Body.SelfTrimL();
	
	pd=D->Para;
	n=0;
	while(pd!=NULL) {
		n++;	sprintf(tmp,"%d",n);
		T="${";			S="${";
		T+=pd->word;	S+=tmp;
		T+="}$";		S+="}$";
		D->Body.SelfReplaceStr(T,S);
		
		T="$("; T+=pd->word; T+=")$";
		D->Body.SelfReplaceStr(T,S);
		pd=pd->nxt;
	}
	return D->Num;
}

DEQU::~DEQU() {
	PDATA *pd,*cd;
	SDEQU *D;
	
	while(rp!=NULL) {
		D=rp; rp=rp->nxt;
		pd=D->Para;
		while(pd!=NULL) {
			cd=pd; pd=pd->nxt;
			if(cd->word!=NULL) delete cd->word;
			delete cd;
		}
		delete D;
		cnt--;
	}
}

using namespace std;

void usage(char *pgmname)
{
	cout << endl;
	cout << "##################################################################" << endl;
	cout << " This tool use to covert DEQU.. macro from *.src file to *.asc" << endl;
	cout << " Usage:" << pgmname << " <main src file> [<path for coverted asc files>]" << endl;
	cout << "   Ex: " << pgmname << " main.src ASCDIR" << endl;
	cout << "       >> Covert main.src & the INSERTed src files to ASCDIR path" << endl;
	cout << "   Ex: " << pgmname << " main.src" << endl;
	cout << "       >> Covert main.src & the INSERTed src files in current path" << endl;
	cout << " Note : *.src file must named by lower-case file name & with .src" << endl; 
	cout << "##################################################################" << endl;	
}

int main (int ac , char ** av )
{
	char CRLF[3];
	char LEND[2];
	
	DEQU DD;
	
	char line[StrMaxLen];
	char DEQUNAME[StrMaxLen];
	char DEQUPARA[StrMaxLen];
	
	int f,p,q;
	FILE *ifp , *ofp;
	
	if(ac<2 || ac>3) { usage(av[0]); exit(-1); }
	
	CRLF[0]=0x0a; CRLF[1]=0x0d; CRLF[2]='\0';
	LEND[0]=0x0a; LEND[1]='\0';
	
	StrBase ifile(av[1]);
	StatementStr S,T,Q;
	
	if((ifp=fopen(ifile,"r"))==NULL) {printf("\n!!! Open '%s' for read fail!",(const char*)ifile); exit(1);}

printf(";;!!! file begin !!!\n");

	f=1;
	while(f) {
		if(fgets(line,StrMaxLen-1,ifp)!=NULL) {
			Q=line;
			printf("%s",(const char *)Q);
			T=Q;
			T.SelfTrimComment();
			T.SelfTrimMouseSym();
			T.SelfTrim();

//printf(" f=%d Q>T ='%s'",f,(const char *)T);
			if(f==1 && T.InStr(SymDEQU)>=0) { 
				f++; 
				strcpy(DEQUNAME,T.PickupStr("#DEQU","("));
				strcpy(DEQUPARA,T.PickupStr("(",")"));
				TrimRight(DEQUNAME,DEQUNAME); 
				TrimLeft(DEQUNAME,DEQUNAME);
				S="";
//printf("\n--> #DEQU <%s>(%s)\n",DEQUNAME,DEQUPARA);
			}
			switch (f) {
			  case 2:
			  	p=T.InStr("{{");	q=T.RevInStr("}}");
//printf("\n !!! f=%d p=%d q=%d len=%d '%s'\n",f,p,q,(int)T,(const char *)T);
			  	if(!(p<0)) {
			  		if(q>p) { S+=T.PartOfStr(p,q+1); f=4; }
			  		else	{ S+=T.PartOfStr(p,-1); f++; }
			  	}
//printf(" S='%s'\n",(const char *)S);
			  	break;
			  case 3:
			  	p=T.RevInStr(LEND); 
			  	if(p<0) p=(int)T;
			  	q=T.RevInStr("}}");
//printf("\n !!! f=%d p=%d q=%d len=%d '%s'\n",f,p,q,(int)T,(const char *)T);
			  	if(q<0 || (q+strlen("}}"))!=p) S+=T;
			  	else { S+=T.PartOfStr(-1,q+1); f=4; }
			  	break;
			}
//printf(" f=%d S='%s'\n",f,(const char *)S);
			if(f>3) {
				T="#DEQU ";
				T+=DEQUNAME;
				T+="(";
				T+=DEQUPARA;
				T+=")";
				T+=" = ";
				T+=S;
				
				DD.Add((char*)T);

				f=1;
			}
//printf("\n*** f=%d \n",f);
		}
		else f=0;
	}
	fclose(ifp);
printf(";;!!! file end !!!\n");

	DD.Show();
/*
printf("\n >> InDEQU('WTSTGENTY') = %d\n",DD.InDEQU("WTSTGENTY"));
printf("\n >> InDEQU('WTSTGEXIT') = %d\n",DD.InDEQU("WTSTGEXIT"));
printf("\n >> InDEQU('FCTES') = %d\n",DD.InDEQU("FCTES"));
printf("\n >> InDEQU('') = %d\n",DD.InDEQU(""));
printf("\n >> InDEQU('WTSTG') = %d\n",DD.InDEQU("WTSTG"));
*/
    exit(0);

}
