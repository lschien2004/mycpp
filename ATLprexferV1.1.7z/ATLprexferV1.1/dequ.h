/*
	Ver.1.1 : (1) Xfer �� parameter TrimR+TrimL (except DEQUSYMS+DEQUSYMX)
	Ver.1.1 : (2) Xfer �� parameter �� SymX+data+SymX�� data ���B�z, ��SymX�h���ᵹBody�Axfer.
*/

#ifndef __DEQU_H__
#define __DEQU_H__

#include "mystr.h"

typedef struct dslink {
	MyStr data;
	dslink *nxt;
} DSLINK;

#define _dequVer_	"V1.1"

#define DEQUKEY    		"#dequ"
#define DEQUPARST  		'<'
#define DEQUPARED  		'>'
#define DEQUBDYST  		"{{"
#define DEQUBDYED  		"}}"
#define DEQUSYMS   		"?\""			// Parameter , body : SymS+data+SymS <- ���B�z
#define DEQUSYMX   		"'%" 			// Xfer�ɳB�z Parameter : SymX+data+SymX <- data ���B�z,SymX�h���ᵹBody�Axfer.
#define DEQULCMT   		';'
#define DEQUCMTC   		'@'
#define DEQUBDYVPAST 	'$'
#define DEQUBDYVPAED 	'$'


class DEQU {
private:
          MyStr      NAME;
          MyStr      BODY;
          int        PARN;
          DSLINK*	 Para;
          MyStr      TMP;
protected:
		  void ParaRelease(void);
public:
          const char *GetTrimDEQU(const char *dequstr);
          const char *GetNameFromTrimDEQU(const char *trimdequ);
          const char *GetBodyFromTrimDEQU(const char *trimdequ);
          const char *GetParaFromTrimDEQU(const char *trimdequ);
		  		  		  
          const char *GetName(void);
          const char *GetBody(void);
                 int  GetParN(void);
          const char *GetPara(void);

                void  Setup(const char *s);

          DEQU();
          DEQU(MyStr &S);
          DEQU(const char *s);
          ~DEQU();
          
		  DEQU& operator=(const char *s);
		  DEQU& operator=(MyStr &S);

		  bool  operator==(const char* name);
		  bool  operator==(MyStr &S);
		  bool  operator!=(const char* name);
		  bool  operator!=(MyStr &S);

};
//###############################################################################

typedef struct dqlink {
	int PARN;
	MyStr NAME;
	dqlink *nxt;
} DQLINK;

//###############################################################################

#define DEQU_DB_MaxLineLen    128

class DEQU_DB {
private:
	 int 			CNT;
	 MyStr			DBfile;
	 DQLINK			*DBP;
	 MyStr			TMP;
protected:
	 void			ReleaseDBP(void);
	 const char*	ParaAnalyze(MyStr &PA,MyStr &SYM);
	 const char *	PickupLineDequPara(MyStr &LL,MyStr &DEQNM,MyStr &SYM,MyStr &LS,MyStr &LE);
public:

 inline const int	GetCNT(void) {return CNT; }

	 void 			Add(DEQU& DD);
	 const char*	DEQU_Inside(const char *line);
	 int 			SearchDEQUparN(const char *dequname);
	 const char*	GetDEQUbodyInDB(const char *dequname);
	 const char*	GetDEQUnameByDBIdx(const int si);

	 const char*	DEQU_xfer(const char *line);

					DEQU_DB(const char *dbfname);
					DEQU_DB(const char *dbfname,DEQU& DD);
					~DEQU_DB();
};

#endif

