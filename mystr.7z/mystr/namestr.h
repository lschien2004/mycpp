/*##############################################################################################
	v1.0@20191019	initial ver.
################################################################################################*/

#ifndef __NameStr_h__
    #define __NameStr_h__
	#define __NameStrVer_h__	"NameStr-v1.0@20191019"

#include "mystr.h"

class namestr : public MyStr {
private:
		 	 char *myname;
protected:
virtual 	 void releasename(void);

public:
			namestr(const char *name=NULL,const char *s=NULL);
			namestr(const char *name,const char sc);
			namestr(const char *name,MyStr &S);
			namestr(const char *name,const int v);
			namestr(const char *name,const long lv);
			
			namestr(const char nc,const char *s=NULL);
			namestr(const char nc,const char sc);
			namestr(const char nc,MyStr &S);
			namestr(const char nc,const int v);
			namestr(const char nc,const long lv);
			
			namestr(MyStr &NAME,const char *s=NULL);
			namestr(MyStr &NAME,const char sc);
			namestr(MyStr &NAME,MyStr &S);
			namestr(MyStr &NAME,const int v);
			namestr(MyStr &NAME,const long lv);

			namestr(const int nv,const char *s=NULL);
			namestr(const int nv,const char sc);
			namestr(const int nv,MyStr &S);
			namestr(const int nv,const int v);
			namestr(const int nv,const long lv);

			namestr(const long nlv,const char *s=NULL);
			namestr(const long nlv,const char sc);
			namestr(const long nlv,MyStr &S);
			namestr(const long nlv,const int v);
			namestr(const long nlv,const long lv);

			namestr(namestr &NS);

			~namestr();
			
			const char *SetName(const char c);
			const char *SetName(const char *name);
			const char *SetName(MyStr &NAME);
			const char *SetName(const int nv);
			const char *SetName(const long nlv);

			const char *GetName();
		     bool	   IsNameEmpty();
		     bool	   IsNotNameEmpty();

virtual 	namestr& operator=(namestr &NS);
virtual 	namestr& operator=(const char sc);
virtual 	namestr& operator=(const char *s);
virtual 	namestr& operator=(MyStr &S);
virtual 	namestr& operator=(const int v);
virtual 	namestr& operator=(const long lv);

virtual 	namestr& operator+=(namestr &NS);
virtual 	namestr& operator+=(const char sc);
virtual 	namestr& operator+=(const char *s);
virtual 	namestr& operator+=(MyStr &S);
virtual 	namestr& operator+=(const int v);
virtual 	namestr& operator+=(const long lv);

virtual 	const char* operator+(namestr &NS);
virtual 	 bool 	 operator==(namestr &NS);
virtual 	 bool 	 operator!=(namestr &NS);

};

#endif
