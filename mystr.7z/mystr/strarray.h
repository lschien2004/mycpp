#include "mystr.h"

#ifndef __StrArray_h__
    #define __StrArray_h__
	#define __StrArrayVer_h___	"StrArray-v1.1@20191018"

class StrArray {
private:
 			MyStr 		*pstr;
 			StrArray	*nxt;
protected:
	 void 	Release(StrArray *nd);
  StrArray *GetNode(MyStr &S);
  StrArray *GetNode(int idx);
public:
			StrArray();
			StrArray(const char *s);
			StrArray(MyStr &S);
			~StrArray();
			
	 int 	GetSNO(const char *s);
	 int 	GetSNO(MyStr &S);
	 
	 int 	GetCNT(void);

	 int 	Add(const char *s);
	 int 	Add(MyStr &S);
	 
	 int 	Del(int idx);
	 int 	Del(MyStr &S);
	 int 	Del(const char *s);

const char*	GetSTR(int idx);

const char*	List(const char *d=",");
const char*	List(const char c);
const char*	List(MyStr &DIV);
	 
 StrArray&  operator+=(const char *s);
 StrArray&  operator+=(MyStr &S);
	MyStr&  operator[](int idx);

};

#endif

