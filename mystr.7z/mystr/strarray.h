/*########################################################################################
	v1.1@20191018 	initial ver.
	v1.2@20191019 	rename GetCNT -> GetArrayCNT
					rename GetSNO -> GetIDX
					Add StrArray&  operator+=(StrArray &IA);
					Add StrArray(StrArray &A);
					Add StrArray(const int v);
					Add StrArray(const long lv);
					Add Add(StrArray &A);
					Add Add(const int v);
					Add Add(const long lv);
##########################################################################################*/

#include "mystr.h"

#ifndef __StrArray_h__
    #define __StrArray_h__
	#define __StrArrayVer_h___	"StrArray-v1.2@20191019"

class StrArray {
private:
 			MyStr 		*pstr;
 			StrArray	*nxt;
protected:
	 void 	Release(StrArray *nd);
  StrArray *GetNode(MyStr &S);
  StrArray *GetNode(int idx);
public:
			StrArray();
			StrArray(const char *s);
			StrArray(MyStr &S);
			StrArray(StrArray &A);
			StrArray(const int v);
			StrArray(const long lv);
			
			~StrArray();
			
	 int 	GetIDX(const char *s);
	 int 	GetIDX(MyStr &S);
	 
	 int 	GetArrayCNT(void);

	 int 	Add(const char *s);
	 int 	Add(MyStr &S);
	 int 	Add(StrArray &A);
	 int 	Add(const int v);
	 int 	Add(const long lv);
	 
	 int 	Del(int idx);
	 int 	Del(MyStr &S);
	 int 	Del(const char *s);

const char*	GetSTR(int idx);

const char*	List(const char *d=",");
const char*	List(const char c);
const char*	List(MyStr &DIV);
	 
 StrArray&  operator+=(const char *s);
 StrArray&  operator+=(MyStr &S);
 StrArray&  operator+=(StrArray &A);
 
 	MyStr&  operator[](int idx);

};

#endif

