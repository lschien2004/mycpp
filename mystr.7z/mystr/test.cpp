#include "strarray.h"
#include "namestr.h"

int main(int ac,char **av) {
	int n;

	printf("\nMyStr S(\"S-1\");");
	MyStr S("S-1");
	printf("\nS[-1]~S[%d]:\n",(int)S);
	for(n=-1;n<=(int)S;n++) printf("S[%d]='%c' ",n,S[n]);	
	
	printf("\nStrArray SA(S);");
	StrArray SA(S);
	printf("\nSA.GetArrayCNT()=%d",SA.GetArrayCNT());
	n=0; printf("\nSA[%d]=\"%s\" GetSTR(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetSTR(n));
	printf("\nSA.List()=\"%s\"",SA.List());
	printf("\nSA.GetIDX(\"%s\")=%d",(char*)S,SA.GetIDX(S));

	printf("\nS=\"S-2\"; SA.Add(S);");
	S="S-2";  SA.Add(S);
	printf("\nSA.GetArrayCNT()=%d",SA.GetArrayCNT());
	n=0; printf("\nSA[%d]=\"%s\" GetSTR(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetSTR(n));
	n=1; printf("\nSA[%d]=\"%s\" GetSTR(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetSTR(n));
	printf("\nSA.List()=\"%s\"",SA.List());
	printf("\nSA.GetIDX(\"%s\")=%d",(char*)S,SA.GetIDX(S));

	n=SA.Add("S-3");
	printf("\nSA.Add(\"S-3\")=%d",n);
	printf("\nSA.GetArrayCNT()=%d",SA.GetArrayCNT());
	n=0; printf("\nSA[%d]=\"%s\" GetSTR(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetSTR(n));
	n=1; printf("\nSA[%d]=\"%s\" GetSTR(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetSTR(n));
	n=2; printf("\nSA[%d]=\"%s\" GetSTR(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetSTR(n));
	printf("\nSA.List()=\"%s\"",SA.List());
	printf("\nSA.GetIDX(\"%s\")=%d",(char*)S,SA.GetIDX(S));

	printf("\nS=\"S-4\"; SA+=S;");
	S="S-4";  SA+=S;
	printf("\nSA.GetArrayCNT()=%d",SA.GetArrayCNT());
	n=0; printf("\nSA[%d]=\"%s\" GetSTR(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetSTR(n));
	n=1; printf("\nSA[%d]=\"%s\" GetSTR(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetSTR(n));
	n=2; printf("\nSA[%d]=\"%s\" GetSTR(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetSTR(n));
	n=3; printf("\nSA[%d]=\"%s\" GetSTR(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetSTR(n));
	printf("\nSA.List()=\"%s\"",SA.List());
	printf("\nSA.GetIDX(\"%s\")=%d",(char*)S,SA.GetIDX(S));

	printf("\nStrArray SB(SA);");
	StrArray SB(SA);
	printf("\nSB.GetArrayCNT()=%d",SB.GetArrayCNT());
	printf("\nSB.List()=\"%s\"",SB.List());

	printf("\nSA+=\"S-5\";");
	SA+="S-5";
	printf("\nSA.GetArrayCNT()=%d",SA.GetArrayCNT());
	n=0; printf("\nSA[%d]=\"%s\" GetSTR(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetSTR(n));
	n=1; printf("\nSA[%d]=\"%s\" GetSTR(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetSTR(n));
	n=2; printf("\nSA[%d]=\"%s\" GetSTR(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetSTR(n));
	n=3; printf("\nSA[%d]=\"%s\" GetSTR(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetSTR(n));
	n=4; printf("\nSA[%d]=\"%s\" GetSTR(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetSTR(n));
	printf("\nSA.List()=\"%s\"",SA.List());
	printf("\nSA.GetIDX('S-5')=%d",SA.GetIDX("S-5"));
	printf("\nSA.GetIDX('S-0')=%d",SA.GetIDX("S-0"));

	n=SA.Del("S-3");
	printf("\nSA.Del(\"S-3\")=%d",n);
	printf("\nSA.GetArrayCNT()=%d",SA.GetArrayCNT());
	printf("\nSA.List()=\"%s\"",SA.List());
	
	n=SA.Del(1);
	printf("\nSA.Del(1)=%d",n);
	printf("\nSA.GetArrayCNT()=%d",SA.GetArrayCNT());
	printf("\nSA.List()=\"%s\"",SA.List());

	n=SA.Del(0);
	printf("\nSA.Del(0)=%d",n);
	printf("\nSA.GetArrayCNT()=%d",SA.GetArrayCNT());
	printf("\nSA.List()=\"%s\"",SA.List());

	n=SB.Del("S-1");
	printf("\nSB.Del(\"S-1\")=%d",n);
	printf("\nSB.GetArrayCNT()=%d",SB.GetArrayCNT());
	printf("\nSB.List()=\"%s\"",SB.List());
	
	printf("\nSA+=\"S-6\";");
	SA+="S-6";
	printf("\nSA.GetArrayCNT()=%d",SA.GetArrayCNT());
	printf("\nSA.List()=\"%s\"",SA.List());

	printf("\nSB+=SA;");
	SB+=SA;
	printf("\nSA.GetArrayCNT()=%d",SA.GetArrayCNT());
	printf("\nSA.List()=\"%s\"",SA.List());
	printf("\nSB.GetArrayCNT()=%d",SB.GetArrayCNT());
	printf("\nSA.List()=\"%s\"",SB.List());

	printf("\nnamestr NSA;");
	namestr NSA;
	printf("\nNSA.GetName()=\"%s\"",NSA.GetName());
	printf("\nNSA.SetName(\"NSA\");");
	NSA.SetName("NSA");
	printf("\nNSA.GetName()=\"%s\"",NSA.GetName());
	printf("\nNSA=\"NSA DATA\";");
	NSA="NSA DATA";
	printf("\n(char*)NSA=\"%s\"",(char*)NSA);
	printf("\nNSA+=\" plus\";");
	NSA+=" plus";
	printf("\n(char*)NSA=\"%s\"",(char*)NSA);
	printf("\nNSA.GetName()=\"%s\"",NSA.GetName());
	printf("\n(int)NSA=%d",(int)NSA);

	printf("\nnamestr NSB(\"NSB\");");
	namestr NSB("NSB");
	printf("\nNSB.GetName()=\"%s\"",NSB.GetName());
	printf("\n(char*)NSB=\"%s\"",(char*)NSB);
	printf("\n(int)NSB=%d",(int)NSB);
	
	printf("\nNSB=\"NSB data\";");
	NSB+="NSB data";
	printf("\nNSB.GetName()=\"%s\"",NSB.GetName());
	printf("\n(char*)NSB=\"%s\"",(char*)NSB);
	printf("\n(int)NSB=%d",(int)NSB);
	
	printf("\nNSB=NSA;");
	NSB=NSA;
	printf("\nNSB.GetName()=\"%s\"",NSB.GetName());
	printf("\n(char*)NSB=\"%s\"",(char*)NSB);
	printf("\n(int)NSB=%d",(int)NSB);
	printf("\nNSA.GetName()=\"%s\"",NSA.GetName());
	printf("\n(char*)NSA=\"%s\"",(char*)NSA);
	printf("\n(int)NSA=%d",(int)NSA);
	printf("\nNSB=\"nsb data\"");
	
	NSB="nsb data";
	printf("\nNSB.GetName()=\"%s\"",NSB.GetName());
	printf("\n(char*)NSB=\"%s\"",(char*)NSB);
	printf("\n(int)NSB=%d",(int)NSB);
	
	printf("\nMyStr T((char*)NSA);");
	MyStr T((char*)NSA);
	printf("\n(char*)T=\"%s\"",(char*)T);
	printf("\nS=NSB;");
	T=NSB;
	printf("\n(char*)T=\"%s\"",(char*)T);
	printf("\nS+=NSA;");
	T+=NSA;
	printf("\n(char*)T=\"%s\"",(char*)T);
	
	exit(0);
}
