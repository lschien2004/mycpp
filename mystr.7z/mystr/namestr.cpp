#include "namestr.h"

void namestr::releasename(void){
	if(myname!=Emptystr) delete [] myname;
	myname=Emptystr;
}

namestr::~namestr(){ releasename(); }
	
namestr::namestr(const char *name,const char *s){
	myname=Emptystr;
	resizeX(&myname,name); resize(s);
}
namestr::namestr(const char *name,const char sc){
	myname=Emptystr;
	MyStr S(sc); resizeX(&myname,name); resize((char*)S);
}
namestr::namestr(const char *name,MyStr &S){
	myname=Emptystr;
	resizeX(&myname,name); resize((char*)S);
}
namestr::namestr(const char *name,const int v){
	myname=Emptystr;
	MyStr S(v); resizeX(&myname,name); resize((char*)S);
}
namestr::namestr(const char *name,const long lv){
	myname=Emptystr;
	MyStr S(lv); resizeX(&myname,name); resize((char*)S);
}

namestr::namestr(const char nc,const char *s){
	myname=Emptystr;
	MyStr NAME(nc); resizeX(&myname,(char*)NAME); resize(s);
}
namestr::namestr(const char nc,const char sc){
	myname=Emptystr;
	MyStr NAME(nc); MyStr S(sc); resizeX(&myname,(char*)NAME); resize((char*)S);
}
namestr::namestr(const char nc,MyStr &S){
	myname=Emptystr;
	MyStr NAME(nc); resizeX(&myname,(char*)NAME); resize((char*)S);
}
namestr::namestr(const char nc,const int v){
	myname=Emptystr;
	MyStr S(v); MyStr NAME(nc); resizeX(&myname,(char*)NAME); resize((char*)S);
}
namestr::namestr(const char nc,const long lv){
	myname=Emptystr;
	MyStr S(lv); MyStr NAME(nc); resizeX(&myname,(char*)NAME); resize((char*)S);
}

namestr::namestr(MyStr &NAME,const char *s){
	myname=Emptystr;
	resizeX(&myname,(char*)NAME); resize(s);
}
namestr::namestr(MyStr &NAME,const char sc){
	myname=Emptystr;
	MyStr S(sc); resizeX(&myname,(char*)NAME); resize((char*)S);
}
namestr::namestr(MyStr &NAME,MyStr &S){
	myname=Emptystr;
	resizeX(&myname,(char*)NAME); resize((char*)S);
}
namestr::namestr(MyStr &NAME,const int v){
	myname=Emptystr;
	MyStr S(v); resizeX(&myname,(char*)NAME); resize((char*)S);
}
namestr::namestr(MyStr &NAME,const long lv){
	myname=Emptystr;
	MyStr S(lv); resizeX(&myname,(char*)NAME); resize((char*)S);
}

namestr::namestr(const int nv,const char *s){
	myname=Emptystr;
	MyStr NAME(nv); resizeX(&myname,(char*)NAME); resize(s);
}
namestr::namestr(const int nv,const char sc){
	myname=Emptystr;
	MyStr NAME(nv); MyStr S(sc); resizeX(&myname,(char*)NAME); resize((char*)S);
}
namestr::namestr(const int nv,MyStr &S){
	myname=Emptystr;
	MyStr NAME(nv); resizeX(&myname,(char*)NAME); resize((char*)S);
}
namestr::namestr(const int nv,const int v){
	myname=Emptystr;
	MyStr NAME(nv); MyStr S(v); resizeX(&myname,(char*)NAME); resize((char*)S);
}
namestr::namestr(const int nv,const long lv){
	myname=Emptystr;
	MyStr NAME(nv); MyStr S(lv); resizeX(&myname,(char*)NAME); resize((char*)S);
}

namestr::namestr(const long nlv,const char *s){
	myname=Emptystr;
	MyStr NAME(nlv); resizeX(&myname,(char*)NAME); resize(s);
}
namestr::namestr(const long nlv,const char sc){
	myname=Emptystr;
	MyStr NAME(nlv); MyStr S(sc); resizeX(&myname,(char*)NAME); resize((char*)S);
}
namestr::namestr(const long nlv,MyStr &S){
	myname=Emptystr;
	MyStr NAME(nlv); resizeX(&myname,(char*)NAME); resize((char*)S);
}
namestr::namestr(const long nlv,const int v){
	myname=Emptystr;
	MyStr NAME(nlv); MyStr S(v); resizeX(&myname,(char*)NAME); resize((char*)S);
}
namestr::namestr(const long nlv,const long lv){
	myname=Emptystr;
	MyStr NAME(nlv); MyStr S(lv); resizeX(&myname,(char*)NAME); resize((char*)S);
}

namestr::namestr(namestr &NS){
	myname=Emptystr;
	operator=(NS);
}

const char *namestr::SetName(const char nc){
	MyStr NAME(nc); return SetName(NAME);
}
const char *namestr::SetName(const char *name){
	MyStr NAME(name); return SetName(NAME);
}
const char *namestr::SetName(MyStr &NAME){
	if((int)NAME<1) return NULL;
	return resizeX(&myname,(char*)NAME);
}
const char *namestr::SetName(const int nv){
	MyStr NAME(nv); 
	return resizeX(&myname,(char*)NAME);
}
const char *namestr::SetName(const long nlv){
	MyStr NAME(nlv); 
	return resizeX(&myname,(char*)NAME);
}

const char *namestr::GetName(){ return resizetmp(myname); }

bool namestr::IsNameEmpty() {
	if(myname==Emptystr) return true; else return false;
}
bool namestr::IsNotNameEmpty() {
	if(myname==Emptystr) return false; else return true;
}

namestr& namestr::operator=(const char sc){ MyStr S(sc); return operator=((char*)S); }
namestr& namestr::operator=(MyStr &S){ return operator=((char*)S); }
namestr& namestr::operator=(const int v){ MyStr S(v); return operator=((char*)S); }
namestr& namestr::operator=(const long lv){ MyStr S(lv); return operator=((char*)S); }
namestr& namestr::operator=(const char *s){
	resize(s);
	return *this;
}
namestr& namestr::operator=(namestr &NS){
	resizeX(&myname,NS.GetName());
	resize((char*)NS);
	return *this;
}

namestr& namestr::operator+=(namestr &NS){
	MyStr::operator+=(NS); return *this;
}
namestr& namestr::operator+=(const char sc){
	MyStr::operator+=(sc); return *this;
}
namestr& namestr::operator+=(const char *s){
	MyStr::operator+=(s); return *this;
}
namestr& namestr::operator+=(MyStr &S){
	MyStr::operator+=(S); return *this;
}
namestr& namestr::operator+=(const int v){
	MyStr S(v); MyStr::operator+=(S); return *this;
}
namestr& namestr::operator+=(const long lv){
	MyStr S(lv); MyStr::operator+=(S); return *this;
}

bool namestr::operator==(namestr &NS){
	return MyStr::operator==((char*)NS);
}
bool namestr::operator!=(namestr &NS){
	return MyStr::operator!=((char*)NS);
}
const char* namestr::operator+(namestr &NS){
	return MyStr::operator+((char*)NS);
}
