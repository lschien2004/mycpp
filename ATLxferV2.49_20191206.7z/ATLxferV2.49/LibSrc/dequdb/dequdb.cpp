#include "dequdb.h"

static MyStr TmpStr;

void ReleaseDSLINK(DSLINK **p) {
//printf("\nReleaseDSLINK(*p=%u)",*p);
	while(*p!=NULL) { 
//printf("..*p=%u",*p);
		DSLINK *t=*p;
		*p=(*p)->nxt;
		delete t;
	}
//printf("..Last *p=%u",*p);
}
//=====================================================================
void AddExchgLineXCmtWithExSymBlk(MyStr &LL,ArrayNameStr &Exchg) {
	PO2 pp;
	MyStr SYM(_DEQUSYMS);
	SYM+=_DEQUSYMU;
	pp.p1=LL.InStrExSymBlk(_DEQUXLCMT,(char*)SYM);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		pp.p2=LL.InStrExSymBlk(pp.p1,"\n",(char*)SYM);
		MyStr T(_DEQU_ExKeyS); T+=_DEQU_EC_XLineCmt; T+=Exchg.GetSN(); T+=n; T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2-1));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp.p1=LL.InStrExSymBlk(_DEQUXLCMT,(char*)SYM);
	}
}
//=====================================================================
void AddExchgLineMessage(MyStr &LL,ArrayNameStr &Exchg) {
	PO2 pp;
	pp.p1=LL.InStr(_DEQUMSGKEY);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		pp.p2=LL.InStr(pp.p1,"\n");
		MyStr T(_DEQU_ExKeyS); T+=_DEQU_EC_Message; T+=Exchg.GetSN(); T+=n; T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2-1));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp.p1=LL.InStr(_DEQUMSGKEY);
	}
}
//=====================================================================
void AddExchgLineCmtWithExSymBlk(MyStr &LL,ArrayNameStr &Exchg) {
	PO2 pp;
	MyStr SYM(_DEQUSYMS);
	SYM+=_DEQUSYMU;
	pp.p1=LL.InStrExSymBlk(_DEQULCMT,(char*)SYM);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		pp.p2=LL.InStrExSymBlk(pp.p1,"\n",(char*)SYM);
		MyStr T(_DEQU_ExKeyS); T+=_DEQU_EC_LineCmt; T+=Exchg.GetSN(); T+=n; T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2-1));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp.p1=LL.InStrExSymBlk(_DEQULCMT,(char*)SYM);
	}
}
void AddExchgLineCmtWithExLineSymBlk(MyStr &LL,ArrayNameStr &Exchg) {
	PO2 pp;
	pp.p1=LL.InStrExLineSymBlk(_DEQULCMT,_DEQUSYMA);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		pp.p2=LL.InStrExLineSymBlk(pp.p1,"\n",_DEQUSYMA);
		MyStr T(_DEQU_ExKeyS); T+=_DEQU_EC_LineCmt; T+=Exchg.GetSN(); T+=n; T+=_DEQU_ExKeyE;
		//NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2-1));
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp.p1=LL.InStrExLineSymBlk(_DEQULCMT,_DEQUSYMA);
	}
}
//=====================================================================
void AddExchgSymChrCmtWithExSymBlk(MyStr &LL,ArrayNameStr &Exchg) {
	ArrayNameStr ANS;
	MyStr T;
	PO2 pp=LL.GetPointOfStackPairKey(_DEQUKEY,_DEQUBDYST);
	while(pp.p1>-1 && pp.p2>-1) {
		T=_DEQU_ExKeyS; T+="tm"; T+=Exchg.GetSN(); T+=ANS.GetArrayCnt(); T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2));
		ANS+=NS;  LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp=LL.GetPointOfStackPairKey(_DEQUKEY,_DEQUBDYST);
	}
	//-------------------------------------------------------------
	pp.p1=LL.InStrExSymBlk(_DEQUCMTC,_DEQUSYMA);
	while(pp.p1>-1) {
		pp.p2=pp.p1+1;
		T=_DEQU_ExKeyS; T+=_DEQU_EC_CmtChar; T+=Exchg.GetSN(); T+=Exchg.GetArrayCnt(); T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp.p1=LL.InStrExSymBlk(_DEQUCMTC,_DEQUSYMA);
	}
	//-------------------------------------------------------------
	T=_DEQU_ExKeyS; T+="tm";
	LL=GetUnExchgStrByExkey(LL,ANS,(char*)T);
}
void AddExchgSymChrCmtWithExLineSymBlk(MyStr &LL,ArrayNameStr &Exchg) {
	ArrayNameStr ANS;
	MyStr T;
	PO2 pp=LL.GetPointOfStackPairKey(_DEQUKEY,_DEQUBDYST);
	while(pp.p1>-1 && pp.p2>-1) {
		T=_DEQU_ExKeyS; T+="tm"; T+=Exchg.GetSN(); T+=ANS.GetArrayCnt(); T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2));
		ANS+=NS;  LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp=LL.GetPointOfStackPairKey(_DEQUKEY,_DEQUBDYST);
	}
	//-------------------------------------------------------------
	pp.p1=LL.InStrExLineSymBlk(_DEQUCMTC,_DEQUSYMA);
	while(pp.p1>-1) {
		pp.p2=pp.p1+1;
		T=_DEQU_ExKeyS; T+=_DEQU_EC_CmtChar; T+=Exchg.GetSN(); T+=Exchg.GetArrayCnt(); T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp.p1=LL.InStrExLineSymBlk(_DEQUCMTC,_DEQUSYMA);
	}
	//-------------------------------------------------------------
	T=_DEQU_ExKeyS; T+="tm";
	LL=GetUnExchgStrByExkey(LL,ANS,(char*)T);
}
//=====================================================================
void AddExchgWithSymlst(MyStr &LL,ArrayNameStr &Exchg,const char *symlst,const char *excode) {
	MyStr SYM(symlst);
	if((int)SYM<1) return;
	PO2 pp;
	pp=LL.SymBlkIdxInStr(0,-1,(char*)SYM);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		MyStr T(_DEQU_ExKeyS); T+=excode; T+=Exchg.GetSN(); T+=n; T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp=LL.SymBlkIdxInStr(0,-1,(char*)SYM);
	}
}
//----------------------------------------------------------------------
void AddExchgWithLineSymlst(MyStr &LL,ArrayNameStr &Exchg,const char *symlst,const char *excode) {
	MyStr SYM(symlst);
	if((int)SYM<1) return;
//printf("\nAddExchgWithLineSymlst(LL[%s],SYM[%s],excode[%s]",(char*)LL,(char*)SYM,excode);
	PO2 pp;
	pp=LL.LineSymBlkIdxInStr(0,-1,(char*)SYM);
//printf("=>pp.p1=%d pp.p2=%d",pp.p1,pp.p2);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		MyStr T(_DEQU_ExKeyS); T+=excode; T+=Exchg.GetSN(); T+=n; T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp=LL.LineSymBlkIdxInStr(0,-1,(char*)SYM);
	}
}
//=====================================================================
void AddExchgSymBlk(MyStr &LL,ArrayNameStr &Exchg) { 
  AddExchgWithSymlst(LL,Exchg,_DEQUSYMS,_DEQU_EC_SymBlkS);
  AddExchgWithSymlst(LL,Exchg,_DEQUSYMU,_DEQU_EC_SymBlkU);
}
void AddExchgSymBlkS(MyStr &LL,ArrayNameStr &Exchg) { return AddExchgWithSymlst(LL,Exchg,_DEQUSYMS,_DEQU_EC_SymBlkS); }
void AddExchgSymBlkU(MyStr &LL,ArrayNameStr &Exchg) { return AddExchgWithSymlst(LL,Exchg,_DEQUSYMU,_DEQU_EC_SymBlkU); }
void AddExchgSymBlkX(MyStr &LL,ArrayNameStr &Exchg) { return AddExchgWithSymlst(LL,Exchg,_DEQUSYMX,_DEQU_EC_SymBlkX); }
void AddExchgSymBlkA(MyStr &LL,ArrayNameStr &Exchg) {
  AddExchgWithSymlst(LL,Exchg,_DEQUSYMS,_DEQU_EC_SymBlkS);
  AddExchgWithSymlst(LL,Exchg,_DEQUSYMU,_DEQU_EC_SymBlkU);
  AddExchgWithSymlst(LL,Exchg,_DEQUSYMX,_DEQU_EC_SymBlkX);
}
//=====================================================================
void AddExchgLineSymBlk(MyStr &LL,ArrayNameStr &Exchg) {
  AddExchgWithLineSymlst(LL,Exchg,_DEQUSYMS,_DEQU_EC_SymBlkS);
  AddExchgWithLineSymlst(LL,Exchg,_DEQUSYMU,_DEQU_EC_SymBlkU);
}
void AddExchgLineSymBlkS(MyStr &LL,ArrayNameStr &Exchg) { return AddExchgWithLineSymlst(LL,Exchg,_DEQUSYMS,_DEQU_EC_SymBlkS); }
void AddExchgLineSymBlkU(MyStr &LL,ArrayNameStr &Exchg) { return AddExchgWithLineSymlst(LL,Exchg,_DEQUSYMU,_DEQU_EC_SymBlkU); }
void AddExchgLineSymBlkX(MyStr &LL,ArrayNameStr &Exchg) { return AddExchgWithLineSymlst(LL,Exchg,_DEQUSYMX,_DEQU_EC_SymBlkX); }
void AddExchgLineSymBlkA(MyStr &LL,ArrayNameStr &Exchg) { 
  AddExchgWithLineSymlst(LL,Exchg,_DEQUSYMS,_DEQU_EC_SymBlkS); 
  AddExchgWithLineSymlst(LL,Exchg,_DEQUSYMU,_DEQU_EC_SymBlkU);
  AddExchgWithLineSymlst(LL,Exchg,_DEQUSYMX,_DEQU_EC_SymBlkX);
}

void AddExchgLineParaBLK(MyStr &LL,ArrayNameStr &Exchg) {
//printf("\nAddExchgLineParaBLK LL=[%s]",(char*)LL);
	ArrayNameStr ANS;
	AddExchgLineSymBlkA(LL,ANS);

	PO2 pp=LL.GetPointOfStackPairKey(_DEQUPARST,_DEQUPARED);
	while(pp.p1>-1 && pp.p2>-1) {
		MyStr T(_DEQU_ExKeyS); T+=_DEQU_EC_ParaBlk; T+=Exchg.GetSN(); T+=Exchg.GetArrayCnt(); T+=_DEQU_ExKeyE;
		MyStr M(LL.GetRangeByIdx(pp.p1,pp.p2));
		M=GetAllUnExchgStr(M,ANS);
//printf("\nAddExchgLineParaBLK(%s,%s)",(char*)T,(char*)M);
		NameStr NS(T,(char*)M);
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp=LL.GetPointOfStackPairKey(_DEQUPARST,_DEQUPARED);
	}
	LL=GetAllUnExchgStr(LL,ANS);
}
void AddExchgLineParaITM(MyStr &LL,ArrayNameStr &Exchg) {
//printf("\nAddExchgLineParaITM LL=[%s]",(char*)LL);
	ArrayNameStr ANS;
	AddExchgLineSymBlkA(LL,ANS);

	MyStr PSYM(_DEQUSYMPA);
	MyStr T,PA;
	int si=0;
	int p=LL.InStr(si,PSYM);
	MyStr FF;
	while(p>-1) {
		T=_DEQU_ExKeyS; T+=_DEQU_EC_ParaItem; T+=Exchg.GetSN(); T+=Exchg.GetArrayCnt(); T+=_DEQU_ExKeyE;
		if(p>0) PA=LL.GetRangeByIdx(si,p-1);
		else	PA="";
		PA=GetAllUnExchgStr(PA,ANS);
//printf("\nAddExchgLineParaITM T=[%s] PA=[%s]",(char*)T,(char*)PA);
		NameStr NS(T,PA.GetTrim());	Exchg+=NS;
		T=T+","; FF+=T;
//printf("\nAddExchgLineParaITM >>FF=[%s]",(char*)FF);
		si=p+(int)PSYM;
		p=LL.InStr(si,PSYM);
	}
//printf("\nAddExchgLineParaITM si=%d (int)LL=%d FF=[%s]",si,(int)LL,(char*)FF);
	if(si<(int)LL){
		T=_DEQU_ExKeyS; T+=_DEQU_EC_ParaItem; T+=Exchg.GetSN(); T+=Exchg.GetArrayCnt(); T+=_DEQU_ExKeyE;
		PA=LL.GetRangeByIdx(si,-1);
		PA=GetAllUnExchgStr(PA,ANS);
//printf("\nAddExchgLineParaITM T=[%s] PA=[%s]",(char*)T,(char*)PA);
		NameStr NS(T,PA.GetTrim());	Exchg+=NS;
		FF+=T;
	}
//printf("\nAddExchgLineParaITM ## FF=[%s]",(char*)FF);
	LL=GetAllUnExchgStr(FF,ANS);
}

//=====================================================================
const char *GetUnExchgStrByExkey(MyStr &LL,ArrayNameStr &Exchg,const char *Exkey) {
	TmpStr=LL; MyStr K(Exkey);
	if((int)K>0) {
		for(int n=Exchg.GetArrayCnt()-1;n>-1;n--) {
			if(WdIdxInStr(Exchg[n].GetName(),(char*)K)>-1)
				TmpStr=TmpStr.GetRangeWithWdChg(Exchg.GetNameByIdx(n),(char*)Exchg[n]);
		}
	} else {
		for(int n=Exchg.GetArrayCnt()-1;n>-1;n--) {
//printf("\n!!Exchg.GetNameByIdx(%d)=[%s] str=[%s]",n,Exchg.GetNameByIdx(n),(char*)Exchg[n]);
			TmpStr=TmpStr.GetRangeWithWdChg(Exchg.GetNameByIdx(n),(char*)Exchg[n]);
		}
	}
	return (char*)TmpStr;
}
int CheckExkeyInside(MyStr &LL,const char *exkey) {
	MyStr K(exkey); if((int)K<1) return -1; else return LL.InStr(K); 
}
const char *GetLineCmtUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) 	{ MyStr K(_DEQU_ExKeyS); K+=_DEQU_EC_LineCmt; return GetUnExchgStrByExkey(LL,Exchg,(char*)K); }
const char *GetSymChrCmtUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) 	{ MyStr K(_DEQU_ExKeyS); K+=_DEQU_EC_CmtChar; return GetUnExchgStrByExkey(LL,Exchg,(char*)K); }
const char *GetSymBlkSUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) 	{ MyStr K(_DEQU_ExKeyS); K+=_DEQU_EC_SymBlkS; return GetUnExchgStrByExkey(LL,Exchg,(char*)K); }
const char *GetSymBlkUUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) 	{ MyStr K(_DEQU_ExKeyS); K+=_DEQU_EC_SymBlkU; return GetUnExchgStrByExkey(LL,Exchg,(char*)K); }
const char *GetSymBlkXUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) 	{ MyStr K(_DEQU_ExKeyS); K+=_DEQU_EC_SymBlkX; return GetUnExchgStrByExkey(LL,Exchg,(char*)K); }
const char *GetSymBlkUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { 
	MyStr S(GetSymBlkSUnExchgStr(LL,Exchg));
	return GetSymBlkSUnExchgStr(S,Exchg);
}
const char *GetSymBlkAUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { 
	MyStr K(_DEQU_ExKeyS);
	K+=_DEQU_EC_SymBlkChar;
	return GetUnExchgStrByExkey(LL,Exchg,(char*)K);
}

const char *GetAllUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { return GetUnExchgStrByExkey(LL,Exchg,""); }
//=====================================================================
const char *GetRemoveExchgStrByExkey(MyStr &LL,ArrayNameStr &Exchg,const char *Exkey) {
	TmpStr=LL; MyStr K(Exkey);
	if((int)K>0) {
		for(int n=Exchg.GetArrayCnt()-1;n>-1;n--) {
			if(WdIdxInStr(Exchg[n].GetName(),(char*)K)>-1)
				TmpStr=TmpStr.GetRangeWithWdChg(Exchg.GetNameByIdx(n),"");
		}
	} else {
		for(int n=Exchg.GetArrayCnt()-1;n>-1;n--) {
			TmpStr=TmpStr.GetRangeWithWdChg(Exchg.GetNameByIdx(n),"");
		}
	}
	return (char*)TmpStr;
}

const char *GetRemoveAllExchgStr(MyStr &LL,ArrayNameStr &Exchg) { return GetRemoveExchgStrByExkey(LL,Exchg,""); }

const char *GetRemoveLineXCmtWithExSymBlkU(MyStr &LL) {
	TmpStr=LL;
	ArrayNameStr ANS;
	AddExchgLineXCmtWithExSymBlk(TmpStr,ANS);
	MyStr K(_DEQU_ExKeyS);
	K+=_DEQU_EC_XLineCmt;
	TmpStr=GetRemoveExchgStrByExkey(TmpStr,ANS,(char*)K);
	return (char*)TmpStr;
}
//=====================================================================
const char *GetDequErrMessage(DequCode r){
	switch (r) {
		case _well:
			TmpStr="";
			break;
		case _none:
			TmpStr="No DEQU defintion !";
			break;
		case _err_name:
			TmpStr="bad DEQU name format !";
			break;
		case _err_dyncname:
			TmpStr="Break dync(Insided) DEQU name rule (MUST w/i one parent $parameter$)!";
			break;
		case _err_namerule:
			TmpStr="Break DEQU name rule (w/o Keywords or w/o Lcase char request >1 Ucase char + >1 \"";
			TmpStr+=_DEQUNAME_exack_chars;
			TmpStr+="\" char & Not #HEX)!";
			break;
		case _err_name_overlap:
			TmpStr="DEQU name overlap !";
			break;
		case _err_para:
			TmpStr="DEQU parameter < > missing !";
			break;
		case _err_body:
			TmpStr="DEQU body {{ }} missing !";
			break;
		case _err_dbfile:
			TmpStr="DEQU DB file acess fail !";
			break;
		default:
			TmpStr="Unknow DEQU format problem !";
			break;
	}
	return (char*)TmpStr;
}

//##################################################################
//				SDequ	SDequ	SDequ	SDequ	
//##################################################################

void SDequ::Reset(void) { NameArrayStr::Reset(); BDY=""; }
SDequ& SDequ::operator=(SDequ &SD) { NameArrayStr::operator=((NameArrayStr&)SD); BDY=SD.BDY; return *this; }

//##################################################################
//				Dequ	Dequ	Dequ	Dequ	
//##################################################################
Dequ::Dequ() {}
Dequ::Dequ(Dequ &DQ) { Dequ::operator=(DQ); }

Dequ& Dequ::operator=(Dequ &DQ) { 
	SDequ::operator=((SDequ&)DQ); 
	Exchg=DQ.Exchg;
	return *this;
}

void Dequ::Reset(void) {
	SDequ::Reset(); Exchg.Reset(); BDY="";
}

int Dequ::GetParaCnt(void) { return GetArrayCnt(); }
const char *Dequ::GetParaList(void) { return List(','); }
const char *Dequ::GetBody(void) { return (char*)BDY; }

//void Dequ::ExchgAddLineCmt(MyStr &LL) 			{ return AddExchgLineCmtWithExSymBlk(LL,Exchg); }
//void Dequ::ExchgAddSymChrCmt(MyStr &LL) 			{ return AddExchgSymChrCmtWithExSymBlk(LL,Exchg); }
//void Dequ::ExchgAddSymBlk(MyStr &LL) 				{ return AddExchgSymBlk(LL,Exchg); }
void Dequ::ExchgAddLineCmt(MyStr &LL) 				{ return AddExchgLineCmtWithExLineSymBlk(LL,Exchg); }
void Dequ::ExchgAddSymChrCmt(MyStr &LL) 			{ return AddExchgSymChrCmtWithExLineSymBlk(LL,Exchg); }
void Dequ::ExchgAddSymBlk(MyStr &LL) 				{ return AddExchgLineSymBlk(LL,Exchg); }

const char *Dequ::GetUnExchgAll(MyStr &LL) 			{ return GetAllUnExchgStr(LL,Exchg); }

PO2  Dequ::GetPointOfDequContents(MyStr &LL) {
	MyStr FF(LL),LS;
	ArrayNameStr ANS;
	AddExchgLineCmtWithExLineSymBlk(FF,ANS);
	AddExchgLineSymBlk(FF,ANS);

	PO2 pp=FF.GetPointOfStackPairKey(_DEQUKEY,_DEQUBDYED);
	if(pp.p1>0) 	{ LS=FF.GetRangeByIdx(-1,pp.p1-1); 	LS=GetAllUnExchgStr(LS,ANS); pp.p1=(int)LS; }
	if(pp.p2>0) 	{ LS=FF.GetRangeByIdx(-1,pp.p2-1); 	LS=GetAllUnExchgStr(LS,ANS); pp.p2=(int)LS; }
	return pp;
}

int Dequ::IsExchgInStr(MyStr &LL) { return CheckExkeyInside(LL,_DEQU_ExKeyS); }

DequCode Dequ::IsWellName(MyStr &NM) {
//printf("\nIsWellName[%s]",(char*)NM);
	int UC=0,SC=0;
	if(NM!=NM.GetTrimA()) return _err_name;
	if((int)NM>0 && IsExchgInStr(NM)<0) {
		//if((NM.WdCntInStr('$')%2)==1) return _err_namerule;
				
		if(NM.InStr(_DEQUKEY)>-1) return _err_namerule;
		//if(NM.InStr(_DEQUPARST)>-1) return _err_namerule;
		//if(NM.InStr(_DEQUPARED)>-1) return _err_namerule;
		if(NM.InStr(_DEQUBDYST)>-1) return _err_namerule;
		if(NM.InStr(_DEQUBDYED)>-1) return _err_namerule;

		if(NM.InStr("%IFE")>-1) return _err_namerule;
		if(NM.InStr("%IFN")>-1) return _err_namerule;
		if(NM.InStr("EQUATE")>-1) return _err_namerule;
		if(NM.InStr("INSERT")>-1) return _err_namerule;
		
		if(NM.InStr("#include")>-1) return _err_namerule;
		if(NM.InStr("#evaldec")>-1) return _err_namerule;
		if(NM.InStr("#evalhex")>-1) return _err_namerule;
		
		MyStr LNM(NM.GetLowerCase());
		if(LNM.InStr("#ifnull")>-1) return _err_namerule;
		if(LNM.InStr("#if!null")>-1) return _err_namerule;
		if(LNM.InStr("#ifequ")>-1) return _err_namerule;
		if(LNM.InStr("#if!equ")>-1) return _err_namerule;
		if(LNM.InStr("#else")>-1) return _err_namerule;
		if(LNM.InStr("#endif")>-1) return _err_namerule;
		
		if(NM.LowerCaseInside()>0) return _well;
		int XHexC=0;
		for(int n=0;n<(int)NM;n++) {
			if(NM[n]>='A' && NM[n]<='Z') UC++;
			if(NM[n]>='G' && NM[n]<='Z') XHexC++;
			if(WdIdxInStr(_DEQUNAME_exack_chars,NM[n])>-1) { 
				if(n>0 || NM[n]!='#') XHexC++;
				SC++;
			}
		}
		if(UC>0 && SC>0 && XHexC>0) return _well;
		return _err_namerule;
	}
	return _err_name;
}

DequCode Dequ::IsWellDyncContents(MyStr &LL,MyStr &PPA) {
	MyStr PA(PPA.GetTrimA());
	if((int)PA<1) {
//printf("\nIsWellDyncContents[%s]PPA[%]<1 error!\n",(char*)LL,(char*)PPA);
		return _err_dyncname;
	}
	if(PA[(int)PA-1]!=',') PA=PA+',';
	//-----------------------------------------
	Dequ DQ; MyStr FF,T;
	DequCode r=DQ.ContentsToDequ(LL,FF,DQ);
	if(r!=_well) {
//printf("\nIsWellDyncContents[%s]DQ.ContentsToDequ->err(%d)!\n",(char*)LL,(int)r);
		return r;
	}
	MyStr NM(DQ.GetName());
	//if((NM.WdCntInStr('$')%2)==1) return _err_dyncname;
	//-----------------------------------------
	int i=0 , q=0;
	int p=PA.InStr(i,',');
	while(p>-1) {
		q++; T='$';
		if(p>0) T+=PA.GetRangeByIdx(i,p-1);
		else	T+=q;
		T+='$';
		if(NM.InStr(T)>-1) break;
		i=p+1;
		p=PA.InStr(i,',');
	}
	if(p<0) {
//printf("\nIsWellDyncContents[%s]PA[%s]NAME[%s] $para$ error!\n",(char*)LL,(char*)PA,(char*)NM);
		return _err_dyncname;
	}
	PO2 pp=GetPointOfDequContents(FF);
	if(pp.p1>-1 && pp.p2>pp.p1) return IsWellDyncContents(FF,PPA);
	return _well;
}

DequCode Dequ::IsWellContents(MyStr &LL) {
	ArrayNameStr TmpExchg;
	MyStr FF(LL);
	//--------------------------------------------------------------------
	//AddExchgLineCmtWithExSymBlk(FF,TmpExchg);
	//AddExchgSymChrCmtWithExSymBlk(FF,TmpExchg);
	//AddExchgSymBlk(FF,TmpExchg);
	AddExchgLineCmtWithExLineSymBlk(FF,TmpExchg);
//	AddExchgSymChrCmtWithExLineSymBlk(FF,TmpExchg);
	AddExchgLineSymBlk(FF,TmpExchg);

//printf("\nIsWellContents(%s),FF[%d](%s)",(char*)LL,(int)FF,(char*)FF);
	PO2 pp=GetPointOfDequContents(FF);
//printf("\npp.p1=%d,pp.p2=%d",pp.p1,pp.p2);
	if(pp.p1<0) return _none;			//error format : #dequ not found
	if(pp.p2<0) return _err_body;		//error format : }} not found
	//--------------------------------------------------------------------
	FF=FF.GetRangeByIdx(pp.p1,pp.p2);
	FF=FF.GetRangeWithWdChg('\t',' ');
//printf("\nFF(%s)",(char*)FF);
	MyStr T(_DEQUKEY); T+=' ';
	int p=FF.InStr(T);
	if(p<0) return _err_name;			//error format :  #dequ+<space> or #dequ+<tab>
	//--------------------------------------------------------------------
	p+=(int)T;
	FF=FF.GetRangeByIdx(p,(int)FF-strlen(_DEQUBDYED)-1);
	FF=FF.GetLineTrim();
	
	int k=FF.InStr(_DEQUBDYST);
//printf("\n#>FF(%s) k=%d",(char*)FF,k);
	if(k<0) return _err_body;						//error format : '{{' missing
	if(k<1) return _err_name;						//error format : NAME missing
	
	MyStr PA;
	MyStr BDY(FF.GetRangeByIdx(-1,k-1));
//printf("\n#BDY=[%s]",(char*)BDY);
	PO2 px=BDY.GetPointRevOfStackPairKey(_DEQUPARST,_DEQUPARED);
//printf("=>px.p1=%d px.p2=%d",px.p1,px.p2);
	if(px.p1>-1 && px.p2>px.p1) {
		if(px.p1>0) T=BDY.GetRangeByIdx(-1,px.p1-1);
		else		T="";
		PA=_DEQUPARST;
		PA=BDY.GetRangeByIdx(px.p1+(int)PA,px.p2-1);
	} else T=BDY;
	T=T.GetTrim();
//printf("\n#T=[%s],PA=[%s]",(char*)T,(char*)PA);
/*
	int q1=FF.InStr(-1,k-1,_DEQUPARST);
	int q2=FF.InStr(-1,k-1,_DEQUPARED);
//printf("\n#>FF(%s) k=%d , q1=%d q2=%d ",(char*)FF,k,q1,q2);

	//--------------------------------------------------------------------
	if(q1>-1 && q2<0) 	return _err_para;			//error format : parameter > missing before {{
	if(q1<0  && q2>-1) 	return _err_para;			//error format : parameter < missing before {{
	if(q1>-1) { 
		T=FF.GetRangeByIdx(-1,q1-1);
		PA=FF.GetRangeByIdx(q1+1,q2-1);
		PA=PA.GetLineTrimA();
	} else T=FF.GetRangeByIdx(-1,k-1); 
	T=T.GetTrim();
*/
	//--------------------------------------------------------------------
	DequCode r=IsWellName(T);
//printf("\n#>T(%s) r=%d PA=(%s)",(char*)T,(int)r,(char*)PA);

	if(r!=_well) return r;							//error format : NAME MUST w/i LowCase or exack chars
	//--------------------------------------------------------------------
	if(IsExchgInStr(PA)>-1) return _err_para;			//error format : Parameters w/i Exchg contents
	//--------------------------------------------------------------------
	k+=strlen(_DEQUBDYST);
	BDY=FF.GetRangeByIdx(k,-1);
	BDY=BDY.GetLineTrim();
	//--------------------------------------------------------------------	
	pp=GetPointOfDequContents(BDY);
	//--------------------------------------------------------------------	
	BDY=GetAllUnExchgStr(BDY,TmpExchg);
//printf("\n#>BDY(%s) k=%d pp.p1=%d pp.p2=%d ",(char*)BDY,k,pp.p1,pp.p2);
	if(pp.p1<0 && pp.p2<0) return _well;
	if(pp.p1>-1 && pp.p2>pp.p1) {
		if((int)PA<1) return _err_dyncname;
		PA+=','; return IsWellDyncContents(BDY,PA);
	}
	return _err_body;								//error format : bad #dequ inside
}

DequCode Dequ::ContentsToDequ(MyStr &InputStr,MyStr &OutputStr,Dequ &ODQ) {
//printf("\n#InputStr=[%s]",(char*)InputStr);
	ODQ.Reset();	MyStr FF(InputStr);	
	//--------------------------------------------------------------------
	//AddExchgLineCmtWithExSymBlk(FF,ODQ.Exchg);
	//AddExchgSymChrCmtWithExSymBlk(FF,ODQ.Exchg);
	//AddExchgSymBlk(FF,ODQ.Exchg);
	AddExchgLineCmtWithExLineSymBlk(FF,ODQ.Exchg);
//	AddExchgSymChrCmtWithExLineSymBlk(FF,ODQ.Exchg);
	AddExchgLineSymBlk(FF,ODQ.Exchg);
//printf("\n#FF=[%s]",(char*)FF);
	PO2 pp=GetPointOfDequContents(FF);
//printf("\n#pp.p1=%d pp.p2=%d",pp.p1,pp.p2);
	if(pp.p1<0) return _none;		//error format : no #dequ found
	if(pp.p2<0) return _err_body;	//error format : no }} found
	//--------------------------------------------------------------------
	if(pp.p1>0)	OutputStr=FF.GetRangeByIdx(-1,pp.p1-1);
	else 		OutputStr="";

	if(pp.p2<((int)FF-1)) OutputStr+=FF.GetRangeByIdx(pp.p2+1,-1);
//printf("\n#OutputStr=[%s]",(char*)OutputStr);
	OutputStr=GetAllUnExchgStr(OutputStr,ODQ.Exchg);
	OutputStr=OutputStr.GetRangeWithCmpressSpLine();
//printf("\n#OutputStr=[%s]",(char*)OutputStr);
	//--------------------------------------------------------------------
	FF=FF.GetRangeByIdx(pp.p1,pp.p2);
	MyStr S(FF.GetRangeWithWdChg('\t',' '));
	MyStr T(_DEQUKEY); T+=' ';
	int p=S.InStr(T);
	if(p<0) return _err_name;			//error format :  #dequ+<space> or #dequ+<tab>
	//--------------------------------------------------------------------
	p+=(int)T;
	FF=FF.GetRangeByIdx(p,(int)FF-strlen(_DEQUBDYED)-1);
//	FF=FF.GetLineTrim();

	int k=FF.InStr(_DEQUBDYST);
	if(k<0) return _err_body;						//error format : '{{' missing
	if(k<1) return _err_name;						//error format : name missing

	MyStr PA;
	T=FF.GetRangeByIdx(-1,k-1);
//printf("\n#BDY=[%s]",(char*)BDY);
	PO2 px=T.GetPointRevOfStackPairKey(_DEQUPARST,_DEQUPARED);
//printf("=>px.p1=%d px.p2=%d",px.p1,px.p2);
	if(px.p1>-1 && px.p2>px.p1) {
		if(px.p1>0) S=T.GetRangeByIdx(-1,px.p1-1);
		else		S="";
		PA=_DEQUPARST;
		PA=T.GetRangeByIdx(px.p1+(int)PA,px.p2-1);
	} else S=T;
	S=S.GetTrim();

/*
	MyStr PA;
	int q1=FF.InStr(-1,k-1,_DEQUPARST);
	int q2=FF.InStr(-1,k-1,_DEQUPARED);
	//--------------------------------------------------------------------
	if(q1>-1 && q2<0) 	return _err_para;			//error format : parameter > missing before {{
	if(q1<0  && q2>-1) 	return _err_para;			//error format : parameter < missing before {{
	if(q1>-1) { 
		S=FF.GetRangeByIdx(-1,q1-1); S=S.GetTrim();
		PA=FF.GetRangeByIdx(q1+1,q2-1);
	} else {
		S=FF.GetRangeByIdx(-1,k-1); S=S.GetTrim();
	}
*/
	//--------------------------------------------------------------------
	DequCode r=IsWellName(S);
	if(r!=_well) return r;	//error format : NAME MUST w/i LowCase or exack chars
	ODQ.SetName(S);
	//--------------------------------------------------------------------
	if(IsExchgInStr(PA)>-1) return _err_para;			//error format : Parameters w/i Exchg contents
	//--------------------------------------------------------------------
	k+=strlen(_DEQUBDYST);
//printf("\n#S=[%s]",(char*)S);
	ODQ.BDY=FF.GetRangeByIdx(k,-1);
	ODQ.BDY=GetAllUnExchgStr(ODQ.BDY,ODQ.Exchg);
	//ODQ.BDY=ODQ.BDY.GetTrim();
	//--------------------------------------------------------------------	
//printf("\n#PA=[%s]",(char*)PA);
//printf("->#BDY=[%s]",(char*)ODQ.BDY);
	if((int)PA>0) {
		PA+=","; k=0; 
		int q1=0;
		p=PA.InStr(k,",");
		while(p>-1) {
			q1++;
			if(p>0) {
				S=PA.GetRangeByIdx(k,p-1);
				S=S.GetTrim();
				if((int)S<1) S=q1;
			} else	S=q1;
			ODQ+=S;
			k=p+1;
			p=PA.InStr(k,",");
		}
	}
	//--------------------------------------------------------------------	
	pp=GetPointOfDequContents(ODQ.BDY);

	//ODQ.BDY=GetAllUnExchgStr(ODQ.BDY,ODQ.Exchg);
	//ODQ.BDY=ODQ.BDY.GetTrim();

	if(pp.p1<0 && pp.p2<0) return _well;
	if(pp.p1>-1 && pp.p2>pp.p1) return IsWellContents(ODQ.BDY);
	return _err_body;								//error format : bad #dequ inside
}

DequCode Dequ::Setup(MyStr &LL) {
	Dequ ODQ; MyStr OutS;
	DequCode rcode=ContentsToDequ(LL,OutS,ODQ);
	if(rcode==_well) { operator=(ODQ);  LL=OutS; }
	return rcode;
}

const char *Dequ::GetErrMessage(DequCode r){ return GetDequErrMessage(r); }

const char *Dequ::RemoveLineCmt(MyStr &LL) {
	MyStr LX(LL);
	//AddExchgLineCmtWithExSymBlk(LX,Exchg);
	AddExchgLineCmtWithExLineSymBlk(LX,Exchg);
	for(int n=0;n<Exchg.GetArrayCnt();n++) {
		MyStr T(Exchg[n].GetName());
		if(T.InStr(_DEQU_EC_LineCmt)>-1) LX=LX.GetRangeWithWdDel((char*)T);
	}
	TmpStr=LX;	return (char*)TmpStr;
}
const char *Dequ::RemoveSymChrCmt(MyStr &LL) {
	MyStr LX(LL);
	//AddExchgSymChrCmtWithExSymBlk(LX,Exchg);
	AddExchgSymChrCmtWithExLineSymBlk(LX,Exchg);
	for(int n=0;n<Exchg.GetArrayCnt();n++) {
		MyStr T(Exchg[n].GetName());
		if(T.InStr(_DEQU_EC_CmtChar)>-1) LX=LX.GetRangeWithWdDel((char*)T);
	}
	TmpStr=LX;	return (char*)TmpStr;
}
const char *Dequ::RemoveSymBlkS(MyStr &LL) {
	MyStr LX(LL);
	//AddExchgSymBlkS(LX,Exchg);
	AddExchgLineSymBlkS(LX,Exchg);
	for(int n=0;n<Exchg.GetArrayCnt();n++) {
		MyStr T(Exchg[n].GetName());
		if(T.InStr(_DEQU_EC_SymBlkS)>-1) LX=LX.GetRangeWithWdDel((char*)T);
	}
	TmpStr=LX;	return (char*)TmpStr;
}
const char *Dequ::RemoveSymBlkU(MyStr &LL) {
	MyStr LX(LL);
	//AddExchgSymBlkU(LX,Exchg);
	AddExchgLineSymBlkU(LX,Exchg);
	for(int n=0;n<Exchg.GetArrayCnt();n++) {
		MyStr T(Exchg[n].GetName());
		if(T.InStr(_DEQU_EC_SymBlkU)>-1) LX=LX.GetRangeWithWdDel((char*)T);
	}
	TmpStr=LX;	return (char*)TmpStr;
}
const char *Dequ::RemoveSymBlk(MyStr &LL) {
	MyStr T(RemoveSymBlkS(LL));
	TmpStr=RemoveSymBlkU(LL);
	return (char*)TmpStr;
}
//####################################################################
//#		DEQU_DB
//####################################################################

const char *DEQU_DB::GetErrMessage(DequCode r){ return GetDequErrMessage(r); }

DEQU_DB::DEQU_DB(const char *dbfname) { 
	if(dbfname==NULL) 	DBfile="tmptmp.dequ";
	else				DBfile=dbfname;
	CNT=0; DBP=NULL; 
}
DEQU_DB::~DEQU_DB() { ReleaseDBP(); }

//===================================================
int DEQU_DB::GetCNT(void) {return CNT; }
const char* DEQU_DB::GetDBfile(void) {return (char*)DBfile; }
void DEQU_DB::SetDBfile(const char *dbfname) { DBfile=dbfname; }
//===================================================
void DEQU_DB::ReleaseDBP(void) {
	while(DBP!=NULL) {
		DQLINK *tp=DBP;
		DBP=DBP->nxt;
		delete tp;
		CNT--;
	}
}
//===================================================
DequCode DEQU_DB::Add(Dequ& DQ,const int Cat) {
//printf("\nDEQU_DB::Add('%s') BODY=[%s]",DQ.GetName(),DQ.GetBody());
//printf("PARN=%d Para='%s')\n",DQ.GetParaCnt(),DQ.GetParaList());
	MyStr T(DQ.GetName());
	//if(T=="") { printf("\n!!! Warning : request DEQU_DB.Add(NULL) !!!\n"); return 0; }
	if(T=="") return _err_name;
	
//printf("\nDEQU_Inside(%s)",(char*)T);
	T=DEQU_Inside(T);
//printf("=(%s)",(char*)T);
	//if(T==DQ.GetName()) { printf("\n!!! Error : reject one more DEQU_DB.Add(%s) !!!\n",(char*)T); return -1; }
	if(T==DQ.GetName()) return _err_name_overlap;
	
	CNT++;
	DQLINK *dp = new DQLINK;
	dp->CAT=Cat;
	dp->SN=CNT;
	dp->NAME=DQ.GetName();
	dp->PARN=DQ.GetParaCnt();
	dp->nxt=NULL;
	if(DBP==NULL) DBP=dp;
	else {
		//******** FIFO *********		
		//DQLINK *tp=DBP;
		//while(tp->nxt!=NULL) tp=tp->nxt;
		//tp->nxt=dp;
		//******** LIFO *********
		dp->nxt=DBP;
		DBP=dp;
	}
	
	if(CNT==1) 	T="w";
    else 		T="a";
    
    FILE *fp=fopen((char*)DBfile,(char*)T);
	if(fp==NULL) return _err_dbfile;

	//---------------------------------------------
	//	File write new ODequ macro
	//---------------------------------------------
	int mxlen=DEQU_DB_MaxLineLen;
	MyStr B(DQ.GetBody());
//printf("\nName(%s),body[%s]",DQ.GetName(),(char*)B);
	//================================================
	int n;	
	for(n=0;n<DBP->PARN;n++) {
		T=_DEQUBDYVPAST;
		T+=DQ[n];
		T+=_DEQUBDYVPAED;
		MyStr N(_DEQUBDYVPAST);
		N+=(n+1);
		N+=_DEQUBDYVPAED;
		B=B.GetRangeWithWdChg((char*)T,(char*)N);
	}
	//================================================
	B=B.GetRangeWithWdChg("\n","\\n");
//printf("=>body[%s]",(char*)B);
	int l=(int)B;
	n=0;
	while(l>mxlen) { n++; l-=mxlen;}
	if(l>0) n++;
	fprintf(fp,"_{%s}_(%d)_[%d]_<%s>_@%s@_$%d$_~%d~_\n",(char*)DBP->NAME,DBP->PARN,n,DQ.GetParaList(),_dequFmtVer_,DBP->SN,DBP->CAT);
	for(l=1;l<n;l++) fprintf(fp,"%s\n",B.GetRangeByIdx((l-1)*mxlen,(l-1)*mxlen+mxlen-1));
	fprintf(fp,"%s\n",B.GetRangeByIdx((n-1)*mxlen,-1));
	//---------------------------------------------
	fclose(fp);
	//return CNT;
	return _well;
}
//===================================================
int DEQU_DB::GetDEQUSeqN(const char *dequname) {
	MyStr DQ(dequname);
	if(CNT>0 || (int)DQ>0) {
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			if(dp->NAME==DQ) return dp->SN;
			dp=dp->nxt;
		}
	}
	return -1;
}
//===================================================
int DEQU_DB::SearchDEQUparN(const char *dequname) {
	MyStr DQ(dequname);
	if(CNT>0 || (int)DQ>0) {
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			if(dp->NAME==DQ) return dp->PARN;
			dp=dp->nxt;
		}
	}
	return -1;
}
//===================================================
const char*  DEQU_DB::GetDEQUnameByDBIdx(const int si) {
	TMP="";
	if(CNT>0 && si>-1 && si<CNT) {
		int n=-1;
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			n++;
			if(n==si) { TMP=dp->NAME; break; }
			dp=dp->nxt;
		}
	}
	return (char*)TMP;
}
//===================================================
const char* DEQU_DB::DEQU_Inside(const char *line) {MyStr LL(line); return DEQU_Inside(LL); }
const char* DEQU_DB::DEQU_Inside(MyStr &LL) {
	
//printf("\n#>DEQU_Inside LL[%s]",(char*)LL);

	TMP="";
	MyStr S(LL);
	ArrayNameStr ANS;
	//AddExchgLineMessage(S,ANS);
	AddExchgLineCmtWithExLineSymBlk(S,ANS);
//	AddExchgSymChrCmtWithExSymBlk(S,ANS);
	AddExchgSymBlkS(S,ANS);
	S=GetRemoveAllExchgStr(S,ANS);

	MyStr T(_DEQUBDYED);
	int lbdyed=(int)T;
	PO2 pp=S.GetPointOfStackPairKey(_DEQUKEY,_DEQUBDYED);
	while(pp.p1>-1 && pp.p2>-1) {
		if(pp.p1>0) T=S.GetRangeByIdx(-1,pp.p1-1);
		else		T="";
		S=T+S.GetRangeByIdx(pp.p2+lbdyed,-1);
		pp=S.GetPointOfStackPairKey(_DEQUKEY,_DEQUBDYED);
	}
	
//printf("\n##>DEQU_Inside S[%s]",(char*)S);

	int n=-1;
	int l=-1;
	
	if(CNT>0 || (int)S>0) {
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			int p=S.InStr((char*)dp->NAME);
			int x=(int)dp->NAME;
			if(p>-1) {
				if(n<0 || p<n || (p==n && x>l) ) { n=p; TMP=dp->NAME; l=x; }
			}
			dp=dp->nxt;
		}
	}
//printf("=>TMP[%s]",(char*)TMP);
	return (char*)TMP;
}
//===================================================
const char *DEQU_DB::GetDEQUdefParaInDB(const char *dequname) {
	TMP="";
	int sq=GetDEQUSeqN(dequname);
	if(sq<1) return (char*)TMP;
	FILE *fp;
	char line[DEQU_DB_MaxLineLen+5];
	if((fp=fopen((char*)DBfile,"r"))==NULL) {
		printf("\n!!! Error : Open '%s' for read fail !!!\n",(char*)DBfile);
		return (char*)TMP;
	}
	MyStr DQ("_{");
	DQ+=dequname;
	DQ+="}_";
	while(1) {
		if(fgets(line,DEQU_DB_MaxLineLen+2,fp)==NULL) break;
		MyStr LL(line);
		int s=atoi(LL.GetRangeBtwKey("_$","$_"));
		if(LL.InStr((char*)DQ)>-1 && s==sq) { TMP=LL.GetRangeBtwKey("_<",">_"); break; }
	}
	fclose(fp);
	return (char*)TMP;
}
//===================================================
const char *DEQU_DB::GetDEQUbodyInDB(const char *dequname) {
	TMP="";
	int sq=GetDEQUSeqN(dequname);
//printf("\ndequname[%s],Seq[%d]",dequname,sq);
	if(sq<1) return (char*)TMP;
	FILE *fp;
	char line[DEQU_DB_MaxLineLen+5];
	if((fp=fopen((char*)DBfile,"r"))==NULL) {
		printf("\n!!! Error : Open '%s' for read fail !!!\n",(char*)DBfile);
		return (char*)TMP;
	}
	MyStr DQ("_{");
	DQ+=dequname;
	DQ+="}_";
	while(1) {
		if(fgets(line,DEQU_DB_MaxLineLen+2,fp)==NULL) { fclose(fp); break; }
		MyStr LL(line);
		int s=atoi(LL.GetRangeBtwKey("_$","$_"));
//printf("\nLL[%s],s[%d]",(char*)LL,s);
		if(LL.InStr((char*)DQ)>-1 && s==sq) {
//printf("\nline='%s'",line);
			int n=atoi(LL.GetRangeBtwKey("_[","]_"));
//printf(" => LL='%s' , n=%d",(char*)LL,n);
			LL="";
			for(int x=0;x<n;x++) {
				if(fgets(line,DEQU_DB_MaxLineLen+2,fp)==NULL) break;
//printf("\n>> line='%s'",line);
				LL+=line;
			}
			fclose(fp);
//printf("\n##>LL='%s'",(char*)LL);
			LL=LL.GetRangeWithWdDel('\n');
			TMP=LL.GetRangeWithWdChg("\\n","\n");
			break;
		}
	}
	return (char*)TMP;
}
//===================================================
const char *DEQU_DB::DEQU_xfer(const char *line) {
	MyStr BDY,LS,LE,PX;
	MyStr LL(line);
	
//printf("\n#>DEQU_xfer LL=[%s]<<line=[%s]",(char*)LL,line);

	ArrayNameStr ANS;
	AddExchgLineCmtWithExLineSymBlk(LL,ANS);
	AddExchgLineSymBlkS(LL,ANS);
	
//printf("\n#>DEQU_xfer Exchged LL=[%s]",(char*)LL);
	MyStr NM(DEQU_Inside((char*)LL));
//printf("\n#>DEQU_xfer NM=[%s]",(char*)NM);
	
	if(NM!="") {
		ArrayNameStr PANS;
		int c=SearchDEQUparN((char*)NM);
//printf("\n#>DEQU_xfer NM=[%s]",(char*)NM);
		BDY=PickupLineDequBody(LL,NM,LS,LE,PANS);
		BDY=BDY.GetTrim();
//printf("\n#>LS=[%s]",(char*)LS);
//printf("\n#>BDY=[%s]",(char*)BDY);
//printf("\n#>LE=[%s]",(char*)LE);
		AddExchgLineCmtWithExLineSymBlk(BDY,ANS);
		AddExchgLineSymBlkS(BDY,ANS);
//printf("\n##>BDY=[%s]",(char*)BDY);
		for(int x=0;x<PANS.GetArrayCnt();x++) {
			BDY=BDY.GetRangeWithWdChg(PANS.GetNameByIdx(x),PANS.GetStrByIdx(x));
//printf("\n##>[%d]BDY=[%s]",x,(char*)BDY);
		}
//printf("\n###>LS 1 =[%s]",(char*)LS);
		LS+=BDY;
//printf("\n###>LS 2 =[%s]",(char*)LS);
		LS+=LE;
		LS=GetAllUnExchgStr(LS,ANS);
		LS=LS.GetDos2Unix();
//printf("\n###>LS 3 =[%s]",(char*)LS);
		return DEQU_xfer((const char*)LS);
	}

	LL=GetSymBlkXUnExchgStr(LL,ANS);
//printf("\n*>LL=[%s]",(char*)LL);

	NM=_DEQUSYMX;
	int n=(int)NM;
	if(n>0) {
		LS="";
		int k=0;
		PO2 PS=LL.SymBlkIdxInStr(k,-1,_DEQUSYMS);
		while(PS.p1>-1) {
			if(PS.p1>k) { LE=LL.GetRangeByIdx(k,PS.p1-1); LS+=LE.GetRangeWithDelBlkSymChr(-1,-1,_DEQUSYMX); }
			LE=LL.GetRangeByIdx(PS.p1,PS.p2);
			LS+=LE.GetRangeWithDelBlkSymChr(_DEQUSYMX);
			k=PS.p2+1;
			PS=LL.SymBlkIdxInStr(k,-1,_DEQUSYMS);
		}
		if(k<(int)LL) {
			LE=LL.GetRangeByIdx(k,-1);
//printf("\n***>LE=[%s]",(char*)LE);
			LS+=LE.GetRangeWithDelBlkSymChr(_DEQUSYMX);
//printf("\n***>LS=[%s]",(char*)LS);
		}
		PS=LS.SymBlkIdxInStr(-1,-1,_DEQUSYMX);
//printf("\n****>PS.p1=%d PS.p2=%d",PS.p1,PS.p2);
		
		LS=GetAllUnExchgStr(LS,ANS);
		
		if(PS.p1>-1) 	return DEQU_xfer((char*)LS);
	} else LS=GetAllUnExchgStr(LL,ANS);

//printf("\n*###>LS=[%s]",(char*)LS);

	//TMP=LS.GetRangeWithDelSpLine();
	TMP=LS;
	
	return (char*)TMP;
}
//===================================================
const char *DEQU_DB::PickupLineDequBody(MyStr &LL,MyStr &NM,MyStr &LS,MyStr &LE,ArrayNameStr &PANS) {
	LS=LL; LE="";	
	MyStr FF(_DEQUPARST);
	MyStr T(_DEQUPARED);
	int lps=(int)FF;
	int lpe=(int)T;
	
//printf("\nPickupLineDequBody LL=[%s],NM[%s]",(char*)LL,(char*)NM);		
	//--------------------------------
	FF=LL;	T=NM.GetTrim();
	ArrayNameStr ANS;
	AddExchgLineCmtWithExLineSymBlk(FF,ANS);
	AddExchgLineSymBlkA(FF,ANS);

//printf("\nPickupLineDequBody FF=[%s],T=[%s]",(char*)FF,(char*)T);		

	int p=FF.InStr(T);
	if(p<0) {TMP=""; return (char*)TMP;}
	
	MyStr BDY(GetDEQUbodyInDB((char*)T));

	if(p>0)	{LS=FF.GetRangeByIdx(-1,p-1);	LS=GetAllUnExchgStr(LS,ANS);}
	else	LS="";	

//printf("\nPickupLineDequBody p=%d LS=[%s]",p,(char*)LS);

	PO2 pp=FF.GetPointOfStackPairKey(p,-1,_DEQUPARST,_DEQUPARED);

//printf("\nPickupLineDequBody pp.p1=%d pp.p2=%d",pp.p1,pp.p2);

	if(pp.p1>-1 && pp.p2>-1) {
		LE=FF.GetRangeByIdx(p,pp.p1-1);
		LE=LE.GetTrim();
		if(T!=LE) pp.p1=-1;
	}
	
	if(pp.p1<0 || pp.p2<0) {
		LE=FF.GetRangeByIdx(p+(int)T,-1);	LE=GetAllUnExchgStr(LE,ANS);
//printf("\nPickupLineDequBody LE=[%s]",(char*)LE);
		TMP=BDY; return (char*)TMP;
	}
	
	LE=FF.GetRangeByIdx(pp.p2+lpe,-1);	LE=GetAllUnExchgStr(LE,ANS);
	
//printf("\nPickupLineDequBody LE=[%s]",(char*)LE);
	
	FF=FF.GetRangeByIdx(pp.p1+lps,pp.p2-1); 
	T=GetAllUnExchgStr(FF,ANS);	T=T.GetTrim();
//printf("\nPickupLineDequBody T=[%s]",(char*)T);
	
	ArrayNameStr XANS;
	FF=_DEQU_ExKeyS; FF+=_DEQU_EC_ParaItem;
	if((int)T>0) {
		AddExchgLineParaBLK(T,XANS);
		AddExchgLineParaITM(T,XANS);
		p=0;
		for(int n=0;n<XANS.GetArrayCnt();n++) {
			T=XANS.GetNameByIdx(n);
			if(T.InStr(FF)>-1) {
//printf("\nPickupLineDequBody XANS[%d] Name=[%s]",n,(char*)T);
				p++; T=XANS.GetStrByIdx(n); 
//printf(" Str=[%s]",(char*)T);
				T=GetAllUnExchgStr(T,XANS);
				T=GetAllUnExchgStr(T,ANS);
				MyStr M('$'); M+=p; M+='$';
//printf("\nPickupLineDequBody PANS < M=[%s] T=[%s]",(char*)M,(char*)T);
				NameStr NS(M,T.GetTrim());
				PANS+=NS;
			}
		}
	}
	
	TMP=BDY;  return (char*)TMP;
}
//===================================================
const char *DEQU_DB::PickupLineDequPara(MyStr &LL,MyStr &DEQNM,MyStr &LS,MyStr &LE) {
	LS="";
	LE="";
	MyStr T;
	int n=LL.InStrExSymBlk((char*)DEQNM,_DEQUSYMS);		//Search MUST include ?**DEQNM**?,'**DEQNM**' SymBLKs

//printf("\n**>PickupLineDequPara DEQNM=[%s] n=%d LL=[%s]",(char*)DEQNM,n,(char*)LL);	

	if(n>-1) { 
		if(n>0) LS=LL.GetRangeByIdx(-1,n-1);
		int sp=n+(int)DEQNM;
	
		MyStr NM(_DEQUPARED);
		int lpaed=(int)NM;
		NM=_DEQUPARST;
		int lpast=(int)NM;
		
		//int a=LL.InStrExSymBlk(sp,_DEQUPARST,(char*)SYM);
		int a=LL.InStrExSymBlk(sp,_DEQUPARST,_DEQUSYMA);		//<Parameter> search excluding all SymBLKs
		
		NM=LL.GetRangeByIdx(sp,a-1);
		NM=NM.GetTrim();

		int b=sp;
		
//printf("\n**>PickupLineDequPara NM=[%s] sp=%d a=%d LS=[%s]",(char*)NM,sp,a,(char*)LS);	
		if(a>-1 && (int)NM==0) { 
			sp=a+lpast;	
			//int b=LL.InStrExSymBlk(sp,_DEQUPARED,(char*)SYM);
			//int x=LL.InStrExSymBlk(sp,_DEQUPARST,(char*)SYM);
			int b=LL.InStrExSymBlk(sp,_DEQUPARED,_DEQUSYMA);
			int x=LL.InStrExSymBlk(sp,_DEQUPARST,_DEQUSYMA);
//printf("\n**>PickupLineDequPara sp=%d b=%d x=%d",sp,b,x);	
			while(x>-1 && x<b) {
				sp=b+lpaed;
				//b=LL.InStrExSymBlk(sp,_DEQUPARED,(char*)SYM);
				//x=LL.InStrExSymBlk(sp,_DEQUPARST,(char*)SYM);
				b=LL.InStrExSymBlk(sp,_DEQUPARED,_DEQUSYMA);
				x=LL.InStrExSymBlk(sp,_DEQUPARST,_DEQUSYMA);
//printf("\n**>PickupLineDequPara sp=%d b=%d x=%d",sp,b,x);	
			}
			if(b>0) {
				T=LL.GetRangeByIdx(a+lpast,b-1);
				sp=b+lpaed;
			}
		}
		LE=LL.GetRangeByIdx(sp,-1);
//printf("\n**>LE=[%s]",(char*)LE);
	}
//printf("\n**>LS=[%s]",(char*)LS);	
//printf("\n**>T=[%s]",(char*)T);	
//printf("\n**>LE=[%s]",(char*)LE);	

	TMP=T;
    return (char*)TMP;
}
//===================================================
int DEQU_DB::AnalyzeDequParameter(MyStr &LL,MyStr &NM,ArrayNameStr &PANS) {
//printf("\nAnalyzeDequParameter(LL[%s],NM[%s])",(char*)LL,(char*)NM);
	MyStr FF(LL);
	ArrayNameStr ANS;
	AddExchgLineCmtWithExLineSymBlk(FF,ANS);
	AddExchgLineSymBlkA(FF,ANS);

	int p=FF.InStr(NM);
//printf("\nAnalyzeDequParameter FF[%s].InStr[%s]=%d",(char*)FF,(char*)NM,p);
	if(p<0) return -1; 
	PO2 pp=FF.GetPointOfStackPairKey(p,-1,_DEQUPARST,_DEQUPARED);
//printf("\nAnalyzeDequParameter pp.p1=%d",pp.p1);
	if(pp.p1<0 || pp.p2<0) return 0;
	MyStr T(FF.GetRangeByIdx(p,pp.p1-1)); T.GetTrim();
	if(T!=NM.GetTrim()) return 0;
//printf("\nAnalyzeDequParameter[1]T[%s]",(char*)T);
	T=FF.GetRangeByIdx(pp.p1+1,pp.p2-1);
	T=GetAllUnExchgStr(T,ANS);	
	T=T.GetTrim();
//printf("\nAnalyzeDequParameter[2]T[%s]",(char*)T);
	if((int)T<1) return 0;
	AddExchgLineParaBLK(T,PANS);
//printf("\nAnalyzeDequParameter[3]T[%s]",(char*)T);
	AddExchgLineParaITM(T,PANS);
//printf("\nAnalyzeDequParameter[4]T[%s]",(char*)T);

	int n=T.WdCntInStr(',')+1;
	return n;
}

//===================================================
const char *DEQU_DB::ParaAnalyze(MyStr &PA,const char *sym) { MyStr SYM(sym); return ParaAnalyze(PA,SYM); }
const char *DEQU_DB::ParaAnalyze(MyStr &PA,MyStr &SYM) {
	MyStr PX(_DEQUPARED);
	int lpaed=(int)PX;
	PX=_DEQUPARST;
	int lpast=(int)PX;
//printf("\n*>ParaAnalyze: PA=[%s],SYM=[%s]",(char*)PA,(char*)SYM);
	MyStr T;
	MyStr PAC(PA.GetRangeWithSpDelExSymBlk((char*)SYM));
	if(PAC!="") {
		int s=0;
		int p=PA.InStrExSymBlk(s,",",(char*)SYM);
		int x=PA.InStrExSymBlk(s,_DEQUPARST,(char*)SYM);
//printf("\n*> 1 s=%d p=%d x=%d",s,p,x);
		while(x>-1 && x<p) {
			s=x+lpast;
			int y=PA.InStrExSymBlk(s,-1,_DEQUPARED,(char*)SYM);
			int k=PA.InStrExSymBlk(s,y-1,_DEQUPARST,(char*)SYM);
//printf("\n*> 2 s=%d y=%d k=%d",s,y,k);
			while(y>-1) {
//printf("\n*> 3 s=%d y=%d k=%d",s,y,k);
				s=y+lpaed;
				if(k>-1) {
					y=PA.InStrExSymBlk(s,-1,_DEQUPARED,(char*)SYM);
					k=PA.InStrExSymBlk(s,y-1,_DEQUPARST,(char*)SYM);
				} else y=-1;
			}
			p=PA.InStrExSymBlk(s,",",(char*)SYM);
			x=PA.InStrExSymBlk(s,_DEQUPARST,(char*)SYM);
//printf("\n*> 4 s=%d p=%d",s,p);
		}
		if(p>0) T=PA.GetRangeByIdx(-1,p-1);  
//printf("\n*>T=[%s]",(char*)T);
		PA=PA.GetRangeByIdx(p+1,-1);
    }
    TMP=T;
    return (char*)TMP;
}

int DEQU_DB::DB_foutput(const char *filename,const int Cat) {
	
	MyStr FIL(filename);

	FILE *fp=fopen((char*)FIL,"w");
	if(fp==NULL) {
		printf("\n!!! Error : Open '%s' for write fail !!!\n",(char*)FIL);
		return -1;
	}
	
	if(DBP==NULL) { fclose(fp);  return 0; }
	
    MyStr T,PA,PX,BDY;
	int k , l=0;
	DQLINK *dp;
	DSLINK *ppa,*ppx;
	bool bflg;	
	//================ list ====================
	for(int n=0;n<CNT;n++) {
		T="";
		dp=DBP;
		bflg = false;
		while(dp!=NULL) {
			if(Cat>-1 && dp->CAT!=Cat) { dp=dp->nxt; continue; }
			if(dp->SN==(n+1)) {
					T+=dp->NAME+_DEQUPARST;
					if(dp->PARN>0) T+=GetDEQUdefParaInDB((char*)dp->NAME);
					T+=_DEQUPARED;
					bflg=true; break;
			}
			dp=dp->nxt;
		}
		if(bflg) {
			l++;
			fprintf(fp,"// %s\n",(char*)T);
		}
	}

	//================= Declare & body =====================
	fprintf(fp,"\n");
	
	for(int n=0;n<CNT;n++) {		
		T=_DEQUKEY;
		T+=" ";
		dp=DBP;
		bflg = false;
		while(dp!=NULL) {
			if(Cat>-1 && dp->CAT!=Cat) { dp=dp->nxt; continue; }
//printf("\n%s(%d) n=%d",(char*)dp->NAME,dp->SN,n);
			if(dp->SN==(n+1)) {
//printf("\n[%s]<",(char*)dp->NAME);
				ppa=NULL;
				T+=dp->NAME+_DEQUPARST;
				if(dp->PARN>0) {
					PA=GetDEQUdefParaInDB((char*)dp->NAME);
					T+=PA;
					//-----------------------------------
//printf("%s>",(char*)PA);
					PA+=",";
					k=0;
					int p=PA.InStr(k,',');
					while(p>-1) { 
						DSLINK *pd=new DSLINK;
						if(p>k) pd->data=PA.GetRangeByIdx(k,p-1);
						else	pd->data="";
						pd->nxt=NULL;
						if(ppa==NULL)  	ppa=pd;
						else			ppx->nxt=pd;
//printf(" %s",(char*)pd->data);
						ppx=pd;  k=p+1;
						p=PA.InStr(k,',');
					}
					//-----------------------------------
				}
//printf(">");
				T+=_DEQUPARED;
				bflg=true;
				break;
			}
			dp=dp->nxt;
		}
		//============================================
	    if(bflg) {
			T+=" ";
			T+=_DEQUBDYST;
			fprintf(fp,"%s",(char*)T);
			T=GetDEQUbodyInDB((char*)dp->NAME);

//printf("\n[%s]{{%s}}\n",(char*)dp->NAME,(char*)T);
			ppx=ppa; 
			k=1;
			while(ppx!=NULL) {
				PA="$"; PA+=k; PA+="$";
				PX="$"; PX+=ppx->data; PX+="$";
//printf("%d[%s]->[%s] ",k,(char*)PA,(char*)PX);
				T=T.GetRangeWithWdChg((char*)PA,(char*)PX);
				k++;
				ppx=ppx->nxt;
			}
			T+=_DEQUBDYED;
//printf("\n>>[%s]%s\n",(char*)dp->NAME,(char*)T);
			fprintf(fp,"%s\n",(char*)T);
			ReleaseDSLINK(&ppa);
		}
	}
	
	fprintf(fp,"\n");
	
	fclose(fp);
	return l;
}

int DEQU_DB::SetDEQUCAT(const char *dequname,const int Cat){ 
	MyStr DQ(dequname);
	if(CNT>0 || (int)DQ>0) {
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			if(dp->NAME==DQ) { dp->CAT=Cat; return 0; }
			dp=dp->nxt;
		}
	}
	return -1;
}
int DEQU_DB::GetDEQUCAT(const char *dequname){ 
	MyStr DQ(dequname);
	if(CNT>0 || (int)DQ>0) {
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			if(dp->NAME==DQ) return dp->CAT;
			dp=dp->nxt;
		}
	}
	return -1;
}
