/*##############################################################################################
	v1.1@20191018	Add InStr,InStrRev,InStrExSymBlk,InStrRevExSymBlk for MyStr type
		+ InStr(MyStr&) & InStr(int,MyStr&) & InStr(int,int,MyStr&)
		+ InStrExSymBlk(MyStr&,char*) & InStrExSymBlk(int,MyStr&,char*) & InStrExSymBlk(int,int,MyStr&,char*)
		+ InStrRev(MyStr&) & InStrRev(int,MyStr&) & InStrRev(int,int,MyStr&)
		+ InStrRevExSymBlk(MyStr&,char*) & InStrRevExSymBlk(int,MyStr&,char*) & InStrRevExSymBlk(int,int,MyStr&,char*)
	v1.1@20191018	Add GetRangeByKey,GetRangeByKeyExSymBlk for MyStr type
		+ GetRangeByKey(char,MyStr&); GetRangeByKey(char*,MyStr&); GetRangeByKey(MyStr&,MyStr&); GetRangeByKey(MyStr&,char); GetRangeByKey(MyStr&,char*);
		+ GetRangeByKeyExSymBlk(char,MyStr&,char*); GetRangeByKeyExSymBlk(char*,MyStr&,char*); GetRangeByKeyExSymBlk(MyStr&,MyStr&,char*); GetRangeByKeyExSymBlk(MyStr&,char,char*); GetRangeByKeyExSymBlk(MyStr&,char*,char*);
	v1.1@20191018	Add GetRangeBtwKey,GetRangeBtwKeyExSymBlk for MyStr type
		+ GetRangeBtwKey(char,MyStr&); GetRangeBtwKey(char*,MyStr&); GetRangeBtwKey(MyStr&,char); GetRangeBtwKey(MyStr&,char*); GetRangeBtwKey(MyStr&,MyStr&);
		+ GetRangeBtwKey(int,char,MyStr&); GetRangeBtwKey(int,char*,MyStr&); GetRangeBtwKey(int,MyStr&,char); GetRangeBtwKey(int,MyStr&,char*); GetRangeBtwKey(int,MyStr&,MyStr&);
		+ GetRangeBtwKey(int,int,char,MyStr&); GetRangeBtwKey(int,int,char*,MyStr&); GetRangeBtwKey(int,int,MyStr&,char); GetRangeBtwKey(int,int,MyStr&,char*); GetRangeBtwKey(int,int,MyStr&,MyStr&);
		+ GetRangeBtwKeyExSymBlk(char,MyStr&); GetRangeBtwKeyExSymBlk(char*,MyStr&); GetRangeBtwKeyExSymBlk(MyStr&,char); GetRangeBtwKeyExSymBlk(MyStr&,char*); GetRangeBtwKeyExSymBlk(MyStr&,MyStr&);
		+ GetRangeBtwKeyExSymBlk(int,char,MyStr&); GetRangeBtwKeyExSymBlk(int,char*,MyStr&); GetRangeBtwKeyExSymBlk(int,MyStr&,char); GetRangeBtwKeyExSymBlk(int,MyStr&,char*); GetRangeBtwKeyExSymBlk(int,MyStr&,MyStr&);
		+ GetRangeBtwKeyExSymBlk(int,int,char,MyStr&); GetRangeBtwKeyExSymBlk(int,int,char*,MyStr&); GetRangeBtwKeyExSymBlk(int,int,MyStr&,char); GetRangeBtwKeyExSymBlk(int,int,MyStr&,char*); GetRangeBtwKeyExSymBlk(int,int,MyStr&,MyStr&);

	v1.2@20191019	
		+ operator[] for char access of MyStr 
		private->protecteded Emptystr[] & sp2 for class inheritance
		+ IsEmptry() & IsNotEmpty()
	v1.3@20191022
		+ operator==(const int); operator==(const long); 
		+ operator!=(const int); operator!=(const long);
	v1.4@20191023
		+ PO2 GetPointOfStackPairKey(const char *k1,const char *k2);
		+ PO2 GetPointOfStackPairKey(MyStr &K1,MyStr &K1);
	v1.5@20191026
		private len,*str,*tmp -> protected len,*str,*tmp 
		+ releaseX(char **pstr) , release() , releasetmp();
		+ resizeX(char **pstr,char) , resizeX(char **pstr,MyStr&)
		+ resize(char), resize(MyStr&)
		+ resizetmp(char), resizetmp(MyStr&)
	v1.6@20191028
		+ int CharOfListInStrIdx(...const char *str,const char *list)
		+ int GetWdCntInStr(...const char *str,const char c)
		+ int GetWdCntInStr(...const char *str,const char *wd)
		+ int MyStr::ChrOfLstInStr(...const char *lst);
		+ int MyStr::WdCntInStr(...const char c);
		+ int MyStr::WdCntInStr(...const char *wd);
	v1.7@20191102
		+ PO2 GetPointOfStackPairKey(const char c1,const char c2);
		Fix GetPointOfStackPairKey bug;
		Fix GetWdCntInStr bug;
	v1.8@20191104
		+ int UpperCaseInside(...)
		+ PO2 LineSymBlkIdxInStr(...) -> SymBlk check within line ('\n') range
		+ int InStrExLineSymBlk(...)
		+ int InStrRevExLineSymBlk(...)
		+ const char *GetRangeByKeyExLineSymBlk(...)
		+ const char *GetRangeBtwKeyExLineSymBlk(...)
		+ const char *GetRangeWithWdChgExLineSymBlk(...)
		+ const char *GetRangeWithWdDelExLineSymBlk(...)
		+ const char *GetRangeWithSpDelExLineSymBlk(...)
		+ const char *GetRangeWithWdCmpressExLineSymBlk(...)
		+ const char* GetRangeWithSpCmpressExLineSymBlk(...)
		+ const char* GetRangeWithDelByKeyExLineSymBlk(...)
		+ const char* GetRangeWithDelBtwKeyExLineSymBlk(...)
		+ const char* GetRangeWithDelLineBlkSymChr(...)
	v1.9@20191108
		+ const char* GetRangeWithCmpressSpLine(...)
	v2.0@20191110
		+ PO2 GetPointRevOfStackPairKey(MyStr &K1,MyStr &K2)
		+ PO2 GetPointRevOfStackPairKey(const char *k1,const char *k2)
		+ PO2 GetPointRevOfStackPairKey(const char c1,const char c2)
	v2.1@20191124
		+ int CharOfListInStrRevIdx(...)
		+ int MyStr::ChrOfLstInStrRev(...)
		Fix CharOfListInStrIdx strlen(list)>strlen(str) return bug
	v2.2@20191127
		PO2 MyStr::SymBlkIdxInStr(const int si,const int ei,const char *str->*sstr ...)
		+PO2 MyStr::GetPointOfStackPairKey(const int si,const int ei,const char c1,const char c2);
		+PO2 MyStr::GetPointOfStackPairKey(const int si,const int ei,MyStr &K1,MyStr &K2);
		+PO2 MyStr::GetPointOfStackPairKey(const int si,const int ei,const char *k1,const char *k2);
################################################################################################*/

#ifndef __MyStr__h__
    #define __MyStr__h__
	#define __MyStrVer__	"MyStr-v2.2@20191127"
	
	#ifndef NullPchr
	   #define NullPchr (char*)NULL
	#endif
	
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <iostream>

typedef struct {
	int p1;
	int p2;
} PO2;

int WdIdxInStr(const char *str,const char *word);
int WdIdxInStr(const int si,const char *str,const char *word);
int WdIdxInStr(const int si,const int ei,const char *str,const char *word);
int WdIdxInStrRev(const char *str,const char *word);
int WdIdxInStrRev(const int si,const char *str,const char *word);
int WdIdxInStrRev(const int si,const int ei,const char *str,const char *word);

int WdIdxInStr(const char *str,const char c);
int WdIdxInStr(const int si,const char *str,const char c);
int WdIdxInStr(const int si,const int ei,const char *str,const char c);
int WdIdxInStrRev(const char *str,const char c);
int WdIdxInStrRev(const int si,const char *str,const char c);
int WdIdxInStrRev(const int si,const int ei,const char *str,const char c);

int CharOfListInStrIdx(const int si,const int ei,const char *str,const char *list);
int CharOfListInStrIdx(const int si,const char *str,const char *list);
int CharOfListInStrIdx(const char *str,const char *list);

int CharOfListInStrRevIdx(const int si,const int ei,const char *str,const char *list);
int CharOfListInStrRevIdx(const int si,const char *str,const char *list);
int CharOfListInStrRevIdx(const char *str,const char *list);

int GetWdCntInStr(const char *str,const char c);
int GetWdCntInStr(const int si,const char *str,const char c);
int GetWdCntInStr(const int si,const int ei,const char *str,const char c);
int GetWdCntInStr(const char *str,const char *wd);
int GetWdCntInStr(const int si,const char *str,const char *wd);
int GetWdCntInStr(const int si,const int ei,const char *str,const char *wd);

class MyStr {
protected:
			 int  		len;
			 char 		*str;
			 char 		*tmp;

static 		 char 		Emptystr[];
static 		 PO2		sp2;

			 const char*	resizeX(char **pstr,const char c);
			 const char*	resizeX(char **pstr,const char *istr);
			 const char*	resizeX(char **pstr,MyStr &S);
			 
virtual 	 const char*	resize(const char c);
virtual 	 const char*	resize(const char *istr);
virtual 	 const char*	resize(MyStr &S);

virtual 	 const char*	resizetmp(const char c);
virtual 	 const char*	resizetmp(const char *istr);
virtual 	 const char*	resizetmp(MyStr &S);

			 const char*	releaseX(char **pstr);
virtual 	 const char*	release(void);
virtual 	 const char*	releasetmp(void);

public:
			 MyStr();
			 MyStr(const char c);
			 MyStr(const char *s);
			 MyStr(MyStr &S);
			 MyStr(const int v);
			 MyStr(const long lv);
			 ~MyStr();
//====================================================================================================================================
virtual 	 operator int();
virtual 	 operator char();
virtual 	 operator char*();
virtual 	 operator const char*();
//====================================================================================================================================
virtual 	 MyStr& operator=(const char *s);
virtual 	 MyStr& operator=(const char c);
virtual 	 MyStr& operator=(MyStr &S);
virtual 	 MyStr& operator=(const int n);
virtual 	 MyStr& operator=(const long l);

virtual 	 MyStr& operator+=(const char *s);
virtual 	 MyStr& operator+=(const char c);
virtual 	 MyStr& operator+=(MyStr &S);
virtual 	 MyStr& operator+=(const int n);
virtual 	 MyStr& operator+=(const long l);

virtual 	 bool operator==(const char *s);
virtual 	 bool operator==(const char c);
virtual 	 bool operator==(MyStr &S);
virtual 	 bool operator==(const int n);
virtual 	 bool operator==(const long l);
 
virtual 	 bool operator!=(const char *s);
virtual 	 bool operator!=(const char c);
virtual 	 bool operator!=(MyStr &S);
virtual 	 bool operator!=(const int n);
virtual 	 bool operator!=(const long l);

virtual 	 const char* operator+(const char *s);
virtual 	 const char* operator+(const char c);
virtual 	 const char* operator+(MyStr &S);
virtual 	 const char* operator+(const int n);
virtual 	 const char* operator+(const long l);

virtual 	 char  operator[](int idx);

//====================================================================================================================================
			 PO2 		SymBlkIdxInStr(const int si,const int ei,const char *SymChrLst);
			 PO2 		SymBlkIdxInStr(const int si,const int ei,const char *sstr,const char *SymChrLst);

			 PO2 		LineSymBlkIdxInStr(const int si,const int ei,const char *SymChrLst);
			 PO2 		LineSymBlkIdxInStr(const int si,const int ei,const char *str,const char *SymChrLst);		 
			 
			 PO2 		GetPointOfStackPairKey(const char c1,const char c2);
			 PO2 		GetPointOfStackPairKey(MyStr &K1,MyStr &K2);
			 PO2		GetPointOfStackPairKey(const char *k1,const char *k2);

			 PO2 		GetPointOfStackPairKey(const int si,const int ei,const char c1,const char c2);
			 PO2 		GetPointOfStackPairKey(const int si,const int ei,MyStr &K1,MyStr &K2);
			 PO2		GetPointOfStackPairKey(const int si,const int ei,const char *k1,const char *k2);

			 PO2 		GetPointRevOfStackPairKey(MyStr &K1,MyStr &K2);
			 PO2 		GetPointRevOfStackPairKey(const char *k1,const char *k2);
			 PO2 		GetPointRevOfStackPairKey(const char c1,const char c2);
//====================================================================================================================================
virtual 	 const char* GetDos2Unix(void);
virtual 	 const char* GetDos2UnixExSymBlk(const char *SymChrLst);

virtual 	 const char* GetLowerCase(void);
virtual 	 const char* GetUpperCase(void);

virtual 	 int 		LowerCaseInside(void);
virtual 	 int 		LowerCaseInside(const int si);
virtual 	 int 		LowerCaseInside(const int si,const int ei);

virtual 	 int 		UpperCaseInside(void);
virtual 	 int 		UpperCaseInside(const int si);
virtual 	 int 		UpperCaseInside(const int si,const int ei);

virtual 	 bool		IsEmpty(void);
virtual 	 bool		IsNotEmpty(void);
//====================================================================================================================================
virtual 	 int 		ChrOfLstInStr(const char *lst);
virtual 	 int 		ChrOfLstInStr(const int si,const char *lst);
virtual 	 int 		ChrOfLstInStr(const int si,const int ei,const char *lst);
//====================================================================================================================================
virtual 	 int 		ChrOfLstInStrRev(const char *lst);
virtual 	 int 		ChrOfLstInStrRev(const int si,const char *lst);
virtual 	 int 		ChrOfLstInStrRev(const int si,const int ei,const char *lst);
//====================================================================================================================================
virtual 	 int 		WdCntInStr(const char c);
virtual 	 int 		WdCntInStr(const int si,const char c);
virtual 	 int 		WdCntInStr(const int si,const int ei,const char c);
virtual 	 int 		WdCntInStr(const char *wd);
virtual 	 int 		WdCntInStr(const int si,const char *wd);
virtual 	 int 		WdCntInStr(const int si,const int ei,const char *wd);
//====================================================================================================================================
virtual 	 int 		InStr(const char c);
virtual 	 int 		InStr(const char *w);
virtual 	 int 		InStr(MyStr &S);
virtual 	 int 		InStr(const int si,const char c);
virtual 	 int 		InStr(const int si,const char *w);
virtual 	 int 		InStr(const int si,MyStr &S);
virtual 	 int 		InStr(const int si,const int ei,const char c);
virtual 	 int 		InStr(const int si,const int ei,const char *w);
virtual 	 int 		InStr(const int si,const int ei,MyStr &S);
//====================================================================================================================================
virtual 	 int 		InStrExSymBlk(const char c,const char *SymChrLst);
virtual 	 int 		InStrExSymBlk(const char *w,const char *SymChrLst);
virtual 	 int 		InStrExSymBlk(MyStr &S,const char *SymChrLst);
virtual 	 int 		InStrExSymBlk(const int si,const char c,const char *SymChrLst);
virtual 	 int 		InStrExSymBlk(const int si,const char *w,const char *SymChrLst);
virtual 	 int 		InStrExSymBlk(const int si,MyStr &S,const char *SymChrLst);
virtual 	 int 		InStrExSymBlk(const int si,const int ei,const char c,const char *SymChrLst);
virtual 	 int 		InStrExSymBlk(const int si,const int ei,const char *w,const char *SymChrLst);
virtual 	 int 		InStrExSymBlk(const int si,const int ei,MyStr &S,const char *SymChrLst);
//====================================================================================================================================
virtual 	 int 		InStrExLineSymBlk(const char c,const char *SymChrLst);
virtual 	 int 		InStrExLineSymBlk(const char *w,const char *SymChrLst);
virtual 	 int 		InStrExLineSymBlk(MyStr &S,const char *SymChrLst);
virtual 	 int 		InStrExLineSymBlk(const int si,const char c,const char *SymChrLst);
virtual 	 int 		InStrExLineSymBlk(const int si,const char *w,const char *SymChrLst);
virtual 	 int 		InStrExLineSymBlk(const int si,MyStr &S,const char *SymChrLst);
virtual 	 int 		InStrExLineSymBlk(const int si,const int ei,const char c,const char *SymChrLst);
virtual 	 int 		InStrExLineSymBlk(const int si,const int ei,const char *w,const char *SymChrLst);
virtual 	 int 		InStrExLineSymBlk(const int si,const int ei,MyStr &S,const char *SymChrLst);
//====================================================================================================================================
virtual 	 int 		InStrRev(const char c);
virtual 	 int 		InStrRev(const char *w);
virtual 	 int 		InStrRev(MyStr &S);
virtual 	 int 		InStrRev(const int si,const char c);                                              
virtual 	 int 		InStrRev(const int si,const char *w);
virtual 	 int 		InStrRev(const int si,MyStr &S);
virtual 	 int 		InStrRev(const int si,const int ei,const char c);
virtual 	 int 		InStrRev(const int si,const int ei,const char *w);
virtual 	 int 		InStrRev(const int si,const int ei,MyStr &S);
//====================================================================================================================================
virtual 	 int 		InStrRevExSymBlk(const char c,const char *SymChrLst);
virtual 	 int 		InStrRevExSymBlk(const char *w,const char *SymChrLst);
virtual 	 int 		InStrRevExSymBlk(MyStr &S,const char *SymChrLst);
virtual 	 int 		InStrRevExSymBlk(const int si,const char c,const char *SymChrLst);
virtual 	 int 		InStrRevExSymBlk(const int si,const char *w,const char *SymChrLst);
virtual 	 int 		InStrRevExSymBlk(const int si,MyStr &S,const char *SymChrLst);
virtual 	 int 		InStrRevExSymBlk(const int si,const int ei,const char c,const char *SymChrLst);
virtual 	 int 		InStrRevExSymBlk(const int si,const int ei,const char *w,const char *SymChrLst);
virtual 	 int 		InStrRevExSymBlk(const int si,const int ei,MyStr &S,const char *SymChrLst);
//====================================================================================================================================
virtual 	 int 		InStrRevExLineSymBlk(const char c,const char *SymChrLst);
virtual 	 int 		InStrRevExLineSymBlk(const char *w,const char *SymChrLst);
virtual 	 int 		InStrRevExLineSymBlk(MyStr &S,const char *SymChrLst);
virtual 	 int 		InStrRevExLineSymBlk(const int si,const char c,const char *SymChrLst);
virtual 	 int 		InStrRevExLineSymBlk(const int si,const char *w,const char *SymChrLst);
virtual 	 int 		InStrRevExLineSymBlk(const int si,MyStr &S,const char *SymChrLst);
virtual 	 int 		InStrRevExLineSymBlk(const int si,const int ei,const char c,const char *SymChrLst);
virtual 	 int 		InStrRevExLineSymBlk(const int si,const int ei,const char *w,const char *SymChrLst);
virtual 	 int 		InStrRevExLineSymBlk(const int si,const int ei,MyStr &S,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeByIdx(const int si,const int ei);
virtual 	 const char* GetRangeBtwIdx(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetRangeByKey(const char c1,const char c2);
virtual 	 const char* GetRangeByKey(const char c1,const char *k2);
virtual 	 const char* GetRangeByKey(const char c1,MyStr &S2);
virtual 	 const char* GetRangeByKey(const char *k1,const char c2);
virtual 	 const char* GetRangeByKey(const char *k1,const char *k2);
virtual 	 const char* GetRangeByKey(const char *k1,MyStr &S2);
virtual 	 const char* GetRangeByKey(MyStr &S1,const char c2);
virtual 	 const char* GetRangeByKey(MyStr &S1,const char *k2);
virtual 	 const char* GetRangeByKey(MyStr &S1,MyStr &S2);
//====================================================================================================================================
virtual 	 const char* GetRangeByKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExSymBlk(const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExSymBlk(const char c1,MyStr &S2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExSymBlk(const char *k1,MyStr &S2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExSymBlk(MyStr &S1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExSymBlk(MyStr &S1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExSymBlk(MyStr &S1,MyStr &S2,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeByKeyExLineSymBlk(const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExLineSymBlk(const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExLineSymBlk(const char c1,MyStr &S2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExLineSymBlk(const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExLineSymBlk(const char *k1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExLineSymBlk(const char *k1,MyStr &S2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExLineSymBlk(MyStr &S1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExLineSymBlk(MyStr &S1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeByKeyExLineSymBlk(MyStr &S1,MyStr &S2,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeBtwKey(const char c1,const char c2);
virtual 	 const char* GetRangeBtwKey(const char c1,const char *k2);
virtual 	 const char* GetRangeBtwKey(const char c1,MyStr &S2);
virtual 	 const char* GetRangeBtwKey(const char *k1,const char c2);
virtual 	 const char* GetRangeBtwKey(const char *k1,const char *k2);
virtual 	 const char* GetRangeBtwKey(const char *k1,MyStr &S2);
virtual 	 const char* GetRangeBtwKey(MyStr &S1,const char c2);
virtual 	 const char* GetRangeBtwKey(MyStr &S1,const char *k2);
virtual 	 const char* GetRangeBtwKey(MyStr &S1,MyStr &S2);

virtual 	 const char* GetRangeBtwKey(const int si,const char c1,const char c2);
virtual 	 const char* GetRangeBtwKey(const int si,const char c1,const char *k2);
virtual 	 const char* GetRangeBtwKey(const int si,const char c1,MyStr &S2);
virtual 	 const char* GetRangeBtwKey(const int si,const char *k1,const char c2);
virtual 	 const char* GetRangeBtwKey(const int si,const char *k1,const char *k2);
virtual 	 const char* GetRangeBtwKey(const int si,const char *k1,MyStr &S2);
virtual 	 const char* GetRangeBtwKey(const int si,MyStr &S1,const char c2);
virtual 	 const char* GetRangeBtwKey(const int si,MyStr &S1,const char *k2);
virtual 	 const char* GetRangeBtwKey(const int si,MyStr &S1,MyStr &S2);

virtual 	 const char* GetRangeBtwKey(const int si,const int ei,const char c1,const char c2);
virtual 	 const char* GetRangeBtwKey(const int si,const int ei,const char c1,const char *k2);
virtual 	 const char* GetRangeBtwKey(const int si,const int ei,const char c1,MyStr &S2);
virtual 	 const char* GetRangeBtwKey(const int si,const int ei,const char *k1,const char c2);
virtual 	 const char* GetRangeBtwKey(const int si,const int ei,const char *k1,const char *k2);
virtual 	 const char* GetRangeBtwKey(const int si,const int ei,const char *k1,MyStr &S2);
virtual 	 const char* GetRangeBtwKey(const int si,const int ei,MyStr &S1,const char c2);
virtual 	 const char* GetRangeBtwKey(const int si,const int ei,MyStr &S1,const char *k2);
virtual 	 const char* GetRangeBtwKey(const int si,const int ei,MyStr &S1,MyStr &S2);
//====================================================================================================================================
virtual 	 const char* GetRangeBtwKeyExSymBlk(const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const char c1,MyStr &S2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const char *k1,MyStr &S2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(MyStr &S1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(MyStr &S1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(MyStr &S1,MyStr &S2,const char *SymChrLst);

virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const char c1,MyStr &S2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const char *k1,MyStr &S2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,MyStr &S1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,MyStr &S1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,MyStr &S1,MyStr &S2,const char *SymChrLst);

virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const int ei,const char c1,MyStr &S2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const int ei,const char *k1,MyStr &S2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const int ei,MyStr &S1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const int ei,MyStr &S1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExSymBlk(const int si,const int ei,MyStr &S1,MyStr &S2,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const char c1,MyStr &S2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const char *k1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const char *k1,MyStr &S2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(MyStr &S1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(MyStr &S1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(MyStr &S1,MyStr &S2,const char *SymChrLst);

virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const int si,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const int si,const char c1,MyStr &S2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const int si,const char *k1,MyStr &S2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const int si,MyStr &S1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const int si,MyStr &S1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const int si,MyStr &S1,MyStr &S2,const char *SymChrLst);

virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const int si,const int ei,const char c1,MyStr &S2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const int si,const int ei,const char *k1,MyStr &S2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const int si,const int ei,MyStr &S1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const int si,const int ei,MyStr &S1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeBtwKeyExLineSymBlk(const int si,const int ei,MyStr &S1,MyStr &S2,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdChg(const char och,const char nch);
virtual 	 const char* GetRangeWithWdChg(const char och,const char *nwd);
virtual 	 const char* GetRangeWithWdChg(const char *owd,const char nch);
virtual 	 const char* GetRangeWithWdChg(const char *owd,const char *nwd);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdChg(const int si,const char och,const char nch);  
virtual 	 const char* GetRangeWithWdChg(const int si,const char och,const char *nwd); 
virtual 	 const char* GetRangeWithWdChg(const int si,const char *owd,const char nch); 
virtual 	 const char* GetRangeWithWdChg(const int si,const char *owd,const char *nwd);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdChg(const int si,const int ei,const char och,const char nch);  
virtual 	 const char* GetRangeWithWdChg(const int si,const int ei,const char och,const char *nwd); 
virtual 	 const char* GetRangeWithWdChg(const int si,const int ei,const char *owd,const char nch); 
virtual 	 const char* GetRangeWithWdChg(const int si,const int ei,const char *owd,const char *nwd);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdChgExSymBlk(const char och,const char nch,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdChgExSymBlk(const char och,const char *nwd,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdChgExSymBlk(const char *owd,const char nch,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdChgExSymBlk(const char *owd,const char *nwd,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdChgExSymBlk(const int si,const char och,const char nch,const char *SymChrLst);  
virtual 	 const char* GetRangeWithWdChgExSymBlk(const int si,const char och,const char *nwd,const char *SymChrLst); 
virtual 	 const char* GetRangeWithWdChgExSymBlk(const int si,const char *owd,const char nch,const char *SymChrLst); 
virtual 	 const char* GetRangeWithWdChgExSymBlk(const int si,const char *owd,const char *nwd,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdChgExSymBlk(const int si,const int ei,const char och,const char nch,const char *SymChrLst);  
virtual 	 const char* GetRangeWithWdChgExSymBlk(const int si,const int ei,const char och,const char *nwd,const char *SymChrLst); 
virtual 	 const char* GetRangeWithWdChgExSymBlk(const int si,const int ei,const char *owd,const char nch,const char *SymChrLst); 
virtual 	 const char* GetRangeWithWdChgExSymBlk(const int si,const int ei,const char *owd,const char *nwd,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdChgExLineSymBlk(const char och,const char nch,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdChgExLineSymBlk(const char och,const char *nwd,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdChgExLineSymBlk(const char *owd,const char nch,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdChgExLineSymBlk(const char *owd,const char *nwd,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdChgExLineSymBlk(const int si,const char och,const char nch,const char *SymChrLst);  
virtual 	 const char* GetRangeWithWdChgExLineSymBlk(const int si,const char och,const char *nwd,const char *SymChrLst); 
virtual 	 const char* GetRangeWithWdChgExLineSymBlk(const int si,const char *owd,const char nch,const char *SymChrLst); 
virtual 	 const char* GetRangeWithWdChgExLineSymBlk(const int si,const char *owd,const char *nwd,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdChgExLineSymBlk(const int si,const int ei,const char och,const char nch,const char *SymChrLst);  
virtual 	 const char* GetRangeWithWdChgExLineSymBlk(const int si,const int ei,const char och,const char *nwd,const char *SymChrLst); 
virtual 	 const char* GetRangeWithWdChgExLineSymBlk(const int si,const int ei,const char *owd,const char nch,const char *SymChrLst); 
virtual 	 const char* GetRangeWithWdChgExLineSymBlk(const int si,const int ei,const char *owd,const char *nwd,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdDel(const char c);
virtual 	 const char* GetRangeWithWdDel(const char *wd);
virtual 	 const char* GetRangeWithWdDel(const int si,const char c);
virtual 	 const char* GetRangeWithWdDel(const int si,const char *wd);
virtual 	 const char* GetRangeWithWdDel(const int si,const int ei,const char c);
virtual 	 const char* GetRangeWithWdDel(const int si,const int ei,const char *wd);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdDelExSymBlk(const char c,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdDelExSymBlk(const char *wd,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdDelExSymBlk(const int si,const char c,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdDelExSymBlk(const int si,const char *wd,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdDelExSymBlk(const int si,const int ei,const char *wd,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdDelExSymBlk(const int si,const int ei,const char c,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdDelExLineSymBlk(const char c,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdDelExLineSymBlk(const char *wd,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdDelExLineSymBlk(const int si,const char c,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdDelExLineSymBlk(const int si,const char *wd,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdDelExLineSymBlk(const int si,const int ei,const char *wd,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdDelExLineSymBlk(const int si,const int ei,const char c,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithSpDel(void);
virtual 	 const char* GetRangeWithSpDel(const int si);
virtual 	 const char* GetRangeWithSpDel(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetRangeWithSpDelExSymBlk(const char *SymChrLst);
virtual 	 const char* GetRangeWithSpDelExSymBlk(const int si,const char *SymChrLst);
virtual 	 const char* GetRangeWithSpDelExSymBlk(const int si,const int ei,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithSpDelExLineSymBlk(const char *SymChrLst);
virtual 	 const char* GetRangeWithSpDelExLineSymBlk(const int si,const char *SymChrLst);
virtual 	 const char* GetRangeWithSpDelExLineSymBlk(const int si,const int ei,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdCmpress(const char c);
virtual 	 const char* GetRangeWithWdCmpress(const char *wd);
virtual 	 const char* GetRangeWithWdCmpress(const int si,const char c);
virtual 	 const char* GetRangeWithWdCmpress(const int si,const char *wd);
virtual 	 const char* GetRangeWithWdCmpress(const int si,const int ei,const char c);
virtual 	 const char* GetRangeWithWdCmpress(const int si,const int ei,const char *wd);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdCmpressExSymBlk(const char c,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdCmpressExSymBlk(const char *wd,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdCmpressExSymBlk(const int si,const char c,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdCmpressExSymBlk(const int si,const char *wd,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdCmpressExSymBlk(const int si,const int ei,const char c,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdCmpressExSymBlk(const int si,const int ei,const char *wd,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithWdCmpressExLineSymBlk(const char c,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdCmpressExLineSymBlk(const char *wd,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdCmpressExLineSymBlk(const int si,const char c,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdCmpressExLineSymBlk(const int si,const char *wd,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdCmpressExLineSymBlk(const int si,const int ei,const char c,const char *SymChrLst);
virtual 	 const char* GetRangeWithWdCmpressExLineSymBlk(const int si,const int ei,const char *wd,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithSpCmpress(void);
virtual 	 const char* GetRangeWithSpCmpress(const int si);
virtual 	 const char* GetRangeWithSpCmpress(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetRangeWithSpCmpressExSymBlk(const char *SymChrLst);
virtual 	 const char* GetRangeWithSpCmpressExSymBlk(const int si,const char *SymChrLst);
virtual 	 const char* GetRangeWithSpCmpressExSymBlk(const int si,const int ei,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithSpCmpressExLineSymBlk(const char *SymChrLst);
virtual 	 const char* GetRangeWithSpCmpressExLineSymBlk(const int si,const char *SymChrLst);
virtual 	 const char* GetRangeWithSpCmpressExLineSymBlk(const int si,const int ei,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithDelByKey(const char c1,const char c2);
virtual 	 const char* GetRangeWithDelByKey(const char c1,const char *k2);
virtual 	 const char* GetRangeWithDelByKey(const char *k1,const char c2);
virtual 	 const char* GetRangeWithDelByKey(const char *k1,const char *k2);

virtual 	 const char* GetRangeWithDelByKey(const int si,const char c1,const char c2);
virtual 	 const char* GetRangeWithDelByKey(const int si,const char c1,const char *k2);
virtual 	 const char* GetRangeWithDelByKey(const int si,const char *k1,const char c2);
virtual 	 const char* GetRangeWithDelByKey(const int si,const char *k1,const char *k2);

virtual 	 const char* GetRangeWithDelByKey(const int si,const int ei,const char c1,const char c2);
virtual 	 const char* GetRangeWithDelByKey(const int si,const int ei,const char c1,const char *k2);
virtual 	 const char* GetRangeWithDelByKey(const int si,const int ei,const char *k1,const char c2);
virtual 	 const char* GetRangeWithDelByKey(const int si,const int ei,const char *k1,const char *k2);
//====================================================================================================================================
virtual 	 const char* GetRangeWithDelBtwKey(const char c1,const char c2);
virtual 	 const char* GetRangeWithDelBtwKey(const char c1,const char *k2);
virtual 	 const char* GetRangeWithDelBtwKey(const char *k1,const char c2);
virtual 	 const char* GetRangeWithDelBtwKey(const char *k1,const char *k2);

virtual 	 const char* GetRangeWithDelBtwKey(const int si,const char c1,const char c2);
virtual 	 const char* GetRangeWithDelBtwKey(const int si,const char c1,const char *k2);
virtual 	 const char* GetRangeWithDelBtwKey(const int si,const char *k1,const char c2);
virtual 	 const char* GetRangeWithDelBtwKey(const int si,const char *k1,const char *k2);

virtual 	 const char* GetRangeWithDelBtwKey(const int si,const int ei,const char c1,const char c2);
virtual 	 const char* GetRangeWithDelBtwKey(const int si,const int ei,const char c1,const char *k2);
virtual 	 const char* GetRangeWithDelBtwKey(const int si,const int ei,const char *k1,const char c2);
virtual 	 const char* GetRangeWithDelBtwKey(const int si,const int ei,const char *k1,const char *k2);
//====================================================================================================================================
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithDelByKeyExLineSymBlk(const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExLineSymBlk(const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExLineSymBlk(const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExLineSymBlk(const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetRangeWithDelByKeyExLineSymBlk(const int si,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExLineSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExLineSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExLineSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetRangeWithDelByKeyExLineSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExLineSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExLineSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelByKeyExLineSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithDelBtwKeyExLineSymBlk(const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExLineSymBlk(const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExLineSymBlk(const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExLineSymBlk(const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetRangeWithDelBtwKeyExLineSymBlk(const int si,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExLineSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExLineSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExLineSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetRangeWithDelBtwKeyExLineSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExLineSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExLineSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBtwKeyExLineSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetLineDelByKey(const char c1,const char c2);
virtual 	 const char* GetLineDelByKey(const char c1,const char *k2);
virtual 	 const char* GetLineDelByKey(const char *k1,const char c2);
virtual 	 const char* GetLineDelByKey(const char *k1,const char *k2);

virtual 	 const char* GetLineDelByKey(const int si,const char c1,const char c2);
virtual 	 const char* GetLineDelByKey(const int si,const char c1,const char *k2);
virtual 	 const char* GetLineDelByKey(const int si,const char *k1,const char c2);
virtual 	 const char* GetLineDelByKey(const int si,const char *k1,const char *k2);

virtual 	 const char* GetLineDelByKey(const int si,const int ei,const char c1,const char c2);
virtual 	 const char* GetLineDelByKey(const int si,const int ei,const char c1,const char *k2);
virtual 	 const char* GetLineDelByKey(const int si,const int ei,const char *k1,const char c2);
virtual 	 const char* GetLineDelByKey(const int si,const int ei,const char *k1,const char *k2);
//====================================================================================================================================
virtual 	 const char* GetLineDelByKeyExSymBlk(const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelByKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetLineDelByKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelByKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetLineDelByKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelByKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetLineDelByKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelByKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetLineDelByKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelByKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetLineDelByKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelByKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetLineDelBtwKey(const char c1,const char c2);
virtual 	 const char* GetLineDelBtwKey(const char c1,const char *k2);
virtual 	 const char* GetLineDelBtwKey(const char *k1,const char c2);
virtual 	 const char* GetLineDelBtwKey(const char *k1,const char *k2);

virtual 	 const char* GetLineDelBtwKey(const int si,const char c1,const char c2);
virtual 	 const char* GetLineDelBtwKey(const int si,const char c1,const char *k2);
virtual 	 const char* GetLineDelBtwKey(const int si,const char *k1,const char c2);
virtual 	 const char* GetLineDelBtwKey(const int si,const char *k1,const char *k2);

virtual 	 const char* GetLineDelBtwKey(const int si,const int ei,const char c1,const char c2);
virtual 	 const char* GetLineDelBtwKey(const int si,const int ei,const char c1,const char *k2);
virtual 	 const char* GetLineDelBtwKey(const int si,const int ei,const char *k1,const char c2);
virtual 	 const char* GetLineDelBtwKey(const int si,const int ei,const char *k1,const char *k2);
//====================================================================================================================================
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetLineDelBtwKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst);

virtual 	 const char* GetLineDelBtwKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst);
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst);
virtual 	 const char* GetLineDelBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetLineTrim(void);
virtual 	 const char* GetLineTrim(const int si);
virtual 	 const char* GetLineTrim(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetLineTrimL(void);
virtual 	 const char* GetLineTrimL(const int si);
virtual 	 const char* GetLineTrimL(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetLineTrimR(void);
virtual 	 const char* GetLineTrimR(const int si);
virtual 	 const char* GetLineTrimR(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetLineTrimA(void);
virtual 	 const char* GetLineTrimA(const int si);
virtual 	 const char* GetLineTrimA(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetLineTrimExSymBlk(const char *SymChrLst);
virtual 	 const char* GetLineTrimExSymBlk(const int si,const char *SymChrLst);
virtual 	 const char* GetLineTrimExSymBlk(const int si,const int ei,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetLineTrimLExSymBlk(const char *SymChrLst);
virtual 	 const char* GetLineTrimLExSymBlk(const int si,const char *SymChrLst);
virtual 	 const char* GetLineTrimLExSymBlk(const int si,const int ei,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetLineTrimRExSymBlk(const char *SymChrLst);
virtual 	 const char* GetLineTrimRExSymBlk(const int si,const char *SymChrLst);
virtual 	 const char* GetLineTrimRExSymBlk(const int si,const int ei,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetLineTrimAExSymBlk(const char *SymChrLst);
virtual 	 const char* GetLineTrimAExSymBlk(const int si,const char *SymChrLst);
virtual 	 const char* GetLineTrimAExSymBlk(const int si,const int ei,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetLineWithCmtChrDelN(const char CmtChr,const int N);
virtual 	 const char* GetLineWithCmtChrDelN(const int si,const char CmtChr,const int N);
virtual 	 const char* GetLineWithCmtChrDelN(const int si,const int ei,const char CmtChr,const int N);
//====================================================================================================================================
virtual 	 const char* GetLineWithCmtChrDelNExSymBlk(const char CmtChr,const int N,const char *SymChrLst);
virtual 	 const char* GetLineWithCmtChrDelNExSymBlk(const int si,const char CmtChr,const int N,const char *SymChrLst);
virtual 	 const char* GetLineWithCmtChrDelNExSymBlk(const int si,const int ei,const char CmtChr,const int N,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetTrim(void);
virtual 	 const char* GetTrim(const int si);
virtual 	 const char* GetTrim(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetTrimL(void);
virtual 	 const char* GetTrimL(const int si);
virtual 	 const char* GetTrimL(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetTrimR(void);
virtual 	 const char* GetTrimR(const int si);
virtual 	 const char* GetTrimR(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetTrimA(void);
virtual 	 const char* GetTrimA(const int si);
virtual 	 const char* GetTrimA(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetRangeWithDelBlkSymChr(const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBlkSymChr(const int si,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelBlkSymChr(const int si,const int ei,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithDelLineBlkSymChr(const char *SymChrLst);
virtual 	 const char* GetRangeWithDelLineBlkSymChr(const int si,const char *SymChrLst);
virtual 	 const char* GetRangeWithDelLineBlkSymChr(const int si,const int ei,const char *SymChrLst);
//====================================================================================================================================
virtual 	 const char* GetRangeWithDelSpLine(void);
virtual 	 const char* GetRangeWithDelSpLine(const int si);
virtual 	 const char* GetRangeWithDelSpLine(const int si,const int ei);
//====================================================================================================================================
virtual 	 const char* GetRangeWithCmpressSpLine(void);
virtual 	 const char* GetRangeWithCmpressSpLine(const int si);
virtual 	 const char* GetRangeWithCmpressSpLine(const int si,const int ei);
};

#endif
