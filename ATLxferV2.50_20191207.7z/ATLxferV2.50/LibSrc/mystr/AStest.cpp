
#include "mystr.h"
#include "arraystr.h"
#include "mystd.h"

int main(int ac,char **av) {
	tout out;
	int n,i;
	out.prt("\nMyStr S(\"MyStr-S\");");
	MyStr S("MyStr-S");
	
	out.prt("\n\nArrayStr AS(\"ArrayStr-0\");");
	ArrayStr AS("ArrayStr-0");
	out.prt("\nn=AS.GetArrayCnt()");
	n=AS.GetArrayCnt();
	out.prt("->n=%",n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)AS[%]=\"%\"",i,(char*)AS[i]);
		out.prt(" ,AS.GetIdx(AS[%])=%",i,AS.GetIdx(AS[i]));
		out.prt(" ,AS.GetStr(%)=\"%\"",i,AS.GetStr(i));
	}
	out.prt("\nAS.List()=\"%\"",AS.List());
	out.prt("\nAS.ListRev(';')=\"%\"",AS.ListRev(';'));

	out.prt("\n\nAS=AS;");
	AS=AS;
	out.prt("\nn=AS.GetArrayCnt()");
	n=AS.GetArrayCnt();
	out.prt("->n=%",n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)AS[%]=\"%\"",i,(char*)AS[i]);
		out.prt(" ,AS.GetIdx(AS[%])=%",i,AS.GetIdx(AS[i]));
		out.prt(" ,AS.GetStr(%)=\"%\"",i,AS.GetStr(i));
	}
	out.prt("\nAS.List()=\"%\"",AS.List());
	out.prt("\nAS.ListRev(';')=\"%\"",AS.ListRev(';'));

	out.prt("\n\nAS+=AS;");
	AS+=AS;
	out.prt("\nn=AS.GetArrayCnt()");
	n=AS.GetArrayCnt();
	out.prt("->n=%",n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)AS[%]=\"%\"",i,(char*)AS[i]);
		out.prt(" ,AS.GetIdx(AS[%])=%",i,AS.GetIdx(AS[i]));
		out.prt(" ,AS.GetStr(%)=\"%\"",i,AS.GetStr(i));
	}
	out.prt("\nAS.List()=\"%\"",AS.List());
	out.prt("\nAS.ListRev(';')=\"%\"",AS.ListRev(';'));

	out.prt("\n\nAS.DelByIdx(1);");
	AS.DelByIdx(1);
	out.prt("\nn=AS.GetArrayCnt()");
	n=AS.GetArrayCnt();
	out.prt("->n=%",n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)AS[%]=\"%\"",i,(char*)AS[i]);
		out.prt(" ,AS.GetIdx(AS[%])=%",i,AS.GetIdx(AS[i]));
		out.prt(" ,AS.GetStr(%)=\"%\"",i,AS.GetStr(i));
	}
	out.prt("\nAS.List()=\"%\"",AS.List());
	out.prt("\nAS.ListRev(';')=\"%\"",AS.ListRev(';'));


	out.prt("\n\nAS+=\"ArrayStr-1\";");
	AS+="ArrayStr-1";
	out.prt("\nn=AS.GetArrayCnt()");
	n=AS.GetArrayCnt();
	out.prt("->n=%",n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)AS[%]=\"%\"",i,(char*)AS[i]);
		out.prt(" ,AS.GetIdx(AS[%])=%",i,AS.GetIdx(AS[i]));
		out.prt(" ,AS.GetStr(%)=\"%\"",i,AS.GetStr(i));
	}
	out.prt("\nAS.List()=\"%\"",AS.List());
	out.prt("\nAS.ListRev(';')=\"%\"",AS.ListRev(';'));

	out.prt("\n\nAS+=S;  (char*)S=\'%\"",(char*)S);
	AS+=S;
	out.prt("\nn=AS.GetArrayCnt()");
	n=AS.GetArrayCnt();
	out.prt("->n=%",n);
	for(i=0;i<n;i++) {
		out.prt("\n(char*)AS[%]=\"%\"",i,(char*)AS[i]);
		out.prt(" ,AS.GetIdx(AS[%])=%",i,AS.GetIdx(AS[i]));
		out.prt(" ,AS.GetStr(%)=\"%\"",i,AS.GetStr(i));
	}
	out.prt("\nAS.List()=\"%\"",AS.List());
	out.prt("\nAS.ListRev(';')=\"%\"",AS.ListRev(';'));

	out.prt("\n\nArrayStr AS1(AS);");
	ArrayStr AS1(AS);
	out.prt("\nAS1.GetArrayCnt()=%",AS1.GetArrayCnt());
	out.prt("\nAS1.List()=\"%\"",AS1.List());

	i=0; out.prt("\nAS1.DelByIdx(%);",i);
	AS1.DelByIdx(i);
	out.prt("\nAS1.GetArrayCnt()=%",AS1.GetArrayCnt());
	out.prt("\nAS1.List()=\"%\"",AS1.List());

	i=AS1.GetArrayCnt()-1; out.prt("\nAS1.DelByIdx(%)",i);
	AS1.DelByIdx(i);
	out.prt("\nAS1.GetArrayCnt()=%",AS1.GetArrayCnt());
	out.prt("\nAS1.List()=\"%\"",AS1.List());

	out.prt("\n\nAS1+=AS;");
	AS1+=AS;
	out.prt("\nAS1.GetArrayCnt()=%",AS1.GetArrayCnt());
	out.prt("\nAS1.List()=\"%\"",AS1.List());

	out.prt("\n\nAS1=AS;");
	AS1=AS;
	out.prt("\nAS1.GetArrayCnt()=%",AS1.GetArrayCnt());
	out.prt("\nAS1.List()=\"%\"",AS1.List());

	out.prt("\n\nAS1=AS1;");
	AS1=AS1;
	out.prt("\nAS1.GetArrayCnt()=%",AS1.GetArrayCnt());
	out.prt("\nAS1.List()=\"%\"",AS1.List());

	out.prt("\n\nAS1+=AS1;");
	AS1+=AS1;
	out.prt("\nAS1.GetArrayCnt()=%",AS1.GetArrayCnt());
	out.prt("\nAS1.List()=\"%\"",AS1.List());

	return 0;
}
