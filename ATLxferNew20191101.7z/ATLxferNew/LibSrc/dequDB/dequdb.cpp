#include "dequdb.h"

static MyStr TmpStr;

void ReleaseDSLINK(DSLINK **p) {
//printf("\nReleaseDSLINK(*p=%u)",*p);
	while(*p!=NULL) { 
//printf("..*p=%u",*p);
		DSLINK *t=*p;
		*p=(*p)->nxt;
		delete t;
	}
//printf("..Last *p=%u",*p);
}


void AddExchgLineCmtWithExSymBlk(MyStr &LL,ArrayNameStr &Exchg) {
	PO2 pp;
	pp.p1=LL.InStrExSymBlk(_DEQULCMT,_DEQUSYMA);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		pp.p2=LL.InStrExSymBlk(pp.p1,"\n",_DEQUSYMA);
		MyStr T(_DEQU_ExKeyS); T+="cl"; T+=n; T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2-1));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp.p1=LL.InStrExSymBlk(_DEQULCMT,_DEQUSYMA);
	}
}
void AddExchgSymChrCmtWithExSymBlk(MyStr &LL,ArrayNameStr &Exchg) {
	PO2 pp;
	pp.p1=LL.InStrExSymBlk(_DEQUCMTC,_DEQUSYMA);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		pp.p2=pp.p1+1;
		MyStr T(_DEQU_ExKeyS); T+="cc"; T+=n; T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp.p1=LL.InStrExSymBlk(_DEQUCMTC,_DEQUSYMA);
	}
}
void AddExchgSymBlk(MyStr &LL,ArrayNameStr &Exchg) {
	AddExchgSymBlkS(LL,Exchg);
	AddExchgSymBlkU(LL,Exchg);
}
void AddExchgSymBlkS(MyStr &LL,ArrayNameStr &Exchg) {
	PO2 pp;
	pp=LL.SymBlkIdxInStr(0,-1,_DEQUSYMS);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		MyStr T(_DEQU_ExKeyS); T+="sm"; T+=n; T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp=LL.SymBlkIdxInStr(0,-1,_DEQUSYMS);
	}
}
void AddExchgSymBlkU(MyStr &LL,ArrayNameStr &Exchg) {
	PO2 pp;
	pp=LL.SymBlkIdxInStr(0,-1,_DEQUSYMU);
	while(pp.p1>-1) {
		int n=Exchg.GetArrayCnt();
		MyStr T(_DEQU_ExKeyS); T+="um"; T+=n; T+=_DEQU_ExKeyE;
		NameStr NS(T,LL.GetRangeByIdx(pp.p1,pp.p2));
		Exchg+=NS;
		LL=LL.GetRangeWithWdChg((char*)NS,(char*)T);
		pp=LL.SymBlkIdxInStr(0,-1,_DEQUSYMU);
	}
}
const char *GetUnExchgStrByExkey(MyStr &LL,ArrayNameStr &Exchg,const char *Exkey) {
	TmpStr=LL; MyStr K(Exkey);
	if((int)K>0) {
		for(int n=Exchg.GetArrayCnt()-1;n>-1;n--) {
			if(WdIdxInStr(Exchg[n].GetName(),(char*)K)>-1)
				TmpStr=TmpStr.GetRangeWithWdChg(Exchg.GetNameByIdx(n),(char*)Exchg[n]);
		}
	} else {
		for(int n=Exchg.GetArrayCnt()-1;n>-1;n--) {
			TmpStr=TmpStr.GetRangeWithWdChg(Exchg.GetNameByIdx(n),(char*)Exchg[n]);
		}
	}
	return (char*)TmpStr;
}
int CheckExkeyInside(MyStr &LL,const char *exkey) {
	MyStr K(exkey); if((int)K<1) return -1; else return LL.InStr(K); 
}
const char *GetLineCmtUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { MyStr K(_DEQU_ExKeyS); K+="cl"; return GetUnExchgStrByExkey(LL,Exchg,(char*)K); }
const char *GetSymChrCmtUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { MyStr K(_DEQU_ExKeyS); K+="cc"; return GetUnExchgStrByExkey(LL,Exchg,(char*)K); }
const char *GetSymBlkSUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { MyStr K(_DEQU_ExKeyS); K+="sm"; return GetUnExchgStrByExkey(LL,Exchg,(char*)K); }
const char *GetSymBlkUUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { MyStr K(_DEQU_ExKeyS); K+="um"; return GetUnExchgStrByExkey(LL,Exchg,(char*)K); }
const char *GetSymBlkUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { 
	MyStr K,S(LL);
	K=_DEQU_ExKeyS; K+="sm";
	S=GetUnExchgStrByExkey(S,Exchg,(char*)K);
	K=_DEQU_ExKeyS; K+="um";
	return GetUnExchgStrByExkey(S,Exchg,(char*)K); 
}

const char *GetAllUnExchgStr(MyStr &LL,ArrayNameStr &Exchg) { return GetUnExchgStrByExkey(LL,Exchg,""); }

//##################################################################
//				SDequ	SDequ	SDequ	SDequ	
//##################################################################

void SDequ::Reset(void) { NameArrayStr::Reset(); BDY=""; }
SDequ& SDequ::operator=(SDequ &SD) { NameArrayStr::operator=((NameArrayStr&)SD); BDY=SD.BDY; return *this; }

//##################################################################
//				Dequ	Dequ	Dequ	Dequ	
//##################################################################
Dequ::Dequ() {}
Dequ::Dequ(Dequ &DQ) { Dequ::operator=(DQ); }

Dequ& Dequ::operator=(Dequ &DQ) { 
	SDequ::operator=((SDequ&)DQ); 
	Exchg=DQ.Exchg;
	return *this;
}

void Dequ::Reset(void) {
	SDequ::Reset(); Exchg.Reset(); BDY="";
}

int Dequ::GetParaCnt(void) { return GetArrayCnt(); }
const char *Dequ::GetParaList(void) { return List(','); }
const char *Dequ::GetBody(void) { return (char*)BDY; }

void Dequ::ExchgAddLineCmt(MyStr &LL) 				{ return AddExchgLineCmtWithExSymBlk(LL,Exchg); }
void Dequ::ExchgAddSymChrCmt(MyStr &LL) 			{ return AddExchgSymChrCmtWithExSymBlk(LL,Exchg); }
void Dequ::ExchgAddSymBlk(MyStr &LL) 				{ return AddExchgSymBlk(LL,Exchg); }

const char *Dequ::GetUnExchgAll(MyStr &LL) 			{ return GetAllUnExchgStr(LL,Exchg); }

PO2  Dequ::GetPointOfDequContents(MyStr &LL) {
	PO2 pp=LL.GetPointOfStackPairKey(_DEQUKEY,_DEQUBDYED);
	return pp;
}

int Dequ::IsExchgInStr(MyStr &LL) { return CheckExkeyInside(LL,_DEQU_ExKeyS); }

DequCode Dequ::IsWellName(MyStr &NM) {
	if((int)NM>0 && IsExchgInStr(NM)<0) {
		if(NM.LowerCaseInside()>0) return _well;
		for(int n=0;n<(int)NM;n++) {
			if(WdIdxInStr(_DEQUNAME_exack_chars,NM[n])>-1) return _well;
		}
		return _err_namerule;
	}
	return _err_name;
}

DequCode Dequ::IsWellContents(MyStr &LL) {
	ArrayNameStr TmpExchg;
	MyStr FF(LL);
	//--------------------------------------------------------------------
	AddExchgLineCmtWithExSymBlk(FF,TmpExchg);
	AddExchgSymChrCmtWithExSymBlk(FF,TmpExchg);
	AddExchgSymBlk(FF,TmpExchg);
	PO2 pp=GetPointOfDequContents(FF);
	if(pp.p1<0) return _none;			//error format : no #dequ found
	if(pp.p2<0) return _err_body;		//error format : no }} found
	//--------------------------------------------------------------------
	FF=FF.GetRangeByIdx(pp.p1,pp.p2);
	FF=FF.GetRangeWithWdChg('\t',' ');
	MyStr T(_DEQUKEY); T+=' ';
	int p=FF.InStr(T);
	if(p<0) return _err_name;			//error format :  #dequ+<space> or #dequ+<tab>
	//--------------------------------------------------------------------
	p+=(int)T;
	FF=FF.GetRangeByIdx(p,(int)FF-strlen(_DEQUBDYED)-1);
	FF=FF.GetLineTrim();
	
	int k=FF.InStr(_DEQUBDYST);
	if(k<0) return _err_body;						//error format : '{{' missing
	if(k<1) return _err_name;						//error format : NAME missing

	MyStr PA,BDY;
	int q1=FF.InStr(-1,k-1,_DEQUPARST);
	int q2=FF.InStr(-1,k-1,_DEQUPARED);
	//--------------------------------------------------------------------
	if(q1>-1 && q2<0) 	return _err_para;			//error format : parameter > missing before {{
	if(q1<0  && q2>-1) 	return _err_para;			//error format : parameter < missing before {{
	if(q1>-1) { 
		T=FF.GetRangeByIdx(-1,q1-1);
		PA=FF.GetRangeByIdx(q1+1,q2-1);
		PA=PA.GetLineTrimA();
	} else T=FF.GetRangeByIdx(-1,k-1); 
	T=T.GetTrim();
	//--------------------------------------------------------------------
	DequCode r=IsWellName(T);
	if(r!=_well) return r;							//error format : NAME MUST w/i LowCase or exack chars
	//--------------------------------------------------------------------
	if(IsExchgInStr(PA)>-1) return _err_para;			//error format : Parameters w/i Exchg contents
	//--------------------------------------------------------------------
	k+=strlen(_DEQUBDYST);
	BDY=FF.GetRangeByIdx(k,-1);
	BDY=BDY.GetLineTrim();
	BDY=GetAllUnExchgStr(BDY,TmpExchg);
	//--------------------------------------------------------------------	
	pp=GetPointOfDequContents(BDY);
	if(pp.p1<0 && pp.p2<0) return _well;
	if(pp.p1>-1 && pp.p2>pp.p1) return IsWellContents(BDY);
	return _err_body;								//error format : bad #dequ inside
}


DequCode Dequ::ContentsToDequ(MyStr &InputStr,MyStr &OutputStr,Dequ &ODQ) {
//printf("\n#InputStr=[%s]",(char*)InputStr);
	ODQ.Reset();	MyStr FF(InputStr);	
	//--------------------------------------------------------------------
	AddExchgLineCmtWithExSymBlk(FF,ODQ.Exchg);
	AddExchgSymChrCmtWithExSymBlk(FF,ODQ.Exchg);
	AddExchgSymBlk(FF,ODQ.Exchg);
	PO2 pp=GetPointOfDequContents(FF);
//printf("\npp.p1=%d pp.p2=%d",pp.p1,pp.p2);
	if(pp.p1<0) return _none;		//error format : no #dequ found
	if(pp.p2<0) return _err_body;	//error format : no }} found
	//--------------------------------------------------------------------
	if(pp.p1>0)	OutputStr=FF.GetRangeByIdx(-1,pp.p1-1);
	MyStr T;
	int x=FF.InStr(pp.p2,'\n');
	if(x>0) {
		T=FF.GetRangeByIdx(pp.p2+1,x);
		T=T.GetTrim();
		if((int)T>0) 	OutputStr+=FF.GetRangeByIdx(pp.p2+1,-1);
		else			OutputStr+=FF.GetRangeByIdx(x+1,-1);
	}
	OutputStr=GetAllUnExchgStr(OutputStr,ODQ.Exchg);
//printf("\n#OutputStr=[%s]",(char*)OutputStr);
	//--------------------------------------------------------------------
	FF=FF.GetRangeByIdx(pp.p1,pp.p2);
	MyStr S(FF.GetRangeWithWdChg('\t',' '));
	T=_DEQUKEY; T+=' ';
	int p=S.InStr(T);
	if(p<0) return _err_name;			//error format :  #dequ+<space> or #dequ+<tab>
	//--------------------------------------------------------------------
	p+=(int)T;
	FF=FF.GetRangeByIdx(p,(int)FF-strlen(_DEQUBDYED)-1);
//	FF=FF.GetLineTrim();

	int k=FF.InStr(_DEQUBDYST);
	if(k<0) return _err_body;						//error format : '{{' missing

	MyStr PA;
	int q1=FF.InStr(-1,k-1,_DEQUPARST);
	int q2=FF.InStr(-1,k-1,_DEQUPARED);
	//--------------------------------------------------------------------
	if(q1>-1 && q2<0) 	return _err_para;			//error format : parameter > missing before {{
	if(q1<0  && q2>-1) 	return _err_para;			//error format : parameter < missing before {{
	if(q1>-1) { 
		S=FF.GetRangeByIdx(-1,q1-1); S=S.GetTrim();
		PA=FF.GetRangeByIdx(q1+1,q2-1);
	} else {
		S=FF.GetRangeByIdx(-1,k-1); S=S.GetTrim();
	}
	//--------------------------------------------------------------------
	DequCode r=IsWellName(S);
	if(r!=_well) return r;	//error format : NAME MUST w/i LowCase or exack chars
	ODQ.SetName(S);
	//--------------------------------------------------------------------
	if(IsExchgInStr(PA)>-1) return _err_para;			//error format : Parameters w/i Exchg contents
	//--------------------------------------------------------------------
	k+=strlen(_DEQUBDYST);
	ODQ.BDY=FF.GetRangeByIdx(k,-1);
//	ODQ.BDY=ODQ.BDY.GetLineTrim();
//printf("\n#BDY=[%s]",(char*)ODQ.BDY);
	q1=ODQ.BDY.InStr('\n');
	if(q1>-1) {
		S=ODQ.BDY.GetRangeByIdx(-1,q1); S=S.GetTrim();
		if((int)S<1) ODQ.BDY=ODQ.BDY.GetRangeByIdx(q1+1,-1);
	}
	ODQ.BDY=GetAllUnExchgStr(ODQ.BDY,ODQ.Exchg);
	//--------------------------------------------------------------------	
//printf("\n#PA=[%s]",(char*)PA);
//printf("->#BDY=[%s]",(char*)ODQ.BDY);
	if((int)PA>0) {
		PA+=","; k=0; q1=0;
		p=PA.InStr(k,",");
		while(p>-1) {
			q1++;
			if(p>0) {
				S=PA.GetRangeByIdx(k,p-1);
				S=S.GetTrim();
				if((int)S<1) S=q1;
			} else	S=q1;
			ODQ+=S;
			k=p+1;
			p=PA.InStr(k,",");
		}
	}
	//--------------------------------------------------------------------	
	pp=GetPointOfDequContents(ODQ.BDY);
	if(pp.p1<0 && pp.p2<0) return _well;
	if(pp.p1>-1 && pp.p2>pp.p1) return IsWellContents(ODQ.BDY);
	return _err_body;								//error format : bad #dequ inside
}

DequCode Dequ::Setup(MyStr &LL) {
	Dequ ODQ; MyStr OutS;
	DequCode rcode=ContentsToDequ(LL,OutS,ODQ);
	if(rcode==_well) { operator=(ODQ);  LL=OutS; }
	return rcode;
}

const char *Dequ::GetErrMessage(DequCode r){
	switch (r) {
		case _well:
			tmp="";
			break;
		case _none:
			tmp="No DEQU defintion !";
			break;
		case _err_name:
			tmp="! Error : bad DEQU name format !";
			break;
		case _err_namerule:
			tmp="! Error : DEQU name rule (w/o lcase or exack chars) !";
			break;
		case _err_para:
			tmp="! Error : DEQU parameter < > missing !";
			break;
		case _err_body:
			tmp="! Error : DEQU body {{ }} missing !";
			break;
		default:
			tmp="! Error : Unknow DEQU format problem !";
			break;
	}
	return (char*)tmp;
}

//####################################################################
//#		DEQU_DB
//####################################################################
DEQU_DB::DEQU_DB(const char *dbfname) { DBfile=dbfname; CNT=0; DBP=NULL; }
//DEQU_DB::DEQU_DB(const char *dbfname,ODequ& DD) { DBfile=dbfname; CNT=0; DBP=NULL; Add(DD); }
DEQU_DB::~DEQU_DB() { ReleaseDBP(); }

//===================================================
int DEQU_DB::GetCNT(void) {return CNT; }
const char* DEQU_DB::GetDBfile(void) {return (char*)DBfile; }

//===================================================
void DEQU_DB::ReleaseDBP(void) {
	while(DBP!=NULL) {
		DQLINK *tp=DBP;
		DBP=DBP->nxt;
		delete tp;
		CNT--;
	}
}
//===================================================
int DEQU_DB::Add(Dequ& DQ) {
//printf("\nDEQU_DB::Add('%s')",DQ.GetName());
//printf("PARN=%d Para='%s')\n",DQ.GetParaCnt(),DQ.GetParaList());
	MyStr T(DQ.GetName());
	if(T=="") { printf("\n!!! Warning : request DEQU_DB.Add(NULL) !!!\n"); return 0; }
	
	T=DEQU_Inside(T);
	if(T==DQ.GetName()) { printf("\n!!! Error : reject one more DEQU_DB.Add(%s) !!!\n",(char*)T); return -1; }
	
	CNT++;
	DQLINK *dp = new DQLINK;
	dp->SN=CNT;
	dp->NAME=DQ.GetName();
	dp->PARN=DQ.GetParaCnt();
	dp->nxt=NULL;
	if(DBP==NULL) DBP=dp;
	else {
		//******** FIFO *********		
		//DQLINK *tp=DBP;
		//while(tp->nxt!=NULL) tp=tp->nxt;
		//tp->nxt=dp;
		//******** LIFO *********
		dp->nxt=DBP;
		DBP=dp;
	}
	
	if(CNT==1) 	T="w";
    else 		T="a";
    
    FILE *fp=fopen((char*)DBfile,(char*)T);
	if(fp==NULL) {
		printf("\n!!! Error : Open '%s' for write(%s) fail !!!\n",(char*)DBfile,(char*)T);
		return -1;
	}
	//---------------------------------------------
	//	File write new ODequ macro
	//---------------------------------------------
	int mxlen=DEQU_DB_MaxLineLen;
	MyStr B(DQ.GetBody());
	//================================================
	int n;	
	for(n=0;n<DBP->PARN;n++) {
		T=_DEQUBDYVPAST;
		T+=DQ[n];
		T+=_DEQUBDYVPAED;
		MyStr N(_DEQUBDYVPAST);
		N+=(n+1);
		N+=_DEQUBDYVPAED;
		B=B.GetRangeWithWdChg((char*)T,(char*)N);
	}
	//================================================
	B=B.GetRangeWithWdChg("\n","\\n");
//printf("\nName(%s),body[%s]",DQ.GetName(),(char*)B);
	int l=(int)B;
	n=0;
	while(l>mxlen) { n++; l-=mxlen;}
	if(l>0) n++;
	fprintf(fp,"_{%s}_(%d)_[%d]_<%s>_@%s@_$%d$_\n",(char*)DBP->NAME,DBP->PARN,n,DQ.GetParaList(),_dequFmtVer_,DBP->SN);
	for(l=1;l<n;l++) fprintf(fp,"%s\n",B.GetRangeByIdx((l-1)*mxlen,(l-1)*mxlen+mxlen-1));
	fprintf(fp,"%s\n",B.GetRangeByIdx((n-1)*mxlen,-1));
	//---------------------------------------------
	fclose(fp);
	return CNT;
}
//===================================================
int DEQU_DB::GetDEQUSeqN(const char *dequname) {
	MyStr DQ(dequname);
	if(CNT>0 || (int)DQ>0) {
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			if(dp->NAME==DQ) return dp->SN;
			dp=dp->nxt;
		}
	}
	return -1;
}
//===================================================
int DEQU_DB::SearchDEQUparN(const char *dequname) {
	MyStr DQ(dequname);
	if(CNT>0 || (int)DQ>0) {
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			if(dp->NAME==DQ) return dp->PARN;
			dp=dp->nxt;
		}
	}
	return -1;
}
//===================================================
const char*  DEQU_DB::GetDEQUnameByDBIdx(const int si) {
	TMP="";
	if(CNT>0 && si>-1 && si<CNT) {
		int n=-1;
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			n++;
			if(n==si) { TMP=dp->NAME; break; }
			dp=dp->nxt;
		}
	}
	return (char*)TMP;
}
//===================================================
const char* DEQU_DB::DEQU_Inside(const char *line) {MyStr LL(line); return DEQU_Inside(LL); }
const char* DEQU_DB::DEQU_Inside(MyStr &LL) {
	TMP="";
	MyStr S(LL.GetLineDelByKeyExSymBlk(_DEQULCMT,"",_DEQUSYMS));
	int n=-1;
	int l=-1;
	
	if(CNT>0 || (int)S>0) {
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			int p=S.InStr((char*)dp->NAME);
			int x=(int)dp->NAME;
			if(p>-1) {
				if(n<0 || p<n || (p==n && x>l) ) { n=p; TMP=dp->NAME; l=x; }
			}
			dp=dp->nxt;
		}
	}
	return (char*)TMP;
}
//===================================================
const char *DEQU_DB::GetDEQUdefParaInDB(const char *dequname) {
	TMP="";
	int sq=GetDEQUSeqN(dequname);
	if(sq<1) return (char*)TMP;
	FILE *fp;
	char line[DEQU_DB_MaxLineLen+5];
	if((fp=fopen((char*)DBfile,"r"))==NULL) {
		printf("\n!!! Error : Open '%s' for read fail !!!\n",(char*)DBfile);
		return (char*)TMP;
	}
	MyStr DQ("_{");
	DQ+=dequname;
	DQ+="}_";
	while(1) {
		if(fgets(line,DEQU_DB_MaxLineLen+2,fp)==NULL) break;
		MyStr LL(line);
		int s=atoi(LL.GetRangeBtwKey("_$","$_"));
		if(LL.InStr((char*)DQ)>-1 && s==sq) { TMP=LL.GetRangeBtwKey("_<",">_"); break; }
	}
	fclose(fp);
	return (char*)TMP;
}
//===================================================
const char *DEQU_DB::GetDEQUbodyInDB(const char *dequname) {
	TMP="";
	int sq=GetDEQUSeqN(dequname);
//printf("\ndequname[%s],Seq[%d]",dequname,sq);
	if(sq<1) return (char*)TMP;
	FILE *fp;
	char line[DEQU_DB_MaxLineLen+5];
	if((fp=fopen((char*)DBfile,"r"))==NULL) {
		printf("\n!!! Error : Open '%s' for read fail !!!\n",(char*)DBfile);
		return (char*)TMP;
	}
	MyStr DQ("_{");
	DQ+=dequname;
	DQ+="}_";
	while(1) {
		if(fgets(line,DEQU_DB_MaxLineLen+2,fp)==NULL) { fclose(fp); break; }
		MyStr LL(line);
		int s=atoi(LL.GetRangeBtwKey("_$","$_"));
//printf("\nLL[%s],s[%d]",(char*)LL,s);
		if(LL.InStr((char*)DQ)>-1 && s==sq) {
//printf("\nline='%s'",line);
			int n=atoi(LL.GetRangeBtwKey("_[","]_"));
//printf(" => LL='%s' , n=%d",(char*)LL,n);
			LL="";
			for(int x=0;x<n;x++) {
				if(fgets(line,DEQU_DB_MaxLineLen+2,fp)==NULL) break;
//printf("\n>> line='%s'",line);
				LL+=line;
			}
			fclose(fp);
//printf("\n##>LL='%s'",(char*)LL);
			LL=LL.GetRangeWithWdDel('\n');
			TMP=LL.GetRangeWithWdChg("\\n","\n");
			break;
		}
	}
	return (char*)TMP;
}
//===================================================
const char *DEQU_DB::DEQU_xfer(const char *line) {
	MyStr BDY,LS,LE,PX;
	MyStr LL(line);
	MyStr NM(DEQU_Inside((char*)LL));

	MyStr SYMS(_DEQUSYMS);
//	MyStr SYMA(_DEQUSYMA);

//printf("\n#>LL=[%s]",(char*)LL);
//printf("\n#>NM=[%s]",(char*)NM);
	
	if(NM!="") {
		BDY=GetDEQUbodyInDB((char*)NM);
		BDY=BDY.GetTrim();
		
		//MyStr PA(PickupLineDequPara(LL,NM,SYMA,LS,LE));
		MyStr PA(PickupLineDequPara(LL,NM,SYMS,LS,LE));
		if(PA!="") {
//printf("\n##>PA=[%s]",(char*)PA);
			MyStr PAC(PA.GetRangeWithSpDelExSymBlk(_DEQUSYMA));
			if(PAC!="") { 
				PA+=',';
				int c=SearchDEQUparN((char*)NM);
				//int s=0;
				for(int a=0;a<c;a++) {
					PX=ParaAnalyze(PA,_DEQUSYMA);
//printf("\n##>PX[%d]=[%s]\n>>>PA=[%s]",a+1,(char*)PX,(char*)PA);
					PX=PX.GetLineTrimExSymBlk(_DEQUSYMA);
					MyStr NX('$');
					NX+=(a+1);
					NX+='$';
					BDY=BDY.GetRangeWithWdChg((char*)NX,(char*)PX);
//printf("\n##>BDY=[%s]",(char*)BDY);
				}
			}
		}
//printf("\n###>LS 1 =[%s]",(char*)LS);
		LS+=BDY;
//printf("\n###>LS 2 =[%s]",(char*)LS);
		LS+=LE;
		LS=LS.GetDos2Unix();
//printf("\n###>LS 3 =[%s]",(char*)LS);
		return DEQU_xfer((char*)LS);
	}
//printf("\n####>LL=[%s]",(char*)LL);

	NM=_DEQUSYMX;
	int n=(int)NM;
	if(n>0) {
		LS="";
		int k=0;
		PO2 PS=LL.SymBlkIdxInStr(k,-1,_DEQUSYMS);
		while(PS.p1>-1) {
			if(PS.p1>k) { LE=LL.GetRangeByIdx(k,PS.p1-1); LS+=LE.GetRangeWithDelBlkSymChr(-1,-1,_DEQUSYMX); }
			LE=LL.GetRangeByIdx(PS.p1,PS.p2);
			LS+=LE.GetRangeWithDelBlkSymChr(_DEQUSYMX);
			k=PS.p2+1;
			PS=LL.SymBlkIdxInStr(k,-1,_DEQUSYMS);
		}
		if(k<(int)LL) {
			LE=LL.GetRangeByIdx(k,-1);
			LS+=LE.GetRangeWithDelBlkSymChr(_DEQUSYMX);
		}
		PS=LS.SymBlkIdxInStr(-1,-1,_DEQUSYMX);
		if(PS.p1>-1) 	return DEQU_xfer((char*)LS);
	} else LS=LL;

//	TMP=LS.GetRangeWithDelSpLine();
	TMP=LS;
	
	return (char*)TMP;
}

//===================================================
const char *DEQU_DB::PickupLineDequPara(MyStr &LL,MyStr &DEQNM,MyStr &SYM,MyStr &LS,MyStr &LE) {
	LS="";
	LE="";
	MyStr T;
	int n=LL.InStrExSymBlk((char*)DEQNM,(char*)SYM);

//printf("\n**>DEQNM=[%s] n=%d LL=[%s]",(char*)DEQNM,n,(char*)LL);	
	if(n>-1) { 
		if(n>0) LS=LL.GetRangeByIdx(-1,n-1);
		int sp=n+(int)DEQNM;
	
		MyStr NM(_DEQUPARED);
		int lpaed=(int)NM;
		NM=_DEQUPARST;
		int lpast=(int)NM;
		
		int a=LL.InStrExSymBlk(sp,_DEQUPARST,(char*)SYM);
		NM=LL.GetRangeByIdx(sp,a-1);
		NM=NM.GetTrim();

		int b=sp;
		
//printf("\n**>sp=%d a=%d LS=[%s]",sp,a,(char*)LS);	
		if(a>-1 && (int)NM==0) { 
			sp=a+lpast;	
			int b=LL.InStrExSymBlk(sp,_DEQUPARED,(char*)SYM);
			int x=LL.InStrExSymBlk(sp,_DEQUPARST,(char*)SYM);
//printf("\n**>sp=%d b=%d x=%d",sp,b,x);	
			while(x>-1 && x<b) {
				sp=b+lpaed;
				b=LL.InStrExSymBlk(sp,_DEQUPARED,(char*)SYM);
				x=LL.InStrExSymBlk(sp,_DEQUPARST,(char*)SYM);
//printf("\n**>sp=%d b=%d x=%d",sp,b,x);	
			}
			if(b>0) {
				T=LL.GetRangeByIdx(a+lpast,b-1);
				sp=b+lpaed;
			}
		}
		LE=LL.GetRangeByIdx(sp,-1);
//printf("\n**>LE=[%s]",(char*)LE);	

	}
//printf("\n**>LS=[%s]",(char*)LS);	
//printf("\n**>T=[%s]",(char*)T);	
//printf("\n**>LE=[%s]",(char*)LE);	

	TMP=T;
    return (char*)TMP;
}
//===================================================
const char *DEQU_DB::ParaAnalyze(MyStr &PA,const char *sym) { MyStr SYM(sym); return ParaAnalyze(PA,SYM); }
const char *DEQU_DB::ParaAnalyze(MyStr &PA,MyStr &SYM) {
	MyStr PX(_DEQUPARED);
	int lpaed=(int)PX;
	PX=_DEQUPARST;
	int lpast=(int)PX;
//printf("\n*>ParaAnalyze: PA=[%s],SYM=[%s]",(char*)PA,(char*)SYM);
	MyStr T;
	MyStr PAC(PA.GetRangeWithSpDelExSymBlk((char*)SYM));
	if(PAC!="") {
		int s=0;
		int p=PA.InStrExSymBlk(s,",",(char*)SYM);
		int x=PA.InStrExSymBlk(s,_DEQUPARST,(char*)SYM);
//printf("\n*> 1 s=%d p=%d x=%d",s,p,x);
		while(x>-1 && x<p) {
			s=x+lpast;
			int y=PA.InStrExSymBlk(s,-1,_DEQUPARED,(char*)SYM);
			int k=PA.InStrExSymBlk(s,y-1,_DEQUPARST,(char*)SYM);
//printf("\n*> 2 s=%d y=%d k=%d",s,y,k);
			while(y>-1) {
//printf("\n*> 3 s=%d y=%d k=%d",s,y,k);
				s=y+lpaed;
				if(k>-1) {
					y=PA.InStrExSymBlk(s,-1,_DEQUPARED,(char*)SYM);
					k=PA.InStrExSymBlk(s,y-1,_DEQUPARST,(char*)SYM);
				} else y=-1;
			}
			p=PA.InStrExSymBlk(s,",",(char*)SYM);
			x=PA.InStrExSymBlk(s,_DEQUPARST,(char*)SYM);
//printf("\n*> 4 s=%d p=%d",s,p);
		}
		if(p>0) T=PA.GetRangeByIdx(-1,p-1);  
//printf("\n*>T=[%s]",(char*)T);
		PA=PA.GetRangeByIdx(p+1,-1);
    }
    TMP=T;
    return (char*)TMP;
}

int DEQU_DB::DB_foutput(const char *filename) {
	
	MyStr FIL(filename);

	FILE *fp=fopen((char*)FIL,"w");
	if(fp==NULL) {
		printf("\n!!! Error : Open '%s' for write fail !!!\n",(char*)FIL);
		return -1;
	}
	
	if(DBP==NULL) { fclose(fp);  return 0; }
	
    MyStr T,PA,PX,BDY;
	int k , l=0;
	DQLINK *dp;
	DSLINK *ppa,*ppx;			

	//================ list ====================
	for(int n=0;n<CNT;n++) {
		T="";
		dp=DBP;
		while(dp!=NULL) {
			if(dp->SN==(n+1)) {
				T+=dp->NAME+_DEQUPARST;
				if(dp->PARN>0) T+=GetDEQUdefParaInDB((char*)dp->NAME);
				T+=_DEQUPARED;
				break;
			}
			dp=dp->nxt;
		}
		l++;
		fprintf(fp,"; %s\n",(char*)T);
	}

	//================= Declare & body =====================
	fprintf(fp,"\n");
				
	for(int n=0;n<CNT;n++) {		
		T=_DEQUKEY;
		T+=" ";
		dp=DBP;
		while(dp!=NULL) {
//printf("\n%s(%d) n=%d",(char*)dp->NAME,dp->SN,n);
			if(dp->SN==(n+1)) {
//printf("\n[%s]<",(char*)dp->NAME);
				ppa=NULL;
				T+=dp->NAME+_DEQUPARST;
				if(dp->PARN>0) {
					PA=GetDEQUdefParaInDB((char*)dp->NAME);
					T+=PA;
					//-----------------------------------
//printf("%s>",(char*)PA);
					PA+=",";
					k=0;
					int p=PA.InStr(k,',');
					while(p>-1) { 
						DSLINK *pd=new DSLINK;
						if(p>k) pd->data=PA.GetRangeByIdx(k,p-1);
						else	pd->data="";
						pd->nxt=NULL;
						if(ppa==NULL)  	ppa=pd;
						else			ppx->nxt=pd;
//printf(" %s",(char*)pd->data);
						ppx=pd;  k=p+1;
						p=PA.InStr(k,',');
					}
					//-----------------------------------
				}
//printf(">");
				T+=_DEQUPARED;
				break;
			}
			dp=dp->nxt;
		}
		//============================================

		T+=" ";
		T+=_DEQUBDYST;
		fprintf(fp,"%s",(char*)T);
		T=GetDEQUbodyInDB((char*)dp->NAME);

//printf("\n[%s]{{%s}}\n",(char*)dp->NAME,(char*)T);
		ppx=ppa; 
		k=1;
		while(ppx!=NULL) {
			PA="$"; PA+=k; PA+="$";
			PX="$"; PX+=ppx->data; PX+="$";
//printf("%d[%s]->[%s] ",k,(char*)PA,(char*)PX);
			T=T.GetRangeWithWdChg((char*)PA,(char*)PX);
			k++;
			ppx=ppx->nxt;
		}
		T+=_DEQUBDYED;
//printf("\n>>[%s]%s\n",(char*)dp->NAME,(char*)T);
		fprintf(fp,"%s\n",(char*)T);

		//============================================
		ReleaseDSLINK(&ppa);
	}
	
	fprintf(fp,"\n");
	
	fclose(fp);
	return l;
}

