# mycpp
my c++ works
home environment : MinGw , mingw32-make.exe

