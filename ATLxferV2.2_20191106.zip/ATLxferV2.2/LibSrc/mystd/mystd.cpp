
#include "mystd.h"

//namespace mystd {

tout& tout::operator<<(const int i)		{ std::cout<<i; return *this; }
tout& tout::operator<<(const long l)	{ std::cout<<l; return *this; }
tout& tout::operator<<(const char *s)	{ if(s!=NULL) std::cout<<s; else std::cout<<"(null)"; return *this; }
tout& tout::operator<<(const char c)	{ std::cout<<c; return *this; }
tout& tout::operator<<(MyStr &S)			{ std::cout<<(char*)S; return *this; }
tout& tout::operator<<(NameStr &NS)		{ std::cout<<(char*)NS; return *this; }

void tout::prt(const char *format) {
	MyStr S(format);
	S=S.GetRangeWithWdChg("/%","%");
	std::cout << (char*)S; 
}

/*
template<typename T1, typename... Targs1>
void tout::prt(const char* format, T1 value, Targs1... Fargs)
{
//	MyStr S(format);
//	if((int)S>0) {
//		int p=S.InStr('%');
//		if(p<0){ std::cout << (char*)S; return; }
//		if(p>0) {
//			if(S[p-1]=='/') {
//				if(p>1) std::cout << S.GetRangeByIdx(0,p-2);
//				std::cout << S[p];
//				return tout::prt(format+p+1,value,Fargs...);
//			}
//			std::cout << S.GetRangeByIdx(0,p-1);
//		}
//		std::cout << value;
//		return tout::prt(format+p+1,Fargs...);
//	}
 	for (;*format != '\0'; format++){
 		if(*format=='/' && *(format+1)=='%') { 
 			std::cout<<*(format+1); 
 			return tout::prt(format+2,value,Fargs...); 
 		}
 		else if(*format=='%') { 
 			std::cout<< value;
 			return tout::prt(format+1,Fargs...); 
 		}
 		std::cout<<*format;
 	}
}
*/

//} // namespace mystd
