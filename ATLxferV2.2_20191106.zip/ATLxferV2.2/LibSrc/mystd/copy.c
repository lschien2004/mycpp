#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(int ac,char **av) {
	if(ac<3) return -1;
	char line[256];
	for(int n=1;n<(ac-1);n++) {
		sprintf(line,"copy %s %s",av[n],av[ac-1]);
		system(line);
	}
	return 0;
}
