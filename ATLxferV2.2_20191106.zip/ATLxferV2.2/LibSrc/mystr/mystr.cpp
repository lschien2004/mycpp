
#include "mystr.h"
//#######################################################################################################################
int WdIdxInStr(const int si,const int ei,const char *str,const char *word) {
    int wl=-1;
    int ll=-1;
    if(str!=NULL) ll=strlen(str);
    if(word!=NULL) wl=strlen(word);
    int sp=si;
    if(sp<0) sp=0;
    int el=ei+1;
    if(ei<0) el=ll;
    
    if( !(ll<1 || wl<1 || ll<wl || sp>=el || el>ll)) {  
    	for(int i=sp;i<el;i++) {
        	if((el-i)<wl) return -1;
        	if(str[i]==word[0]) if(strncmp(str+i,word,wl)==0) return i;
    	}
    }
    return -1;
}
int WdIdxInStr(const char *str,const char *word) {
	return WdIdxInStr(-1,-1,str,word);
}
int WdIdxInStr(const int si,const char *str,const char *word) {
	return WdIdxInStr(si,-1,str,word);
}
int WdIdxInStr(const int si,const int ei,const char *str,const char c) {
	char s[2]; s[0]=c; s[1]='\0'; 
	return WdIdxInStr(si,ei,str,s);
}
int WdIdxInStr(const char *str,const char c) {
	return WdIdxInStr(-1,-1,str,c);
}
int WdIdxInStr(const int si,const char *str,const char c) {
	return WdIdxInStr(si,-1,str,c);
}
//#######################################################################################################################
int WdIdxInStrRev(const int si,const int ei,const char *str,const char *word) {
    int wl=-1;
    int ll=-1;
    if(str!=NULL) ll=strlen(str);
    if(word!=NULL) wl=strlen(word);
    int sp=si;
    if(sp<0) sp=0;
    int el=ei+1;
    if(ei<0) el=ll;
    
    if( !(ll<1 || wl<1 || ll<wl || sp>=el || el>ll)) {  
    	for(int i=el-wl;i>=sp;i--) {
        	if(str[i]==word[0]) if(strncmp(str+i,word,wl)==0) return i;
    	}
    }
    return -1;
}
int WdIdxInStrRev(const char *str,const char *word) {
	return WdIdxInStrRev(-1,-1,str,word);
}
int WdIdxInStrRev(const int si,const char *str,const char *word) {
	return WdIdxInStrRev(si,-1,str,word);
}
int WdIdxInStrRev(const int si,const int ei,const char *str,const char c) {
	char s[2]; s[0]=c; s[1]='\0'; 
	return WdIdxInStrRev(si,ei,str,s);
}
int WdIdxInStrRev(const char *str,const char c) {
	return WdIdxInStrRev(-1,-1,str,c);
}
int WdIdxInStrRev(const int si,const char *str,const char c) {
	return WdIdxInStrRev(si,-1,str,c);
}
//#######################################################################################################################
int CharOfListInStrIdx(const char *str,const char *list) { return CharOfListInStrIdx(-1,-1,str,list); }
int CharOfListInStrIdx(const int si,const char *str,const char *list) { return CharOfListInStrIdx(si,-1,str,list); }
int CharOfListInStrIdx(const int si,const int ei,const char *str,const char *list) {
    int wl=-1;
    int ll=-1;
    if(str!=NULL) ll=strlen(str);
    if(list!=NULL) wl=strlen(list);
    int sp=si;
    if(sp<0) sp=0;
    int el=ei+1;
    if(ei<0) el=ll;
    
    if( !(ll<1 || wl<1 || ll<wl || sp>=el || el>ll)) {  
		for(int i=sp;i<el;i++) {
			if(WdIdxInStr(list,str[i])>-1) return i;
		}
	}
	return -1;
}
//#######################################################################################################################
int GetWdCntInStr(const char *str,const char c) { return GetWdCntInStr(-1,-1,str,c); }
int GetWdCntInStr(const int si,const char *str,const char c) { return GetWdCntInStr(si,-1,str,c); }
int GetWdCntInStr(const int si,const int ei,const char *str,const char c) {
    int ll=-1;
    if(str!=NULL) ll=strlen(str);
    int sp=si;
    if(sp<0) sp=0;
    int el=ei+1;
    if(ei<0) el=ll;
    int cnt=0;
    if( !(ll<1 || sp>=el || el>ll) ) {  
		for(int i=sp;i<el;i++) {
			if(str[i]==c) cnt++;
		}
	}
	return cnt;
}
//------------------------------------------------------------------------------------------------------------
int GetWdCntInStr(const char *str,const char *wd) { return GetWdCntInStr(-1,-1,str,wd); }
int GetWdCntInStr(const int si,const char *str,const char *wd) { return GetWdCntInStr(si,-1,str,wd); }
int GetWdCntInStr(const int si,const int ei,const char *str,const char *wd) {
    int wl=-1;
    int ll=-1;
    if(str!=NULL) ll=strlen(str);
    if(wd!=NULL) wl=strlen(wd);
    int sp=si;
    if(sp<0) sp=0;
    int ep=ei;
    if(ei<0) ep=ll-1;
    int cnt=0;
    if( !(ll<1 || wl<1 || ll<wl || sp>ep || ep>=ll)) {
//printf("\n#wd[%s] str[%s] sp=%d ep=%d",wd,str,sp,ep);
		int p=WdIdxInStr(sp,ep,str,wd);
//printf("\n#sp=%d -> p=%d , cnt=%d",sp,p,cnt);
		while(p>-1) {
			cnt++; sp=p+wl;
			p=WdIdxInStr(sp,ep,str,wd);
//printf("\n#sp=%d -> p=%d , cnt=%d",sp,p,cnt);
		}
	}
//printf(" -> return cnt=%d",cnt);
	return cnt;
}
//#######################################################################################################################
PO2 MyStr::GetPointOfStackPairKey(const MyStr &K1,const MyStr &K2) {
	MyStr S(str),KY1(K1),KY2(K2);
	PO2 pp;
	pp.p2=-1;
	int ix,si=0;
	pp.p1 = S.InStr(si,K1);
	if(pp.p1>-1) {
		si=pp.p1+K1.len;
		ix=si;
		pp.p2=S.InStr(ix,K2);
//printf("\nS=[%s],S[%d]=%c,pp.p2=%d",(char*)S,si,S[si],pp.p2);
		while(pp.p2>pp.p1) {
//int i=S.WdCntInStr(si,pp.p2-1,(char*)KY1);
//int j=S.WdCntInStr(si,pp.p2-1,(char*)KY2);
//printf("\npp.p2-1=%d ->i=%d j=%d",pp.p2-1,i,j);
			if(S.WdCntInStr(si,pp.p2-1,(char*)KY1)==S.WdCntInStr(si,pp.p2-1,(char*)KY2)) break;
			ix=pp.p2+K2.len;
			pp.p2=S.InStr(ix,K2);
//printf(" -> ix=%d pp.p2=%d",ix,pp.p2);
		}
	}
	if(pp.p2>-1) pp.p2=pp.p2+K2.len-1;
	return pp;
}

PO2 MyStr::GetPointOfStackPairKey(const char *k1,const char *k2) {
	MyStr K1(k1); MyStr K2(k2);
	return GetPointOfStackPairKey(K1,K2);
}
PO2 MyStr::GetPointOfStackPairKey(const char c1,const char c2) {
	MyStr K1(c1); MyStr K2(c2);
	return GetPointOfStackPairKey(K1,K2);
}

//#######################################################################################################################


char MyStr::Emptystr[2]="";
PO2	MyStr::sp2;
//#######################################################################################################################
PO2 MyStr::LineSymBlkIdxInStr(const int si,const int ei,const char *SymChrLst) {
	return LineSymBlkIdxInStr(si,ei,str,SymChrLst);
}
PO2 MyStr::LineSymBlkIdxInStr(const int si,const int ei,const char *str,const char *SymChrLst) {
//printf("\n*>LineSymBlkIdxInStr: si=%d ei=%d str(%s) SymChrLst(%s)",si,ei,str,SymChrLst);
	sp2.p1=-1; sp2.p2=-1;
	int ll=-1;
	if(str!=NULL) ll=strlen(str);
	int lsym=-1;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	int sp=si;
	if(sp<0) sp=0;
	int ep=ei;
	if(ei<0) ep=ll-1;
//printf("\n*>ll=%d sp=%d ep=%d str(sp,ep)=[%s]",ll,sp,ep,GetRangeByIdx(sp,ep));
	while(ll>0 && lsym>0 && sp<=ep && ep<ll) {
		int k=WdIdxInStr(sp,ep,str,'\n');
//printf("\n*>k=%d",k);
		if(k<0) k=ep;
		for(int n=0;n<lsym;n++) {
//printf("\n*>sp=%d k=%d SymChrLst[%d]='%c'",sp,k,n,SymChrLst[n]);
			int p=WdIdxInStr(sp,k,str,SymChrLst[n]);
			int q=WdIdxInStr(p+1,k,str,SymChrLst[n]);
//printf(" p=%d q=%d",p,q);
			if(p>-1 && q>-1) {
				if(sp2.p1<0) {sp2.p1=p; sp2.p2=q;}
				else if(p<sp2.p1) {sp2.p1=p; sp2.p2=q;}
			}
		}
		if(sp2.p1>-1 && sp2.p2>-1) break;
		sp=k+1;
//printf("\n*>sp2.p1=%d sp2.p2=%d k=%d sp=%d",sp2.p1,sp2.p2,k,sp);
	}
	return sp2;
}

//#######################################################################################################################
PO2 MyStr::SymBlkIdxInStr(const int si,const int ei,const char *str,const char *SymChrLst) {
//printf("\n*>SymBlkIdxInStr: si=%d ei=%d str(%s) SymChrLst(%s)",si,ei,str,SymChrLst);
	sp2.p1=-1; sp2.p2=-1;
	int ll=-1;
	if(str!=NULL) ll=strlen(str);
	int lsym=-1;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	int sp=si;
	if(sp<0) sp=0;
	int ep=ei;
	if(ei<0) ep=ll-1;
//printf("\n*>str(sp,ep)=[%s]",GetRangeByIdx(sp,ep));
	if(ll>0 || lsym>0 || sp<=ep || ep<ll) {
		for(int n=0;n<lsym;n++) {
//printf("\n*>sp=%d ep=%d SymChrLst[%d]='%c'",sp,ep,n,SymChrLst[n]);
			int p=WdIdxInStr(sp,ep,str,SymChrLst[n]);
			int q=WdIdxInStr(p+1,ep,str,SymChrLst[n]);
//printf(" p=%d q=%d",p,q);
			if(p>-1 && q>-1) {
				if(sp2.p1<0) {sp2.p1=p; sp2.p2=q;}
				else if(p<sp2.p1) {sp2.p1=p; sp2.p2=q;}
			}
		}
//printf("\n*>sp2.p1=%d sp2.p2=%d",sp2.p1,sp2.p2);
	}
	return sp2;
}
PO2 MyStr::SymBlkIdxInStr(const int si,const int ei,const char *SymChrLst) {
	return SymBlkIdxInStr(si,ei,str,SymChrLst);
}
//#######################################################################################################################
const char* MyStr::GetDos2Unix() {
	char CRLF[3]; CRLF[0]=0xd; CRLF[1]=0xa; CRLF[2]='\0';
	char LF[2]; LF[0]=0xa; LF[1]='\0';
	return GetRangeWithWdChg(CRLF,LF);
}
const char* MyStr::GetDos2UnixExSymBlk(const char *SymChrLst) {
	char CRLF[3]; CRLF[0]=0xd; CRLF[1]=0xa; CRLF[2]='\0';
	char LF[2]; LF[0]=0xa; LF[1]='\0';
	return GetRangeWithWdChgExSymBlk(CRLF,LF,SymChrLst);
}
//#######################################################################################################################
const char*	MyStr::resizeX(char **pstr,const char c) 	{ char cc[2]; cc[0]=c; cc[1]='\0'; return resizeX(pstr,cc); }
const char*	MyStr::resizeX(char **pstr,const MyStr &S) 	{ return resizeX(pstr,S.str); }
const char*	MyStr::resizeX(char **pstr,const char *istr){
//printf("\n** str=%u tmp=%u Emptystr=%u *pstr=%u istr='%s'",str,tmp,Emptystr,*pstr,istr);
	int ll=0;
	if(*pstr==NULL) *pstr=Emptystr;
	else			ll=strlen(*pstr);
	int ii=0;
	if(istr!=NULL) ii=strlen(istr);
	if(ii!=ll) {
		if(*pstr!=Emptystr) delete [] *pstr;
		if(ii<1)	*pstr=Emptystr;
		else		*pstr=strdup(istr);
	} else if(ii>0) 	strcpy(*pstr,istr);
	return *pstr;
}

const char*	MyStr::resize(const char c) 	{ resizeX(&str,c); len=strlen(str); return str; }
const char*	MyStr::resize(const MyStr &S) 	{ resizeX(&str,S); len=strlen(str); return str; }
const char*	MyStr::resize(const char *istr) {
	if(istr==NULL) { len=0; return releaseX(&str); }
	resizeX(&str,istr); len=strlen(str); return str; 
}

const char*	MyStr::resizetmp(const char c) { return resizeX(&tmp,c); }
const char*	MyStr::resizetmp(const MyStr &S) { return resizeX(&tmp,S); }
const char*	MyStr::resizetmp(const char *istr) { 
	if(istr==NULL) return releaseX(&tmp);
	return resizeX(&tmp,istr); 
}
//#######################################################################################################################
const char*	MyStr::releaseX(char **pstr){ 
	if(*pstr!=Emptystr) delete [] *pstr; 
	*pstr=Emptystr;	 return *pstr;
}
const char*	MyStr::release(void) { len=0; return releaseX(&str); }
const char*	MyStr::releasetmp(void) { return releaseX(&tmp); }
//#######################################################################################################################
//const char*	MyStr::EmptyAddr(void){ return Emptystr; }
//#######################################################################################################################
MyStr::MyStr() { 
	tmp=Emptystr; str=Emptystr; len=0;
}
MyStr::MyStr(const char c) {
	tmp=Emptystr;
	str=Emptystr; resize(c); len=strlen(str);
}
MyStr::MyStr(const char *s) {
	tmp=Emptystr;
	str=Emptystr; resize(s); len=strlen(str);
}
MyStr::MyStr(const MyStr &S) {
	tmp=Emptystr;
	str=Emptystr; resize(S.str); len=strlen(str); 
}
MyStr::MyStr(const int v) {
	char s[32]; sprintf(s,"%d",v);
	tmp=Emptystr;
	str=Emptystr; resize(s); len=strlen(str);
}
MyStr::MyStr(const long lv) {
	char s[32]; sprintf(s,"%ld",lv);
	tmp=Emptystr;
	str=Emptystr; resize(s); len=strlen(str);
}
MyStr::~MyStr() {
	releasetmp(); release();
}
//#######################################################################################################################
char  MyStr::operator[](int idx) {
	if(idx<0 || idx>=len) return '\0';
	return str[idx];
}
//#######################################################################################################################
MyStr::operator int() 				{ return len; }
MyStr::operator char() 				{ return str[0]; }
MyStr::operator char*() 			{ return str; }
MyStr::operator const char*() 		{ return str; }
//#######################################################################################################################
MyStr&	MyStr::operator=(const char *s)	{ resize(s); return *this; }
MyStr&	MyStr::operator=(const char c)	{ char s[2]; s[0]=c; s[1]='\0'; resize(s); return *this; }
MyStr&	MyStr::operator=(const MyStr &S)		{ resize(S.str); return *this; }
MyStr&	MyStr::operator=(const int n)	{ char t[32]; sprintf(t,"%d",n); resize(t); return *this; }
MyStr&	MyStr::operator=(const long l)	{ char t[32]; sprintf(t,"%ld",l); resize(t); return *this; }
//#######################################################################################################################
MyStr& MyStr::operator+=(const char *s) {
	if(s!=NULL) {
		int ls=0;
		if(s!=NULL) ls=strlen(s);
		if(ls>0) {
			ls+=len;
			char *t=new char[ls+1];
			strncpy(t,str,len);
			strcpy(t+len,s);
			release();
			str=t;
			len=strlen(str);
		}
	}
	return *this;
}
MyStr&	MyStr::operator+=(const char c)	{ char s[2]; s[0]=c; s[1]='\0'; return operator+=(s); }
MyStr&	MyStr::operator+=(const MyStr &S)		{ return operator+=(S.str); }
MyStr&	MyStr::operator+=(const int n)	{ char t[32]; sprintf(t,"%d",n); return operator+=(t); }
MyStr&	MyStr::operator+=(const long l)	{ char t[32]; sprintf(t,"%ld",l); return operator+=(t); }
//#######################################################################################################################
bool MyStr::operator==(const char *s) {
	int ls=-1;
	if(s!=NULL) ls=strlen(s);
	if(len==ls) {
		if(strcmp(str,s)==0) return true;
	}
	return false;
}
bool	MyStr::operator==(const char c)	{ char s[2]; s[0]=c; s[1]='\0'; return operator==(s); }
bool	MyStr::operator==(const MyStr &S)		{ return operator==(S.str); }
bool	MyStr::operator==(const int n)	{ char t[32]; sprintf(t,"%d",n); return operator==(t); }
bool	MyStr::operator==(const long l)	{ char t[32]; sprintf(t,"%ld",l); return operator==(t); }
//#######################################################################################################################
bool	MyStr::operator!=(const char *s)	{ if(operator==(s)) return false; else return true; }
bool	MyStr::operator!=(const char c) 	{ char s[2]; s[0]=c; s[1]='\0'; return operator!=(s); }
bool	MyStr::operator!=(const MyStr &S) 		{ return operator!=(S.str); }
bool	MyStr::operator!=(const int n)		{ char t[32]; sprintf(t,"%d",n); return operator!=(t); }
bool	MyStr::operator!=(const long l)		{ char t[32]; sprintf(t,"%ld",l); return operator!=(t); }
//#######################################################################################################################
const char*	MyStr::operator+(const char *s) {
	int ls=0;
	if(s!=NULL) ls=strlen(s);
	if(ls>0) {
		char *t=new char[len+ls+1];
		strncpy(t,str,len);
		strcpy(t+len,s);
		releasetmp();
		tmp=t;
	} else resizetmp(str);
	return tmp;
}
const char*	MyStr::operator+(const char c)	{ char s[2]; s[0]=c; s[1]='\0'; return operator+(s); }
const char*	MyStr::operator+(const MyStr &S)		{ return operator+(S.str); }
const char*	MyStr::operator+(const int n)	{ char t[32]; sprintf(t,"%d",n); return operator+(t); }
const char*	MyStr::operator+(const long l)	{ char t[32]; sprintf(t,"%ld",l); return operator+(t); }

//#######################################################################################################################
int		MyStr::InStr(const char *w) 							{ return WdIdxInStr(-1,-1,str,w); }
int		MyStr::InStr(const int si,const char *w) 				{ return WdIdxInStr(si,-1,str,w); }
int		MyStr::InStr(const int si,const int ei,const char *w) 	{ return WdIdxInStr(si,ei,str,w); }

int		MyStr::InStr(const char c) 								{ return WdIdxInStr(-1,-1,str,c); }
int		MyStr::InStr(const int si,const char c) 				{ return WdIdxInStr(si,-1,str,c); }
int		MyStr::InStr(const int si,const int ei,const char c) 	{ return WdIdxInStr(si,ei,str,c); }

int		MyStr::InStr(const MyStr &S) 								{ return WdIdxInStr(-1,-1,str,S.str); }
int		MyStr::InStr(const int si,const MyStr &S) 					{ return WdIdxInStr(si,-1,str,S.str); }
int		MyStr::InStr(const int si,const int ei,const MyStr &S) 		{ return WdIdxInStr(si,ei,str,S.str); }

//#######################################################################################################################
int		MyStr::InStrExSymBlk(const char c,const char *SymChrLst){ return InStrExSymBlk(-1,-1,c,SymChrLst); }
int		MyStr::InStrExSymBlk(const char *w,const char *SymChrLst){ return InStrExSymBlk(-1,-1,w,SymChrLst); }
int		MyStr::InStrExSymBlk(const MyStr &S,const char *SymChrLst){ return InStrExSymBlk(-1,-1,S.str,SymChrLst); }

int		MyStr::InStrExSymBlk(const int si,const char c,const char *SymChrLst){ return InStrExSymBlk(si,-1,c,SymChrLst); }
int		MyStr::InStrExSymBlk(const int si,const char *w,const char *SymChrLst){ return InStrExSymBlk(si,-1,w,SymChrLst); }
int		MyStr::InStrExSymBlk(const int si,const MyStr &S,const char *SymChrLst){ return InStrExSymBlk(si,-1,S.str,SymChrLst); }

int		MyStr::InStrExSymBlk(const int si,const int ei,const MyStr &S,const char *SymChrLst){return InStrExSymBlk(si,ei,S.str,SymChrLst);}
int		MyStr::InStrExSymBlk(const int si,const int ei,const char c,const char *SymChrLst){
	char s[2]; s[0]=c; s[1]='\0'; 
	return InStrExSymBlk(si,ei,s,SymChrLst);
}
int		MyStr::InStrExSymBlk(const int si,const int ei,const char *w,const char *SymChrLst){
    int lw=-1;
    if(w!=NULL) lw=strlen(w);
    int sp=si;
    if(si<0) sp=0;
    int ep=ei;
    if(ei<0) ep=len-1;
    
    if(len<1 || lw<1 || len<lw || sp>ep || ep>=len) return -1; 
	
	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return InStr(si,ei,w);
	
	int n=-1;
	PO2 pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	while(pp.p1>-1) {
		if(pp.p1>sp) {
			n=InStr(sp,pp.p1-1,w);
			if(n>-1) return n;
		}
		sp=pp.p2+1;
		pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	}
	if(sp<=ep) n=InStr(sp,ep,w);
	return n;
}
//#######################################################################################################################
int		MyStr::InStrExLineSymBlk(const char c,const char *SymChrLst){ return InStrExLineSymBlk(-1,-1,c,SymChrLst); }
int		MyStr::InStrExLineSymBlk(const char *w,const char *SymChrLst){ return InStrExLineSymBlk(-1,-1,w,SymChrLst); }
int		MyStr::InStrExLineSymBlk(const MyStr &S,const char *SymChrLst){ return InStrExLineSymBlk(-1,-1,S.str,SymChrLst); }

int		MyStr::InStrExLineSymBlk(const int si,const char c,const char *SymChrLst){ return InStrExLineSymBlk(si,-1,c,SymChrLst); }
int		MyStr::InStrExLineSymBlk(const int si,const char *w,const char *SymChrLst){ return InStrExLineSymBlk(si,-1,w,SymChrLst); }
int		MyStr::InStrExLineSymBlk(const int si,const MyStr &S,const char *SymChrLst){ return InStrExLineSymBlk(si,-1,S.str,SymChrLst); }

int		MyStr::InStrExLineSymBlk(const int si,const int ei,const MyStr &S,const char *SymChrLst){return InStrExLineSymBlk(si,ei,S.str,SymChrLst);}
int		MyStr::InStrExLineSymBlk(const int si,const int ei,const char c,const char *SymChrLst){
	char s[2]; s[0]=c; s[1]='\0'; 
	return InStrExLineSymBlk(si,ei,s,SymChrLst);
}
int		MyStr::InStrExLineSymBlk(const int si,const int ei,const char *w,const char *SymChrLst){
//printf("n#>InStrExLineSymBlk: si=%d,ei=%d,w=[%s],SymChrLst=[%s]",si,ei,w,SymChrLst);
    int lw=-1;
    if(w!=NULL) lw=strlen(w);
    int sp=si;
    if(si<0) sp=0;
    int ep=ei;
    if(ei<0) ep=len-1;
    
    if(len<1 || lw<1 || len<lw || sp>ep || ep>=len) return -1; 
	
	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return InStr(si,ei,w);
	
	int n=-1;
//printf("\n#>sp=%d ep=%d",sp,ep);
	PO2 pp=LineSymBlkIdxInStr(sp,ep,SymChrLst);
//printf("\n#>pp.p1=%d pp.p2=%d",pp.p1,pp.p2);
	while(pp.p1>-1) {
		if(pp.p1>sp) {
			n=InStr(sp,pp.p1-1,w);
			if(n>-1) return n;
		}
		sp=pp.p2+1;
		pp=LineSymBlkIdxInStr(sp,ep,SymChrLst);
	}
	if(sp<=ep) n=InStr(sp,ep,w);
	return n;
}
//#######################################################################################################################
int		MyStr::InStrRev(const char *w) 								{ return WdIdxInStrRev(-1,-1,str,w); }
int		MyStr::InStrRev(const int si,const char *w) 				{ return WdIdxInStrRev(si,-1,str,w); }
int		MyStr::InStrRev(const int si,const int ei,const char *w) 	{ return WdIdxInStrRev(si,ei,str,w); }

int		MyStr::InStrRev(const char c) 								{ return WdIdxInStrRev(-1,-1,str,c); }
int		MyStr::InStrRev(const int si,const char c) 					{ return WdIdxInStrRev(si,-1,str,c); }
int		MyStr::InStrRev(const int si,const int ei,const char c) 	{ return WdIdxInStrRev(si,ei,str,c); }

int		MyStr::InStrRev(const MyStr &S) 									{ return WdIdxInStrRev(-1,-1,str,S.str); }
int		MyStr::InStrRev(const int si,const MyStr &S) 						{ return WdIdxInStrRev(si,-1,str,S.str); }
int		MyStr::InStrRev(const int si,const int ei,const MyStr &S) 		{ return WdIdxInStrRev(si,ei,str,S.str); }
//#######################################################################################################################
int		MyStr::InStrRevExSymBlk(const char c,const char *SymChrLst) { return InStrRevExSymBlk(-1,-1,c,SymChrLst); }
int		MyStr::InStrRevExSymBlk(const char *w,const char *SymChrLst) { return InStrRevExSymBlk(-1,-1,w,SymChrLst); }
int		MyStr::InStrRevExSymBlk(const MyStr &S,const char *SymChrLst) { return InStrRevExSymBlk(-1,-1,S.str,SymChrLst); }

int		MyStr::InStrRevExSymBlk(const int si,const char c,const char *SymChrLst) { return InStrRevExSymBlk(si,-1,c,SymChrLst); }
int		MyStr::InStrRevExSymBlk(const int si,const char *w,const char *SymChrLst) { return InStrRevExSymBlk(si,-1,w,SymChrLst); }
int		MyStr::InStrRevExSymBlk(const int si,const MyStr &S,const char *SymChrLst) { return InStrRevExSymBlk(si,-1,S.str,SymChrLst); }

int		MyStr::InStrRevExSymBlk(const int si,const int ei,const MyStr &S,const char *SymChrLst) {return InStrRevExSymBlk(si,ei,S.str,SymChrLst);}
int		MyStr::InStrRevExSymBlk(const int si,const int ei,const char c,const char *SymChrLst) {
	char w[2]; w[0]=c; w[1]='\0';
	return InStrRevExSymBlk(si,ei,w,SymChrLst);
}
int		MyStr::InStrRevExSymBlk(const int si,const int ei,const char *w,const char *SymChrLst) {
    int lw=-1;
    if(w!=NULL) lw=strlen(w);
    int sp=si;
    if(si<0) sp=0;
    int ep=ei;
    if(ei<0) ep=len-1;
    
    if(len<1 || lw<1 || len<lw || sp>ep || ep>=len) return -1; 
	
	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return InStrRev(si,ei,w);
	
	int p;
	int n=-1;
	PO2 pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	while(pp.p1>-1) {
		if(pp.p1>sp) {
			p=InStrRev(sp,pp.p1-1,w);
			if(p>n) n=p;
		}
		sp=pp.p2+1;
		pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	}
	if(sp<=ep) {
		p=InStrRev(sp,ep,w);
		if(p>n) n=p;
	}
	return n;
}
//#######################################################################################################################
int		MyStr::InStrRevExLineSymBlk(const char c,const char *SymChrLst) { return InStrRevExLineSymBlk(-1,-1,c,SymChrLst); }
int		MyStr::InStrRevExLineSymBlk(const char *w,const char *SymChrLst) { return InStrRevExLineSymBlk(-1,-1,w,SymChrLst); }
int		MyStr::InStrRevExLineSymBlk(const MyStr &S,const char *SymChrLst) { return InStrRevExLineSymBlk(-1,-1,S.str,SymChrLst); }

int		MyStr::InStrRevExLineSymBlk(const int si,const char c,const char *SymChrLst) { return InStrRevExLineSymBlk(si,-1,c,SymChrLst); }
int		MyStr::InStrRevExLineSymBlk(const int si,const char *w,const char *SymChrLst) { return InStrRevExLineSymBlk(si,-1,w,SymChrLst); }
int		MyStr::InStrRevExLineSymBlk(const int si,const MyStr &S,const char *SymChrLst) { return InStrRevExLineSymBlk(si,-1,S.str,SymChrLst); }

int		MyStr::InStrRevExLineSymBlk(const int si,const int ei,const MyStr &S,const char *SymChrLst) {return InStrRevExLineSymBlk(si,ei,S.str,SymChrLst);}
int		MyStr::InStrRevExLineSymBlk(const int si,const int ei,const char c,const char *SymChrLst) {
	char w[2]; w[0]=c; w[1]='\0';
	return InStrRevExLineSymBlk(si,ei,w,SymChrLst);
}
int		MyStr::InStrRevExLineSymBlk(const int si,const int ei,const char *w,const char *SymChrLst) {
    int lw=-1;
    if(w!=NULL) lw=strlen(w);
    int sp=si;
    if(si<0) sp=0;
    int ep=ei;
    if(ei<0) ep=len-1;
    
    if(len<1 || lw<1 || len<lw || sp>ep || ep>=len) return -1; 
	
	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return InStrRev(si,ei,w);
	
	int p;
	int n=-1;
	PO2 pp=LineSymBlkIdxInStr(sp,ep,SymChrLst);
	while(pp.p1>-1) {
		if(pp.p1>sp) {
			p=InStrRev(sp,pp.p1-1,w);
			if(p>n) n=p;
		}
		sp=pp.p2+1;
		pp=LineSymBlkIdxInStr(sp,ep,SymChrLst);
	}
	if(sp<=ep) {
		p=InStrRev(sp,ep,w);
		if(p>n) n=p;
	}
	return n;
}
//#######################################################################################################################
const char* MyStr::GetRangeByIdx(const int si,const int ei) {
//printf("\nMyStr::GetRangeByIdx(%d,%d) ..",si,ei);
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	if(len>0 && sp<=ep && ep<len) {
		int ll=ep-sp+1;
		char *t=new char[ll+1];
		strncpy(t,str+sp,ll);
		t[ll]='\0';
		releasetmp();
		tmp=t;
//printf("sp=%d ep=%d tmp=[%s]",sp,ep,tmp);
		return tmp;
	}
	return releasetmp();
}
//#######################################################################################################################
const char* MyStr::GetRangeBtwIdx(const int si,const int ei) {
	int sp=si+1;
	if(si<0) sp=0;
	int ep=-1;
	if(ei<0) ep=len-1;
	else if(ei<len) ep=ei-1;
	
	if(len>0 && sp<=ep && ep<len) {
		int ll=ep-sp+1;
		char *t=new char[ll+1];
		strncpy(t,str+sp,ll);
		t[ll]='\0';
		releasetmp();
		tmp=t;
		return tmp;
	}
	return releasetmp();
}
//#######################################################################################################################

const char* MyStr::GetRangeByKey(const char *k1,const char *k2) {
	int lk1=0;
	if(k1!=NULL) lk1=strlen(k1);
	int lk2=0;
	if(k2!=NULL) lk2=strlen(k2);
	if( (lk1<1 && lk2<1) || len<1 ) return resizetmp(str);
	
	int p=0;
	int q=len-1;
	if(lk1>0) { 
		p=InStr(k1);
		if(p>-1 && lk2>0) q=InStr(p+lk1,k2);
	} else if(lk2>0) q=InStr(k2);
	if(p>-1 && q>-1) {
		lk1=q-p+lk2;
		char *t=new char[lk1+1];
		strncpy(t,str+p,lk1);
		t[lk1]='\0';
		releasetmp();
		tmp=t;
		return tmp;
	}
	return releasetmp();
}
const char* MyStr::GetRangeByKey(const char c1,const char c2) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeByKey(k1,k2);
}
const char* MyStr::GetRangeByKey(const char *k1,const char c2) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeByKey(k1,k2);
}
const char* MyStr::GetRangeByKey(const char c1,const char *k2) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeByKey(k1,k2);
}
const char* MyStr::GetRangeByKey(const char c1,const MyStr &S2) {return GetRangeByKey(c1,S2.str);}
const char* MyStr::GetRangeByKey(const char *k1,const MyStr &S2) {return GetRangeByKey(k1,S2.str);}
const char* MyStr::GetRangeByKey(const MyStr &S1,const char c2) {return GetRangeByKey(S1.str,c2);}
const char* MyStr::GetRangeByKey(const MyStr &S1,const char *k2) {return GetRangeByKey(S1.str,k2);}
const char* MyStr::GetRangeByKey(const MyStr &S1,const MyStr &S2) {return GetRangeByKey(S1.str,S2.str);}

//#######################################################################################################################
const char* MyStr::GetRangeByKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst) {
	int lk1=0;
	if(k1!=NULL) lk1=strlen(k1);
	int lk2=0;
	if(k2!=NULL) lk2=strlen(k2);
	if( (lk1<1 && lk2<1) || len<1 ) return resizetmp(str);
	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeByKey(k1,k2);
	
	int k=0 ,p=-1 ,q=-1;
	if(lk1<1) p=k;
	if(lk2<1) q=len;
	PO2 pp=SymBlkIdxInStr(k,-1,SymChrLst);
	while(pp.p1>-1) {
		if(lk1>0 && p<0) {
			p=InStr(k,pp.p1-1,k1);
			if(p>-1) k=p+lk1;
		}
		if(lk2>0) q=InStr(k,pp.p1-1,k2);
		if(p>-1 && q>-1) break;
		k=pp.p2+1;
		pp=SymBlkIdxInStr(k,-1,SymChrLst);
	}
	if(lk1>0 && p<0) {
		p=InStr(k,-1,k1);
		if(p>-1) k=p+lk1;
	}
	if(lk2>0 && q<0 ) q=InStr(k,-1,k2);
	if(p>-1 && q>-1) {
		lk1=q+lk2-p;
		char *t=new char[lk1+1];
		strncpy(t,str+p,lk1);
		t[lk1]='\0';
		releasetmp();
		tmp=t;
		return tmp;
	}	
	return releasetmp();
}
const char* MyStr::GetRangeByKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeByKeyExSymBlk(k1,k2,SymChrLst);
}
const char* MyStr::GetRangeByKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeByKeyExSymBlk(k1,k2,SymChrLst);
}
const char* MyStr::GetRangeByKeyExSymBlk(const char c1,const char c2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeByKeyExSymBlk(k1,k2,SymChrLst);
}
const char* MyStr::GetRangeByKeyExSymBlk(const char c1,const MyStr &S2,const char *SymChrLst) {return GetRangeByKeyExSymBlk(c1,S2.str,SymChrLst);}
const char* MyStr::GetRangeByKeyExSymBlk(const char *k1,const MyStr &S2,const char *SymChrLst) {return GetRangeByKeyExSymBlk(k1,S2.str,SymChrLst);}
const char* MyStr::GetRangeByKeyExSymBlk(const MyStr &S1,const MyStr &S2,const char *SymChrLst) {return GetRangeByKeyExSymBlk(S1.str,S2.str,SymChrLst);}
const char* MyStr::GetRangeByKeyExSymBlk(const MyStr &S1,const char c2,const char *SymChrLst) {return GetRangeByKeyExSymBlk(S1.str,c2,SymChrLst);}
const char* MyStr::GetRangeByKeyExSymBlk(const MyStr &S1,const char *k2,const char *SymChrLst) {return GetRangeByKeyExSymBlk(S1.str,k2,SymChrLst);}
//#######################################################################################################################
const char* MyStr::GetRangeByKeyExLineSymBlk(const char *k1,const char *k2,const char *SymChrLst) {
	int lk1=0;
	if(k1!=NULL) lk1=strlen(k1);
	int lk2=0;
	if(k2!=NULL) lk2=strlen(k2);
	if( (lk1<1 && lk2<1) || len<1 ) return resizetmp(str);
	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeByKey(k1,k2);
	
	int k=0 ,p=-1 ,q=-1;
	if(lk1<1) p=k;
	if(lk2<1) q=len;
	PO2 pp=LineSymBlkIdxInStr(k,-1,SymChrLst);
	while(pp.p1>-1) {
		if(lk1>0 && p<0) {
			p=InStr(k,pp.p1-1,k1);
			if(p>-1) k=p+lk1;
		}
		if(lk2>0) q=InStr(k,pp.p1-1,k2);
		if(p>-1 && q>-1) break;
		k=pp.p2+1;
		pp=LineSymBlkIdxInStr(k,-1,SymChrLst);
	}
	if(lk1>0 && p<0) {
		p=InStr(k,-1,k1);
		if(p>-1) k=p+lk1;
	}
	if(lk2>0 && q<0 ) q=InStr(k,-1,k2);
	if(p>-1 && q>-1) {
		lk1=q+lk2-p;
		char *t=new char[lk1+1];
		strncpy(t,str+p,lk1);
		t[lk1]='\0';
		releasetmp();
		tmp=t;
		return tmp;
	}	
	return releasetmp();
}
const char* MyStr::GetRangeByKeyExLineSymBlk(const char c1,const char *k2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeByKeyExLineSymBlk(k1,k2,SymChrLst);
}
const char* MyStr::GetRangeByKeyExLineSymBlk(const char *k1,const char c2,const char *SymChrLst) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeByKeyExLineSymBlk(k1,k2,SymChrLst);
}
const char* MyStr::GetRangeByKeyExLineSymBlk(const char c1,const char c2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeByKeyExLineSymBlk(k1,k2,SymChrLst);
}
const char* MyStr::GetRangeByKeyExLineSymBlk(const char c1,const MyStr &S2,const char *SymChrLst) {return GetRangeByKeyExLineSymBlk(c1,S2.str,SymChrLst);}
const char* MyStr::GetRangeByKeyExLineSymBlk(const char *k1,const MyStr &S2,const char *SymChrLst) {return GetRangeByKeyExLineSymBlk(k1,S2.str,SymChrLst);}
const char* MyStr::GetRangeByKeyExLineSymBlk(const MyStr &S1,const MyStr &S2,const char *SymChrLst) {return GetRangeByKeyExLineSymBlk(S1.str,S2.str,SymChrLst);}
const char* MyStr::GetRangeByKeyExLineSymBlk(const MyStr &S1,const char c2,const char *SymChrLst) {return GetRangeByKeyExLineSymBlk(S1.str,c2,SymChrLst);}
const char* MyStr::GetRangeByKeyExLineSymBlk(const MyStr &S1,const char *k2,const char *SymChrLst) {return GetRangeByKeyExLineSymBlk(S1.str,k2,SymChrLst);}

//#######################################################################################################################
const char* MyStr::GetRangeBtwKey(const char c1,const char c2) { return GetRangeBtwKey(-1,-1,c1,c2); }
const char* MyStr::GetRangeBtwKey(const char c1,const char *k2) { return GetRangeBtwKey(-1,-1,c1,k2); }
const char* MyStr::GetRangeBtwKey(const char c1,const MyStr &S2) { return GetRangeBtwKey(-1,-1,c1,S2.str); }
const char* MyStr::GetRangeBtwKey(const char *k1,const char c2) { return GetRangeBtwKey(-1,-1,k1,c2); }
const char* MyStr::GetRangeBtwKey(const char *k1,const char *k2) { return GetRangeBtwKey(-1,-1,k1,k2); }
const char* MyStr::GetRangeBtwKey(const char *k1,const MyStr &S2) { return GetRangeBtwKey(-1,-1,k1,S2.str); }
const char* MyStr::GetRangeBtwKey(const MyStr &S1,const char c2) { return GetRangeBtwKey(-1,-1,S1.str,c2); }
const char* MyStr::GetRangeBtwKey(const MyStr &S1,const char *k2) { return GetRangeBtwKey(-1,-1,S1.str,k2); }
const char* MyStr::GetRangeBtwKey(const MyStr &S1,const MyStr &S2) { return GetRangeBtwKey(-1,-1,S1.str,S2.str); }

const char* MyStr::GetRangeBtwKey(const int si,const char c1,const char c2) { return GetRangeBtwKey(si,-1,c1,c2); }
const char* MyStr::GetRangeBtwKey(const int si,const char c1,const char *k2) { return GetRangeBtwKey(si,-1,c1,k2); }
const char* MyStr::GetRangeBtwKey(const int si,const char c1,const MyStr &S2) { return GetRangeBtwKey(si,-1,c1,S2.str); }
const char* MyStr::GetRangeBtwKey(const int si,const char *k1,const char c2) { return GetRangeBtwKey(si,-1,k1,c2); }
const char* MyStr::GetRangeBtwKey(const int si,const char *k1,const char *k2) { return GetRangeBtwKey(si,-1,k1,k2); }
const char* MyStr::GetRangeBtwKey(const int si,const char *k1,const MyStr &S2) { return GetRangeBtwKey(si,-1,k1,S2.str); }
const char* MyStr::GetRangeBtwKey(const int si,const MyStr &S1,const char c2) { return GetRangeBtwKey(si,-1,S1.str,c2); }
const char* MyStr::GetRangeBtwKey(const int si,const MyStr &S1,const char *k2) { return GetRangeBtwKey(si,-1,S1.str,k2); }
const char* MyStr::GetRangeBtwKey(const int si,const MyStr &S1,const MyStr &S2) { return GetRangeBtwKey(si,-1,S1.str,S2.str); }

const char* MyStr::GetRangeBtwKey(const int si,const int ei,const char c1,const MyStr &S2) {return GetRangeBtwKey(si,ei,c1,S2.str);}
const char* MyStr::GetRangeBtwKey(const int si,const int ei,const char c1,const char c2) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeBtwKey(si,ei,k1,k2);
}
const char* MyStr::GetRangeBtwKey(const int si,const int ei,const char c1,const char *k2) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeBtwKey(si,ei,k1,k2);
}
const char* MyStr::GetRangeBtwKey(const int si,const int ei,const char *k1,const MyStr &S2) {return GetRangeBtwKey(si,ei,k1,S2.str);}
const char* MyStr::GetRangeBtwKey(const int si,const int ei,const char *k1,const char c2) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeBtwKey(si,ei,k1,k2);
}
const char* MyStr::GetRangeBtwKey(const int si,const int ei,const char *k1,const char *k2) {
	int lk1=0;
	if(k1!=NULL) lk1=strlen(k1);
	int lk2=0;
	if(k2!=NULL) lk2=strlen(k2);
	
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if( (lk1<1 && lk2<1) || len<1 ) return resizetmp(str);
	if(sp>ep || ep>=len) return releasetmp();

	int p=sp;
	int q=ep;

	if(lk1>0) { 
		p=InStr(sp,ep,k1);
		if(p>-1) {
			p+=lk1;
			if(lk2>0) q=InStr(p,ep,k2)-1;
		}
	} else if(lk2>0) q=InStr(sp,ep,k2)-1;
	if(p>-1 && q>-1) {
		lk1=q-p+1;
		char *t=new char[lk1+1];
		strncpy(t,str+p,lk1);
		t[lk1]='\0';
		releasetmp();
		tmp=t;
		return tmp;
	}
	return releasetmp();
}
const char* MyStr::GetRangeBtwKey(const int si,const int ei,const MyStr &S1,const char c2) {return GetRangeBtwKey(si,ei,S1.str,c2);}
const char* MyStr::GetRangeBtwKey(const int si,const int ei,const MyStr &S1,const char *k2) {return GetRangeBtwKey(si,ei,S1.str,k2);}
const char* MyStr::GetRangeBtwKey(const int si,const int ei,const MyStr &S1,const MyStr &S2) {return GetRangeBtwKey(si,ei,S1.str,S2.str);}

//#######################################################################################################################
const char* MyStr::GetRangeBtwKeyExSymBlk(const char c1,const char c2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(-1,-1,c1,c2,SymChrLst); }
const char* MyStr::GetRangeBtwKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(-1,-1,c1,k2,SymChrLst); }
const char* MyStr::GetRangeBtwKeyExSymBlk(const char c1,const MyStr &S2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(-1,-1,c1,S2.str,SymChrLst); }
const char* MyStr::GetRangeBtwKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(-1,-1,k1,c2,SymChrLst); }
const char* MyStr::GetRangeBtwKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(-1,-1,k1,k2,SymChrLst); }
const char* MyStr::GetRangeBtwKeyExSymBlk(const char *k1,const MyStr &S2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(-1,-1,k1,S2.str,SymChrLst); }
const char* MyStr::GetRangeBtwKeyExSymBlk(const MyStr &S1,const char c2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(-1,-1,S1.str,c2,SymChrLst); }
const char* MyStr::GetRangeBtwKeyExSymBlk(const MyStr &S1,const char *k2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(-1,-1,S1.str,k2,SymChrLst); }
const char* MyStr::GetRangeBtwKeyExSymBlk(const MyStr &S1,const MyStr &S2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(-1,-1,S1.str,S2.str,SymChrLst); }

const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(si,-1,c1,c2,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(si,-1,c1,k2,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const char c1,const MyStr &S2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(si,-1,c1,S2.str,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(si,-1,k1,c2,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(si,-1,k1,k2,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const char *k1,const MyStr &S2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(si,-1,k1,S2.str,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const MyStr &S1,const char c2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(si,-1,S1.str,c2,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const MyStr &S1,const char *k2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(si,-1,S1.str,k2,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const MyStr &S1,const MyStr &S2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(si,-1,S1.str,S2.str,SymChrLst);}

const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const int ei,const char c1,const MyStr &S2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(si,ei,c1,S2.str,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeBtwKeyExSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeBtwKeyExSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const int ei,const char *k1,const MyStr &S2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(si,ei,k1,S2.str,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeBtwKeyExSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst) {
	int lk1=0;
	if(k1!=NULL) lk1=strlen(k1);
	int lk2=0;
	if(k2!=NULL) lk2=strlen(k2);
	if( (lk1<1 && lk2<1) || len<1 ) return resizetmp(str);

	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeBtwKey(si,ei,k1,k2);
	
	int k=sp ,p=-1 ,q=-1;
	if(lk1<1) p=k;
	if(lk2<1) q=ep+1;
	
	PO2 pp=SymBlkIdxInStr(k,ep,SymChrLst);
	while(pp.p1>-1) {
		if(lk1>0 && p<0) {
			p=InStr(k,pp.p1-1,k1);
			if(p>-1) k=p+lk1;
		}
		if(lk2>0) q=InStr(k,pp.p1-1,k2);
		if(p>-1 && q>-1) break;
		k=pp.p2+1;
		pp=SymBlkIdxInStr(k,ep,SymChrLst);
	}
	if(lk1>0 && p<0) {
		p=InStr(k,ep,k1);
		if(p>-1) k=p+lk1;
	}
	if(lk2>0 && q<0 ) q=InStr(k,ep,k2);
	if(p>-1 && q>-1) {
		if(lk1>0) p+=lk1;
		if(lk2>0) q--;
		lk1=q-p+1;
		char *t=new char[lk1+1];
		strncpy(t,str+p,lk1);
		t[lk1]='\0';
		releasetmp();
		tmp=t;
		return tmp;
	}	
	return releasetmp();
}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const int ei,const MyStr &S1,const MyStr &S2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(si,ei,S1.str,S2.str,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const int ei,const MyStr &S1,const char c2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(si,ei,S1.str,c2,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExSymBlk(const int si,const int ei,const MyStr &S1,const char *k2,const char *SymChrLst) {return GetRangeBtwKeyExSymBlk(si,ei,S1.str,k2,SymChrLst);}
//#######################################################################################################################
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const char c1,const char c2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(-1,-1,c1,c2,SymChrLst); }
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const char c1,const char *k2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(-1,-1,c1,k2,SymChrLst); }
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const char c1,const MyStr &S2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(-1,-1,c1,S2.str,SymChrLst); }
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const char *k1,const char c2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(-1,-1,k1,c2,SymChrLst); }
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const char *k1,const char *k2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(-1,-1,k1,k2,SymChrLst); }
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const char *k1,const MyStr &S2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(-1,-1,k1,S2.str,SymChrLst); }
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const MyStr &S1,const char c2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(-1,-1,S1.str,c2,SymChrLst); }
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const MyStr &S1,const char *k2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(-1,-1,S1.str,k2,SymChrLst); }
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const MyStr &S1,const MyStr &S2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(-1,-1,S1.str,S2.str,SymChrLst); }

const char* MyStr::GetRangeBtwKeyExLineSymBlk(const int si,const char c1,const char c2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(si,-1,c1,c2,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(si,-1,c1,k2,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const int si,const char c1,const MyStr &S2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(si,-1,c1,S2.str,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(si,-1,k1,c2,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(si,-1,k1,k2,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const int si,const char *k1,const MyStr &S2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(si,-1,k1,S2.str,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const int si,const MyStr &S1,const char c2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(si,-1,S1.str,c2,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const int si,const MyStr &S1,const char *k2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(si,-1,S1.str,k2,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const int si,const MyStr &S1,const MyStr &S2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(si,-1,S1.str,S2.str,SymChrLst);}

const char* MyStr::GetRangeBtwKeyExLineSymBlk(const int si,const int ei,const char c1,const MyStr &S2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(si,ei,c1,S2.str,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeBtwKeyExLineSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeBtwKeyExLineSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const int si,const int ei,const char *k1,const MyStr &S2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(si,ei,k1,S2.str,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeBtwKeyExLineSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst) {
	int lk1=0;
	if(k1!=NULL) lk1=strlen(k1);
	int lk2=0;
	if(k2!=NULL) lk2=strlen(k2);
	if( (lk1<1 && lk2<1) || len<1 ) return resizetmp(str);

	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeBtwKey(si,ei,k1,k2);
	
	int k=sp ,p=-1 ,q=-1;
	if(lk1<1) p=k;
	if(lk2<1) q=ep+1;
	
	PO2 pp=LineSymBlkIdxInStr(k,ep,SymChrLst);
	while(pp.p1>-1) {
		if(lk1>0 && p<0) {
			p=InStr(k,pp.p1-1,k1);
			if(p>-1) k=p+lk1;
		}
		if(lk2>0) q=InStr(k,pp.p1-1,k2);
		if(p>-1 && q>-1) break;
		k=pp.p2+1;
		pp=LineSymBlkIdxInStr(k,ep,SymChrLst);
	}
	if(lk1>0 && p<0) {
		p=InStr(k,ep,k1);
		if(p>-1) k=p+lk1;
	}
	if(lk2>0 && q<0 ) q=InStr(k,ep,k2);
	if(p>-1 && q>-1) {
		if(lk1>0) p+=lk1;
		if(lk2>0) q--;
		lk1=q-p+1;
		char *t=new char[lk1+1];
		strncpy(t,str+p,lk1);
		t[lk1]='\0';
		releasetmp();
		tmp=t;
		return tmp;
	}	
	return releasetmp();
}
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const int si,const int ei,const MyStr &S1,const MyStr &S2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(si,ei,S1.str,S2.str,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const int si,const int ei,const MyStr &S1,const char c2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(si,ei,S1.str,c2,SymChrLst);}
const char* MyStr::GetRangeBtwKeyExLineSymBlk(const int si,const int ei,const MyStr &S1,const char *k2,const char *SymChrLst) {return GetRangeBtwKeyExLineSymBlk(si,ei,S1.str,k2,SymChrLst);}

//#######################################################################################################################

const char* MyStr::GetRangeWithWdChg(const int si,const int ei,const char *owd,const char *nwd) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ep<0) ep=len-1;
	
	MyStr OWD(owd);
	MyStr oNWD,NWD(nwd);
		
	if(len<1 || sp>ep || ep>=len) return releasetmp();
	if((int)OWD<1 || OWD==NWD) return resizetmp(str);

	int xp=NWD.InStr(OWD.str);
	if(xp>-1) {
		char bb=0x7;
		oNWD=nwd;
		if(xp>0) 	{ NWD=oNWD.GetRangeByIdx(-1,xp-1); NWD+=bb; NWD+=oNWD.GetRangeByIdx(xp+1,-1); }
		else		{ NWD=bb; NWD+=oNWD.GetRangeByIdx(xp+1,-1); }
	}
//printf("\n*** xp=%d NWD=[%s] oNWD=[%s]",xp,(char*)NWD,(char*)oNWD);

	int isp=sp;
	MyStr T;
	int p=InStr(sp,ep,OWD.str);
	while(p>-1) {
		if(p>sp) T+=GetRangeByIdx(sp,p-1);
		if((int)NWD>0) T+=NWD;
		sp=p+(int)OWD;
		p=InStr(sp,ep,OWD);
	}
	if(sp==isp) return resizetmp(str);
	if(sp<=ep) T+=GetRangeByIdx(sp,ep);
	T=T.GetRangeWithWdChg(OWD.str,NWD.str);
//printf("\n>>> T=[%s]",T.str);
	if(xp>-1) T=T.GetRangeWithWdChg(NWD.str,oNWD.str);
//printf("\n### T=[%s]",T.str);
	return resizetmp(T.str);
}

const char* MyStr::GetRangeWithWdChg(const int si,const int ei,const char och,const char nch) { 
	char owd[2]; owd[0]=och; owd[1]='\0';
	char nwd[2]; nwd[0]=nch; nwd[1]='\0';
	return GetRangeWithWdChg(si,ei,owd,nwd);
}
const char* MyStr::GetRangeWithWdChg(const int si,const int ei,const char och,const char *nwd) { 
	char owd[2]; owd[0]=och; owd[1]='\0';
	return GetRangeWithWdChg(si,ei,owd,nwd);
}
const char* MyStr::GetRangeWithWdChg(const int si,const int ei,const char *owd,const char nch) { 
	char nwd[2]; nwd[0]=nch; nwd[1]='\0';
	return GetRangeWithWdChg(si,ei,owd,nwd);
}

const char* MyStr::GetRangeWithWdChg(const int si,const char och,const char nch) { 
	return GetRangeWithWdChg(si,-1,och,nch);
}
const char* MyStr::GetRangeWithWdChg(const int si,const char och,const char *nwd) { 
	return GetRangeWithWdChg(si,-1,och,nwd);
}
const char* MyStr::GetRangeWithWdChg(const int si,const char *owd,const char nch) { 
	return GetRangeWithWdChg(si,-1,owd,nch);
}
const char* MyStr::GetRangeWithWdChg(const int si,const char *owd,const char *nwd) { 
	return GetRangeWithWdChg(si,-1,owd,nwd);
}

const char* MyStr::GetRangeWithWdChg(const char och,const char nch) { 
	return GetRangeWithWdChg(-1,-1,och,nch);
}
const char* MyStr::GetRangeWithWdChg(const char och,const char *nwd) { 
	return GetRangeWithWdChg(-1,-1,och,nwd);
}
const char* MyStr::GetRangeWithWdChg(const char *owd,const char nch) { 
	return GetRangeWithWdChg(-1,-1,owd,nch);
}
const char* MyStr::GetRangeWithWdChg(const char *owd,const char *nwd) { 
	return GetRangeWithWdChg(-1,-1,owd,nwd); 
}

//#######################################################################################################################
const char* MyStr::GetRangeWithWdChgExSymBlk(const int si,const int ei,const char *owd,const char *nwd,const char *SymChrLst) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ep<0) ep=len-1;
	int lowd=0;
	if(owd!=NULL) lowd=strlen(owd);
	int lnwd=0;
	if(nwd!=NULL) lnwd=strlen(nwd);
//printf("\nstr='%s'",str);
	if(len<1 || sp>ep || ep>=len) return releasetmp();
	if(lowd<1) return resizetmp(str);
	if(lowd>0 && lowd==lnwd) if(strcmp(owd,nwd)==0) return resizetmp(str);

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeWithWdChg(si,ei,owd,nwd);

//printf("\nowd='%s' nwd='%s'  SymChrLst='%s'",owd,nwd,SymChrLst);

	MyStr T,S;
	PO2 pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	while(pp.p1>-1) {
		int p=InStr(sp,pp.p1-1,owd);
		if(p>0) {
			T+=GetRangeByIdx(sp,p-1);
//printf("\n>>T.str='%s'",T.str);
			if(lnwd>0) { T+=nwd; T=T.GetRangeWithWdChg(owd,nwd); }
//printf("\n>>>T.str='%s'",T.str);
			sp=p+lowd;
		} else	{T+=GetRangeByIdx(sp,pp.p2); sp=pp.p2+1;}
		pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	}
//printf("\n>>>>sp=%d ep=%d T.str='%s'",sp,ep,T.str);
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		T+=S.GetRangeWithWdChg(owd,nwd);
	}
//printf("\n##>T.str='%s'",T.str);
	return resizetmp(T.str);
}
const char* MyStr::GetRangeWithWdChgExSymBlk(const int si,const int ei,const char och,const char *nwd,const char *SymChrLst) {
	char owd[2]; owd[0]=och; owd[1]='\0';
	return GetRangeWithWdChgExSymBlk(si,ei,owd,nwd,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExSymBlk(const int si,const int ei,const char *owd,const char nch,const char *SymChrLst) {
	char nwd[2]; nwd[0]=nch; nwd[1]='\0';
	return GetRangeWithWdChgExSymBlk(si,ei,owd,nwd,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExSymBlk(const int si,const int ei,const char och,const char nch,const char *SymChrLst) {
	char owd[2]; owd[0]=och; owd[1]='\0';
	char nwd[2]; nwd[0]=nch; nwd[1]='\0';
	return GetRangeWithWdChgExSymBlk(si,ei,owd,nwd,SymChrLst);
}

const char* MyStr::GetRangeWithWdChgExSymBlk(const int si,const char *owd,const char *nwd,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(si,-1,owd,nwd,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExSymBlk(const int si,const char och,const char *nwd,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(si,-1,och,nwd,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExSymBlk(const int si,const char *owd,const char nch,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(si,-1,owd,nch,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExSymBlk(const int si,const char och,const char nch,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(si,-1,och,nch,SymChrLst);
}

const char* MyStr::GetRangeWithWdChgExSymBlk(const char *owd,const char *nwd,const char *SymChrLst) { 
	return GetRangeWithWdChgExSymBlk(-1,-1,owd,nwd,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExSymBlk(const char och,const char *nwd,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(-1,-1,och,nwd,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExSymBlk(const char *owd,const char nch,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(-1,-1,owd,nch,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExSymBlk(const char och,const char nch,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(-1,-1,och,nch,SymChrLst);
}
//#######################################################################################################################
const char* MyStr::GetRangeWithWdChgExLineSymBlk(const int si,const int ei,const char *owd,const char *nwd,const char *SymChrLst) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ep<0) ep=len-1;
	int lowd=0;
	if(owd!=NULL) lowd=strlen(owd);
	int lnwd=0;
	if(nwd!=NULL) lnwd=strlen(nwd);
//printf("\nstr='%s'",str);
	if(len<1 || sp>ep || ep>=len) return releasetmp();
	if(lowd<1) return resizetmp(str);
	if(lowd>0 && lowd==lnwd) if(strcmp(owd,nwd)==0) return resizetmp(str);

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeWithWdChg(si,ei,owd,nwd);

//printf("\nowd='%s' nwd='%s'  SymChrLst='%s'",owd,nwd,SymChrLst);

	MyStr T,S;
	PO2 pp=LineSymBlkIdxInStr(sp,ep,SymChrLst);
	while(pp.p1>-1) {
		int p=InStr(sp,pp.p1-1,owd);
		if(p>0) {
			T+=GetRangeByIdx(sp,p-1);
//printf("\n>>T.str='%s'",T.str);
			if(lnwd>0) { T+=nwd; T=T.GetRangeWithWdChg(owd,nwd); }
//printf("\n>>>T.str='%s'",T.str);
			sp=p+lowd;
		} else	{T+=GetRangeByIdx(sp,pp.p2); sp=pp.p2+1;}
		pp=LineSymBlkIdxInStr(sp,ep,SymChrLst);
	}
//printf("\n>>>>sp=%d ep=%d T.str='%s'",sp,ep,T.str);
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		T+=S.GetRangeWithWdChg(owd,nwd);
	}
//printf("\n##>T.str='%s'",T.str);
	return resizetmp(T.str);
}
const char* MyStr::GetRangeWithWdChgExLineSymBlk(const int si,const int ei,const char och,const char *nwd,const char *SymChrLst) {
	char owd[2]; owd[0]=och; owd[1]='\0';
	return GetRangeWithWdChgExLineSymBlk(si,ei,owd,nwd,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExLineSymBlk(const int si,const int ei,const char *owd,const char nch,const char *SymChrLst) {
	char nwd[2]; nwd[0]=nch; nwd[1]='\0';
	return GetRangeWithWdChgExLineSymBlk(si,ei,owd,nwd,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExLineSymBlk(const int si,const int ei,const char och,const char nch,const char *SymChrLst) {
	char owd[2]; owd[0]=och; owd[1]='\0';
	char nwd[2]; nwd[0]=nch; nwd[1]='\0';
	return GetRangeWithWdChgExLineSymBlk(si,ei,owd,nwd,SymChrLst);
}

const char* MyStr::GetRangeWithWdChgExLineSymBlk(const int si,const char *owd,const char *nwd,const char *SymChrLst) {
	return GetRangeWithWdChgExLineSymBlk(si,-1,owd,nwd,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExLineSymBlk(const int si,const char och,const char *nwd,const char *SymChrLst) {
	return GetRangeWithWdChgExLineSymBlk(si,-1,och,nwd,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExLineSymBlk(const int si,const char *owd,const char nch,const char *SymChrLst) {
	return GetRangeWithWdChgExLineSymBlk(si,-1,owd,nch,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExLineSymBlk(const int si,const char och,const char nch,const char *SymChrLst) {
	return GetRangeWithWdChgExLineSymBlk(si,-1,och,nch,SymChrLst);
}

const char* MyStr::GetRangeWithWdChgExLineSymBlk(const char *owd,const char *nwd,const char *SymChrLst) { 
	return GetRangeWithWdChgExLineSymBlk(-1,-1,owd,nwd,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExLineSymBlk(const char och,const char *nwd,const char *SymChrLst) {
	return GetRangeWithWdChgExLineSymBlk(-1,-1,och,nwd,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExLineSymBlk(const char *owd,const char nch,const char *SymChrLst) {
	return GetRangeWithWdChgExLineSymBlk(-1,-1,owd,nch,SymChrLst);
}
const char* MyStr::GetRangeWithWdChgExLineSymBlk(const char och,const char nch,const char *SymChrLst) {
	return GetRangeWithWdChgExLineSymBlk(-1,-1,och,nch,SymChrLst);
}
//#######################################################################################################################

const char* MyStr::GetRangeWithWdDel(const int si,const int ei,const char *wd) { 
	return GetRangeWithWdChg(si,ei,wd,""); 
}
const char* MyStr::GetRangeWithWdDel(const int si,const int ei,const char c) { 
	return GetRangeWithWdChg(si,ei,c,""); 
}

const char* MyStr::GetRangeWithWdDel(const int si,const char c) { 
	return GetRangeWithWdChg(si,-1,c,""); 
}
const char* MyStr::GetRangeWithWdDel(const int si,const char *wd) { 
	return GetRangeWithWdChg(si,-1,wd,""); 
}

const char* MyStr::GetRangeWithWdDel(const char c) { 
	return GetRangeWithWdChg(-1,-1,c,""); 
}
const char* MyStr::GetRangeWithWdDel(const char *wd) { 
	return GetRangeWithWdChg(-1,-1,wd,""); 
}

//#######################################################################################################################
const char* MyStr::GetRangeWithWdDelExSymBlk(const char c,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(-1,-1,c,"",SymChrLst);
}
const char* MyStr::GetRangeWithWdDelExSymBlk(const int si,const char c,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(si,-1,c,"",SymChrLst);
}
const char* MyStr::GetRangeWithWdDelExSymBlk(const int si,const int ei,const char c,const char *SymChrLst){
	return GetRangeWithWdChgExSymBlk(si,ei,c,"",SymChrLst);
}	

const char* MyStr::GetRangeWithWdDelExSymBlk(const char *wd,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(-1,-1,wd,"",SymChrLst);
}
const char* MyStr::GetRangeWithWdDelExSymBlk(const int si,const char *wd,const char *SymChrLst) {
	return GetRangeWithWdChgExSymBlk(si,-1,wd,"",SymChrLst);
}
const char* MyStr::GetRangeWithWdDelExSymBlk(const int si,const int ei,const char *wd,const char *SymChrLst){
	return GetRangeWithWdChgExSymBlk(si,ei,wd,"",SymChrLst);
}	
//#######################################################################################################################
const char* MyStr::GetRangeWithWdDelExLineSymBlk(const char c,const char *SymChrLst) {
	return GetRangeWithWdChgExLineSymBlk(-1,-1,c,"",SymChrLst);
}
const char* MyStr::GetRangeWithWdDelExLineSymBlk(const int si,const char c,const char *SymChrLst) {
	return GetRangeWithWdChgExLineSymBlk(si,-1,c,"",SymChrLst);
}
const char* MyStr::GetRangeWithWdDelExLineSymBlk(const int si,const int ei,const char c,const char *SymChrLst){
	return GetRangeWithWdChgExLineSymBlk(si,ei,c,"",SymChrLst);
}	

const char* MyStr::GetRangeWithWdDelExLineSymBlk(const char *wd,const char *SymChrLst) {
	return GetRangeWithWdChgExLineSymBlk(-1,-1,wd,"",SymChrLst);
}
const char* MyStr::GetRangeWithWdDelExLineSymBlk(const int si,const char *wd,const char *SymChrLst) {
	return GetRangeWithWdChgExLineSymBlk(si,-1,wd,"",SymChrLst);
}
const char* MyStr::GetRangeWithWdDelExLineSymBlk(const int si,const int ei,const char *wd,const char *SymChrLst){
	return GetRangeWithWdChgExLineSymBlk(si,ei,wd,"",SymChrLst);
}	

//#######################################################################################################################

const char* MyStr::GetRangeWithSpDel(const int si,const int ei) {
	MyStr T(GetRangeWithWdDelExSymBlk(si,ei,'\t',""));
	return resizetmp(T.GetRangeWithWdDelExSymBlk(si,ei,' ',""));
}
const char* MyStr::GetRangeWithSpDel(const int si) {
	return GetRangeWithSpDel(si,-1);
}
const char* MyStr::GetRangeWithSpDel(void) {
	return GetRangeWithSpDel(-1,-1);
}

//#######################################################################################################################
const char* MyStr::GetRangeWithSpDelExSymBlk(const int si,const int ei,const char *SymChrLst) {
	MyStr T(GetRangeWithWdDelExSymBlk(si,ei,'\t',SymChrLst));
	return resizetmp(T.GetRangeWithWdDelExSymBlk(si,ei,' ',SymChrLst));
}
const char* MyStr::GetRangeWithSpDelExSymBlk(const int si,const char *SymChrLst) {
	return GetRangeWithSpDelExSymBlk(si,-1,SymChrLst);
}
const char* MyStr::GetRangeWithSpDelExSymBlk(const char *SymChrLst) {
	return GetRangeWithSpDelExSymBlk(-1,-1,SymChrLst);
}
//#######################################################################################################################
const char* MyStr::GetRangeWithSpDelExLineSymBlk(const int si,const int ei,const char *SymChrLst) {
	MyStr T(GetRangeWithWdDelExLineSymBlk(si,ei,'\t',SymChrLst));
	return resizetmp(T.GetRangeWithWdDelExLineSymBlk(si,ei,' ',SymChrLst));
}
const char* MyStr::GetRangeWithSpDelExLineSymBlk(const int si,const char *SymChrLst) {
	return GetRangeWithSpDelExLineSymBlk(si,-1,SymChrLst);
}
const char* MyStr::GetRangeWithSpDelExLineSymBlk(const char *SymChrLst) {
	return GetRangeWithSpDelExLineSymBlk(-1,-1,SymChrLst);
}
//#######################################################################################################################

const char* MyStr::GetRangeWithWdCmpress(const int si,const int ei,const char *wd) {
	int lwd=0;
	if(wd!=NULL) lwd=strlen(wd);
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	
	if(sp>ep || ep>=len) releasetmp();
	if(len<(lwd*2) || lwd<1) return resizetmp(str);
	
	MyStr T;
	int p=InStr(sp,ep,wd);
	while(p>-1) {
		T+=GetRangeByIdx(sp,p+lwd-1);
		sp=p+lwd;  p=InStr(sp,ep,wd);
		while(p==sp) { sp=p+lwd; p=InStr(sp,ep,wd); }
	}
	if(sp<=ep) T+=GetRangeByIdx(sp,ep);
	return resizetmp(T.str);
}
const char* MyStr::GetRangeWithWdCmpress(const int si,const char *wd) {
	return GetRangeWithWdCmpress(si,-1,wd);
}
const char* MyStr::GetRangeWithWdCmpress(const char *wd) {
	return GetRangeWithWdCmpress(-1,-1,wd);
}
const char* MyStr::GetRangeWithWdCmpress(const int si,const int ei,const char c) {
	char cc[2]; cc[0]=c; cc[1]='\0';
	return GetRangeWithWdCmpress(si,ei,cc);
}
const char* MyStr::GetRangeWithWdCmpress(const int si,const char c) {
	return GetRangeWithWdCmpress(si,-1,c);
}
const char* MyStr::GetRangeWithWdCmpress(const char c) {
	return GetRangeWithWdCmpress(-1,-1,c);
}

//#######################################################################################################################
const char* MyStr::GetRangeWithWdCmpressExSymBlk(const int si,const int ei,const char *wd,const char *SymChrLst) {
	int lwd=0;
	if(wd!=NULL) lwd=strlen(wd);
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	
	if(sp>ep || ep>=len) releasetmp();
	if(len<(lwd*2) || lwd<1) return resizetmp(str);

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeWithWdCmpress(si,ei,wd);
	
	MyStr T,S;
	PO2 pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	while(pp.p1>-1) {
		if(pp.p1>sp) {
			S=GetRangeByIdx(sp,pp.p1-1);
			T+=S.GetRangeWithWdCmpress(-1,-1,wd);
		}
		T+=GetRangeByIdx(pp.p1,pp.p2);
		sp=pp.p2+1;
		pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	}
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		T+=S.GetRangeWithWdCmpress(-1,-1,wd);
	}
	return resizetmp(T.str);
}
const char* MyStr::GetRangeWithWdCmpressExSymBlk(const int si,const char *wd,const char *SymChrLst) {
	return GetRangeWithWdCmpressExSymBlk(si,-1,wd,SymChrLst);
}
const char* MyStr::GetRangeWithWdCmpressExSymBlk(const char *wd,const char *SymChrLst) {
	return GetRangeWithWdCmpressExSymBlk(-1,-1,wd,SymChrLst);
}
const char* MyStr::GetRangeWithWdCmpressExSymBlk(const int si,const int ei,const char c,const char *SymChrLst) {
	char cc[2]; cc[0]=c; cc[1]='\0';
	return GetRangeWithWdCmpressExSymBlk(si,ei,cc,SymChrLst);
}
const char* MyStr::GetRangeWithWdCmpressExSymBlk(const int si,const char c,const char *SymChrLst) {
	return GetRangeWithWdCmpressExSymBlk(si,-1,c,SymChrLst);
}
const char* MyStr::GetRangeWithWdCmpressExSymBlk(const char c,const char *SymChrLst) {
	return GetRangeWithWdCmpressExSymBlk(-1,-1,c,SymChrLst);
}
//#######################################################################################################################
const char* MyStr::GetRangeWithWdCmpressExLineSymBlk(const int si,const int ei,const char *wd,const char *SymChrLst) {
	int lwd=0;
	if(wd!=NULL) lwd=strlen(wd);
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	
	if(sp>ep || ep>=len) releasetmp();
	if(len<(lwd*2) || lwd<1) return resizetmp(str);

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeWithWdCmpress(si,ei,wd);
	
	MyStr T,S;
	PO2 pp=LineSymBlkIdxInStr(sp,ep,SymChrLst);
	while(pp.p1>-1) {
		if(pp.p1>sp) {
			S=GetRangeByIdx(sp,pp.p1-1);
			T+=S.GetRangeWithWdCmpress(-1,-1,wd);
		}
		T+=GetRangeByIdx(pp.p1,pp.p2);
		sp=pp.p2+1;
		pp=LineSymBlkIdxInStr(sp,ep,SymChrLst);
	}
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		T+=S.GetRangeWithWdCmpress(-1,-1,wd);
	}
	return resizetmp(T.str);
}
const char* MyStr::GetRangeWithWdCmpressExLineSymBlk(const int si,const char *wd,const char *SymChrLst) {
	return GetRangeWithWdCmpressExLineSymBlk(si,-1,wd,SymChrLst);
}
const char* MyStr::GetRangeWithWdCmpressExLineSymBlk(const char *wd,const char *SymChrLst) {
	return GetRangeWithWdCmpressExLineSymBlk(-1,-1,wd,SymChrLst);
}
const char* MyStr::GetRangeWithWdCmpressExLineSymBlk(const int si,const int ei,const char c,const char *SymChrLst) {
	char cc[2]; cc[0]=c; cc[1]='\0';
	return GetRangeWithWdCmpressExLineSymBlk(si,ei,cc,SymChrLst);
}
const char* MyStr::GetRangeWithWdCmpressExLineSymBlk(const int si,const char c,const char *SymChrLst) {
	return GetRangeWithWdCmpressExLineSymBlk(si,-1,c,SymChrLst);
}
const char* MyStr::GetRangeWithWdCmpressExLineSymBlk(const char c,const char *SymChrLst) {
	return GetRangeWithWdCmpressExLineSymBlk(-1,-1,c,SymChrLst);
}

//#######################################################################################################################

const char* MyStr::GetRangeWithSpCmpress(const int si,const int ei) {
	MyStr S(GetRangeWithWdChg(si,ei,'\t',' '));
	return resizetmp(S.GetRangeWithWdCmpress(' '));
}
const char* MyStr::GetRangeWithSpCmpress(const int si) {
	return GetRangeWithSpCmpress(si,-1);
}
const char* MyStr::GetRangeWithSpCmpress(void) {
	return GetRangeWithSpCmpress(-1,-1);
}

//#######################################################################################################################
const char* MyStr::GetRangeWithSpCmpressExSymBlk(const int si,const int ei,const char *SymChrLst) {
	MyStr S(GetRangeWithWdChgExSymBlk(si,ei,'\t',' ',SymChrLst));
	return resizetmp(S.GetRangeWithWdCmpressExSymBlk(-1,-1,' ',SymChrLst));
}
const char* MyStr::GetRangeWithSpCmpressExSymBlk(const int si,const char *SymChrLst) {
	return GetRangeWithSpCmpressExSymBlk(si,-1,SymChrLst);
}
const char* MyStr::GetRangeWithSpCmpressExSymBlk(const char *SymChrLst) {
	return GetRangeWithSpCmpressExSymBlk(-1,-1,SymChrLst);
}
//#######################################################################################################################
const char* MyStr::GetRangeWithSpCmpressExLineSymBlk(const int si,const int ei,const char *SymChrLst) {
	MyStr S(GetRangeWithWdChgExLineSymBlk(si,ei,'\t',' ',SymChrLst));
	return resizetmp(S.GetRangeWithWdCmpressExLineSymBlk(-1,-1,' ',SymChrLst));
}
const char* MyStr::GetRangeWithSpCmpressExLineSymBlk(const int si,const char *SymChrLst) {
	return GetRangeWithSpCmpressExLineSymBlk(si,-1,SymChrLst);
}
const char* MyStr::GetRangeWithSpCmpressExLineSymBlk(const char *SymChrLst) {
	return GetRangeWithSpCmpressExLineSymBlk(-1,-1,SymChrLst);
}

//#######################################################################################################################
const char* MyStr::GetTrimL(const int si,const int ei) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return releasetmp();

	MyStr T;
	MyStr S(GetRangeByIdx(sp,ep));
	for(int n=0;n<S.len;n++) {
		if(S.str[n]>32 && S.str[n]<127) { T=S.GetRangeByIdx(n,-1); break; }
	}
	return resizetmp(T.str);
}
const char* MyStr::GetTrimL(const int si) {
	return GetTrimL(si,-1);
}
const char* MyStr::GetTrimL(void) {
	return GetTrimL(-1,-1);
}
//#######################################################################################################################
const char* MyStr::GetTrimR(const int si,const int ei) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return releasetmp();

	MyStr T;
	MyStr S(GetRangeByIdx(sp,ep));
	for(int n=S.len-1;n>=0;n--) {
		if(S.str[n]>32 && S.str[n]<127) { T=S.GetRangeByIdx(-1,n); break; }
	}
	return resizetmp(T.str);
}
const char* MyStr::GetTrimR(const int si) {
	return GetTrimR(si,-1);
}
const char* MyStr::GetTrimR(void) {
	return GetTrimR(-1,-1);
}
//#######################################################################################################################
const char* MyStr::GetTrim(const int si,const int ei) {
	MyStr S(GetRangeByIdx(si,ei));
	S=S.GetTrimL(-1,-1);
	return resizetmp(S.GetTrimR(-1,-1));
}
const char* MyStr::GetTrim(const int si) {
	return GetTrim(si,-1);
}
const char* MyStr::GetTrim(void) {
	return GetTrim(-1,-1);
}
//#######################################################################################################################
const char* MyStr::GetTrimA(const int si,const int ei) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	
	if(len<1 || sp>ep || ep>=len) return releasetmp();

	resizetmp(str);
	int p=0;
	for(int n=sp;n<=ep;n++) {
		if(str[n]>32 && str[n]<127) tmp[p++]=str[n];
	}
	tmp[p]='\0';
	return tmp;
}
const char* MyStr::GetTrimA(const int si) {
	return GetTrimA(si,-1);
}
const char* MyStr::GetTrimA(void) {
	return GetTrimA(-1,-1);
}
//#######################################################################################################################

const char* MyStr::GetLineTrimL(const int si,const int ei) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return releasetmp();

	MyStr T,S;
	int p=InStr(sp,ep,'\n');
	while(p>-1) {
		if(p>sp) {
			S=GetRangeByIdx(sp,p-1);
			T+=S.GetLineTrimL(-1,-1);
		}
		T+='\n';
		sp=p+1;
		p=InStr(sp,ep,'\n');
	}
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		for(int n=0;n<S.len;n++) {
			if(S.str[n]>32 && S.str[n]<127) { T+=S.GetRangeByIdx(n,-1); break; }
		}
	}
	return resizetmp(T.str);
}
const char* MyStr::GetLineTrimL(const int si) {
	return GetLineTrimL(si,-1);
}
const char* MyStr::GetLineTrimL(void) {
	return GetLineTrimL(-1,-1);
}

//#######################################################################################################################

const char* MyStr::GetLineTrimR(const int si,const int ei) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return releasetmp();

	MyStr T,S;
	int p=InStr(sp,ep,'\n');
	while(p>-1) {
		if(p>sp) {
			S=GetRangeByIdx(sp,p-1);
			T+=S.GetLineTrimR(-1,-1);
		}
		T+='\n';
		sp=p+1;
		p=InStr(sp,ep,'\n');
	}
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		for(int n=S.len-1;n>=0;n--) {
			if(S.str[n]>32 && S.str[n]<127) { T+=S.GetRangeByIdx(-1,n); break; }
		}
	}
	return resizetmp(T.str);
}
const char* MyStr::GetLineTrimR(const int si) {
	return GetLineTrimR(si,-1);
}
const char* MyStr::GetLineTrimR(void) {
	return GetLineTrimR(-1,-1);
}

//#######################################################################################################################

const char* MyStr::GetLineTrim(const int si,const int ei) {
	MyStr S(GetRangeByIdx(si,ei));
	S=S.GetLineTrimL(-1,-1);
	return resizetmp(S.GetLineTrimR(-1,-1));
}
const char* MyStr::GetLineTrim(const int si) {
	return GetLineTrim(si,-1);
}
const char* MyStr::GetLineTrim(void) {
	return GetLineTrim(-1,-1);
}

//#######################################################################################################################

const char* MyStr::GetLineTrimA(const int si,const int ei) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	
	if(len<1 || sp>ep || ep>=len) return releasetmp();

	resizetmp(str);
	int p=0;
	for(int n=sp;n<=ep;n++) {
		if(str[n]=='\n' || (str[n]>32 && str[n]<127)) tmp[p++]=str[n];
	}
	tmp[p]='\0';
	return tmp;
}
const char* MyStr::GetLineTrimA(const int si) {
	return GetLineTrimA(si,-1);
}
const char* MyStr::GetLineTrimA(void) {
	return GetLineTrimA(-1,-1);
}

//#######################################################################################################################

const char* MyStr::GetLineTrimLExSymBlk(const int si,const int ei,const char *SymChrLst) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return releasetmp();

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetLineTrimL(sp,ep);
	
	MyStr T,S;
	int p=InStr(sp,ep,'\n');
	while(p>-1) {	
		int k=sp;
		PO2 pp=SymBlkIdxInStr(k,ep,SymChrLst);
		while(pp.p1>-1) {
			if(pp.p1<=p && pp.p2>=p) {
				pp.p2=InStr(pp.p2+1,ep,'\n');
				if(pp.p2<0) pp.p2=ep;
				break;
			}
			k=pp.p2+1;
			pp=SymBlkIdxInStr(k,ep,SymChrLst);
		}
		if(pp.p1<0) {
			S=GetRangeByIdx(sp,p);
			T+=S.GetLineTrimL();
			sp=p+1;
		} else {
			if(pp.p1>sp) { 
				S=GetRangeByIdx(sp,pp.p1-1);
				T+=S.GetLineTrimL();
				T+=GetRangeByIdx(pp.p1,pp.p2);
			} else T+=GetRangeByIdx(sp,pp.p2);
			sp=pp.p2+1;
		}
		p=InStr(sp,ep,'\n');
	}
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		T+=S.GetLineTrimL();
	}
	return resizetmp(T.str);
}
const char* MyStr::GetLineTrimLExSymBlk(const int si,const char *SymChrLst) {
	return GetLineTrimLExSymBlk(si,-1,SymChrLst);
}
const char* MyStr::GetLineTrimLExSymBlk(const char *SymChrLst) {
	return GetLineTrimLExSymBlk(-1,-1,SymChrLst);
}

//#######################################################################################################################

const char* MyStr::GetLineTrimRExSymBlk(const int si,const int ei,const char *SymChrLst) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return releasetmp();

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetLineTrimR(sp,ep);
	
	MyStr T,S;
	int p=InStr(sp,ep,'\n');
	while(p>-1) {	
		int k=sp;
		PO2 pp=SymBlkIdxInStr(k,ep,SymChrLst);
		while(pp.p1>-1) {
			if(pp.p1<=p && pp.p2>=p) break;
			k=pp.p2+1;
			pp=SymBlkIdxInStr(k,ep,SymChrLst);
		}
		if(pp.p1<0) {
			S=GetRangeByIdx(sp,p);
			T+=S.GetLineTrimR();
			sp=p+1;
		} else {
			T+=GetRangeByIdx(sp,pp.p2);
			sp=pp.p2+1;
		}
		p=InStr(sp,ep,'\n');
	}
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		T+=S.GetLineTrimR();
	}
	return resizetmp(T.str);
}
const char* MyStr::GetLineTrimRExSymBlk(const int si,const char *SymChrLst) {
	return GetLineTrimRExSymBlk(si,-1,SymChrLst);
}
const char* MyStr::GetLineTrimRExSymBlk(const char *SymChrLst) {
	return GetLineTrimRExSymBlk(-1,-1,SymChrLst);
}

//#######################################################################################################################

const char* MyStr::GetLineTrimExSymBlk(const int si,const int ei,const char *SymChrLst) {
	MyStr S(GetRangeByIdx(si,ei));
	S=S.GetLineTrimLExSymBlk(SymChrLst);
	return resizetmp(S.GetLineTrimRExSymBlk(SymChrLst));
}
const char* MyStr::GetLineTrimExSymBlk(const int si,const char *SymChrLst) {
	return GetLineTrimExSymBlk(si,-1,SymChrLst);
}
const char* MyStr::GetLineTrimExSymBlk(const char *SymChrLst) {
	return GetLineTrimExSymBlk(-1,-1,SymChrLst);
}

//#######################################################################################################################

const char* MyStr::GetLineTrimAExSymBlk(const int si,const int ei,const char *SymChrLst) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return releasetmp();

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	
	if(lsym<1) return GetLineTrimA(sp,ep);
	
	MyStr T,S;
	PO2 pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	while(pp.p1>-1) {
		if(pp.p1>sp) {
			S=GetRangeByIdx(sp,pp.p1-1);
			T+=S.GetLineTrimA(-1,-1);
		}
		T+=GetRangeByIdx(pp.p1,pp.p2);
		sp=pp.p2+1;
		pp=SymBlkIdxInStr(sp,ep,SymChrLst);
	}
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		T+=S.GetLineTrimA(-1,-1);
	}
	return resizetmp(T.str);
}
const char* MyStr::GetLineTrimAExSymBlk(const int si,const char *SymChrLst) {
	return GetLineTrimAExSymBlk(si,-1,SymChrLst);
}
const char* MyStr::GetLineTrimAExSymBlk(const char *SymChrLst) {
	return GetLineTrimAExSymBlk(-1,-1,SymChrLst);
}

//#######################################################################################################################

const char* MyStr::GetRangeWithDelByKey(const char c1,const char c2) {
	return GetRangeWithDelByKey(-1,-1,c1,c2);
}
const char* MyStr::GetRangeWithDelByKey(const char c1,const char *k2) {
	return GetRangeWithDelByKey(-1,-1,c1,k2);
}
const char* MyStr::GetRangeWithDelByKey(const char *k1,const char c2) {
	return GetRangeWithDelByKey(-1,-1,k1,c2);
}
const char* MyStr::GetRangeWithDelByKey(const char *k1,const char *k2) {
	return GetRangeWithDelByKey(-1,-1,k1,k2);
}

const char* MyStr::GetRangeWithDelByKey(const int si,const char c1,const char c2) {
	return GetRangeWithDelByKey(si,-1,c1,c2);
}
const char* MyStr::GetRangeWithDelByKey(const int si,const char c1,const char *k2) {
	return GetRangeWithDelByKey(si,-1,c1,k2);
}
const char* MyStr::GetRangeWithDelByKey(const int si,const char *k1,const char c2) {
	return GetRangeWithDelByKey(si,-1,k1,c2);
}
const char* MyStr::GetRangeWithDelByKey(const int si,const char *k1,const char *k2) {
	return GetRangeWithDelByKey(si,-1,k1,k2);
}

const char* MyStr::GetRangeWithDelByKey(const int si,const int ei,const char *k1,const char *k2) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	if(len<1 || sp>ep || ep>=len) return releasetmp();
	
	int l1=0;
	if(k1!=NULL) l1=strlen(k1);
	int l2=0;
	if(k2!=NULL) l2=strlen(k2);

	int p=-1;
	int q=-1;
	if(l1<1) {
		if(l2>0) q=InStr(sp,ep,k2);
		if(q>-1) return GetRangeByIdx(q,ep);
	} else if(l2<1) {
		p=InStr(sp,ep,k1);
		if(p>-1) {
			if(p>sp) return GetRangeByIdx(sp,p-1);
			else	 return releasetmp();
		}
	} else {
		p=InStr(sp,ep,k1);
		if(p>-1) q=InStr(p+l1,ep,k2);
		if(p>-1 && q>-1) {
			MyStr T;
			if(p>sp) T=GetRangeByIdx(sp,p-1);
			MyStr S(GetRangeByIdx(q+l2,ep));
			T+=S.GetRangeWithDelByKey(-1,-1,k1,k2);
			return resizetmp(T.str);
		}
	}
	return GetRangeByIdx(sp,ep);
}
const char* MyStr::GetRangeWithDelByKey(const int si,const int ei,const char c1,const char c2) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelByKey(si,ei,k1,k2);
}
const char* MyStr::GetRangeWithDelByKey(const int si,const int ei,const char c1,const char *k2) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeWithDelByKey(si,ei,k1,k2);
}
const char* MyStr::GetRangeWithDelByKey(const int si,const int ei,const char *k1,const char c2) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelByKey(si,ei,k1,k2);
}

//#######################################################################################################################

const char* MyStr::GetRangeWithDelBtwKey(const char c1,const char c2) {
	return GetRangeWithDelBtwKey(-1,-1,c1,c2);
}
const char* MyStr::GetRangeWithDelBtwKey(const char c1,const char *k2) {
	return GetRangeWithDelBtwKey(-1,-1,c1,k2);
}
const char* MyStr::GetRangeWithDelBtwKey(const char *k1,const char c2) {
	return GetRangeWithDelBtwKey(-1,-1,k1,c2);
}
const char* MyStr::GetRangeWithDelBtwKey(const char *k1,const char *k2) {
	return GetRangeWithDelBtwKey(-1,-1,k1,k2);
}

const char* MyStr::GetRangeWithDelBtwKey(const int si,const char c1,const char c2) {
	return GetRangeWithDelBtwKey(si,-1,c1,c2);
}
const char* MyStr::GetRangeWithDelBtwKey(const int si,const char c1,const char *k2) {
	return GetRangeWithDelBtwKey(si,-1,c1,k2);
}
const char* MyStr::GetRangeWithDelBtwKey(const int si,const char *k1,const char c2) {
	return GetRangeWithDelBtwKey(si,-1,k1,c2);
}
const char* MyStr::GetRangeWithDelBtwKey(const int si,const char *k1,const char *k2) {
	return GetRangeWithDelBtwKey(si,-1,k1,k2);
}

const char* MyStr::GetRangeWithDelBtwKey(const int si,const int ei,const char *k1,const char *k2) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	if(len<1 || sp>ep || ep>=len) return releasetmp();
	
	int l1=0;
	if(k1!=NULL) l1=strlen(k1);
	int l2=0;
	if(k2!=NULL) l2=strlen(k2);

	int p=-1;
	int q=-1;
	if(l1<1) {
		if(l2>0) q=InStr(sp,ep,k2);
		if(q>-1) return GetRangeByIdx(q,ep);
	} else if(l2<1) {
		p=InStr(sp,ep,k1);
		if(p>-1) return GetRangeByIdx(sp,p+l1-1);
	} else {
		p=InStr(sp,ep,k1);
		if(p>-1) q=InStr(p+l1,ep,k2);
		if(p>-1 && q>-1) {
			MyStr T(GetRangeByIdx(sp,p+l1-1));
			T+=k2;
			MyStr S(GetRangeByIdx(q+l2,ep));
			T+=S.GetRangeWithDelBtwKey(-1,-1,k1,k2);
			return resizetmp(T.str);
		}
	}
	return GetRangeByIdx(sp,ep);
}
const char* MyStr::GetRangeWithDelBtwKey(const int si,const int ei,const char c1,const char c2) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelBtwKey(si,ei,k1,k2);
}
const char* MyStr::GetRangeWithDelBtwKey(const int si,const int ei,const char c1,const char *k2) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeWithDelBtwKey(si,ei,k1,k2);
}
const char* MyStr::GetRangeWithDelBtwKey(const int si,const int ei,const char *k1,const char c2) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelBtwKey(si,ei,k1,k2);
}

//#######################################################################################################################
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const char c1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExSymBlk(-1,-1,c1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExSymBlk(-1,-1,c1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExSymBlk(-1,-1,k1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExSymBlk(-1,-1,k1,k2,SymChrLst);
}

const char* MyStr::GetRangeWithDelByKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExSymBlk(si,-1,c1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExSymBlk(si,-1,c1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExSymBlk(si,-1,k1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExSymBlk(si,-1,k1,k2,SymChrLst);
}

const char* MyStr::GetRangeWithDelByKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst) {
	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeWithDelByKey(si,ei,k1,k2);
	
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	if(len<1 || sp>ep || ep>=len) return releasetmp();
	
	int l1=0;
	if(k1!=NULL) l1=strlen(k1);
	int l2=0;
	if(k2!=NULL) l2=strlen(k2);
	
	int p=sp;
	int q=ep;
	if(l1>0) p=InStr(sp,ep,k1);
	if(l2>0) {
		if(l1>0) 	q=InStr(p+l1,ep,k2);
	    else		q=InStr(sp,ep,k2);
	}

	if(p>-1 && q>-1) {
		int k=sp;
		PO2 pp=SymBlkIdxInStr(k,ep,SymChrLst);
		while(pp.p1>-1) {
			k=pp.p2+1;
			if(l1>0 && (p>=pp.p1 && p<=pp.p2)) {
				p=InStr(k,ep,k1);
				if(l2>0) q=InStr(p+l1,ep,k2);
			}
			if(l2>0 && (q>=pp.p1 && q<=pp.p2)) q=InStr(k,ep,k2);
			if(p<0 || q<0) break;
			pp=SymBlkIdxInStr(k,ep,SymChrLst);
		}	
		if(p>-1 && q>=p) {
			MyStr T;
			if(p>sp) T+=GetRangeByIdx(sp,p-1);
			if(l2>0) {
				q+=l2;
				if(q<ep) { MyStr S(GetRangeByIdx(q,ep)); T+=S.GetRangeWithDelByKeyExSymBlk(-1,-1,k1,k2,SymChrLst); }
			}
			return resizetmp(T.str);
		}
	}
	return resizetmp(GetRangeByIdx(sp,ep));
}
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelByKeyExSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeWithDelByKeyExSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelByKeyExSymBlk(si,ei,k1,k2,SymChrLst);
}
//#######################################################################################################################
const char* MyStr::GetRangeWithDelByKeyExLineSymBlk(const char c1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExLineSymBlk(-1,-1,c1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExLineSymBlk(const char c1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExLineSymBlk(-1,-1,c1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExLineSymBlk(const char *k1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExLineSymBlk(-1,-1,k1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExLineSymBlk(const char *k1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExLineSymBlk(-1,-1,k1,k2,SymChrLst);
}

const char* MyStr::GetRangeWithDelByKeyExLineSymBlk(const int si,const char c1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExLineSymBlk(si,-1,c1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExLineSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExLineSymBlk(si,-1,c1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExLineSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExLineSymBlk(si,-1,k1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExLineSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelByKeyExLineSymBlk(si,-1,k1,k2,SymChrLst);
}

const char* MyStr::GetRangeWithDelByKeyExLineSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst) {
	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeWithDelByKey(si,ei,k1,k2);
	
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	if(len<1 || sp>ep || ep>=len) return releasetmp();
	
	int l1=0;
	if(k1!=NULL) l1=strlen(k1);
	int l2=0;
	if(k2!=NULL) l2=strlen(k2);
	
	int p=sp;
	int q=ep;
	if(l1>0) p=InStr(sp,ep,k1);
	if(l2>0) {
		if(l1>0) 	q=InStr(p+l1,ep,k2);
	    else		q=InStr(sp,ep,k2);
	}

	if(p>-1 && q>-1) {
		int k=sp;
		PO2 pp=LineSymBlkIdxInStr(k,ep,SymChrLst);
		while(pp.p1>-1) {
			k=pp.p2+1;
			if(l1>0 && (p>=pp.p1 && p<=pp.p2)) {
				p=InStr(k,ep,k1);
				if(l2>0) q=InStr(p+l1,ep,k2);
			}
			if(l2>0 && (q>=pp.p1 && q<=pp.p2)) q=InStr(k,ep,k2);
			if(p<0 || q<0) break;
			pp=LineSymBlkIdxInStr(k,ep,SymChrLst);
		}	
		if(p>-1 && q>=p) {
			MyStr T;
			if(p>sp) T+=GetRangeByIdx(sp,p-1);
			if(l2>0) {
				q+=l2;
				if(q<ep) { MyStr S(GetRangeByIdx(q,ep)); T+=S.GetRangeWithDelByKeyExLineSymBlk(-1,-1,k1,k2,SymChrLst); }
			}
			return resizetmp(T.str);
		}
	}
	return resizetmp(GetRangeByIdx(sp,ep));
}
const char* MyStr::GetRangeWithDelByKeyExLineSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelByKeyExLineSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExLineSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeWithDelByKeyExLineSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelByKeyExLineSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelByKeyExLineSymBlk(si,ei,k1,k2,SymChrLst);
}

//#######################################################################################################################
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const char c1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExSymBlk(-1,-1,c1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExSymBlk(-1,-1,c1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExSymBlk(-1,-1,k1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExSymBlk(-1,-1,k1,k2,SymChrLst);
}

const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExSymBlk(si,-1,c1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExSymBlk(si,-1,c1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExSymBlk(si,-1,k1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExSymBlk(si,-1,k1,k2,SymChrLst);
}

const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst) {
	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeWithDelBtwKey(si,ei,k1,k2);
	
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	if(len<1 || sp>ep || ep>=len) return releasetmp();
	
	int l1=0;
	if(k1!=NULL) l1=strlen(k1);
	int l2=0;
	if(k2!=NULL) l2=strlen(k2);
	
	int p=sp;
	int q=ep;
	if(l1>0) p=InStr(sp,ep,k1);
	if(l2>0) {
		if(l1>0) 	q=InStr(p+l1,ep,k2);
	    else		q=InStr(sp,ep,k2);
	}

	if(p>-1 && q>-1) {
		int k=sp;
		PO2 pp=SymBlkIdxInStr(k,ep,SymChrLst);
		while(pp.p1>-1) {
			k=pp.p2+1;
			if(l1>0 && (p>=pp.p1 && p<=pp.p2)) {
				p=InStr(k,ep,k1);
				if(l2>0) q=InStr(p+l1,ep,k2);
			}
			if(l2>0 && (q>=pp.p1 && q<=pp.p2)) q=InStr(k,ep,k2);
			if(p<0 || q<0) break;
			pp=SymBlkIdxInStr(k,ep,SymChrLst);
		}	
		if(p>-1 && q>=p) {
			MyStr T;
			if(p>sp) T+=GetRangeByIdx(sp,p-1);
			if(l1>0) T+=k1;
			if(l2>0) {
				T+=k2;  q+=l2;
				if(q<ep) { MyStr S(GetRangeByIdx(q,ep)); T+=S.GetRangeWithDelBtwKeyExSymBlk(-1,-1,k1,k2,SymChrLst); }
			}
			return resizetmp(T.str);
		}
	}
	return resizetmp(GetRangeByIdx(sp,ep));
}
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelBtwKeyExSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelBtwKeyExSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeWithDelBtwKeyExSymBlk(si,ei,k1,k2,SymChrLst);
}
//#######################################################################################################################
const char* MyStr::GetRangeWithDelBtwKeyExLineSymBlk(const char c1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExLineSymBlk(-1,-1,c1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExLineSymBlk(const char c1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExLineSymBlk(-1,-1,c1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExLineSymBlk(const char *k1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExLineSymBlk(-1,-1,k1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExLineSymBlk(const char *k1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExLineSymBlk(-1,-1,k1,k2,SymChrLst);
}

const char* MyStr::GetRangeWithDelBtwKeyExLineSymBlk(const int si,const char c1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExLineSymBlk(si,-1,c1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExLineSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExLineSymBlk(si,-1,c1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExLineSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExLineSymBlk(si,-1,k1,c2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExLineSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst) {
	return GetRangeWithDelBtwKeyExLineSymBlk(si,-1,k1,k2,SymChrLst);
}

const char* MyStr::GetRangeWithDelBtwKeyExLineSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst) {
	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetRangeWithDelBtwKey(si,ei,k1,k2);
	
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	if(len<1 || sp>ep || ep>=len) return releasetmp();
	
	int l1=0;
	if(k1!=NULL) l1=strlen(k1);
	int l2=0;
	if(k2!=NULL) l2=strlen(k2);
	
	int p=sp;
	int q=ep;
	if(l1>0) p=InStr(sp,ep,k1);
	if(l2>0) {
		if(l1>0) 	q=InStr(p+l1,ep,k2);
	    else		q=InStr(sp,ep,k2);
	}

	if(p>-1 && q>-1) {
		int k=sp;
		PO2 pp=LineSymBlkIdxInStr(k,ep,SymChrLst);
		while(pp.p1>-1) {
			k=pp.p2+1;
			if(l1>0 && (p>=pp.p1 && p<=pp.p2)) {
				p=InStr(k,ep,k1);
				if(l2>0) q=InStr(p+l1,ep,k2);
			}
			if(l2>0 && (q>=pp.p1 && q<=pp.p2)) q=InStr(k,ep,k2);
			if(p<0 || q<0) break;
			pp=LineSymBlkIdxInStr(k,ep,SymChrLst);
		}	
		if(p>-1 && q>=p) {
			MyStr T;
			if(p>sp) T+=GetRangeByIdx(sp,p-1);
			if(l1>0) T+=k1;
			if(l2>0) {
				T+=k2;  q+=l2;
				if(q<ep) { MyStr S(GetRangeByIdx(q,ep)); T+=S.GetRangeWithDelBtwKeyExLineSymBlk(-1,-1,k1,k2,SymChrLst); }
			}
			return resizetmp(T.str);
		}
	}
	return resizetmp(GetRangeByIdx(sp,ep));
}
const char* MyStr::GetRangeWithDelBtwKeyExLineSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelBtwKeyExLineSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExLineSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst) {
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetRangeWithDelBtwKeyExLineSymBlk(si,ei,k1,k2,SymChrLst);
}
const char* MyStr::GetRangeWithDelBtwKeyExLineSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst) {
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetRangeWithDelBtwKeyExLineSymBlk(si,ei,k1,k2,SymChrLst);
}

//#######################################################################################################################
const char* MyStr::GetLineWithCmtChrDelN(const char CmtChr,const int N) {
	return GetLineWithCmtChrDelN(-1,-1,CmtChr,N);
}
const char* MyStr::GetLineWithCmtChrDelN(const int si,const char CmtChr,const int N) {
	return GetLineWithCmtChrDelN(si,-1,CmtChr,N);
}
const char* MyStr::GetLineWithCmtChrDelN(const int si,const int ei,const char CmtChr,const int N) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return releasetmp();
	
	if(CmtChr=='\0') return resizetmp(str);

	MyStr T;
	int k=sp;
	int p=InStr(k,ep,'\n');
	while(p>-1) {
		if(p>k) {
			MyStr S(GetRangeByIdx(k,p-1));
			T+=S.GetLineWithCmtChrDelN(CmtChr,N);
			k=p;			
		}
		if(k<=p) T+=GetRangeByIdx(k,p);
		k=p+1;
		p=InStr(k,ep,'\n');
	}
	if(k<=ep) {
		int q=InStr(k,ep,CmtChr);
		while(q>-1) {
			if(q>k) T+=GetRangeByIdx(k,q-1);
			k=q+1;
			if(N>0) k+=N;
			q=InStr(k,ep,CmtChr);
		}
		if(k<=ep) T+=GetRangeByIdx(k,ep);
	}
	return resizetmp(T.str);
}
//#######################################################################################################################
const char* MyStr::GetLineWithCmtChrDelNExSymBlk(const char CmtChr,const int N,const char *SymChrLst){
	return GetLineWithCmtChrDelNExSymBlk(-1,-1,CmtChr,N,SymChrLst);
}
const char* MyStr::GetLineWithCmtChrDelNExSymBlk(const int si,const char CmtChr,const int N,const char *SymChrLst){
	return GetLineWithCmtChrDelNExSymBlk(si,-1,CmtChr,N,SymChrLst);
}
const char* MyStr::GetLineWithCmtChrDelNExSymBlk(const int si,const int ei,const char CmtChr,const int N,const char *SymChrLst){
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return releasetmp();
	
	if(CmtChr=='\0') return resizetmp(str);
	
	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	
	if(lsym<1) return GetLineWithCmtChrDelN(si,ei,CmtChr,N);

	MyStr T,S;
	int k=sp;
	PO2 pp=SymBlkIdxInStr(k,ep,SymChrLst);
	
	while(pp.p1>-1) {
		if(pp.p1>k) { S=GetRangeByIdx(k,pp.p1-1); T+=S.GetLineWithCmtChrDelN(CmtChr,N); }
		T+=GetRangeByIdx(pp.p1,pp.p2);
		k=pp.p2+1;
		pp=SymBlkIdxInStr(k,ep,SymChrLst);
	}
	if(k<=ep) {
		S=GetRangeByIdx(k,ep);
		T+=S.GetLineWithCmtChrDelN(CmtChr,N);
	}
	return resizetmp(T.str);
}
//#######################################################################################################################
const char* MyStr::GetLineDelByKey(const char c1,const char c2) { return GetLineDelByKey(-1,-1,c1,c2); }
const char* MyStr::GetLineDelByKey(const char c1,const char *k2) { return GetLineDelByKey(-1,-1,c1,k2); }
const char* MyStr::GetLineDelByKey(const char *k1,const char c2) { return GetLineDelByKey(-1,-1,k1,c2); }
const char* MyStr::GetLineDelByKey(const char *k1,const char *k2){ return GetLineDelByKey(-1,-1,k1,k2); }

const char* MyStr::GetLineDelByKey(const int si,const char c1,const char c2) { return GetLineDelByKey(si,-1,c1,c2); }
const char* MyStr::GetLineDelByKey(const int si,const char c1,const char *k2) { return GetLineDelByKey(si,-1,c1,k2); }
const char* MyStr::GetLineDelByKey(const int si,const char *k1,const char c2) { return GetLineDelByKey(si,-1,k1,c2); }
const char* MyStr::GetLineDelByKey(const int si,const char *k1,const char *k2){ return GetLineDelByKey(si,-1,k1,k2); }

const char* MyStr::GetLineDelByKey(const int si,const int ei,const char c1,const char c2) { 
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetLineDelByKey(si,ei,k1,k2); 
}
const char* MyStr::GetLineDelByKey(const int si,const int ei,const char c1,const char *k2) { 
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetLineDelByKey(si,ei,k1,k2); 
}
const char* MyStr::GetLineDelByKey(const int si,const int ei,const char *k1,const char c2) { 
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetLineDelByKey(si,ei,k1,k2); 
}
const char* MyStr::GetLineDelByKey(const int si,const int ei,const char *k1,const char *k2){
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return releasetmp();
	
	MyStr S(k2);
	if(S=="\n") return GetLineDelByKey(si,ei,k1,"");
	S=k1;
	if(S=="\n") return GetLineDelByKey(si,ei,"",k2);
		
	MyStr T;
	int p=InStr(sp,ep,'\n');
	while(p>-1) {
		if(p>sp) {
			S=GetRangeByIdx(sp,p-1);
			T+=S.GetRangeWithDelByKey(k1,k2);
		}
		T+='\n';
		sp=p+1;
		p=InStr(sp,ep,'\n');
	}
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		T+=S.GetRangeWithDelByKey(k1,k2);
	}
	return resizetmp(T.str);
}
//#######################################################################################################################
const char* MyStr::GetLineDelBtwKey(const char c1,const char c2) { return GetLineDelBtwKey(-1,-1,c1,c2); }
const char* MyStr::GetLineDelBtwKey(const char c1,const char *k2) { return GetLineDelBtwKey(-1,-1,c1,k2); }
const char* MyStr::GetLineDelBtwKey(const char *k1,const char c2) { return GetLineDelBtwKey(-1,-1,k1,c2); }
const char* MyStr::GetLineDelBtwKey(const char *k1,const char *k2){ return GetLineDelBtwKey(-1,-1,k1,k2); }

const char* MyStr::GetLineDelBtwKey(const int si,const char c1,const char c2) { return GetLineDelBtwKey(si,-1,c1,c2); }
const char* MyStr::GetLineDelBtwKey(const int si,const char c1,const char *k2) { return GetLineDelBtwKey(si,-1,c1,k2); }
const char* MyStr::GetLineDelBtwKey(const int si,const char *k1,const char c2) { return GetLineDelBtwKey(si,-1,k1,c2); }
const char* MyStr::GetLineDelBtwKey(const int si,const char *k1,const char *k2){ return GetLineDelBtwKey(si,-1,k1,k2); }

const char* MyStr::GetLineDelBtwKey(const int si,const int ei,const char c1,const char c2) { 
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetLineDelBtwKey(si,ei,k1,k2); 
}
const char* MyStr::GetLineDelBtwKey(const int si,const int ei,const char c1,const char *k2) { 
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetLineDelBtwKey(si,ei,k1,k2); 
}
const char* MyStr::GetLineDelBtwKey(const int si,const int ei,const char *k1,const char c2) { 
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetLineDelBtwKey(si,ei,k1,k2); 
}
const char* MyStr::GetLineDelBtwKey(const int si,const int ei,const char *k1,const char *k2){
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return releasetmp();

	MyStr S(k2);
	if(S=="\n") return GetLineDelBtwKey(si,ei,k1,"");
	S=k1;
	if(S=="\n") return GetLineDelBtwKey(si,ei,"",k2);

//printf("\nGetLineDelBtwKey k1=[%s] k2=[%s] str=[%s]",k1,k2,str);
	
	MyStr T;
	int p=InStr(sp,ep,'\n');
	while(p>-1) {
		if(p>sp) {
			S=GetRangeByIdx(sp,p-1);
//printf("\nGetLineDelBtwKey 0 S=[%s]",S.str);
			T+=S.GetRangeWithDelBtwKey(k1,k2);
		}
		T+='\n';
		sp=p+1;
		p=InStr(sp,ep,'\n');
	}
//printf("\nGetLineDelBtwKey 1 T=[%s]",(char*)T);
	if(sp<=ep) {
		S=GetRangeByIdx(sp,ep);
		T+=S.GetRangeWithDelBtwKey(k1,k2);
	}
//printf("\nGetLineDelBtwKey 2 T=[%s]",(char*)T);
	return resizetmp(T.str);
}
//#######################################################################################################################
const char* MyStr::GetLineDelByKeyExSymBlk(const char c1,const char c2,const char *SymChrLst){return GetLineDelByKeyExSymBlk(-1,-1,c1,c2,SymChrLst);}
const char* MyStr::GetLineDelByKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst){return GetLineDelByKeyExSymBlk(-1,-1,c1,k2,SymChrLst);}
const char* MyStr::GetLineDelByKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst){return GetLineDelByKeyExSymBlk(-1,-1,k1,c2,SymChrLst);}
const char* MyStr::GetLineDelByKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst){return GetLineDelByKeyExSymBlk(-1,-1,k1,k2,SymChrLst);}

const char* MyStr::GetLineDelByKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst){return GetLineDelByKeyExSymBlk(si,-1,c1,c2,SymChrLst);}
const char* MyStr::GetLineDelByKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst){return GetLineDelByKeyExSymBlk(si,-1,c1,k2,SymChrLst);}
const char* MyStr::GetLineDelByKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst){return GetLineDelByKeyExSymBlk(si,-1,k1,c2,SymChrLst);}
const char* MyStr::GetLineDelByKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst){return GetLineDelByKeyExSymBlk(si,-1,k1,k2,SymChrLst);}

const char* MyStr::GetLineDelByKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst){
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetLineDelByKeyExSymBlk(si,ei,k1,k2,SymChrLst); 
}
const char* MyStr::GetLineDelByKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst){
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetLineDelByKeyExSymBlk(si,ei,k1,k2,SymChrLst); 
}
const char* MyStr::GetLineDelByKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst){
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetLineDelByKeyExSymBlk(si,ei,k1,k2,SymChrLst); 
}
const char* MyStr::GetLineDelByKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst){
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return releasetmp();

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetLineDelByKey(si,ei,k1,k2);

	MyStr T,S;
	int k=sp;
	PO2 pp=SymBlkIdxInStr(k,ep,SymChrLst);
	
	while(pp.p1>-1) {
		if(pp.p1>k) { S=GetRangeByIdx(k,pp.p1-1); T+=S.GetLineDelByKey(k1,k2); }
		T+=GetRangeByIdx(pp.p1,pp.p2);
		k=pp.p2+1;
		pp=SymBlkIdxInStr(k,ep,SymChrLst);
	}
	if(k<=ep) {
		S=GetRangeByIdx(k,ep);
		T+=S.GetLineDelByKey(k1,k2);
	}
	return resizetmp(T.str);
}

//#######################################################################################################################
const char* MyStr::GetLineDelBtwKeyExSymBlk(const char c1,const char c2,const char *SymChrLst){return GetLineDelBtwKeyExSymBlk(-1,-1,c1,c2,SymChrLst);}
const char* MyStr::GetLineDelBtwKeyExSymBlk(const char c1,const char *k2,const char *SymChrLst){return GetLineDelBtwKeyExSymBlk(-1,-1,c1,k2,SymChrLst);}
const char* MyStr::GetLineDelBtwKeyExSymBlk(const char *k1,const char c2,const char *SymChrLst){return GetLineDelBtwKeyExSymBlk(-1,-1,k1,c2,SymChrLst);}
const char* MyStr::GetLineDelBtwKeyExSymBlk(const char *k1,const char *k2,const char *SymChrLst){return GetLineDelBtwKeyExSymBlk(-1,-1,k1,k2,SymChrLst);}

const char* MyStr::GetLineDelBtwKeyExSymBlk(const int si,const char c1,const char c2,const char *SymChrLst){return GetLineDelBtwKeyExSymBlk(si,-1,c1,c2,SymChrLst);}
const char* MyStr::GetLineDelBtwKeyExSymBlk(const int si,const char c1,const char *k2,const char *SymChrLst){return GetLineDelBtwKeyExSymBlk(si,-1,c1,k2,SymChrLst);}
const char* MyStr::GetLineDelBtwKeyExSymBlk(const int si,const char *k1,const char c2,const char *SymChrLst){return GetLineDelBtwKeyExSymBlk(si,-1,k1,c2,SymChrLst);}
const char* MyStr::GetLineDelBtwKeyExSymBlk(const int si,const char *k1,const char *k2,const char *SymChrLst){return GetLineDelBtwKeyExSymBlk(si,-1,k1,k2,SymChrLst);}

const char* MyStr::GetLineDelBtwKeyExSymBlk(const int si,const int ei,const char c1,const char c2,const char *SymChrLst){
	char k1[2]; k1[0]=c1; k1[1]='\0';
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetLineDelBtwKeyExSymBlk(si,ei,k1,k2,SymChrLst); 
}
const char* MyStr::GetLineDelBtwKeyExSymBlk(const int si,const int ei,const char c1,const char *k2,const char *SymChrLst){
	char k1[2]; k1[0]=c1; k1[1]='\0';
	return GetLineDelBtwKeyExSymBlk(si,ei,k1,k2,SymChrLst); 
}
const char* MyStr::GetLineDelBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char c2,const char *SymChrLst){
	char k2[2]; k2[0]=c2; k2[1]='\0';
	return GetLineDelBtwKeyExSymBlk(si,ei,k1,k2,SymChrLst); 
}
const char* MyStr::GetLineDelBtwKeyExSymBlk(const int si,const int ei,const char *k1,const char *k2,const char *SymChrLst){
//printf("\nGetLineDelBtwKeyExSymBlk ...");
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;

	if(len<1 || sp>ep || ep>=len) return releasetmp();

	int lsym=0;
	if(SymChrLst!=NULL) lsym=strlen(SymChrLst);
	if(lsym<1) return GetLineDelBtwKey(si,ei,k1,k2);

	MyStr T,S;
	int k=sp;
	PO2 pp=SymBlkIdxInStr(k,ep,SymChrLst);
	
	while(pp.p1>-1) {
//printf("\nGetLineDelBtwKeyExSymBlk 1 k=%d pp.p1=%d ep=%d T=[%s]",k,pp.p1,ep,(char*)T);
		if(pp.p1>k) { 
			int m=pp.p1-1;
			S=GetRangeByIdx(k,pp.p1-1); 
			T+=S.GetLineDelBtwKey(k1,k2); 
		}
		T+=GetRangeByIdx(pp.p1,pp.p2);
//printf("\nGetLineDelBtwKeyExSymBlk 2 k=%d pp.p2=%d T=[%s]",k,pp.p2,(char*)T);
		k=pp.p2+1;
		pp=SymBlkIdxInStr(k,ep,SymChrLst);
	}
//printf("\nGetLineDelBtwKeyExSymBlk 3 k=%d T=[%s]",k,(char*)T);
	if(k<=ep) {
		S=GetRangeByIdx(k,ep);
		T+=S.GetLineDelBtwKey(k1,k2);
	}
//printf("\nGetLineDelBtwKeyExSymBlk end T=[%s]",(char*)T);
	return resizetmp(T.str);
}

//#######################################################################################################################
const char* MyStr::GetLowerCase(void) {
	resizetmp(str);
	for(int n=0;n<len;n++) {
		if(tmp[n]>='A' && tmp[n]<='Z') tmp[n]=tmp[n]+('a'-'A');
	}
	return tmp;
}
//#######################################################################################################################
const char* MyStr::GetUpperCase(void) {
	resizetmp(str);
	for(int n=0;n<len;n++) {
		if(tmp[n]>='a' && tmp[n]<='z') tmp[n]=tmp[n]-('a'-'A');
	}
	return tmp;
}
//#######################################################################################################################
int MyStr::LowerCaseInside(void) { return LowerCaseInside(-1,-1); }
int MyStr::LowerCaseInside(const int si) { return LowerCaseInside(si,-1); }
int MyStr::LowerCaseInside(const int si,const int ei) {
//printf("\nstr=[%s]",str);
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	if(sp>ep || ep>=len) return -1;
	int n=0;
	if(len>0) {
		for(int p=sp;p<=ep;p++) if(str[p]>='a' && str[p]<='z') n++;
	}
//printf(" n=%d",n);
	return n;
}
//#######################################################################################################################
int MyStr::UpperCaseInside(void) { return UpperCaseInside(-1,-1); }
int MyStr::UpperCaseInside(const int si) { return UpperCaseInside(si,-1); }
int MyStr::UpperCaseInside(const int si,const int ei) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	if(sp>ep || ep>=len) return -1;
	int n=0;
	if(len>0) {
		for(int p=sp;p<=ep;p++) if(str[p]>='A' && str[p]<='Z') n++;
	}
	return n;
}
//#######################################################################################################################
const char* MyStr::GetRangeWithDelBlkSymChr(const char *SymChrLst) { return GetRangeWithDelBlkSymChr(-1,-1,SymChrLst); }
const char* MyStr::GetRangeWithDelBlkSymChr(const int si,const char *SymChrLst) { return GetRangeWithDelBlkSymChr(si,-1,SymChrLst); }
const char* MyStr::GetRangeWithDelBlkSymChr(const int si,const int ei,const char *SymChrLst) {
//printf("\n#>GetRangeWithDelBlkSymChr: si=%d ei=%d SymChrLst(%s)",si,ei,SymChrLst);
//printf("\n#>len=%d str=[%s]",len,str);
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
//printf("\n#>sp=%d ep=%d",sp,ep);
	if(sp>ep || ep>=len) return releasetmp();
	
	MyStr SYM(SymChrLst);
//printf("\n#>SYM(%s)",(char*)SYM);
	if((int)len<2 || (int)SYM<1) return resizetmp(str);

	MyStr T;
	int k=sp;
	PO2 PP=SymBlkIdxInStr(k,ep,SYM.str);
//printf("\n#>sp=%d ep=%d k=%d PP.p1=%d PP.p2=%d",sp,ep,k,PP.p1,PP.p2);
	while(PP.p1>-1) {
//printf("\n#>k=%d PP.p1=%d PP.p2=%d",k,PP.p1,PP.p2);
		if(PP.p1>k) T+=GetRangeByIdx(k,PP.p1-1);
		T+=GetRangeByIdx(PP.p1+1,PP.p2-1);
//printf(" T=[%s]",(char*)T);
		k=PP.p2+1;
		PP=SymBlkIdxInStr(k,ep,SYM.str);
	}
//printf("\n##>k=%d PP.p1=%d PP.p2=%d ==> T=[%s]",k,PP.p1,PP.p2,(char*)T);
	if(k<len) T+=GetRangeByIdx(k,ep);
//printf("\n###>T[%s]",(char*)T);
	return resizetmp(T.str);
}
//#######################################################################################################################
const char* MyStr::GetRangeWithDelLineBlkSymChr(const char *SymChrLst) { return GetRangeWithDelLineBlkSymChr(-1,-1,SymChrLst); }
const char* MyStr::GetRangeWithDelLineBlkSymChr(const int si,const char *SymChrLst) { return GetRangeWithDelLineBlkSymChr(si,-1,SymChrLst); }
const char* MyStr::GetRangeWithDelLineBlkSymChr(const int si,const int ei,const char *SymChrLst) {
//printf("\n#>GetRangeWithDelLineBlkSymChr: si=%d ei=%d SymChrLst(%s)",si,ei,SymChrLst);
//printf("\n#>len=%d str=[%s]",len,str);
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
//printf("\n#>sp=%d ep=%d",sp,ep);
	if(sp>ep || ep>=len) return releasetmp();
	
	MyStr SYM(SymChrLst);
//printf("\n#>SYM(%s)",(char*)SYM);
	if((int)len<2 || (int)SYM<1) return resizetmp(str);

	MyStr T;
	int k=sp;
	PO2 PP=LineSymBlkIdxInStr(k,ep,SYM.str);
//printf("\n#>sp=%d ep=%d k=%d PP.p1=%d PP.p2=%d",sp,ep,k,PP.p1,PP.p2);
	while(PP.p1>-1) {
//printf("\n#>k=%d PP.p1=%d PP.p2=%d",k,PP.p1,PP.p2);
		if(PP.p1>k) T+=GetRangeByIdx(k,PP.p1-1);
		T+=GetRangeByIdx(PP.p1+1,PP.p2-1);
//printf(" T=[%s]",(char*)T);
		k=PP.p2+1;
		PP=LineSymBlkIdxInStr(k,ep,SYM.str);
	}
//printf("\n##>k=%d PP.p1=%d PP.p2=%d ==> T=[%s]",k,PP.p1,PP.p2,(char*)T);
	if(k<len) T+=GetRangeByIdx(k,ep);
//printf("\n###>T[%s]",(char*)T);
	return resizetmp(T.str);
}

//#######################################################################################################################
const char* MyStr::GetRangeWithDelSpLine(void) { return GetRangeWithDelSpLine(-1,-1); }
const char* MyStr::GetRangeWithDelSpLine(const int si) { return GetRangeWithDelSpLine(si,-1); }
const char* MyStr::GetRangeWithDelSpLine(const int si,const int ei) {
	int sp=si;
	if(si<0) sp=0;
	int ep=ei;
	if(ei<0) ep=len-1;
	if(len<1 || sp>ep || ep>=len) return releasetmp();

	MyStr T;
	int k=sp;
	int p=InStr(k,ep,"\n");
	while(p>-1) {
		MyStr LL(GetRangeByIdx(k,p));
		MyStr S(LL.GetTrim());
		if(S!="") T+=LL;
		k=p+1;
		p=InStr(k,ep,"\n");
	}
	if(k<=ep) T+=GetRangeByIdx(k,-1);
	return resizetmp(T.str);
}
//#######################################################################################################################
bool MyStr::IsEmpty(void){ if(len<1) return true; else return false; }
bool MyStr::IsNotEmpty(void){ if(len<1) return false; else return true; }
//#######################################################################################################################
int MyStr::ChrOfLstInStr(const char *lst) { return CharOfListInStrIdx(-1,-1,str,lst); }
int MyStr::ChrOfLstInStr(const int si,const char *lst) { return CharOfListInStrIdx(si,-1,str,lst); }
int MyStr::ChrOfLstInStr(const int si,const int ei,const char *lst) { return CharOfListInStrIdx(si,ei,str,lst); }
//#######################################################################################################################
int MyStr::WdCntInStr(const char c) { return GetWdCntInStr(-1,-1,str,c); }
int MyStr::WdCntInStr(const int si,const char c) { return GetWdCntInStr(si,-1,str,c); }
int MyStr::WdCntInStr(const int si,const int ei,const char c) { return GetWdCntInStr(si,ei,str,c); }
int MyStr::WdCntInStr(const char *wd) { return GetWdCntInStr(-1,-1,str,wd); }
int MyStr::WdCntInStr(const int si,const char *wd) { return GetWdCntInStr(si,-1,str,wd); }
int MyStr::WdCntInStr(const int si,const int ei,const char *wd) { return GetWdCntInStr(si,ei,str,wd); }
//#######################################################################################################################
