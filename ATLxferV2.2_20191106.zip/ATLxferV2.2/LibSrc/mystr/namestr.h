/*##############################################################################################
	v1.0@20191019	initial ver.
	v1.1@20191025	+ Reset();
					+ enum NameStr_enum {NS_name=0,NS_str};
					+ const char* operator[](NameStr_enum);
	v1.2@20191026	private *myname -> protected
					void releasename(void)->const char*releasename(void)
################################################################################################*/

#ifndef __NameStr_h__
    #define __NameStr_h__
    #define __NameStrVer__	"NameStr-v1.2@20191026"

#include "mystr.h"

enum NameStr_enum {NS_name=0,NS_str};

class NameStr : public MyStr {
protected:
		 	 char *myname;
		 	 
virtual 	 const char *resizename(const char c);
virtual 	 const char *resizename(const char *s);
virtual 	 const char *resizename(const MyStr &S);

virtual 	 const char *releasename(void);

public:
			NameStr(const char *name=NULL,const char *s=NULL);
			NameStr(const char *name,const char sc);
			NameStr(const char *name,const MyStr &S);
			NameStr(const char *name,const int v);
			NameStr(const char *name,const long lv);
			
			NameStr(const char nc,const char *s=NULL);
			NameStr(const char nc,const char sc);
			NameStr(const char nc,const MyStr &S);
			NameStr(const char nc,const int v);
			NameStr(const char nc,const long lv);
			
			NameStr(const MyStr &NAME,const char *s=NULL);
			NameStr(const MyStr &NAME,const char sc);
			NameStr(const MyStr &NAME,const MyStr &S);
			NameStr(const MyStr &NAME,const int v);
			NameStr(const MyStr &NAME,const long lv);

			NameStr(const int nv,const char *s=NULL);
			NameStr(const int nv,const char sc);
			NameStr(const int nv,const MyStr &S);
			NameStr(const int nv,const int v);
			NameStr(const int nv,const long lv);

			NameStr(const long nlv,const char *s=NULL);
			NameStr(const long nlv,const char sc);
			NameStr(const long nlv,const MyStr &S);
			NameStr(const long nlv,const int v);
			NameStr(const long nlv,const long lv);

			NameStr(NameStr &NS);

			~NameStr();

		     void 	   Reset(void);
	
			const char *SetName(const char c);
			const char *SetName(const char *name);
			const char *SetName(const MyStr &NAME);
			const char *SetName(const int nv);
			const char *SetName(const long nlv);

			const char *GetName();
		     bool	   IsNameEmpty();
		     bool	   IsNotNameEmpty();

virtual 	NameStr& operator=(const NameStr &NS);
virtual 	NameStr& operator=(const char sc);
virtual 	NameStr& operator=(const char *s);
virtual 	NameStr& operator=(const MyStr &S);
virtual 	NameStr& operator=(const int v);
virtual 	NameStr& operator=(const long lv);

virtual 	NameStr& operator+=(const NameStr &NS);
virtual 	NameStr& operator+=(const char sc);
virtual 	NameStr& operator+=(const char *s);
virtual 	NameStr& operator+=(const MyStr &S);
virtual 	NameStr& operator+=(const int v);
virtual 	NameStr& operator+=(const long lv);

virtual 	const char* operator+(const NameStr &NS);
virtual 	 bool 	 operator==(const NameStr &NS);
virtual 	 bool 	 operator!=(const NameStr &NS);

virtual     const char* operator[](NameStr_enum);

};

#endif
