
#include "mystr.h"
#include "namestr.h"
#include "mystd.h"

int main(int ac,char **av) {
	tout out;
	
	out.prt("\nMyStr S(\"I'm MyStr S\");");
	MyStr S("I'm MyStr S");
	out.prt("\n(char*)S=\"%\"",(char*)S);
	out.prt("\nS=S;");
	S=S;
	out.prt("\n(char*)S=\"%\"",(char*)S);
	out.prt("\nS+=S;");
	S+=S;
	out.prt("\n(char*)S=\"%\"",(char*)S);
	out.prt("\nS=\"MyStr-S\"");
	S="MyStr-S";
	out.prt("\n(char*)S=\"%\"",(char*)S);

	out.prt("\n\nNameStr NS(\"NamStr-NS\",S););");
	NameStr NS("NamStr-NS",S);
	out.prt("\n(int)NS=%,NS.GetName()=\"%\",(char*)NS=\"%\"\n",(int)NS,NS.GetName(),(char*)NS);
	out.prt("\nNS=NS;");
	NS=NS;
	out.prt("\n(int)NS=%,NS.GetName()=\"%\",(char*)NS=\"%\"\n",(int)NS,NS.GetName(),(char*)NS);
	out.prt("\nNS+=NS;");
	NS+=NS;
	out.prt("\n(int)NS=%,NS.GetName()=\"%\",(char*)NS=\"%\"\n",(int)NS,NS.GetName(),(char*)NS);
	out.prt("\nNS=S;");
	NS=S;
	out.prt("\n(int)NS=%,NS.GetName()=\"%\",(char*)NS=\"%\"\n",(int)NS,NS.GetName(),(char*)NS);

	
	out.prt("\nNS=\"NS data\"");
	NS="NS data";
	out.prt("\n(int)NS=%,NS.GetName()=\"%\",(char*)NS=\"%\"\n",(int)NS,NS.GetName(),(char*)NS);

	out.prt("\nNameStr NS1(\"NamStr-NS1\",\"NS1 data\");");
	NameStr NS1("NamStr-NS1","NS1 data");
	out.prt("\n(int)NS1=%,NS1.GetName()=\"%\",(char*)NS1=\"%\"\n",(int)NS1,NS1.GetName(),(char*)NS1);

	out.prt("\nNameStr NS2(NS);");
	NameStr NS2(NS);
	out.prt("\n(int)NS2=%,NS2.GetName()=\"%\",(char*)NS2=\"%\"\n",(int)NS2,NS2.GetName(),(char*)NS2);
	
	out.prt("\nNS2.SetName(\"NameStr-NS2\");");
	NS2.SetName("NameStr-NS2");
	out.prt("\n(int)NS2=%,NS2.GetName()=\"%\",(char*)NS2=\"%\"\n",(int)NS2,NS2.GetName(),(char*)NS2);

	out.prt("\nNS2=NS1;");
	NS2=NS1;
	out.prt("\n(int)NS2=%,NS2.GetName()=\"%\",(char*)NS2=\"%\"\n",(int)NS2,NS2.GetName(),(char*)NS2);

	out.prt("\nNS2=S;");
	NS2=S;
	out.prt("\n(int)NS2=%,NS2.GetName()=\"%\",(char*)NS2=\"%\"\n",(int)NS2,NS2.GetName(),(char*)NS2);

	out.prt("\nNS2+=NS;");
	NS2+=NS;
	out.prt("\n(int)NS2=%,NS2.GetName()=\"%\",(char*)NS2=\"%\"\n",(int)NS2,NS2.GetName(),(char*)NS2);

	out.prt("\nNS2+=S;");
	NS2+=S;
	out.prt("\n(int)NS2=%,NS2.GetName()=\"%\",(char*)NS2=\"%\"\n",(int)NS2,NS2.GetName(),(char*)NS2);

	return 0;
}
