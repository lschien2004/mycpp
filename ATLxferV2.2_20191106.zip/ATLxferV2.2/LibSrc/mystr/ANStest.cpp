#include "mystd.h"
#include "namestr.h"
#include "mystr.h"
//#include "arraystr.h"
#include "arraynamestr.h"
//#include "namearraystr.h"

int main(int ac,char **av) {
	int n;
	tout out;
	
	MyStr S,T;
	
	out.prt("\nS=\"Para0\";");
	S="Para0";
	out.prt("->S=\"%\"",(char*)S);
	
	out.prt("\nNameStr NS(S,\"data0\");");	
	NameStr NS(S,"data0");
	out.prt("->NS[%]=\"%\"",NS.GetName(),(char*)NS);
	
	out.prt("\nArrayNameStr ANS;");	
	ArrayNameStr ANS;
	out.prt("->ANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);
	
	out.prt("\n\nANS=NS;");	
	ANS=NS;
	out.prt("->ANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	out.prt("\n\nANS.Add(\"Para1\",\"data1\");");	
	ANS.Add("Para1","data1");
	out.prt("->ANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	out.prt("\n\nT=\"DATA2\";");
	T="DATA2";
	out.prt("->T=\"%\"",(char*)T);

	out.prt("\n\nANS.Add(\"Para2\",T=\"%\");",(char*)T);	
	ANS.Add("Para2",T);
	out.prt("->ANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	out.prt("\n\nS=\"PARA3\"; T=\"DATA3\";");
	S="PARA3"; T="DATA3";
	out.prt("->S=\"%\",T=\"%\"",(char*)S,(char*)T);

	out.prt("\n\nANS.Add(S=\"%\",T=\"%\");",(char*)S,(char*)T);	
	ANS.Add(S,T);
	out.prt("->ANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);
	out.prt("\nANS.NameList=%",ANS.NameList());
	out.prt("\nANS.NameListRev=%",ANS.NameListRev());
	out.prt("\nANS.StrList=%",ANS.StrList());
	out.prt("\nANS.StrListRev=%",ANS.StrListRev());

	out.prt("\n\nANS=ANS");	
	ANS=ANS;
	out.prt("->ANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	out.prt("\n\nANS+=ANS");	
	ANS+=ANS;
	out.prt("->ANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	out.prt("\n\nArrayNameStr ANS1(NS);");
	ArrayNameStr ANS1(NS);
	n=0; out.prt("\nANS1.Cnt=% ANS1[%]=[%]\"%\"",ANS1.GetArrayCnt(),n,ANS1[n].GetName(),(char*)ANS1[n]);

	out.prt("\n\nArrayNameStr ANS2(ANS);");
	ArrayNameStr ANS2(ANS);
	n=0; out.prt("\nANS2.Cnt=% ANS2[%]=[%]\"%\"",ANS2.GetArrayCnt(),n,ANS2[n].GetName(),(char*)ANS2[n]);
	n=1; out.prt("\nANS2.Cnt=% ANS2[%]=[%]\"%\"",ANS2.GetArrayCnt(),n,ANS2[n].GetName(),(char*)ANS2[n]);

	out.prt("\n\nArrayNameStr ANS3(\"Nchar*1\",'C');");
	ArrayNameStr ANS3("Nchar*1",'C');
	n=0; out.prt("\nANS3.Cnt=% ANS3[%]=[%]\"%\"",ANS3.GetArrayCnt(),n,ANS3[n].GetName(),(char*)ANS3[n]);

	out.prt("\n\nArrayNameStr ANS4(\"Nchar*2\",4);");
	ArrayNameStr ANS4("Nchar*2",4);
	n=0; out.prt("\nANS4.Cnt=% ANS4[%]=[%]\"%\"",ANS4.GetArrayCnt(),n,ANS4[n].GetName(),(char*)ANS4[n]);

	out.prt("\n\nANS+=ANS3;");
	ANS+=ANS3;
	out.prt("\nANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	out.prt("\n\nNS[%]=\"%\"",NS.GetName(),(char*)NS);
	out.prt("\nANS.GetIdxByNameStr(NS)=%",ANS.GetIdxByNameStr(NS));
	out.prt("\nANS.GetIdxRevByNameStr(NS)=%",ANS.GetIdxRevByNameStr(NS));

	out.prt("\n\nS=ANS[2].GetName();");
	S=ANS[2].GetName();
	out.prt("->S=\"%\"",(char*)S);
	
	out.prt("\n\nNS=ANS[3];");
	NS=ANS[3];
	out.prt("->NS[%]=\"%\"",NS.GetName(),(char*)NS);

	out.prt("\n\nANS.GetIdxByName(S=\"%\")=%",(char*)S,ANS.GetIdxByName(S));
	out.prt("\nANS.GetIdxByName(%)=%",(char*)NS,ANS.GetIdxByName((char*)NS));
	out.prt("\nANS.GetIdxByName(%)=%",NS.GetName(),ANS.GetIdxByName(NS.GetName()));
	out.prt("\nANS.GetIdxByNameStr(NS)=%",ANS.GetIdxByNameStr(NS));
	out.prt("\nANS.GetIdxRevByNameStr(NS)=%",ANS.GetIdxRevByNameStr(NS));

	out.prt("\n\nS=ANS.GetNameByIdx(1);");
	S=ANS.GetNameByIdx(1);
	out.prt("->S=\"%\"",(char*)S);
	out.prt("\nANS.GetIdxByName(S=\"%\")=%",(char*)S,ANS.GetIdxByName(S));

	out.prt("\n\nNS=ANS[2];");
	NS=ANS[2];
	out.prt("\n->NS[%]=\"%\"",NS.GetName(),(char*)NS);
	
	out.prt("\n\nANS2=ANS;");
	ANS2=ANS;
	out.prt("\nANS2.Cnt=%",ANS2.GetArrayCnt());
	for(n=0;n<ANS2.GetArrayCnt();n++) out.prt("\nANS2[%]=[%]\"%\"",n,ANS2[n].GetName(),(char*)ANS2[n]);
	
	out.prt("\n\nANS.DelByIdx(1) ...");
	ANS.DelByIdx(1);
	out.prt("\nANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	int k=ANS.GetArrayCnt()-1;
	out.prt("\nANS.DelByIdx(%) ...",k);
	ANS.DelByIdx(k);
	out.prt("\nANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);
	
	out.prt("\n");
	k=ANS.GetArrayCnt();
	for (int i=0;i<k;i++) {
		out.prt("\nANS.DelByIdx(0) ...");
		ANS.DelByIdx(0);
		out.prt("\nANS.Cnt=%",ANS.GetArrayCnt());
		for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);
	}
	
	out.prt("\n\nANS+=NS");
	ANS+=NS;
	out.prt("\nANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);
	
	out.prt("\n\nANS.Add(S=\"%\",\"dataS\");",(char*)S);
	ANS.Add(S,"dataS");
	out.prt("\nANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	out.prt("\n\nNS=ANS[0]");
	NS=ANS[0]; 
	out.prt("\nNS[%]=\"%\"",NS.GetName(),(char*)NS);
	T=(char*)NS;
	out.prt("\nNS=\"datax\";");
	NS="datax";
	out.prt("\nNS[%]=\"%\"",NS.GetName(),(char*)NS);
	
	out.prt("\n\nANS.DelByName(S) ...");
	ANS.DelByName(S);
	out.prt("\nANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	out.prt("\n\nANS.DelByNameStr(NS) ...");
	ANS.DelByNameStr(NS);
	out.prt("\nANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	out.prt("\n\nNS=\"%\";",(char*)T);
	NS=T;
	out.prt("\nNS[%]=\"%\"",NS.GetName(),(char*)NS);

	out.prt("\n\nANS.DelByNameStr(NS) ...");
	ANS.DelByNameStr(NS);
	out.prt("\nANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	out.prt("\n\nANS2.Cnt=%",ANS2.GetArrayCnt());
	for(n=0;n<ANS2.GetArrayCnt();n++) out.prt("\nANS2[%]=[%]\"%\"",n,ANS2[n].GetName(),(char*)ANS2[n]);

	out.prt("\n\nS=ANS2[0].GetName();");
	S=ANS2[0].GetName();
	out.prt("\nS=\"%\"",(char*)S);
	out.prt("\nS=ANS2.DelRevByName(S);");
	ANS2.DelRevByName(S);
	out.prt("\nANS2.Cnt=%",ANS2.GetArrayCnt());
	for(n=0;n<ANS2.GetArrayCnt();n++) out.prt("\nANS2[%]=[%]\"%\"",n,ANS2[n].GetName(),(char*)ANS2[n]);

	out.prt("\n\nS=ANS2.DelAllByName(S);");
	ANS2.DelAllByName(S);
	out.prt("\nANS2.Cnt=%",ANS2.GetArrayCnt());
	for(n=0;n<ANS2.GetArrayCnt();n++) out.prt("\nANS2[%]=[%]\"%\"",n,ANS2[n].GetName(),(char*)ANS2[n]);

	out.prt("\n\nS=ANS2[0].GetName();");
	S=ANS2[0].GetName();
	out.prt("\nS=\"%\"",(char*)S);
	out.prt("\nS=ANS2.DelAllByName(S);");
	ANS2.DelAllByName(S);
	out.prt("\nANS2.Cnt=%",ANS2.GetArrayCnt());
	for(n=0;n<ANS2.GetArrayCnt();n++) out.prt("\nANS2[%]=[%]\"%\"",n,ANS2[n].GetName(),(char*)ANS2[n]);

	out.prt("\n\nS=(char*)ANS2[0];");
	S=(char*)ANS2[0];
	out.prt("\nS=\"%\"",(char*)S);
	out.prt("\nANS2.GetIdxByStr(S)=%",ANS2.GetIdxByStr(S));
	out.prt("\nANS2.GetIdxByStr(S,0)=%",ANS2.GetIdxByStr(S,0));
	out.prt("\nANS2.GetIdxByStr(S,1,-1)=%",ANS2.GetIdxByStr(S,1,-1));
	out.prt("\nANS2.GetIdxByStr(S,2,-1)=%",ANS2.GetIdxByStr(S,2,-1));
	out.prt("\nANS2.GetIdxByStr(S,3,-1)=%",ANS2.GetIdxByStr(S,3,-1));
	out.prt("\nANS2.GetIdxByStr(S,4,-1)=%",ANS2.GetIdxByStr(S,4,-1));
	out.prt("\nANS2.GetIdxRevByStr(S)=%",ANS2.GetIdxRevByStr(S));
	out.prt("\nANS2.GetIdxRevByStr(S,-1)=%",ANS2.GetIdxRevByStr(S,-1));
	out.prt("\nANS2.GetIdxRevByStr(S,-1,-1)=%",ANS2.GetIdxRevByStr(S,-1,-1));
	out.prt("\nANS2.GetIdxRevByStr(S,2,-1)=%",ANS2.GetIdxRevByStr(S,2,-1));
	out.prt("\nANS2.GetIdxRevByStr(S,3,-1)=%",ANS2.GetIdxRevByStr(S,3,-1));
	out.prt("\nANS2.GetIdxRevByStr(S,4,-1)=%",ANS2.GetIdxRevByStr(S,3,-1));

	exit(0);
}
