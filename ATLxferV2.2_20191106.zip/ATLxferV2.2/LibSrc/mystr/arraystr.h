/*########################################################################################
	v1.1@20191018 	initial ver.
	v1.2@20191019 	rename GetCNT -> GetArrayCnt
					rename GetSNO -> GetIdx
					+ ArrayStr&  operator+=(ArrayStr &IA);
					+ ArrayStr(ArrayStr &A);
					+ ArrayStr(const int v);
					+ ArrayStr(const long lv);
					+ Add(ArrayStr &A);
					+ Add(const int v);
					+ Add(const long lv);
	v1.3@20191021	+ ArrayStr& operator=(ArrayStr &)
					+ ListRev(const char)		
					+ ListRev(const char*)	
					+ ListRev(MyStr&)	
	v1.4@20191026	private MyStr &pstr,ArrayStr *nxt -> protested
					+ Reset(void)
					Del(int)->DelByIdx(int)
					Del(MyStr&)->DelByStr(MyStr&)
					Del(const char*)->DelByStr(const char*)
					+ DelByStr(const char)
					+ DelByStr(const int)
					+ DelByStr(const long)
					+ GetIdxRev(MyStr&)
					+ GetIdxRev(const char*)
					+ DelRevByStr(...)
					+ DelAllByStr(...)
##########################################################################################*/

#include "mystr.h"

#ifndef __ArrayStr_h__
    #define __ArrayStr_h__
	#define __ArrayStrVer__	"ArrayStr-v1.4@20191026"

class ArrayStr {
protected:
 			MyStr 		*pstr;
 			ArrayStr	*nxt;

	 void 	Release(ArrayStr *nd);
  ArrayStr *GetNode(MyStr &S);
  ArrayStr *GetNode(int idx);
public:
			ArrayStr();
			ArrayStr(const char *s);
			ArrayStr(MyStr &S);
			ArrayStr(ArrayStr &A);
			ArrayStr(const int v);
			ArrayStr(const long lv);
			
			~ArrayStr();
	 
	 void 	Reset(void);
	 		
	 int 	GetIdx(const char *s);
	 int 	GetIdx(MyStr &S);

	 int 	GetIdxRev(const char *s);
	 int 	GetIdxRev(MyStr &S);

	 int 	GetArrayCnt(void);

	 int 	Add(const char *s);
	 int 	Add(MyStr &S);
	 int 	Add(ArrayStr &A);
	 int 	Add(const int v);
	 int 	Add(const long lv);
	 
	 int 	DelByIdx(int idx);
	 
	 int 	DelByStr(MyStr &S);
	 int 	DelByStr(const char c);
	 int 	DelByStr(const char *s);
	 int 	DelByStr(const int v);
	 int 	DelByStr(const long lv);

	 int 	DelRevByStr(MyStr &S);
	 int 	DelRevByStr(const char c);
	 int 	DelRevByStr(const char *s);
	 int 	DelRevByStr(const int v);
	 int 	DelRevByStr(const long lv);

	 int 	DelAllByStr(MyStr &S);
	 int 	DelAllByStr(const char c);
	 int 	DelAllByStr(const char *s);
	 int 	DelAllByStr(const int v);
	 int 	DelAllByStr(const long lv);

const char*	GetStr(int idx);

const char*	List(const char *d=",");
const char*	List(const char c);
const char*	List(MyStr &DIV);

const char*	ListRev(const char *d=",");
const char*	ListRev(const char c);
const char*	ListRev(MyStr &DIV);
	 
 ArrayStr&  operator=(ArrayStr &A);

 ArrayStr&  operator+=(const char *s);
 ArrayStr&  operator+=(MyStr &S);
 ArrayStr&  operator+=(ArrayStr &A);
 
 	MyStr&  operator[](int idx);

};

#endif

