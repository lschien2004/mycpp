#include "mystd.h"
#include "namestr.h"
#include "mystr.h"
//#include "arraystr.h"
#include "arraynamestr.h"
//#include "namearraystr.h"


int main(int ac,char **av) {
	int n;
	tout out;
	
	MyStr S,T;
	
	out.prt("\nNameStr NS0(\"NS0\",\"NS0DATA\");");
	NameStr NS0("NS0","NS0DATA");
	out.prt("->NS0[%]=\"%\"",NS0.GetName(),(char*)NS0);	
	out.prt("\nNS0[NS_name]=\"%\" NS0[NS_str]=\"%\"",NS0[NS_name],NS0[NS_str]);
	
	out.prt("\nNS0.Reset();");
	NS0.Reset();
	out.prt("->NS0[%]=\"%\"",NS0.GetName(),(char*)NS0);
	out.prt("\nNS0[NS_name]=\"%\" NS0[NS_str]=\"%\"",NS0[NS_name],NS0[NS_str]);

	
	out.prt("\nS=\"Para0\";");
	S="Para0";
	out.prt("->S=\"%\"",(char*)S);
	
	out.prt("\nNameStr NS(S,\"data0\");");	
	NameStr NS(S,"data0");
	out.prt("->NS[%]=\"%\"",NS.GetName(),(char*)NS);
	
	out.prt("\nArrayNameStr ANS;");	
	ArrayNameStr ANS;
	out.prt("->ANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);
	
	out.prt("\nANS=NS;");	
	ANS=NS;
	out.prt("->ANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	out.prt("\nANS.Add(\"Para1\",\"data1\");");	
	ANS.Add("Para1","data1");
	out.prt("->ANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	out.prt("\nT=\"DATA2\";");
	T="DATA2";
	out.prt("->T=\"%\"",(char*)T);

	out.prt("\nANS.Add(\"Para2\",T=\"%\");",(char*)T);	
	ANS.Add("Para2",T);
	out.prt("->ANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	out.prt("\nS=\"PARA3\"; T=\"DATA3\";");
	S="PARA3"; T="DATA3";
	out.prt("->S=\"%\",T=\"%\"",(char*)S,(char*)T);

	out.prt("\nANS.Add(S=\"%\",T=\"%\");",(char*)S,(char*)T);	
	ANS.Add(S,T);
	out.prt("->ANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);
	out.prt("\nANS.NameList=%",ANS.NameList());
	out.prt("\nANS.NameListRev=%",ANS.NameListRev());
	out.prt("\nANS.StrList=%",ANS.StrList());
	out.prt("\nANS.StrListRev=%",ANS.StrListRev());

	out.prt("\n");

	out.prt("\nArrayNameStr ANS1(NS);");
	ArrayNameStr ANS1(NS);
	n=0; out.prt("\nANS1.Cnt=% ANS1[%]=[%]\"%\"",ANS1.GetArrayCnt(),n,ANS1[n].GetName(),(char*)ANS1[n]);

	out.prt("\nArrayNameStr ANS2(ANS);");
	ArrayNameStr ANS2(ANS);
	n=0; out.prt("\nANS2.Cnt=% ANS2[%]=[%]\"%\"",ANS2.GetArrayCnt(),n,ANS2[n].GetName(),(char*)ANS2[n]);
	n=1; out.prt("\nANS2.Cnt=% ANS2[%]=[%]\"%\"",ANS2.GetArrayCnt(),n,ANS2[n].GetName(),(char*)ANS2[n]);

	out.prt("\nArrayNameStr ANS3(\"Nchar*1\",'C');");
	ArrayNameStr ANS3("Nchar*1",'C');
	n=0; out.prt("\nANS3.Cnt=% ANS3[%]=[%]\"%\"",ANS3.GetArrayCnt(),n,ANS3[n].GetName(),(char*)ANS3[n]);

	out.prt("\nArrayNameStr ANS4(\"Nchar*2\",4);");
	ArrayNameStr ANS4("Nchar*2",4);
	n=0; out.prt("\nANS4.Cnt=% ANS4[%]=[%]\"%\"",ANS4.GetArrayCnt(),n,ANS4[n].GetName(),(char*)ANS4[n]);

	out.prt("\nANS+=ANS3;");
	ANS+=ANS3;
	out.prt("\nANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	out.prt("\nNS[%]=\"%\"",NS.GetName(),(char*)NS);
	out.prt("\nANS.GetIdxByNameStr(NS)=%",ANS.GetIdxByNameStr(NS));

	out.prt("\nS=ANS[2].GetName();");
	S=ANS[2].GetName();
	out.prt("->S=\"%\"",(char*)S);
	
	out.prt("\nNS=ANS[3];");
	NS=ANS[3];
	out.prt("->NS[%]=\"%\"",NS.GetName(),(char*)NS);

	out.prt("\nANS.GetIdxByName(S=\"%\")=%",(char*)S,ANS.GetIdxByName(S));
	out.prt("\nANS.GetIdxByName(%)=%",(char*)NS,ANS.GetIdxByName((char*)NS));
	out.prt("\nANS.GetIdxByName(%)=%",NS.GetName(),ANS.GetIdxByName(NS.GetName()));
	out.prt("\nANS.GetIdxByNameStr(NS)=%",ANS.GetIdxByNameStr(NS));

	out.prt("\n\nS=ANS.GetNameByIdx(1);");
	S=ANS.GetNameByIdx(1);
	out.prt("->S=\"%\"",(char*)S);
	out.prt("\nANS.GetIdxByName(S=\"%\")=%",(char*)S,ANS.GetIdxByName(S));

	out.prt("\nNS=ANS[2];");
	NS=ANS[2];
	out.prt("\n->NS[%]=\"%\"",NS.GetName(),(char*)NS);
	
	out.prt("\nANS.DelByIdx(1) ...");
	ANS.DelByIdx(1);
	out.prt("\nANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	int k=ANS.GetArrayCnt()-1;
	out.prt("\nANS.DelByIdx(%) ...",k);
	ANS.DelByIdx(k);
	out.prt("\nANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);
	
	k=ANS.GetArrayCnt();
	for (int i=0;i<k;i++) {
		out.prt("\nANS.DelByIdx(0) ...");
		ANS.DelByIdx(0);
		out.prt("\nANS.Cnt=%",ANS.GetArrayCnt());
		for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);
	}
	
	out.prt("\nANS+=NS");
	ANS+=NS;
	out.prt("\nANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);
	
	out.prt("\nANS.Add(S=\"%\",\"dataS\");",(char*)S);
	ANS.Add(S,"dataS");
	out.prt("\nANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	out.prt("\nNS=ANS[0]");
	NS=ANS[0]; 
	out.prt("\nNS[%]=\"%\"",NS.GetName(),(char*)NS);
	T=(char*)NS;
	out.prt("\nNS=\"datax\";");
	NS="datax";
	out.prt("\nNS[%]=\"%\"",NS.GetName(),(char*)NS);
	
	out.prt("\nANS.DelByName(S) ...");
	ANS.DelByName(S);
	out.prt("\nANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	out.prt("\nANS.DelByNameStr(NS) ...");
	ANS.DelByNameStr(NS);
	out.prt("\nANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

	out.prt("\nNS=\"%\";",(char*)T);
	NS=T;
	out.prt("\nNS[%]=\"%\"",NS.GetName(),(char*)NS);

	out.prt("\nANS.DelByNameStr(NS) ...");
	ANS.DelByNameStr(NS);
	out.prt("\nANS.Cnt=%",ANS.GetArrayCnt());
	for(n=0;n<ANS.GetArrayCnt();n++) out.prt("\nANS[%]=[%]\"%\"",n,ANS[n].GetName(),(char*)ANS[n]);

/*
	printf("\nMyStr S(\"S-1\");");
	MyStr S("S-1");
	printf("\nS[-1]~S[%d]:\n",(int)S);
	for(n=-1;n<=(int)S;n++) printf("S[%d]='%c' ",n,S[n]);	
	
	printf("\nArrayStr SA(S);");
	ArrayStr SA(S);
	printf("\nSA.GetArrayCnt()=%d",SA.GetArrayCnt());
	n=0; printf("\nSA[%d]=\"%s\" GetStr(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetStr(n));
	printf("\nSA.List()=\"%s\"",SA.List());
	printf("\nSA.GetIdx(\"%s\")=%d",(char*)S,SA.GetIdx(S));

	printf("\nS=\"S-2\"; SA.Add(S);");
	S="S-2";  SA.Add(S);
	printf("\nSA.GetArrayCnt()=%d",SA.GetArrayCnt());
	n=0; printf("\nSA[%d]=\"%s\" GetStr(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetStr(n));
	n=1; printf("\nSA[%d]=\"%s\" GetStr(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetStr(n));
	printf("\nSA.List()=\"%s\"",SA.List());
	printf("\nSA.GetIdx(\"%s\")=%d",(char*)S,SA.GetIdx(S));

	n=SA.Add("S-3");
	printf("\nSA.Add(\"S-3\")=%d",n);
	printf("\nSA.GetArrayCnt()=%d",SA.GetArrayCnt());
	n=0; printf("\nSA[%d]=\"%s\" GetStr(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetStr(n));
	n=1; printf("\nSA[%d]=\"%s\" GetStr(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetStr(n));
	n=2; printf("\nSA[%d]=\"%s\" GetStr(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetStr(n));
	printf("\nSA.List()=\"%s\"",SA.List());
	printf("\nSA.GetIdx(\"%s\")=%d",(char*)S,SA.GetIdx(S));

	printf("\nS=\"S-4\"; SA+=S;");
	S="S-4";  SA+=S;
	printf("\nSA.GetArrayCnt()=%d",SA.GetArrayCnt());
	n=0; printf("\nSA[%d]=\"%s\" GetStr(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetStr(n));
	n=1; printf("\nSA[%d]=\"%s\" GetStr(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetStr(n));
	n=2; printf("\nSA[%d]=\"%s\" GetStr(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetStr(n));
	n=3; printf("\nSA[%d]=\"%s\" GetStr(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetStr(n));
	printf("\nSA.List()=\"%s\"",SA.List());
	printf("\nSA.GetIdx(\"%s\")=%d",(char*)S,SA.GetIdx(S));

	printf("\nArrayStr SB(SA);");
	ArrayStr SB(SA);
	printf("\nSB.GetArrayCnt()=%d",SB.GetArrayCnt());
	printf("\nSB.List()=\"%s\"",SB.List());

	printf("\nSA+=\"S-5\";");
	SA+="S-5";
	printf("\nSA.GetArrayCnt()=%d",SA.GetArrayCnt());
	n=0; printf("\nSA[%d]=\"%s\" GetStr(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetStr(n));
	n=1; printf("\nSA[%d]=\"%s\" GetStr(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetStr(n));
	n=2; printf("\nSA[%d]=\"%s\" GetStr(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetStr(n));
	n=3; printf("\nSA[%d]=\"%s\" GetStr(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetStr(n));
	n=4; printf("\nSA[%d]=\"%s\" GetStr(%d)=\"%s\"",n,(char*)SA[n],n,SA.GetStr(n));
	printf("\nSA.List()=\"%s\"",SA.List());
	printf("\nSA.GetIdx('S-5')=%d",SA.GetIdx("S-5"));
	printf("\nSA.GetIdx('S-0')=%d",SA.GetIdx("S-0"));

	n=SA.Del("S-3");
	printf("\nSA.Del(\"S-3\")=%d",n);
	printf("\nSA.GetArrayCnt()=%d",SA.GetArrayCnt());
	printf("\nSA.List()=\"%s\"",SA.List());
	
	n=SA.Del(1);
	printf("\nSA.Del(1)=%d",n);
	printf("\nSA.GetArrayCnt()=%d",SA.GetArrayCnt());
	printf("\nSA.List()=\"%s\"",SA.List());

	n=SA.Del(0);
	printf("\nSA.Del(0)=%d",n);
	printf("\nSA.GetArrayCnt()=%d",SA.GetArrayCnt());
	printf("\nSA.List()=\"%s\"",SA.List());

	n=SB.Del("S-1");
	printf("\nSB.Del(\"S-1\")=%d",n);
	printf("\nSB.GetArrayCnt()=%d",SB.GetArrayCnt());
	printf("\nSB.List()=\"%s\"",SB.List());
	
	printf("\nSA+=\"S-6\";");
	SA+="S-6";
	printf("\nSA.GetArrayCnt()=%d",SA.GetArrayCnt());
	printf("\nSA.List()=\"%s\"",SA.List());

	printf("\nSB+=SA;");
	SB+=SA;
	printf("\nSA.GetArrayCnt()=%d",SA.GetArrayCnt());
	printf("\nSA.List()=\"%s\"",SA.List());
	printf("\nSB.GetArrayCnt()=%d",SB.GetArrayCnt());
	printf("\nSA.List()=\"%s\"",SB.List());

	printf("\nNameStr NS1;");
	NameStr NS1;
	printf("\nNS1.GetName()=\"%s\"",NS1.GetName());
	printf("\nNS1.SetName(\"NS1\");");
	NS1.SetName("NS1");
	printf("\nNS1.GetName()=\"%s\"",NS1.GetName());
	printf("\nNS1=\"NS1 DATA\";");
	NS1="NS1 DATA";
	printf("\n(char*)NS1=\"%s\"",(char*)NS1);
	printf("\nNS1+=\" plus\";");
	NS1+=" plus";
	printf("\n(char*)NS1=\"%s\"",(char*)NS1);
	printf("\nNS1.GetName()=\"%s\"",NS1.GetName());
	printf("\n(int)NS1=%d",(int)NS1);

	printf("\nNameStr NS2(\"NS2\");");
	NameStr NS2("NS2");
	printf("\nNS2.GetName()=\"%s\"",NS2.GetName());
	printf("\n(char*)NS2=\"%s\"",(char*)NS2);
	printf("\n(int)NS2=%d",(int)NS2);
	
	printf("\nNS2=\"NS2 data\";");
	NS2+="NS2 data";
	printf("\nNS2.GetName()=\"%s\"",NS2.GetName());
	printf("\n(char*)NS2=\"%s\"",(char*)NS2);
	printf("\n(int)NS2=%d",(int)NS2);
	
	printf("\nNS2=NS1;");
	NS2=NS1;
	printf("\nNS2.GetName()=\"%s\"",NS2.GetName());
	printf("\n(char*)NS2=\"%s\"",(char*)NS2);
	printf("\n(int)NS2=%d",(int)NS2);
	printf("\nNS1.GetName()=\"%s\"",NS1.GetName());
	printf("\n(char*)NS1=\"%s\"",(char*)NS1);
	printf("\n(int)NS1=%d",(int)NS1);
	printf("\nNS2=\"nsb data\"");
	
	NS2="nsb data";
	printf("\nNS2.GetName()=\"%s\"",NS2.GetName());
	printf("\n(char*)NS2=\"%s\"",(char*)NS2);
	printf("\n(int)NS2=%d",(int)NS2);
	
	printf("\nMyStr T((char*)NS1);");
	MyStr T((char*)NS1);
	printf("\n(char*)T=\"%s\"",(char*)T);
	printf("\nS=NS2;");
	T=NS2;
	printf("\n(char*)T=\"%s\"",(char*)T);
	printf("\nS+=NS1;");
	T+=NS1;
	printf("\n(char*)T=\"%s\"",(char*)T);




	S="S-0";
	out.prt("\n\nS=\"%\";",(char*)S);

	NameStr NS0("NS0",S);
	out.prt("\nNameStr NS0(\"NS0\",S);->NS0[%]=\"%\"",NS0.GetName(),(char*)NS0);

	ArrayStr SA0(S); SA0+="S-1";
	out.prt("\nArrayStr SA0(S); SA0+=\"S-1\";->SA0 cnt=% ,list=\"%\"",SA0.GetArrayCnt(),SA0.List());

	NameArrayStr NSA0("NSA0",NS0);
	out.prt("\nNameArrayStr NSA0(\"NSA0\",NS0);->NSA0[%] cnt=% ,list=\"%\"",NSA0.GetName(),NSA0.GetArrayCnt(),NSA0.List());
	
	NSA0=SA0;
	out.prt("\nNSA0=SA0;->NSA0[%] cnt=% , list=\"%\"",NSA0.GetName(),NSA0.GetArrayCnt(),NSA0.List());

	NameArrayStr NSA1(NS0);
	out.prt("\nNameArrayStr NSA1(NS0);->NSA1[%] cnt=% , list=\"%\"",NSA1.GetName(),NSA1.GetArrayCnt(),NSA1.List());

	NSA1=NSA0;
	out.prt("\nNSA1=NSA0;->NSA1[%] cnt=% , list=\"%\"",NSA1.GetName(),NSA1.GetArrayCnt(),NSA1.List());
	
	NSA1.SetName("NSA1");
	out.prt("\nNSA1.SetName(\"NSA1\");->NSA1[%] cnt=% , list=\"%\"",NSA1.GetName(),NSA1.GetArrayCnt(),NSA1.List());
	
	NSA1.Del("S-0");
	out.prt("\nNSA1.Del(\"S-0\");->NSA1[%] cnt=% , list=\"%\"",NSA1.GetName(),NSA1.GetArrayCnt(),NSA1.List());
	
	NSA0.Del(1);
	out.prt("\nNSA0.Del(1);->NSA0[%] cnt=% , list=\"%\"",NSA0.GetName(),NSA0.GetArrayCnt(),NSA0.List());

	NSA0+="A-0";
	out.prt("\nNSA0+=\"A-0\";->NSA0[%] cnt=% , list=\"%\"",NSA0.GetName(),NSA0.GetArrayCnt(),NSA0.List());

	NSA1.Add("E-0");
	out.prt("\nNSA1.Add(\"E-0\");->NSA1[%] cnt=% , list=\"%\"",NSA1.GetName(),NSA1.GetArrayCnt(),NSA1.List());

	NSA1+=NS0;
	out.prt("\nNSA1+=NS0;->NSA1[%] cnt=% , list=\"%\"",NSA1.GetName(),NSA1.GetArrayCnt(),NSA1.List());
	
	
	S+=NS0; NSA0+=S;
	out.prt("\nS+=NS;NSA0+=S;->NSA0[%] cnt=% , list=\"%\"",NSA0.GetName(),NSA0.GetArrayCnt(),NSA0.List());

	SA0+=NS0;
	out.prt("\nSA0+=NS0;->SA0 cnt=% , list=\"%\"",SA0.GetArrayCnt(),SA0.List());

	SA0+=NSA0;
	out.prt("\nSA0+=NSA0;->SA0 cnt=% , list=\"%\"",SA0.GetArrayCnt(),SA0.List());
	
	out.prt("\nSA0 cnt=% , listRev=\"%\"",SA0.GetArrayCnt(),SA0.ListRev());
	out.prt("\nNSA0 cnt=% , listRev=\"%\"",NSA0.GetArrayCnt(),NSA0.ListRev());

*/	
	exit(0);
}
