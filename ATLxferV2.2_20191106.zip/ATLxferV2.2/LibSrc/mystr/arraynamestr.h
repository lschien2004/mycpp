/*########################################################################################
	v1.0@20191022 	initial ver.
	v1.1@20191023	+ Reset()
	v1.2@20191026	private NameStr *pstr,ArrayNameStr *nxt; -> protected
					GetIdxByNameStr(NameStr&NS,int) -> GetIdxByNameStr(NameStr&NS,int,int)
					GetIdxByName(NameStr&NS,int) -> GetIdxByName(NameStr&NS,int,int)
					GetIdxByStr(NameStr&NS,int) -> GetIdxByStr(NameStr&NS,int,int)
					+ GetIdxRevByNameStr(NameStr&NS,int,int)
					+ GetIdxRevByName(...,int,int)
					+ GetIdxRevByStr(...,int,int)
					+ DelRevByNameStr(NameStr&)
					+ DelAllByNameStr(NameStr&)
					+ DelRevByName(...)
					+ DelAllByName(...)
##########################################################################################*/

#ifndef __ArrayNameStr_h__
    #define __ArrayNameStr_h__
	#define __ArrayNameStrVer__	"ArrayNameStr-v1.2@20191026"

#include "mystr.h"
#include "namestr.h"

class ArrayNameStr {
protected:
 			NameStr 		*pstr;
 			ArrayNameStr	*nxt;

	 void 	Release(ArrayNameStr *nd);
  ArrayNameStr *GetNode(MyStr &NM);
  ArrayNameStr *GetNode(int idx);

public:
			ArrayNameStr();
			ArrayNameStr(NameStr &NS);
			ArrayNameStr(ArrayNameStr &ANS);

			ArrayNameStr(const char nc,const char *s=NULL);
			ArrayNameStr(const char nc,const char sc);
			ArrayNameStr(const char nc,MyStr &S);
			ArrayNameStr(const char nc,const int i);
			ArrayNameStr(const char nc,const long l);

			ArrayNameStr(const char *name,const char *s=NULL);
			ArrayNameStr(const char *name,const char sc);
			ArrayNameStr(const char *name,MyStr &S);
			ArrayNameStr(const char *name,const int i);
			ArrayNameStr(const char *name,const long l);

			ArrayNameStr(MyStr &NM,const char *s=NULL);
			ArrayNameStr(MyStr &NM,const char sc);
			ArrayNameStr(MyStr &NM,MyStr &S);
			ArrayNameStr(MyStr &NM,const int i);
			ArrayNameStr(MyStr &NM,const long l);

			ArrayNameStr(const int ni,const char *s=NULL);
			ArrayNameStr(const int ni,const char sc);
			ArrayNameStr(const int ni,MyStr &S);
			ArrayNameStr(const int ni,const int i);
			ArrayNameStr(const int ni,const long l);
			
			ArrayNameStr(const long nl,const char *s=NULL);
			ArrayNameStr(const long nl,const char sc);
			ArrayNameStr(const long nl,MyStr &S);
			ArrayNameStr(const long nl,const int i);
			ArrayNameStr(const long nl,const long l);

			~ArrayNameStr();
			
	 void 	Reset(void);		
			
	 int 	Add(NameStr &NS);
	 int 	Add(ArrayNameStr &ANS);
	 
	 int 	Add(const char nc,const char *s=NULL);
	 int 	Add(const char nc,const char sc);
	 int 	Add(const char nc,MyStr &S);
	 int 	Add(const char nc,const int i);
	 int 	Add(const char nc,const long l);

	 int 	Add(const char *name,const char *s=NULL);
	 int 	Add(const char *name,const char sc);
	 int 	Add(const char *name,MyStr &S);
	 int 	Add(const char *name,const int i);
	 int 	Add(const char *name,const long l);

	 int 	Add(MyStr &NM,const char *s=NULL);
	 int 	Add(MyStr &NM,const char sc);
	 int 	Add(MyStr &NM,MyStr &S);
	 int 	Add(MyStr &NM,const int i);
	 int 	Add(MyStr &NM,const long l);

	 int 	Add(const int ni,const char *s=NULL);
	 int 	Add(const int ni,const char sc);
	 int 	Add(const int ni,MyStr &S);
	 int 	Add(const int ni,const int i);
	 int 	Add(const int ni,const long l);

	 int 	Add(const long nl,const char *s=NULL);
	 int 	Add(const long nl,const char sc);
	 int 	Add(const long nl,MyStr &S);
	 int 	Add(const long nl,const int i);
	 int 	Add(const long nl,const long l);

	 int 	DelByIdx(int idx);
	 
	 int 	DelByNameStr(NameStr &NS);
	 int 	DelRevByNameStr(NameStr &NS);
	 int 	DelAllByNameStr(NameStr &NS);

	 int 	DelByName(const char nc);
	 int 	DelByName(const char *name);
	 int 	DelByName(MyStr &NM);
	 int 	DelByName(const int ni);
	 int 	DelByName(const long nl);

	 int 	DelRevByName(const char nc);
	 int 	DelRevByName(const char *name);
	 int 	DelRevByName(MyStr &NM);
	 int 	DelRevByName(const int ni);
	 int 	DelRevByName(const long nl);

	 int 	DelAllByName(const char nc);
	 int 	DelAllByName(const char *name);
	 int 	DelAllByName(MyStr &NM);
	 int 	DelAllByName(const int ni);
	 int 	DelAllByName(const long nl);
	 
//	 int 	DelByStr(const char c);
//	 int 	DelByStr(const char *s);
//	 int 	DelByStr(MyStr &S);
//	 int 	DelByStr(const int i);
//	 int 	DelByStr(const long l);

			
	 int 	GetArrayCnt(void);

	 int 	GetIdxByNameStr(NameStr &NS,const int startIdx=0,const int endIdx=-1);
	 int 	GetIdxRevByNameStr(NameStr &NS,const int startIdx=0,const int endIdx=-1);

	 int 	GetIdxByName(const char nc,const int startIdx=0,const int endIdx=-1);
	 int 	GetIdxByName(const char *name,const int startIdx=0,const int endIdx=-1);
	 int 	GetIdxByName(MyStr &NM,const int startIdx=0,const int endIdx=-1);
	 int 	GetIdxByName(const int ni,const int startIdx=0,const int endIdx=-1);
	 int 	GetIdxByName(const long nl,const int startIdx=0,const int endIdx=-1);
	 
	 int 	GetIdxRevByName(const char nc,const int startIdx=0,const int endIdx=-1);
	 int 	GetIdxRevByName(const char *name,const int startIdx=0,const int endIdx=-1);
	 int 	GetIdxRevByName(MyStr &NM,const int startIdx=0,const int endIdx=-1);
	 int 	GetIdxRevByName(const int ni,const int startIdx=0,const int endIdx=-1);
	 int 	GetIdxRevByName(const long nl,const int startIdx=0,const int endIdx=-1);
	 
	 int 	GetIdxByStr(const char sc,const int startIdx=0,const int endIdx=-1);
	 int 	GetIdxByStr(const char *s,const int startIdx=0,const int endIdx=-1);
	 int 	GetIdxByStr(MyStr &S,const int startIdx=0,const int endIdx=-1);
	 int 	GetIdxByStr(const int i,const int startIdx=0,const int endIdx=-1);
	 int 	GetIdxByStr(const long l,const int startIdx=0,const int endIdx=-1);

	 int 	GetIdxRevByStr(const char sc,const int startIdx=0,const int endIdx=-1);
	 int 	GetIdxRevByStr(const char *s,const int startIdx=0,const int endIdx=-1);
	 int 	GetIdxRevByStr(MyStr &S,const int startIdx=0,const int endIdx=-1);
	 int 	GetIdxRevByStr(const int i,const int startIdx=0,const int endIdx=-1);
	 int 	GetIdxRevByStr(const long l,const int startIdx=0,const int endIdx=-1);

const char*	GetNameByIdx(int idx);

const char*	GetStrByIdx(int idx);

const char*	GetStrByName(const char nc);
const char*	GetStrByName(const char *name);
const char*	GetStrByName(MyStr &NM);
const char*	GetStrByName(const int ni);
const char*	GetStrByName(const long nl);

const char*	StrList(const char *d=",",const int startIdx=0);
const char*	StrList(const char c,const int startIdx=0);
const char*	StrList(MyStr &DIV,const int startIdx=0);

const char*	StrListRev(const char *d=",",const int startIdx=0);
const char*	StrListRev(const char c,const int startIdx=0);
const char*	StrListRev(MyStr &DIV,const int startIdx=0);

const char*	NameList(const char *d=",",const int startIdx=0);
const char*	NameList(const char c,const int startIdx=0);
const char*	NameList(MyStr &DIV,const int startIdx=0);

const char*	NameListRev(const char *d=",",const int startIdx=0);
const char*	NameListRev(const char c,const int startIdx=0);
const char*	NameListRev(MyStr &DIV,const int startIdx=0);
	 
	 
 ArrayNameStr&  operator=(NameStr &NS);
 ArrayNameStr&  operator=(ArrayNameStr &ANS);
 
 ArrayNameStr&  operator+=(NameStr &NS);
 ArrayNameStr&  operator+=(ArrayNameStr &ANS);
 
 	NameStr&  operator[](int idx);

};

#endif

