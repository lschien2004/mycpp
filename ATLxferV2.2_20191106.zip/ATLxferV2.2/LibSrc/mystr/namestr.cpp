#include "namestr.h"

void NameStr::Reset(void) { releasename(); release(); releasetmp(); }

const char *NameStr::releasename(void){ return releaseX(&myname); }

const char *NameStr::resizename(const MyStr &S)	{ return resizeX(&myname,S); }
const char *NameStr::resizename(const char *s)	{ return resizeX(&myname,s); }
const char *NameStr::resizename(const char c)	{ return resizeX(&myname,c); }

NameStr::~NameStr(){ releasename(); }
	
NameStr::NameStr(const char *name,const char *s) { myname=Emptystr; resizeX(&myname,name); resize(s); }
NameStr::NameStr(const char *name,const char sc) { myname=Emptystr; resizeX(&myname,name); resize(sc); }
NameStr::NameStr(const char *name,const MyStr &S){ myname=Emptystr; resizeX(&myname,name); resize(S); }
NameStr::NameStr(const char *name,const int v)	 { myname=Emptystr; resizeX(&myname,name); MyStr S(v); resize(S); }
NameStr::NameStr(const char *name,const long lv) { myname=Emptystr; resizeX(&myname,name); MyStr S(lv); resize((char*)S); }

NameStr::NameStr(const char nc,const char *s)	{ myname=Emptystr; resizeX(&myname,nc); resize(s); }
NameStr::NameStr(const char nc,const char sc)	{ myname=Emptystr; resizeX(&myname,nc); resize(sc); }
NameStr::NameStr(const char nc,const MyStr &S)	{ myname=Emptystr; resizeX(&myname,nc); resize(S); }
NameStr::NameStr(const char nc,const int v)		{ myname=Emptystr; resizeX(&myname,nc); MyStr S(v); resize(S); }
NameStr::NameStr(const char nc,const long lv)	{ myname=Emptystr; resizeX(&myname,nc); MyStr S(lv); resize(S); }

NameStr::NameStr(const MyStr &NAME,const char *s)		{ myname=Emptystr; resizeX(&myname,NAME); resize(s); }
NameStr::NameStr(const MyStr &NAME,const char sc)		{ myname=Emptystr; resizeX(&myname,NAME); resize(sc); }
NameStr::NameStr(const MyStr &NAME,const MyStr &S)	{ myname=Emptystr; resizeX(&myname,NAME); resize(S); }
NameStr::NameStr(const MyStr &NAME,const int v)		{ myname=Emptystr; resizeX(&myname,NAME); MyStr S(v); resize(S); }
NameStr::NameStr(const MyStr &NAME,const long lv)		{ myname=Emptystr; resizeX(&myname,NAME); MyStr S(lv); resize(S); }

NameStr::NameStr(const int nv,const char *s)	{ myname=Emptystr; MyStr NAME(nv); resizeX(&myname,NAME); resize(s); }
NameStr::NameStr(const int nv,const char sc)	{ myname=Emptystr; MyStr NAME(nv); resizeX(&myname,NAME); resize(sc); }
NameStr::NameStr(const int nv,const MyStr &S)	{ myname=Emptystr; MyStr NAME(nv); resizeX(&myname,NAME); resize(S); }
NameStr::NameStr(const int nv,const int v)		{ myname=Emptystr; MyStr NAME(nv); resizeX(&myname,NAME); MyStr S(v); resize(S); }
NameStr::NameStr(const int nv,const long lv)	{ myname=Emptystr; MyStr NAME(nv); resizeX(&myname,NAME); MyStr S(lv); resize(S); }

NameStr::NameStr(const long nlv,const char *s)	{ myname=Emptystr; MyStr NAME(nlv); resizeX(&myname,NAME); resize(s); }
NameStr::NameStr(const long nlv,const char sc)	{ myname=Emptystr; MyStr NAME(nlv); resizeX(&myname,NAME); resize(sc); }
NameStr::NameStr(const long nlv,const MyStr &S)	{ myname=Emptystr; MyStr NAME(nlv); resizeX(&myname,NAME); resize(S); }
NameStr::NameStr(const long nlv,const int v)	{ myname=Emptystr; MyStr NAME(nlv); resizeX(&myname,NAME); MyStr S(v); resize(S); }
NameStr::NameStr(const long nlv,const long lv)	{ myname=Emptystr; MyStr NAME(nlv); resizeX(&myname,NAME); MyStr S(lv); resize(S); }

NameStr::NameStr(NameStr &NS)					{ myname=Emptystr; operator=(NS); }

const char *NameStr::SetName(const char nc)		{ return resizeX(&myname,nc);}
const char *NameStr::SetName(const char *name)	{ return resizeX(&myname,name);}
const char *NameStr::SetName(const MyStr &NAME)	{ return resizeX(&myname,NAME);}
const char *NameStr::SetName(const int nv)		{ MyStr NAME(nv); return resizeX(&myname,NAME); }
const char *NameStr::SetName(const long nlv)	{ MyStr NAME(nlv); return resizeX(&myname,NAME); }

const char *NameStr::GetName()					{ return resizetmp(myname); }

bool NameStr::IsNameEmpty() 					{ if(myname==Emptystr) return true; else return false; }
bool NameStr::IsNotNameEmpty() 					{ if(myname==Emptystr) return false; else return true; }

NameStr& NameStr::operator=(const NameStr &NS)	{ resizeX(&myname,NS.myname); return operator=((MyStr&)NS); }
NameStr& NameStr::operator=(const char sc)		{ MyStr::operator=(sc);	return *this; }
NameStr& NameStr::operator=(const MyStr &S)		{ MyStr::operator=(S); 	return *this; }
NameStr& NameStr::operator=(const int v)		{ MyStr::operator=(v); 	return *this; }
NameStr& NameStr::operator=(const long lv)		{ MyStr::operator=(lv); return *this; }
NameStr& NameStr::operator=(const char *s)		{ MyStr::operator=(s); 	return *this; }

NameStr& NameStr::operator+=(const NameStr &NS)	{ MyStr::operator+=((MyStr&)NS); return *this; }

NameStr& NameStr::operator+=(const char sc)		{ MyStr::operator+=(sc); 	return *this; }
NameStr& NameStr::operator+=(const char *s)		{ MyStr::operator+=(s); 	return *this; }
NameStr& NameStr::operator+=(const MyStr &S)	{ MyStr::operator+=(S); 	return *this; }
NameStr& NameStr::operator+=(const int v)		{ MyStr::operator+=(v); 	return *this; }
NameStr& NameStr::operator+=(const long lv)		{ MyStr::operator+=(lv); 	return *this; }

bool NameStr::operator==(const NameStr &NS)		{ return MyStr::operator==((MyStr&)NS); }

bool NameStr::operator!=(const NameStr &NS)		{ return MyStr::operator!=((MyStr&)NS); }

const char* NameStr::operator+(const NameStr &NS)	{ return MyStr::operator+((MyStr&)NS); }

const char* NameStr::operator[](NameStr_enum s)	{ if(s==NS_name) return myname; else return str; }
