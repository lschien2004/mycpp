/* ###################################################################################################
	v1.1   : (1) Xfer�� parameter TrimR+TrimL (except _DEQUSYMS+_DEQUSYMX)
	v1.1   : (2) Xfer�� parameter �� SymX+data+SymX�� data ���B�z, ��SymX�h���ᵹBody�Axfer.(Symx='%)
	v1.1   : (3) Xfer�O�d @x comment
	v1.1   : (4) output file ��X ;@> + xfer�e�쫬 .
	v1.1   : (5) Xfer��parameter �i�H��J dequ ���� ex. Titem<10,"FUNC 1",ClearArray<FDUT>,FUNSUB>

	v1.2   : (1) Xfer��Parameter�ϥ� macro1<,macro2<>> �_����J���D�ѨM
	v1.2   : (2) Xfer��Parameter�ϥΪ�macro�L�Ѽƥi�٥h<>. (FunPon<>��i�H��FunPon) 
	v1.2   : (3) DEQU_DB v1.2 DEQU add �� FIFO �令 LIFO & DEQU body�a�JSeqN search,�᭱�P�W macro�u��.
	v1.2   : (4) Xfer��Parameter�ϥ� SymX �_���p 'pon<TIM1,3MS,`IN1,IN2`>' ���D�ѨM
	v1.2   : (5) output DEQU macro DB file �令 macro�쫬��X-> ODIR\m+ifile

	v1.3   : (1) Fix Macro name including the other short macro name issue
	v1.3   : (2) accept non-parameter macro definition without <> 
	
	v1.6@20191031 	
		1)change to dequdb
		2)remove Statement EQUATE,SDEF,...check during #dequ load
		3)Add _DEQUSYMU '?' , and it can be xferred if macro inside
		4)Accept #dequ inside #dequ ( insided #dequ willn't be load still defined #dequ is used )
		5)#dequ inside INSERT statement will be executed still defined #dequ is used .
		6)Reject to load the same #dequ name again
	v2.0@20191103
		+ #dequ name rule (any A~Z + any exack chars) if no a~z chars
		+ Global setting/Err message : SC
		+ Argument : -c ATLcompileOption , -f fulloutputfilename
		+ ATL compile Option analyizer
		+ Dync(Insided) #dequ name rule (MUST includeing parent $para$)
		+ DequXfer modify <-  #dequ macro xfer parameter cnt mis-match check
	v2.0@20191104
		+ Correct ;;#dequ comment line mis-judge bug
	v2.1@20191105
		+ -x argument for <file>[line]content display off
	    + Fix IntStack pop bug
	    + Separate InStack class to be independancy code in LibSrc/mystd 
		+ MultiLine_ATL_CmpOptFilter to Filter xferred output option statements
	v2.2@20191106
		+ EQUATE '"' can be xferred
		+ #dequ Name NM!=NM.GetTrimA <- _err_name
		+ #dequ Name _err_namerule <- _DEQU*** Keys ,%IFE %IFN EQUATE inside
		+ #dequ Name _err_namerule <- #*** is HEX string
		+ -u argument ->Disable add comment line of command before xfer to output file
	v2.3@20191107
	    Fix parameter using #dequ macro set caused parameter cnt mis-match problem .
	v2.31@20191107
		fix DequXfer xfer comment output twice problem & turning xfer trimming for '\n'
	v2.32@20191108
		fix parameter using sym('`) <- parameter mis-match problem
	v2.33@20191108
		fix 2nd~ insided #dequ lose problem .
	v2.34@20191110
		fix #dequ ~ at line[0] missing bug
	v2.34b@20191111
		#dequ name accept '<' '>'  chars ( Ex. #dequ XB++>YB++ {{XB=XB+1^BX YB=YB+1}} is passible)
		Fix inside #dequ using macro caused repeated xfercmt bug
		+ Message exchg for INSERT in %MESSAGE problem
	v2.35@20191112
		Class ArrayNameStr add Obj SN .
		AddExchg*** (in dequdb) add (ArrayNameStr)Exchg.GetSN() in exchange_code to isolate diff. Exchg
		+ -r argument ->Disable macro DB file output
		remove MySTD related for UNIX comparable
		Fix main_src_file/Output_path => Lcase caused UNIX system error 
	v2.36@20191114
		Fix used macro parameter mis-match When using '' or ?? symBLKs  
  ################################################################################################### */

#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>    //printf
#include <stdlib.h>   //malloc
#include <string.h>   //strncpy
#include <unistd.h>   //close
#include <iostream>
#include <ctime>

//#define _DOS_

#include "mystr.h"
//#include "mystd.h"
#include "fileobj.h"
#include "namestr.h"
#include "arraystr.h"
#include "arraynamestr.h"
#include "namearraystr.h"
#include "dequdb.h"
#include "intstack.h"

#define __ATLXferVer__ "ATLxfer-v2.36@20191114"
#define __Author__ "L.S Chien"

#ifdef _DOS_
	#define __SYS__ "DOS"
    #define SymPath  '\\'
#else
	#define __SYS__ "UNIX"
    #define SymPath  '/'
#endif

#define FileInsertStatement "INSERT"

#define StrMaxLen 256

using namespace std;

//########################################
//		Global Variables
//========================================
struct setting {
	FileObj 	FO;					//output file information & operation
	FnameObj	INF;				//input file information
	FnameObj	ONF;				//Dequ output file information
	DEQU_DB 	QDB;				//DEQU_DB
	ArrayStr	OPC;				//Compile option list
	IntStack	ops;				//Compile option nest stack
	MyStr		Me;					//my name AV[0]
	bool		DisLineShow;		// Default enable (DisLineShow=false)
	bool        EnDequXferCmt;		// Default enable (EnDequXferCmt=true)
	bool        EnDequDBoutput;		// Default enable (EnDequDBoutput=true)
	int			err;
	MyStr		ErrMsg;
	int			MaxWriteDmyLineCnt;
};

static setting SC;
//########################################
static char line[StrMaxLen];
static PO2 P2;

void usage(void);
void ShowInformation(void);
int  SetupINF(MyStr &S);
int  SetupONF(MyStr &O);
int  SetupCompileOption(MyStr &OPCS);
void ArgAnalyzer(const int ac,char **av);
int  Err_ATL_OptAnalyzer(const int err,FnameObj &INF,long llnn);
int  ATL_OptAnalyzer(MyStr &LX,FnameObj &INF,long llnn);
int  ATL_CmpOptFilter(MyStr &LL,FnameObj &INF,long llnn);
int  MultiLine_ATL_CmpOptFilter(MyStr &LL,FnameObj &INF,long llnn);
int EQUATE_Xfer(MyStr &LL,FnameObj &INF,long llnn);
PO2 GetPointOfEQUcontents(MyStr &LL);

void PickupInsertFileName(MyStr &Fname,MyStr &LS,MyStr &LE,const char *line);
void SpCtlWrite(const char *ll,int &LFcnt);
void SpCtlWrite(MyStr &LL,int &LFcnt);
int  DequXfer(MyStr &LL,FnameObj &INF,long llnn,bool CmtOn=true);
int  InsertCheckXferWrite(FnameObj &INF,MyStr &LL,int &LFcnt,long llnn);
int  FileXfer(FnameObj &INF,int &state,MyStr &FF,int &LFcnt);
void GetTimeStr(MyStr &RtnStr);

//########################################
int EQUATE_Xfer(MyStr &LL,FnameObj &INF,long llnn) {
	MyStr FF(LL);
	FF=FF.GetRangeWithWdChg('\t',' ');
	int p=FF.InStr("EQUATE ");
	if(p<0) return 0;
//printf("\n#>EQUATE_Xfer[%s]",(char*)FF);
	int q=FF.InStr(p,'\n');
	if(q<0) q=(int)LL;
	int k=FF.InStr(p,q,'=');
	if(k<0) return -1;		// EQUATE & = MUST in the same line (format err)
	MyStr T(FF.GetRangeByIdx(p+strlen("EQUATE"),k-1));
//printf("\n#>T=[%s]",(char*)T);
	T.GetTrimA();
	if((int)T<1) return -2;	// Null Name error
	FF=LL.GetRangeByIdx(k+1,-1);
//printf("\n#>FF=[%s]",(char*)FF);
	int n=FF.WdCntInStr('\"');
//printf("=> n=%d",n);
	if((n%2)!=0) return -3;	// pair '"' err
	LL=LL.GetRangeByIdx(-1,k);
	p=0;
	PO2 pp=FF.SymBlkIdxInStr(p,-1,"\"");
	while(pp.p1>-1 && pp.p2>pp.p1) {
		LL+=FF.GetRangeByIdx(p,pp.p1);
		T=FF.GetRangeByIdx(pp.p1+1,pp.p2-1);
//printf("\n##>T=[%s]",(char*)T);
		if(DequXfer(T,INF,llnn,false)<0) return -4; // xfer err
//printf("=> DequXfer =>T=[%s]",(char*)T);
		LL+=T; LL+="\"";
//printf("=>LL=[%s]",(char*)LL);
		p=pp.p2+1;
		pp=FF.SymBlkIdxInStr(p,-1,"\"");
	}
//printf("\n##>p=%d (int)FF=%s",p,(int)FF);
	if(p<(int)FF) LL+=FF.GetRangeByIdx(p,-1);
//printf("\n###>LL=[%s]",(char*)LL);
	return 0;
}

void GeneralExchgLineStr(MyStr &LL,ArrayNameStr &Exchg) {
	AddExchgLineCmtWithExLineSymBlk(LL,Exchg);
	AddExchgLineMessage(LL,Exchg);
	AddExchgLineSymBlk(LL,Exchg);
	AddExchgSymChrCmtWithExLineSymBlk(LL,Exchg);
}

void usage(void)
{
	printf("\n Usage: %s  main_src_file [output_path or -f output_pathfilename] [-c ATLcompileOption] [-u] [-r] [-x]",(char*)SC.Me);
	printf("\n       >> w/o output_path & output_pathfilename -> output in current path .");
	printf("\n       >> w/i -c ATLcompileOption : Ex. -c A,P -> transfer with %IFE condition check .");
	printf("\n       >> -u : turn-off the transferred comment in output file .");
	printf("\n       >> -r : turn-off macro DB file output .");
	printf("\n       >> -x : turn-off display file line information .");
	printf("\n          Note : the ATLcompileOption will be transferred to Upper-Case when option condition checking.\n");
}

void ShowInformation(void)
{
	printf("\n##################################################################");
	printf("\n[[[ ATL Xfer %s %s By %s (DequDef=%d)]]]",__SYS__,__ATLXferVer__,__Author__,__DequDef__);
	printf("\n==================================================================");
	printf("\n     This tool is used to convert the source files which writed with");
	printf("\n%s macro to a .asc file for ADV tester's compiler .\n",_DEQUKEY);
	printf("\n Note :");
	printf("\n     1) Except DOS ver. ,all of inserted files must be lower-case file name !");
	printf("\n     2) main_src_file and all of inserted files must be stored in the same");
	printf("\n        path !");
	printf("\n     3) All of inserted files' att_name must use the same att_name of ");
	printf("\n        main_src_file !");
	printf("\n        Ex: main_src_file is main.s , the insertd files must be *.s");
	printf("\n     4) If main_src_file's att_name is .asc and output_path is same");
	printf("\n        as main_src_file's path, then output file's att_name will");
	printf("\n        change to be .asc2)");
	printf("\n  Regarding %s marco :",_DEQUKEY);
	printf("\n     1) Re-define the same %s macro name will be rejected since V1.6",_DEQUKEY);
	printf("\n     2) Name of %s macro must exist at the least one lower-case or",_DEQUKEY);
	printf("\n        inclinding one of %s chars.",_DEQUNAME_exack_chars);
	printf("\n     3) Don't support ATL compile option for %s macro transfer now !",_DEQUKEY);
	printf("\n==================================================================");
	printf("\n Related lib :");
	printf("\n   %s\t \t%s",__MyStrVer__,__NameStrVer__);
	printf("\n   %s\t%s",__ArrayStrVer__,__ArrayNameStrVer__);
	printf("\n   %s\t%s",__NameArrayStrVer__,__DequDBVer__);
//	printf("\n   %s\t \t%s",__MyStdVer__,__FileObjVer__);
	printf("\n   %s",__FileObjVer__);
	printf("\n##################################################################\n");
	usage();
}

int SetupINF(MyStr &S) {
	SC.err=0;
	SC.INF.NameSetByFullFileName(S);
	if(!SC.INF.IsFileExist()) {
		sprintf(line,"!!! Error : file '%s' not found !!!",SC.INF.GetFullFileName());
		SC.ErrMsg=line;	SC.err=-1;
	}
	return SC.err;
}

int SetupONF(MyStr &O) {
	MyStr S(O),F;
	SC.err=0;	
	if(SC.ONF.IsPathExist((char*)S)) {
//printf("\n#>path S=[%s]",(char*)S);
		//**********************************
		//	user specify output path
		//**********************************
		if( S[(int)S-1]!=_SymDir ) S+=_SymDir;
		F=S+SC.INF.GetFileName();
		F=F.GetRangeWithWdDel(SC.INF.GetFileAtt());
		//--------------------------------
		S=".asc";
		if(S==SC.INF.GetFileAtt()) S=S+"2";
		S=F+S;
	}
//printf("\n#>S=[%s]",(char*)S);
	SC.ONF.NameSetByFullFileName(S);
	if(!SC.ONF.IsLegalFileName()) {
		sprintf(line,"!!! Error : bad output filename '%s' !!!",SC.ONF.GetFullFileName());
		SC.ErrMsg=line;	SC.err=-1;
	}
	return SC.err;
}

int SetupCompileOption(MyStr &OPCS) {
	MyStr F(OPCS);
	MyStr S;
	SC.err=0;

	F=F.GetUpperCase();
	int p=F.InStr(',');
	while(p>0) {
		S=F.GetRangeByIdx(-1,p-1); S=S.GetTrim();
		if((int)S<1) { SC.err=-1; break; }
		SC.OPC.Add(S);
		F=F.GetRangeByIdx(p+1,-1);
		p=F.InStr(',');
	}
	if((int)F>0) { 
		F=F.GetTrim(); 
		if((int)F<1) 	SC.err=-1;
		else			SC.OPC.Add(F); 
	}	
	if(SC.err!=0) {
		sprintf(line,"!!! Error : bad option usage '%s' !!!",(char*)OPCS);
		SC.ErrMsg=line; 
	}
	return SC.err; 
}

void ArgAnalyzer(const int ac,char **av) {
	SC.err=0;
	SC.Me = av[0];
	if(ac<2) { SC.err=-1; SC.ErrMsg="!!! Error : bad usage !!!"; return; }
	
	MyStr S,F;
	int n;
	int state=0;
	
	for(n=1;n<ac;n++) {
		if(SC.err<0) break;
		S=av[n];
		if(state==0) {
			if(S[0]!='-') {
				//-----------------------------------
				F=SC.INF.GetFileName();
				if((int)F<1) { SetupINF(S); continue; }
				//-----------------------------------
				F=SC.ONF.GetFileName();
				if((int)F<1) { SetupONF(S); continue; }
				//---------------------------------------
				sprintf(line,"!!! Error : Unknown argument '%s' !!!",(char*)S); 
				SC.ErrMsg=line;	SC.err=-1; return;
			} else {
				//----------------------------------------------------
				if((int)S<2) {
					sprintf(line,"!!! Error : bad option usage '%s' !!!",(char*)S); 
					SC.ErrMsg=line;	SC.err=-1; return; 
				}
				//----------------------------------------------------
				if(S[1]=='c') {
					F=S.GetRangeByIdx(2,-1);
					F=F.GetRangeWithWdDel('=');
					if((int)F>0) { SetupCompileOption(F); state=0; }
					else		state=1; 
					continue;
				}
				//----------------------------------------------------
				if(S[1]=='x') { SC.DisLineShow=true; continue; }	 	// disable show <file>[linno]content
				//----------------------------------------------------
				if(S[1]=='r') { SC.EnDequDBoutput=false; continue; }	// disable macro DB file output
				//----------------------------------------------------
				if(S[1]=='u') { 										// disable Add comment line of command before xfer to output file
					SC.MaxWriteDmyLineCnt++;
					SC.EnDequXferCmt=false; 
					continue; 
				}	
				//----------------------------------------------------
				if(S[1]=='f') {
					F=S.GetRangeByIdx(2,-1);
					F=F.GetRangeWithWdDel('=');
					if((int)F>0) { SetupONF(F); state=0; }
					else		state=2; 
					continue;
				}
				//----------------------------------------------------
				sprintf(line,"!!! Error : Unknown option '%s' !!!",(char*)S); 
				SC.ErrMsg=line;	SC.err=-1; return; 
			}
		}
		if(state==1) { state=0; SetupCompileOption(S); continue; }
		if(state==2) { state=0; SetupONF(S); continue; }
	} // for
	
	if(SC.err==0) {
		F=SC.ONF.GetFileName();
		if((int)F<1) { F='.'; SetupONF(F); }
	}
}

int Err_ATL_OptAnalyzer(const int err,FnameObj &INF,long llnn) {
	SC.err=err;
	switch (err) {
		case -2:
			sprintf(line,"!!! Error : file'%s'@line(%ld)-> bad .XXX. operator in ATL compile option command !",INF.GetFileName(),llnn);
			SC.ErrMsg=line;	break;
		case -3:
			sprintf(line,"!!! Error : file'%s'@line(%ld)-> bad () sets in ATL compile option command !",INF.GetFileName(),llnn);
			SC.ErrMsg=line;	break;
		case -4:
			sprintf(line,"!!! Error : file'%s'@line(%ld)-> Null option in ATL compile option command !",INF.GetFileName(),llnn);
			SC.ErrMsg=line;	break;
		case -5:
			sprintf(line,"!!! Error : file'%s'@line(%ld)-> In-corrected %I**/%E** ATL compile option command !",INF.GetFileName(),llnn);
			SC.ErrMsg=line;	break;
		case -6:
			sprintf(line,"!!! Error : file'%s'@line(%ld)-> %ENDC w/o %IF* !",INF.GetFileName(),llnn);
			SC.ErrMsg=line;	break;
		default:
			sprintf(line,"!!! Error : file'%s'@line(%ld)-> bad format in ATL compile option command !",INF.GetFileName(),llnn);
			SC.ErrMsg=line;	break;	
	}
//printf(" ->Err(%s)",SC.err);
	return SC.err;
}

int ATL_OptAnalyzer(MyStr &LX,FnameObj &INF,long llnn) {
//printf("\nIn LX=\"%s\"",(char*)LX);
//MyStr Z(LX);

	MyStr F,S,T;
	int p,q;
	LX=LX.GetTrimA();
	if((LX.WdCntInStr('.')%2)>0) return Err_ATL_OptAnalyzer(-2,INF,llnn);
	if(LX.WdCntInStr('(')!=LX.WdCntInStr(')')) return Err_ATL_OptAnalyzer(-3,INF,llnn);
	if((int)LX<1) return Err_ATL_OptAnalyzer(-4,INF,llnn);
	PO2 pp=LX.GetPointOfStackPairKey('(',')');
//printf("\nLX[%s]<-'()' : pp.p1=%d pp.p2=%d",(char*)LX,pp.p1,pp.p2);
	while(pp.p1>-1) {
		if(pp.p2>pp.p1) { 
			if(pp.p1>0) S=LX.GetRangeByIdx(-1,pp.p1-1);
			else		S="";
			T=LX.GetRangeByIdx(pp.p2+1,-1);
			F=LX.GetRangeByIdx(pp.p1+1,pp.p2-1);
//printf("\n[%s],F=\"%s\"",(char*)LX,(char*)F);
			if((int)F<1) return Err_ATL_OptAnalyzer(-4,INF,llnn);
//printf("->F=\"%s\"",(char*)F);
			p=ATL_OptAnalyzer(F,INF,llnn);
			if(p<0) return p;
			if((int)S>0 || (int)T>0) { 
				F=S+F; F+=T; p=ATL_OptAnalyzer(F,INF,llnn); 
				if(p<0) return p; 
			}
			LX=F;
			pp=LX.GetPointOfStackPairKey('(',')');
		} else return Err_ATL_OptAnalyzer(-1,INF,llnn);
	}
	if(pp.p2>-1) return Err_ATL_OptAnalyzer(-1,INF,llnn);
	//---------------------------------------------------------
	ArrayNameStr ANS; 
	NameStr NS;
	NS.SetName(".NOT."); 	NS=".!"; 	ANS.Add(NS);
	NS.SetName(".AND."); 	NS=".&"; 	ANS.Add(NS);
	NS.SetName(".OR."); 	NS=".+"; 	ANS.Add(NS);
	NS.SetName(".XOR."); 	NS=".^"; 	ANS.Add(NS);
	for(p=0;p<ANS.GetArrayCnt();p++) {
		LX=LX.GetRangeWithWdChg(ANS.GetNameByIdx(p),(char*)ANS[p]);
	}
//printf("\n#>LX=\"%s\"",(char*)LX);
	p=0;
	q=LX.InStr(p,'.');
	F="";
	while(q>-1) {
		if(q>p) T=LX.GetRangeByIdx(p,q-1);
		else	T="";
		p=q+2;
		if(p>=(int)LX) return Err_ATL_OptAnalyzer(-4,INF,llnn);
//printf("\n##>T=\"%s\"",(char*)T);
		if((int)T>0) {
			if(T!='1' && T!='0') { 
				T=T.GetUpperCase(); S='0';
				for(int n=0;n<SC.OPC.GetArrayCnt();n++) {
//printf("\n>SC.OPC[%d]=\"%s\"",n,(char*)SC.OPC[n]);
					if(T==SC.OPC[n]) {S='1'; break;}
				}
//printf("\n>S=[%s]",(char*)S);
				F+=S;
			} else F+=T;
		}
		F+=LX.GetRangeByIdx(q,q+1);
//printf(" -> F=\"%s\"",(char*)F);
		q=LX.InStr(p,'.');
	}
	T=LX.GetRangeByIdx(p,-1);
//printf("->#>F=\"%s\" ,T=\"%s\"",(char*)F,(char*)T);
	if((int)T>0) {
		if(T!='1' && T!='0') { 
			T=T.GetUpperCase(); S='0';
			for(int n=0;n<SC.OPC.GetArrayCnt();n++) { 
//printf("\n>SC.OPC[%d]=\"%s\"",n,(char*)SC.OPC[n]);
				if(T==SC.OPC[n]) {S='1'; break;}
			}
//printf("\n>S=[%s]",(char*)S);
			F+=S;
		} else F+=T;
	}
//printf("\nIn LX[%s]-> F=[%s]",(char*)Z,(char*)F);
	LX=F.GetRangeWithWdChg(".!0","1");
	LX=LX.GetRangeWithWdChg(".!1","0");
	LX=LX.GetRangeWithWdChg("0.&0","0");
	LX=LX.GetRangeWithWdChg("0.&1","0");
	LX=LX.GetRangeWithWdChg("1.&0","0");
	LX=LX.GetRangeWithWdChg("1.&1","1");
	LX=LX.GetRangeWithWdChg("0.+0","0");
	LX=LX.GetRangeWithWdChg("0.+1","1");
	LX=LX.GetRangeWithWdChg("1.+0","1");
	LX=LX.GetRangeWithWdChg("1.+1","1");
	LX=LX.GetRangeWithWdChg("0.^0","0");
	LX=LX.GetRangeWithWdChg("0.^1","1");
	LX=LX.GetRangeWithWdChg("1.^0","1");
	LX=LX.GetRangeWithWdChg("1.^1","0");
//printf("-> Out LX=[%s]",(char*)LX);
	if(LX=='1') return 1;
	return 0;
}

int MultiLine_ATL_CmpOptFilter(MyStr &LL,FnameObj &INF,long llnn) {
	MyStr T,S;
	int r,s=0;
	int n=LL.InStr(s,'\n');
	while(n>-1) {
		T=LL.GetRangeByIdx(s,n);
		r=ATL_CmpOptFilter(T,INF,llnn);
		if(r<0) return r;
		if(r>0) S+=T;
		s=n+1;
		n=LL.InStr(s,'\n');
	}
	if(s<(int)LL) {
		T=LL.GetRangeByIdx(s,-1);
		r=ATL_CmpOptFilter(T,INF,llnn);
		if(r<0) return r;
		if(r>0) S+=T;
	}

	LL=S;
	if((int)S>0) return 1;
	return 0;
}

int ATL_CmpOptFilter(MyStr &LL,FnameObj &INF,long llnn) {
//printf("\n#ATL_CmpOptFilter LL=[%s]",(char*)LL);
	if(SC.ops.GetVal()<0) return 1;			// ATL Compile Option Analyize disable

	Dequ DQ;
	MyStr S(DQ.RemoveLineCmt(LL));
	S=DQ.RemoveSymChrCmt(S);
	S=DQ.RemoveSymBlk(S);
	S=S.GetRangeWithSpCmpress();
	S=S.GetTrim();

	int p=S.InStr("%I");
	int q=S.InStr("%E");
//printf("\np=%d q=%d",p,q);
	
	if(p<0 && q<0) return SC.ops.GetVal();	// None %I*** , %E*** return

//printf("\n#ATL_CmpOptFilter LL=[%s]",(char*)LL);

	if(q>-1) { // %E*** entry
		if(q!=S.InStr("%ENDC")) return Err_ATL_OptAnalyzer(-5,INF,llnn);
		if(SC.ops.StackCnt()>0) { 
			SC.ops.Pop(); 
//printf("->SC.ops.GetVal=%d\n",SC.ops.GetVal());
			return 0; 
		} // %I*** , %E*** return 0 to mask output
		return Err_ATL_OptAnalyzer(-6,INF,llnn);
	}
	
	// %I** statement
	q=S.InStr(' ');
	if(q<0) return Err_ATL_OptAnalyzer(-5,INF,llnn);
	MyStr T(S.GetRangeByIdx(p,q-1));
	if(T!="%IFE" && T!="%IFN") Err_ATL_OptAnalyzer(-5,INF,llnn);
	
	// During OFF state , just continue to push(0) for N %ENDC pop
	if(SC.ops.GetVal()<1) { SC.ops.Push(0); return 0; }
	
	if(T=="%IFN") T=".NOT.(";
	else		  T="(";
	S=S.GetRangeByIdx(q,-1); S=S.GetTrim();
	T+=S; T+=")";

	int n=ATL_OptAnalyzer(T,INF,llnn);
	if(n<0) return n;
	
	SC.ops.Push(n);
//printf("->SC.ops.GetVal=%d\n",SC.ops.GetVal());
	return 0;		// %I** or %E** return 0 to mask output
}

void PickupInsertFileName(MyStr &Fname,MyStr &LS,MyStr &LE,const char *line) {
	LS=line;  ArrayNameStr Exchg;
	GeneralExchgLineStr(LS,Exchg);

	LE=LS.GetRangeWithWdChg('\t',' ');
	LE=LE.GetRangeWithWdChg('\n',' ');
	Fname=FileInsertStatement;
	Fname+=" ";

	int p=LE.InStr(Fname);
	if(p<0) {LS=line; LE=""; Fname=""; return; }
	MyStr T;
	if(p>0) T=LS.GetRangeByIdx(-1,p-1);
	p=p+(int)Fname;
	
	int l=LE.InStr(p,_DEQU_ExKeyS); // ExKeyStart
	if(l<0) l=(int)LE;
	
	while(p<l && LE[p]==' ') p++;
	int q=p;
	while(q<l && LE[q]!=' ') q++;
	Fname=LE.GetRangeByIdx(p,q-1);
	Fname=Fname.GetLowerCase();
	LE=LS.GetRangeByIdx(q,-1);
	LS=GetAllUnExchgStr(T,Exchg);
	LE=GetAllUnExchgStr(LE,Exchg);
}

int DequXfer(MyStr &LL,FnameObj &INF,long llnn,bool CmtOn) {
//printf("\nDequXfer LL[%s]\n",(char*)LL);
	ArrayNameStr Exchg;
	AddExchgLineCmtWithExLineSymBlk(LL,Exchg);
	AddExchgLineMessage(LL,Exchg);
	AddExchgSymChrCmtWithExLineSymBlk(LL,Exchg);
	AddExchgLineSymBlkS(LL,Exchg);
//printf("\n#>LL[%s]",(char*)LL);
	
	MyStr T(SC.QDB.DEQU_Inside((char*)LL));
//printf("\n#>T[%s]",(char*)T);

	int flg=0;
	MyStr C;
	if(CmtOn && (int)T>0) {flg++; C=";@>"; C+=LL; C+='\n';}
//printf("=>C[%s]",(char*)C);

	while(T!="") {
//printf("\n#>DEQU_Inside<LL[%s]>T[%s]",(char*)LL,(char*)T);
		MyStr LS,LE,SYM(_DEQUSYMA);
		int n=SC.QDB.SearchDEQUparN((char*)T);
		MyStr PA(SC.QDB.PickupLineDequPara(LL,T,LS,LE));
//printf("\n#>PA=SC.QDB.PickupLineDequPara([%s],[%s]>n=%d)",(char*)LL,(char*)T,n);
		int x=SC.QDB.AnalyzeParaCnt(PA);
//printf("\n#>SC.QDB.AnalyzeParaCnt(%s)>x=%d",(char*)PA,x);
		if(x!=n) {
			sprintf(line,"!!! Error : file'%s'@line(%ld) %s '%s' parameters mis-match !",INF.GetFileName(),llnn,_DEQUKEY,(char*)T); 
			SC.err=-1; SC.ErrMsg=line; return -1;
		}
        //T=SC.QDB.DEQU_xfer((char*)LL);
		//LL=T.GetRangeWithWdCmpressExSymBlk('\n',_DEQUSYMA);
//printf("\n#>SC.QDB.DEQU_xfer(LL[%s])",(char*)LL);
		LL=SC.QDB.DEQU_xfer((char*)LL);
//printf("=>LL[%s]",(char*)LL);
//printf("\n#>T.GetRangeWithWdCmpressExSymBlk>LL[%s]",(char*)LL);
		T=SC.QDB.DEQU_Inside((char*)LL);
	}
	//----------------------------------------------
	LL=C+LL;
//printf("\n#>LL=C+LL=[%s]\n",(char*)LL);
	LL=GetAllUnExchgStr(LL,Exchg);
	if(flg>0) LL=LL.GetRangeWithWdCmpressExSymBlk('\n',_DEQUSYMA);
	
//printf("\n####>DequXfer LL[%s]\n",(char*)LL);
	return 0;
}

void SpCtlWrite(const char *ll,int &LFcnt) { MyStr LL(ll); return SpCtlWrite(LL,LFcnt); }
void SpCtlWrite(MyStr &LL,int &LFcnt) {
	MyStr S(LL.GetTrim());
//printf("LFcnt[%d][%s]",LFcnt,(char*)LL);
	if((int)S<1) { 
		//if(++LFcnt>1) { LFcnt=1; return; }
		if(++LFcnt>SC.MaxWriteDmyLineCnt) { LFcnt=SC.MaxWriteDmyLineCnt; return; }
	} else if(--LFcnt<0) LFcnt=0;
	SC.FO.FileWrite(LL);
}

int InsertCheckXferWrite(FnameObj &INF,MyStr &LL,int &LFcnt,long llnn) {
	FnameObj XNF;
	MyStr LS,LE,X;
	DequCode R;
	int n;
	
//printf("\nInsertCheckXferWrite#LL=[%s]",(char*)LL);
	if(DequXfer(LL,INF,llnn,SC.EnDequXferCmt)<0) return -1;
//printf("\n=>DequXfer->LL=[%s]",(char*)LL);

	Dequ DQ;
	//*********************************************************
	//	inside #dequ check
	//*********************************************************
	PO2 pp=DQ.GetPointOfDequContents(LL);
//printf("\n=>pp.p1=%d pp.p2=%d",pp.p1,pp.p2);

	if(pp.p1>-1) {
		if(pp.p2>0) {
//printf("\nInsertCheckXferWrite#dequ detect>LL=[%s]",(char*)LL);
			R=DQ.IsWellContents(LL);
			if(R!=_well) {
//printf("\nDQ.IsWellContents(%s) err(%d)",(char*)LL,(int)R);
				sprintf(line,"!!! Error : file'%s'@line(%ld) %s <- %s",INF.GetFileName(),llnn,_DEQUKEY,GetDequErrMessage(R)); 
				SC.err=-1; SC.ErrMsg=line; return -1;
			}
//printf("\n#>DQ.Setup(%s)",(char*)LL);
			R=DQ.Setup(LL);
//printf(">LL=[%s] R=%d",(char*)LL,(int)R);
			if(R!=_well) {
				sprintf(line,"!!! Error : file'%s'@line(%ld) %s <- %s",INF.GetFileName(),llnn,_DEQUKEY,GetDequErrMessage(R)); 
				SC.err=-1; SC.ErrMsg=line; return -1;
			}
			R=SC.QDB.Add(DQ);
			if(R!=_well) {
//printf("\n#>SC.QDB.Add(DQ[%s])>R=%d",DQ.GetName(),(int)R);
				sprintf(line,"!!! Error : file'%s'@line(%ld) %s '%s' <- %s",INF.GetFileName(),llnn,_DEQUKEY,DQ.GetName(),GetDequErrMessage(R));
				SC.err=-1; SC.ErrMsg=line; return -1;
			}
			X=LL.GetTrim();
//printf("\n#>X=[%s],LL=[%s]",(char*)X,(char*)LL);
			if((int)X>0) {
				bool b=SC.EnDequXferCmt;
				SC.EnDequXferCmt=false;
				n=InsertCheckXferWrite(INF,LL,LFcnt,llnn);
				SC.EnDequXferCmt=b;
				if(n<0) return n;
			}
			return 0;
		}
		sprintf(line,"!!! Error : file'%s'@line(%ld)-> in-completed %s definition !",INF.GetFileName(),llnn,_DEQUKEY); 
		SC.err=-1; SC.ErrMsg=line; return -1;
	}
	//*********************************************************
	//	without #dequ
	//*********************************************************
	ArrayNameStr Exchg;
	MyStr LX=LL;
	GeneralExchgLineStr(LX,Exchg);
	PickupInsertFileName(X,LS,LE,LX);
	//====== w/o INSERT comment =============
	if((int)X<1) {
		n=MultiLine_ATL_CmpOptFilter(LL,INF,llnn);
//printf("\n#>MultiLine_ATL_CmpOptFilter(%s)>n=%d",(char*)LL,n);
		if(n<0) return n;
		if(n>0) SpCtlWrite(LL,LFcnt);
		return 0; 
	}
	//======	Insert statement detect  ======
	if((int)LS>0) { 
		LS=GetAllUnExchgStr(LS,Exchg); 
		n=MultiLine_ATL_CmpOptFilter(LS,INF,llnn);
		if(n<0) return n;
		if(n>0) SpCtlWrite(LS,LFcnt);
	}
	//----------------------------------------------------------------
	sprintf(line,"%s%s%s",INF.GetFilePath(),(char*)X,INF.GetFileAtt());
	XNF.NameSetByFullFileName(line);
	sprintf(line,";;;; insert(%s) %s\n",XNF.GetFileName(),(char*)LE);
	LE=line; LS=GetAllUnExchgStr(LE,Exchg); 
	SpCtlWrite((char*)LS,LFcnt);
	int s=0;	LX="";
	return FileXfer(XNF,s,LX,LFcnt);
}

PO2 GetPointOfEQUcontents(MyStr &LL) {
	P2.p1=-1; P2.p2=-1;
	ArrayNameStr ANS;
	MyStr FF,LX(LL);
	AddExchgLineCmtWithExSymBlk(LX,ANS);
	AddExchgLineMessage(LX,ANS);
	AddExchgSymChrCmtWithExSymBlk(LX,ANS);
	AddExchgSymBlkU(LX,ANS);
	//------------------------------------
	FF=LX.GetRangeWithWdChg('\t',' ');
	MyStr T("EQUATE ");
	int p=FF.InStr(T);
	if(p<0) return P2;					// w/o EQUATE
	P2.p1=p;
	if(p>0) { FF=LX.GetRangeByIdx(-1,p-1); FF=GetAllUnExchgStr(FF,ANS); P2.p1=(int)FF; }
	p=p+(int)T;
	FF=LX.GetRangeByIdx(p,-1);
	p=FF.InStr(P2.p1,'=');
	if(p<0) { P2.p1=-1; return P2; }	// w/o '=' (format err)
	FF=FF.GetRangeByIdx(p,-1);
	//-------------------------------------------------
	int n=FF.WdCntInStr('\"');
	if(n<1) { P2.p1=-1; return P2; }	// w/o '"' (format err)
	if((n%2)!=0) return P2;	// Not yet complete ! 
	//-------------------------------------------------
	p=LX.InStrRev('\"');
	FF=LX.GetRangeByIdx(-1,p-1);	FF=GetAllUnExchgStr(FF,ANS);
	P2.p2=(int)FF;
	return P2;
}

int FileXfer(FnameObj &INF,int &state,MyStr &FF,int &LFcnt) {
	FnameObj XNF;
	FileObj FI(INF,_read_mode);
	if(!FI.IsFileExist()) { 
		sprintf(line,"!!! Error : file '%s' not found !!!",FI.GetFullFileName());
		SC.err=-1; SC.ErrMsg=line; return -1;
	}
	
	//FI.SetBuffer(StrMaxLen);
	if(FI.FileOpen()!=_reading) { 
		sprintf(line,"!!! Error : Open '%s' for read fail !!!",FI.GetFullFileName()); 
		SC.err=-1; SC.ErrMsg=line; return -1;
	}

	MyStr SYMA(_DEQUSYMA);
	
	long llnn=0;
	MyStr LL,X,T,LX;
	MyStr LS,LE;
	
	Dequ DQ;
	DequCode r;
	ArrayNameStr Exchg;
	PO2 pp;
	int n;
		
	while(1) {
		
		if(SC.err!=0) break;
		if(FI.GetFileState()==_onclose) break;
		
		FI.FileRead(LL);
		llnn++;

		//if(SC.DisLineShow==false) out.prt("<%>[%]%",INF.GetFileName(),llnn,(char*)LL);
		if(SC.DisLineShow==false) printf("<%s>[%ld]%s",INF.GetFileName(),llnn,(char*)LL);

		LL=LL.GetDos2Unix();
		LX=LL; Exchg.Reset();
	
		GeneralExchgLineStr(LX,Exchg);
//printf("\n#FileXfer state<%d>,LX=\"%s\"",state,(char*)LX);

		if(state==0) {
			//************************************
			//*	Not during DEQU load
			//************************************
			n=ATL_CmpOptFilter(LL,INF,llnn);		//%IF* , %ENDC check
			if(n<0) break;
			if(n==0) continue;
			//===================================================
			pp=DQ.GetPointOfDequContents(LX);
			if(pp.p1<0) {
				pp=GetPointOfEQUcontents(LL);
				if(pp.p1>-1) {
					if(pp.p2<0) { state--; FF=LL; continue; } // EQUATE not yet complete
					n=EQUATE_Xfer(LL,INF,llnn);
					if(n<0) {
						sprintf(line,"!!! Error : file'%s'@line(%ld)-> bad EQUATE format !",INF.GetFileName(),llnn);
						SC.err=n; SC.ErrMsg=line; break;
					}
				}
				if(InsertCheckXferWrite(INF,LL,LFcnt,llnn)<0) break;
				FF=""; continue;
			} else {
				//=====================
				//	#dequ detect
				//=====================
				if(pp.p2<0) { state++; FF=LL; continue; }	// not yet complete
				r=DQ.IsWellContents(LL);
				if(r!=_well) {
					sprintf(line,"!!! Error : file'%s'@line(%ld) %s <- %s",INF.GetFileName(),llnn,_DEQUKEY,GetDequErrMessage(r)); 
					SC.err=-1; SC.ErrMsg=line; break;
				}
				r=DQ.Setup(LL);
				if(r!=_well) {
					sprintf(line,"!!! Error : file'%s'@line(%ld) %s <- %s",INF.GetFileName(),llnn,_DEQUKEY,GetDequErrMessage(r)); 
					SC.err=-1; SC.ErrMsg=line; break;
				}
				T=LL.GetTrim();
				if((int)T>0) { 
					if(InsertCheckXferWrite(INF,LL,LFcnt,llnn)<0) break;
				}
				r=SC.QDB.Add(DQ);
				if(r!=_well) {
					sprintf(line,"!!! Error : file'%s'@line(%ld) %s '%s' <- %s",INF.GetFileName(),llnn,_DEQUKEY,DQ.GetName(),GetDequErrMessage(r)); 
					SC.err=-1; SC.ErrMsg=line; break;
				}  
				FF=""; continue;
			}
		}
		if(state<0) {
			//************************************
			//*	During EQUATE load
			//************************************
			FF+=LL;
			pp=GetPointOfEQUcontents(FF);
			if(pp.p2<0) {
				state--;
				if((int)FF>50000 || state<-500 ) {
					sprintf(line,"!!! Error : file'%s'@line(%ld)-> EQUATE definition over size , stop !",INF.GetFileName(),llnn);
					SC.err=-1; SC.ErrMsg=line; break; 
				}
				continue;
			}
			n=EQUATE_Xfer(FF,INF,llnn);
			if(n<0) {
				sprintf(line,"!!! Error : file'%s'@line(%ld)-> bad EQUATE format !",INF.GetFileName(),llnn);
				SC.err=n; SC.ErrMsg=line; break;
			}
			if(InsertCheckXferWrite(INF,FF,LFcnt,llnn)<0) break;
			FF=""; state=0; continue;
		}
		if(state>0) {
			//************************************
			//*	During DEQU load
			//************************************
			FF+=LL;
//printf("<%d>FF=\"%s\"",state,(char*)FF);
			LX=FF; Exchg.Reset();
			GeneralExchgLineStr(LX,Exchg);
//printf("\nLX=\"%s\"",(char*)LX);
	
			PO2 pp=DQ.GetPointOfDequContents(LX);
//printf("\npp.p1=%d pp.p2=%d",pp.p1,pp.p2);
			if(pp.p2<0) {
				state++;
				if((int)FF>50000 || state>500 ) {
					sprintf(line,"!!! Error : file'%s'@line(%ld)-> %s over size , stop !",INF.GetFileName(),llnn,_DEQUKEY);
					SC.err=-1; SC.ErrMsg=line; break; 
				}
			    continue;
			} else {
//printf("\nDQ.IsWellContents(%s)",(char*)FF);
				r=DQ.IsWellContents(FF);
//printf(">err(%d)",(int)r);
				if(r!=_well) {
					sprintf(line,"!!! Error : file'%s'@line(%ld) %s <- %s",INF.GetFileName(),llnn,_DEQUKEY,GetDequErrMessage(r)); 
					SC.err=-1; SC.ErrMsg=line; break;
				}
//printf("\nDQ.Setup(%s)",(char*)FF);
				r=DQ.Setup(FF);
//printf(">err(%d)FF=[%s]",(int)r,(char*)FF);
				if(r!=_well) {
					sprintf(line,"!!! Error : file'%s'@line(%ld) %s <- %s",INF.GetFileName(),llnn,_DEQUKEY,GetDequErrMessage(r)); 
					SC.err=-1; SC.ErrMsg=line; break;
				}
				T=FF.GetTrim();
				if((int)T>0) { 
					if(InsertCheckXferWrite(INF,FF,LFcnt,llnn)<0) break;
				}
				r=SC.QDB.Add(DQ);
//printf("\nSC.QDB.Add(%s) err(%d)",(char*)DQ.GetName(),(int)r);
				if(r!=_well) {
					sprintf(line,"!!! Error : file'%s'@line(%ld) %s '%s' <- %s",INF.GetFileName(),llnn,_DEQUKEY,DQ.GetName(),GetDequErrMessage(r)); 
					SC.err=-1; SC.ErrMsg=line; break;
				}
				FF=""; state=0; continue;
			}
		}
	}
	
	if(SC.err!=0) return SC.err;	
	return 0;
}

void GetTimeStr(MyStr &RtnStr) {
	time_t now = time(0);
	tm *lt = localtime(&now);
	RtnStr=(1900+lt->tm_year);
	RtnStr+="/";
	RtnStr+=(1+lt->tm_mon);
	RtnStr+="/";
	RtnStr+=(lt->tm_mday);
	RtnStr+=" ";
	RtnStr+=(lt->tm_hour);
	RtnStr+=":";
	RtnStr+=(1+lt->tm_min);
	RtnStr+=":";
	RtnStr+=(1+lt->tm_sec);
}

int main (int ac , char ** av )
{
	//tout out;
	if(ac<2) { ShowInformation(); exit(-1); }

	SC.DisLineShow=false;		// Enable display <file>[LineNo]content
	SC.EnDequXferCmt=true;		// Enable Add comment line of command before xfer to output file
	SC.EnDequDBoutput=true;		// Enable to output macro DB file
	SC.MaxWriteDmyLineCnt=0;	// Output file Max dmy line cnt control setting value

	ArgAnalyzer(ac,av);
	//if(SC.err<0) { out.prt("\n\n%",(char*)SC.ErrMsg); usage(); exit(1); }
	if(SC.err<0) { printf("\n\n%s",(char*)SC.ErrMsg); usage(); exit(1); }

	if(SC.OPC.GetArrayCnt()>0) 	SC.ops.SetVal(1);	// option enable state for beginning
	else						SC.ops.SetVal(-1);	// none option checking

//printf("\nSC.INF FullFileName[%s]",SC.INF.GetFullFileName());
//printf("\n >FilePath[%s] FileName[%s] FileAtt[%s]",SC.INF.GetFilePath(),SC.INF.GetFileName(),SC.INF.GetFileAtt());
//printf("\n\nSC.ONF FullFileName[%s]",SC.ONF.GetFullFileName());
//printf("\n >FilePath[%s] FileName[%s] FileAtt[%s]",SC.ONF.GetFilePath(),SC.ONF.GetFileName(),SC.ONF.GetFileAtt());
//printf("\n\nSC.OPC ArrayCnt=[%d] List=[%s]",SC.OPC.GetArrayCnt(),SC.OPC.List());
//printf("\n\nSC.ops StackCnt=[%d] GetVal=[%d]",SC.ops.StackCnt(),SC.ops.GetVal());

	MyStr DateTime;
	GetTimeStr(DateTime);
			
	//out.prt("\n## Transfer '%' with INSERTed *% to '%' ##\n",SC.INF.GetFullFileName(),SC.INF.GetFileAtt(),SC.ONF.GetFullFileName());
	printf("\n## Transfer '%s' with INSERTed *%s to '%s' ##\n",SC.INF.GetFullFileName(),SC.INF.GetFileAtt(),SC.ONF.GetFullFileName());

	sprintf(line,"%s.dequ",SC.ONF.GetFullFileName());
	SC.QDB.SetDBfile(line);

	SC.FO.NameSetByFullFileName(SC.ONF.GetFullFileName()); SC.FO.SetFileMode(_write_mode);
	//if(SC.FO.FileOpen()!=_writing) { out.prt("!!! Error : Open '%' for write fail !!!",SC.FO.GetFullFileName()); return -1; }
	if(SC.FO.FileOpen()!=_writing) { printf("!!! Error : Open '%s' for write fail !!!",SC.FO.GetFullFileName()); return -1; }

	int state=0;
	int LFcnt=0;

	sprintf(line,";This file converted from %s %s by %s %s_%s\n",SC.INF.GetFileName(),(char*)DateTime,av[0],__SYS__,__ATLXferVer__);
	SpCtlWrite(line,LFcnt);
	
	MyStr DEQBUF;
	for(int n=0;n<ac;n++) { DEQBUF+=" "; DEQBUF+=av[n]; }		
	sprintf(line,";exec>%s\n",(char*)DEQBUF);
	SpCtlWrite(line,LFcnt);

	DEQBUF="";
	LFcnt=FileXfer(SC.INF,state,DEQBUF,LFcnt);
	if(LFcnt!=0) {
		//out.prt("\n\n%\n\n",(char*)SC.ErrMsg);
		printf("\n\n%s\n\n",(char*)SC.ErrMsg);
		SC.FO.FileWrite((char*)SC.ErrMsg);
	}
	SC.FO.FileClose();
	
	//if(LFcnt==0) out.prt("\n>> Transfer to '%' complete !\n",SC.FO.GetFullFileName());
	if(LFcnt==0) printf("\n>> Transfer to '%s' complete !\n",SC.FO.GetFullFileName());
	
	if(SC.EnDequDBoutput && SC.QDB.GetCNT()>0) {
		sprintf(line,"%s.s",SC.FO.GetFullFileName());
		SC.QDB.DB_foutput(line);
		//out.prt(">> Generated macro DB file '%'\n",line);
		printf(">> Generated macro DB file '%s'\n",line);
	}
	
	if(access(SC.QDB.GetDBfile(),F_OK)==0) {
#ifdef _DOS_
		sprintf(line,"del %s",SC.QDB.GetDBfile());
#else
		sprintf(line,"rm %s",SC.QDB.GetDBfile());
#endif
	    system(line);
	}

    exit(0);
}
