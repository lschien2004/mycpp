/*##############################################################################################
	v1.0@20191027	new version
	v1.1@20191028	+ IsFileExist(const char* fullfilename=NULL)
					+ FileOpen(void)
					+ AllocBuffer(void)
					+ ReleaseBuffer(void)
	v2.0@20191028	+FnameObj class
	                 +bool IsLegalFileName(const char *fullfilename==NULL)
	                 +bool NameSetByFullFileName(const char *fullfilename)
	                 +const char *GetFullFileName(void)
	                 +const char *GetFilePath(void)
	                 +const char *GetFileName(void),*GetFileAtt(void)
	                 +bool IsPathExist(const char *fullfilename=NULL)
	                 +bool IsPathForRead(const char *fullfilename=NULL)
	                 +bool IsPathForWrite(const char *fullfilename=NULL)
	                 +bool IsPathForRun(const char *fullfilename=NULL)
	                 +long GetFileSize(const char *fullfilename=NULL)
	                 +bool IsFileExist(const char *fullfilename=NULL)
	                 +bool IsFileForRead(const char *fullfilename=NULL)
	                 +bool IsFileForWrite(const char *fullfilename=NULL)
	                 +bool IsFileForRun(const char *fullfilename=NULL)
					FileObj inherits from FnameObj
					+ FileObj(FnameObj &Fname,FileMode m=_read_mode);
	v1.2@20191103	IsPathExist add stat(".\") check for stat() version problem
################################################################################################*/

#ifndef __FileObj__h__
    #define __FileObj__h__
    #define __FileObjVer__	"FileObj-v1.2@20191103"

#ifndef	_UNIX_
    #define _SymDir  '\\'		// default DOS file system
    #define _Illegal_FileNameChars	"*?<>()=&%$!@^`'\";[]{}|\t /"
#else
    #define _SymDir  '/'		// UNIX like file system
    #define _Illegal_FileNameChars	"*?<>()=&%$!@^`'\";[]{}|\t: \\"
#endif

#ifndef default_buffer_size
	#define default_buffer_size 256
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>    //printf
#include <stdlib.h>   //malloc
#include <string.h>   //strncpy
#include <unistd.h>   //close
#include <iostream>

#include "mystr.h"

//###################################################################

enum FileMode 		{_read_mode=0,_write_mode,_append_mode};
enum FileState 		{_onclose=0,_reading,_writing};
enum FileObjRetCode {_ok=0,_opErr,_cmdErr};

class FnameObj {
protected:
		MyStr			FilePath;
		MyStr			FileName;
		MyStr			FileAtt;
		
		MyStr			tmp;
public:		
		FnameObj(const char *fullfilename=NULL);
		FnameObj(MyStr &FFNAME);
		FnameObj(FnameObj &NF);
		
		bool			IsLegalFileName(const char *fullfilename=NULL);
		
		bool			NameSetByFullFileName(MyStr &FFNAME);
		bool			NameSetByFullFileName(const char *fullfilename);
		
		const char		*GetFullFileName(void);
		
		const char		*GetFilePath(void);
		const char		*GetFileName(void);
		const char		*GetFileAtt(void);
		
		long			GetFileSize(const char *fullfilename=NULL);
		
		bool			IsPathExist(const char *fullpath=NULL);
		bool			IsPathForRead(const char *fullfilename=NULL);
		bool			IsPathForWrite(const char *fullfilename=NULL);
		bool			IsPathForRun(const char *fullfilename=NULL);

		bool			IsFileExist(const char *fullfilename=NULL);
		bool			IsFileForRead(const char *fullfilename=NULL);
		bool			IsFileForWrite(const char *fullfilename=NULL);
		bool			IsFileForRun(const char *fullfilename=NULL);
};

class FileObj : public FnameObj {
private:
		int 	bsize;
		char 	*buff;

protected:
		FileMode		mode;
		FileState		state;
		FILE 			*fp;

		FileObjRetCode	AllocBuffer(void);
		void 			ReleaseBuffer(void);
public:
		FileObj(const char *fullfilename=NULL,FileMode m=_read_mode);
		FileObj(MyStr &FFNAME,FileMode m=_read_mode);
		FileObj(FnameObj &Fname,FileMode m=_read_mode);

		~FileObj();

		FileObjRetCode	SetBuffer(const int nsize=default_buffer_size);

		FileObjRetCode	SetFileMode(FileMode m);

		FileMode		GetFileMode(void);
		FileState		GetFileState(void);
		int				GetBufferSize(void);

		FileState		FileOpen(void);
		FileState		FileOpen(FileMode m);
		
		FileState		FileRead(MyStr &RtnStr);
		
		FileState		FileWrite(const char *s);
		FileState		FileWrite(MyStr &OutStr);
		
		FileState		FileClose(void);
};

#endif

		