/*##############################################################################################
	v1.0@20191027	new version
################################################################################################*/

#ifndef __FileObj__h__
    #define __FileObj__h__
    #define __FileObjVer__	"FileObj-v1.0@20191027"

#ifndef	_UNIX_
    #define _SymDir  '\\'		// default DOS file system
#else
    #define _SymDir  '/'		// UNIX like file system
#endif

#ifndef default_buffer_size
	#define default_buffer_size 130
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>    //printf
#include <stdlib.h>   //malloc
#include <string.h>   //strncpy
#include <unistd.h>   //close
#include <iostream>

#include "mystr.h"

//###################################################################

enum FileMode 		{_read_mode=0,_write_mode,_append_mode};
enum FileState 		{_onclose=0,_reading,_writing};
enum FileObjRetCode {_ok=0,_opErr,_cmdErr};

class FileObj {
private:
		int 	bsize;
		char 	*buff;

protected:
		FileMode		mode;
		FileState		state;
		FILE 			*fp;

		MyStr			FilePath;
		MyStr			FileName;
		MyStr			FileAtt;

		MyStr			tmp;
public:
		FileObj(const char *fullfilename=NULL,FileMode m=_read_mode);
		~FileObj();

		FileObjRetCode	SetBuffer(const int nsize=default_buffer_size);
		FileObjRetCode	NameSetByFullFileName(const char *fullfilename);
		
		const char		*GetFullFileName(void);
		const char		*GetFileName(void);
		const char		*GetFilePath(void);
		const char		*GetFileAtt(void);

		FileObjRetCode	SetFileMode(FileMode m);

		FileMode		GetFileMode(void);
		FileState		GetFileState(void);
		int				GetBufferSize(void);

		FileState		FileOpen(FileMode m);
		FileState		FileRead(MyStr &RtnStr);
		FileState		FileWrite(MyStr &OutStr);
		FileState		FileClose(void);
};

#endif


		