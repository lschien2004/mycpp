/* ###################################################################################################
	Ver.1.1   : (1) Xfer�� parameter TrimR+TrimL (except DEQUSYMS+DEQUSYMX)
	Ver.1.1   : (2) Xfer�� parameter �� SymX+data+SymX�� data ���B�z, ��SymX�h���ᵹBody�Axfer.(Symx='%)
	Ver.1.1   : (3) Xfer�O�d @x comment
	Ver.1.1   : (4) output file ��X ;@> + xfer�e�쫬 .
	Ver.1.1   : (5) Xfer��parameter �i�H��J dequ ���� ex. Titem<10,"FUNC 1",ClearArray<FDUT>,FUNSUB>
	
	Ver.1.2   : (1) Xfer��Parameter�ϥ� macro1<,macro2<>> �_����J���D�ѨM
	Ver.1.2   : (2) Xfer��Parameter�ϥΪ�macro�L�Ѽƥi�٥h<>. (FunPon<>��i�H��FunPon) 
	Ver.1.2   : (3) DEQU_DB v1.2 DEQU add �� FIFO �令 LIFO & DEQU body�a�JSeqN search,�᭱�P�W macro�u��.
	Ver.1.2   : (4) Xfer��Parameter�ϥ� SymX �_���p 'pon<TIM1,3MS,`IN1,IN2`>' ���D�ѨM
	Ver.1.2   : (5) output DEQU macro DB file �令 macro�쫬��X-> ODIR\m+ifile
	
	Ver.1.3   : (1) Fix Macro name including the other short macro name issue
	Ver.1.3   : (2) accept non-parameter macro definition without <> 
  ################################################################################################### */

#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>    //printf
#include <stdlib.h>   //malloc
#include <string.h>   //strncpy
#include <unistd.h>   //close
#include <iostream>
#include <ctime>

#define _DOS_

#include "mystr.h"
#include "mystd.h"
#include "fileobj.h"
#include "dequ.h"

#define __PgmVer__ "ATLxfer-v1.4@20191016"
#define __Author__ "L.S Chien"

#ifdef _DOS_
	#define __SYS__ "DOS"
    #define SymPath  '\\'
#else
	#define __SYS__ "UNIX"
    #define SymPath  '/'
#endif

#define FileInsertStatement "INSERT"

#define StrMaxLen 256

using namespace std;

void usage(char *pgmname)
{
	tout out;
	out.prt("\n##################################################################");
	out.prt("\n[[[ ATL PreXfer % % By % ]]]",__SYS__, __PgmVer__,__Author__);
	out.prt("\n Related lib :");
	out.prt("\n   %\t\t%",__MyStdVer__,__FileObjVer__);
	out.prt("\n   %\t\t%",__MyStrVer__,_dequVer_);
	out.prt("\n==================================================================");
	out.prt("\n     This tool is used to covert the source files which writed with");
	out.prt("\n% macro to a .asc file for ADV tester's compiler .\n",DEQUKEY);
	out.prt("\n Usage : %  main_src_file  [output_path]",pgmname);
	out.prt("\n       >> w/o output_path -> output in current path .\n");
	out.prt("\n    Ex : % wtmain.src ASCDIR",pgmname);
	out.prt("\n       >> Transfer wtmain.src to ASCDIR%wtmain.asc",SymPath);
	out.prt("\n    Ex : % ..%wtmain.src",pgmname,SymPath);
	out.prt("\n       >> Transfer ..%wtmain.src to .%wtmain.asc\n",SymPath,SymPath);
	out.prt("\n Note :");
	out.prt("\n     1) All of inserted files must be lower-case file name !");
	out.prt("\n     2) main_src_file and all of inserted files must be stored in");
	out.prt("\n        the same path !");
	out.prt("\n     3) All of inserted files' att_name must as same as the att_name");
	out.prt("\n        of main_src_file !");
	out.prt("\n        Ex: main_src_file is main.s , the insertd files must be *.s");
	out.prt("\n     4) If main_src_file's att_name is .asc and output_path is same");
	out.prt("\n        as main_src_file's path, then output file's att_name will");
	out.prt("\n        change to be .asc2)");
	out.prt("\n==================================================================");
	out.prt("\n  Regarding % marco :",DEQUKEY);
	out.prt("\n     1) If % macro are re-defined, the last loaded macro",DEQUKEY);
	out.prt("\n        before transfer will dominate !");
	out.prt("\n     2) Name of % macro must exist at the least one lower-case",DEQUKEY);
	out.prt("\n        char .");
	out.prt("\n##################################################################\n");
}

bool CheckDeclareStatmentInside(const char *line) {
	MyStr LL(line);
	LL=LL.GetDos2Unix();
	LL=LL.GetRangeWithDelBtwKeyExSymBlk(";","\n","\"?");
	LL=LL.GetRangeWithWdChgExSymBlk(";\n","\n","\"?");
	LL=LL.GetLineWithCmtChrDelNExSymBlk('@',1,"\"?");	
	LL=LL.GetLineTrim();
	LL=LL.GetRangeWithWdCmpressExSymBlk("\n","\"?");
	
	LL=LL.GetRangeWithSpDelExSymBlk("\"?");
	
	if(LL.InStr(DEQUKEY)==0) return true;
	if(LL.InStr("EQUAT")==0) return true;
	if(LL.InStr("DMACRO")==0) return true;
	if(LL.InStr("SDEF")==0) return true;
	if(LL.InStr("MODULE")==0) return true;
	return false;
}

void PickupInsertFileName(MyStr &LL,const char *line) {
	LL=line;
	LL=LL.GetRangeWithWdChg('\t',' ');
	LL=LL.GetRangeWithDelByKey(DEQULCMT,'\n');
	LL=LL.GetLineWithCmtChrDelN('@',1);
	LL=LL.GetRangeBtwKey(FileInsertStatement,"");
	LL=LL.GetRangeWithWdDel('\n');
	LL=LL.GetLineTrimA();
	LL=LL.GetLowerCase();
}

int FileXfer(DEQU_DB &QDB,MyStr &IDIR,MyStr &ifile,MyStr &iatt,FILE *ofp,int &state,MyStr &FF,int &LFn) {
	tout out;
	char line[StrMaxLen];
//FileObjRetCode fr;
//FileState fs;	
	//FILE *ifp;
	//sprintf(line,"%s%s",(char*)IDIR,(char*)ifile);
	
	FileObj FI(IDIR+ifile);
//out.prt("\n% mode=% state=% size=%",FI.GetFullFileName(),(int)FI.GetFileMode(),(int)FI.GetFileState(),FI.GetBufferSize());
	FI.SetBuffer(StrMaxLen);
//out.prt("\nFI.GetBufferSize=%",FI.GetBufferSize());
	if(FI.FileOpen(_read_mode)!=_reading) {
		out.prt("\n\n Error ! Open '%' for read fail !\n\n",FI.GetFullFileName());
		return -1;
	}

	MyStr SYMA(DEQUSYMS);
	SYMA+=DEQUSYMX;
	
	long llnn=0;
	MyStr ErrMsg;
	MyStr LL,X,T,LX;
	DEQU QQ;
	
	while(1) {
		if(FI.GetFileState()==_onclose) break;
		FI.FileRead(LL);
		//if(fgets(line,StrMaxLen-1,ifp)==NULL) break;
		llnn++;
		//LL=line;
		LL=LL.GetDos2Unix();
		LX=LL.GetLineDelByKey(DEQULCMT,'\n');
		if(state<1) {
			//************************************
			//*	Not during DEQU load
			//************************************
			//if(LL.InStr(DEQUKEY)>-1) {
			if(LX.InStr(DEQUKEY)>-1) {
				//***  DEQU definition detect ****
				state++; FF=LL;
				if(LL.InStr(DEQUBDYED)>-1) {
					//***  one line finish ***
					state=0;
					QQ=FF;
					QDB.Add(QQ);
				}
			} else {
			    //if(LL.InStr(FileInsertStatement)<0) {
				if(LX.InStr(FileInsertStatement)<0) {
					T=QDB.DEQU_Inside((char*)LL);
					if(T!="") {
						fprintf(ofp,";@>%s",(char*)LL);
						T=QDB.DEQU_xfer((char*)LL);
						//T=T.GetLineTrimRExSymBlk((char*)SYMA);
						T=T.GetRangeWithWdCmpressExSymBlk('\n',(char*)SYMA);
						//T=T.GetRangeWithSpCmpressExSymBlk((char*)SYMA);
						LL=T;
					}
					//-----------------------------------------
					T=LL.GetTrimA();
					if(T=="") {
						if(++LFn>1) { LFn=1; continue; }
					} else if(--LFn<0) LFn=0;
					//-----------------------------------------
					fprintf(ofp,"%s",(char*)LL);
				} else {
					//***	Insert statement detect  ***
					PickupInsertFileName(X,(char*)LL);
					X+=iatt;
					fprintf(ofp,";;;; insert(%s)\n",(char*)X);
					if(FileXfer(QDB,IDIR,X,iatt,ofp,state,FF,LFn)<0) {
						sprintf(line,"\n Error ! file'%s'@line(%d)->%s , stop !\n",(const char*)ifile,llnn,(char*)LL);
						ErrMsg=line; break; 
					}
				}
			}
		} else {
			//************************************
			//*	During DEQU load
			//************************************
			//if(LL.InStr(FileInsertStatement)<0) {
			if(LX.InStr(FileInsertStatement)<0) {
				if(LL.InStr(DEQUBDYED)<0) {
					state++;
					if(state>1000 || CheckDeclareStatmentInside((char*)LL)) {
						sprintf(line,"\n Error ! file'%s'@line(%d)->%s macro ending '}}' missing ,stop !\n",(const char*)ifile,llnn,DEQUKEY);
						ErrMsg=line; break; 
					}
					FF+=LL;
				} else {
					FF+=LL;
					state=0;
					QQ=FF;
					QDB.Add(QQ);
				}
			} else {
				//***	Insert statement detect  ***
				PickupInsertFileName(X,(char*)LL);
				X+=iatt;
				fprintf(ofp,";;;; insert(%s)\n",(char*)X);
				if(FileXfer(QDB,IDIR,X,iatt,ofp,state,FF,LFn)<0) {
						sprintf(line,"\n Error ! file'%s'@line(%d)->%s , stop !\n",(const char*)ifile,llnn,(char*)LL);
						ErrMsg=line; break; 
				}
			}
		}
	}
	//fclose(ifp);
	
	if((int)ErrMsg>0) { 
		out << (char*) ErrMsg;
		fprintf(ofp,"%s",(char*)ErrMsg);
		return -1;
	}
	return 0;
}

int main (int ac , char ** av )
{
	if(ac<2 || ac>3) { usage(av[0]); exit(-1); }

	time_t now = time(0);
	tm *lt = localtime(&now);
	MyStr DateTime;
	DateTime=(1900+lt->tm_year);
	DateTime+="/";
	DateTime+=(1+lt->tm_mon);
	DateTime+="/";
	DateTime+=(lt->tm_mday);
	DateTime+=" ";
	DateTime+=(1+lt->tm_hour);
	DateTime+=":";
	DateTime+=(1+lt->tm_min);
	DateTime+=":";
	DateTime+=(1+lt->tm_sec);
		
	char line[StrMaxLen];	
	MyStr ifile,ofile;
	MyStr iatt,oatt;
	MyStr IDIR(av[1]);
	MyStr ODIR('.');
	
	int n=IDIR.InStrRev(SymPath);
	if(n<0) { ifile=IDIR; IDIR='.'; IDIR+=SymPath; }
	else	{ ifile=IDIR.GetRangeByIdx(n+1,-1); IDIR=IDIR.GetRangeByIdx(-1,n); }
	
	n=ifile.InStrRev('.');
	if(n>-1) iatt=ifile.GetRangeByIdx(n,-1);
	ofile=ifile.GetRangeByIdx(-1,n);
	if(n<0) ofile+=".asc"; else ofile+="asc";

	if(ac>2) ODIR=av[2];
	n=ODIR.InStrRev(SymPath);
	if((int)ODIR!=n+1) ODIR+=SymPath;

	if(ifile==ofile && IDIR==ODIR) ofile+="2";
	
	printf("\n## Transfer '%s%s' with INSERTed *%s to '%s%s' ##",(char*)IDIR,(char*)ifile,(char*)iatt,(char*)ODIR,(char*)ofile);

	sprintf(line,"%s%s.dequ",(char*)ODIR,(char*)ifile);
	DEQU_DB QDB(line);

	sprintf(line,"%s%s",(char*)ODIR,(char*)ofile);

	FILE *ofp;

	if((ofp=fopen(line,"w"))==NULL) {
		cout << endl << "\n Error ! Open '" << (char*)line << "' for write fail !\n" << endl;
		exit(1);
	}

	fprintf(ofp,";This file converted from %s %s by %s %s_%s\n",(char*)ifile,(char*)DateTime,av[0],__SYS__,__PgmVer__);

	int state=0;
	int LFn=0;
	MyStr DEQBUF;
	LFn=FileXfer(QDB,IDIR,ifile,iatt,ofp,state,DEQBUF,LFn);
	fclose(ofp);
	
	if(LFn==0) 	printf("\n>> Transfer to '%s' complete !",line);

	sprintf(line,"%s%s.s",(char*)ODIR,(char*)ifile);
	QDB.DB_foutput(line);
	printf("\n>> Generated macro DB file '%s'\n",line);
	
	if(access(QDB.GetDBfile(),F_OK)==0) {
#ifdef _DOS_
		sprintf(line,"del %s",QDB.GetDBfile());
#else
		sprintf(line,"rm %s",QDB.GetDBfile());
#endif
	    system(line);
	}

    exit(0);
}
