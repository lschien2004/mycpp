#include "fileobj.h"

//====================================================================================
FileObj::FileObj(const char *fullfilename,FileMode m) {
	buff=NULL;	bsize=-1;	
	mode=m;	state=_onclose;
	NameSetByFullFileName(fullfilename);
	//SetBuffer();
}
FileObj::~FileObj() { 
	if(fp!=NULL) fclose(fp);
	if(buff!=NULL) delete [] buff;
}
//====================================================================================
FileMode 	FileObj::GetFileMode(void)	{ return mode; }
FileState 	FileObj::GetFileState(void)	{ return state; }

//====================================================================================
const char* FileObj::GetFullFileName(void)	{ 
	tmp=FileName;
	if((int)FilePath>0) {
		if(FilePath[(int)FilePath-1]!=_SymDir) 	{ tmp=FilePath+_SymDir; tmp+=FileName; }
		else									tmp=FilePath+FileName;
	}
	return (char*)tmp;
}
const char* FileObj::GetFileName(void)	{ return (const char*) FileName; }
const char* FileObj::GetFilePath(void)	{ return (const char*) FilePath; }
const char* FileObj::GetFileAtt(void)	{ return (const char*) FileAtt; }

int FileObj::GetBufferSize(void) { return bsize; }
//====================================================================================
FileObjRetCode FileObj::NameSetByFullFileName(const char *fullfilename) {
	FilePath=""; FileAtt="";
	FileName=fullfilename;
#ifndef _UNIX_
	FileName=FileName.GetLowerCase();
#endif
	FileName=FileName.GetTrim();
	int flen=(int)FileName;
	if(flen<1) return _cmdErr;

	int p=FileName.InStrRev(_SymDir);
	if(p>0 && (flen-1-p)>0) {
		FilePath=FileName.GetRangeByIdx(-1,p);
		FileName=FileName.GetRangeByIdx(p+1,-1);
		flen=(int)FileName;
	}
	p=FileName.InStrRev('.');
	if(p>0) FileAtt=FileName.GetRangeByIdx(p,-1);

	return _ok;
}
//====================================================================================
FileObjRetCode FileObj::SetBuffer(const int nsize) {
	int n=default_buffer_size;
	if(n<nsize) n=nsize;
	if(buff!=NULL) {
		if(bsize!=n) delete [] buff;
	}
	bsize=n;
	buff=new char[bsize];
	if(buff==NULL) 	{ bsize=-1; return _opErr; }
	return _ok;
}
//====================================================================================
FileObjRetCode FileObj::SetFileMode(FileMode m) {
	if(m!=mode) {
		if(state!=_onclose) return _cmdErr;
		mode=m;
	}
	return _ok;
}
//====================================================================================
FileState FileObj::FileOpen(FileMode m) {
	if(SetFileMode(m)!=_ok) return state;
	if(state==_onclose) {
		MyStr F(GetFullFileName());
		//------------------------------------------------	
		switch (mode){
			case _read_mode :
				fp=fopen((char*)F,"r");	state=_reading;	break;
			case _write_mode :
				fp=fopen((char*)F,"w");	state=_writing;	break;
			case _append_mode:
				fp=fopen((char*)F,"a");	state=_writing;	break;
			default:									break;
		}
		//------------------------------------------------	
		if(fp==NULL) state=_onclose;
		//------------------------------------------------	
	}
	return state;
}
//====================================================================================
FileState FileObj::FileRead(MyStr &RtnStr) {
	RtnStr="";
	if(state==_reading) {
		if(buff==NULL) { if(SetBuffer()!=_ok) return FileClose(); }
		if(fgets(buff,bsize,fp)==NULL) return FileClose();
		RtnStr=buff; 
	}
	return state;
}
//====================================================================================
FileState FileObj::FileWrite(MyStr &OutStr) {
	if(mode!=_read_mode || state!=_writing) fprintf(fp,"%s",(char*)OutStr);
	return state;
}
//====================================================================================
FileState FileObj::FileObj::FileClose(void) { fclose(fp); state=_onclose; return state; }
