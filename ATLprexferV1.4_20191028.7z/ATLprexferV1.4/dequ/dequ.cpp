#include "dequ.h"

void ReleaseDSLINK(DSLINK **p) {
//printf("\nReleaseDSLINK(*p=%u)",*p);
	while(*p!=NULL) { 
//printf("..*p=%u",*p);
		DSLINK *t=*p;
		*p=(*p)->nxt;
		delete t;
	}
//printf("..Last *p=%u",*p);
}

DEQU::DEQU() { PARN=0; NAME=""; BODY=""; Para=NULL; }
DEQU::DEQU(MyStr &S) { PARN=0; Para=NULL; Setup((const char*)S); }
DEQU::DEQU(const char *s) { PARN=0; Para=NULL; Setup(s); }
DEQU::~DEQU(void) { ReleaseDSLINK(&Para); PARN=0; }

const char *DEQU::GetTrimDEQU(const char *dequstr)
{
	int klen=strlen(DEQUKEY);
	int minlen = klen+5;
	MyStr T(dequstr);
	MyStr S,X;
	if((int)T<minlen) { TMP=""; return (const char*)TMP; }

	T=T.GetLineDelBtwKeyExSymBlk(DEQUBDYED,"",DEQUSYMS);
	//T=T.GetLineWithCmtChrDelNExSymBlk(DEQUCMTC,1,DEQUSYMS);
	T=T.GetLineDelByKey(DEQULCMT,"");
	T=T.GetRangeWithWdChgExSymBlk("\n\n","\n",DEQUSYMS);
	//T=T.GetRangeWithSpCmpressExSymBlk(DEQUSYMS);
	//T=T.GetLineTrimExSymBlk(DEQUSYMS);	
	T=T.GetLineTrimRExSymBlk(DEQUSYMS);
	int epa=T.InStr(DEQUBDYST)-1;

	S=DEQUKEY; S+=' ';
	if(T.InStr((char*)S)>-1 && epa>0) {
		S=T.GetRangeByIdx(-1,epa-1);
		S=S.GetTrim();
		if(S.InStr(DEQUPARST)<0 && S.InStr(DEQUPARED)<0) { S+=DEQUPARST; S+=DEQUPARED; }
		T=S+T.GetRangeByIdx(epa,-1);
		epa=T.InStr(DEQUBDYST)-1;
		S=S.GetRangeBtwKey(DEQUKEY,DEQUPARST);
		S=S.GetTrim();
		
		if((int)S>0 && epa>-1) {
			TMP=DEQUKEY;
			TMP+=' ';
			TMP+=S;
			
			int p=T.InStr(klen,epa,DEQUPARST);
			int q=T.InStrRev(klen,epa,DEQUPARED);

			if(p>-1 && q>p) {
				//=============================
				// parameters of #dequ declare
				//=============================
				S=T.GetRangeByIdx(p,q);
				S=S.GetLineTrimAExSymBlk(DEQUSYMS);
				TMP+=S;
				//=============================
				// Body of #dequ declare
				//=============================
				p=T.InStr(q,DEQUBDYST);
				//q=T.InStr(q,DEQUBDYED);
				q=T.InStrRev(q,DEQUBDYED);
				if(p>-1 && q>p) {
					S=T.GetRangeByIdx(p+strlen(DEQUBDYST),q-1);
					S=S.GetLineDelByKeyExSymBlk(DEQULCMT,"",DEQUSYMS);
					//S=S.GetLineTrimR();
					TMP+=DEQUBDYST;
					TMP+=S;
					TMP+=DEQUBDYED;
					return (const char*)TMP;
				}
			}
		}
	}
	TMP="";
	return (const char*)TMP;
}

void DEQU::Setup(const char *s) {
//printf("\nPara=%u",Para);
	ReleaseDSLINK(&Para);  PARN=0;
//printf("->ReleaseDSLINK->Para=%u",Para);
	MyStr S(GetTrimDEQU(s));
	BODY="";
	NAME=GetNameFromTrimDEQU((char*)S);
	if(NAME.LowerCaseInside()<1) NAME="";
	if(NAME!="") {
		BODY=GetBodyFromTrimDEQU((char*)S);
		BODY=BODY.GetRangeWithWdCmpress('\n');
		MyStr PA(GetParaFromTrimDEQU((char*)S));
//printf("\nPA='%s'",(char*)PA);
		DSLINK *dp;
		if((int)PA>0) {
			PA+=',';
			int k=0;
			int p=PA.InStr(k,-1,',');
//printf(" -> k=%d p=%d",k,p);
			while(p>-1) {
				PARN++;
				DSLINK *nd=new DSLINK[1];
				if(p>k) nd->data=PA.GetRangeByIdx(k,p-1);
				else	nd->data=PARN;
//printf("\nPARN=%d nd->data='%s'",PARN,(char*)nd->data);

				//===============================
				MyStr T(DEQUBDYVPAST);
				T+=nd->data;
				T+=DEQUBDYVPAED;
				MyStr N(DEQUBDYVPAST);
				N+=PARN;
				N+=DEQUBDYVPAED;
				BODY=BODY.GetRangeWithWdChg((char*)T,(char*)N);
				//===============================
				nd->nxt=NULL;
				if(Para==NULL) 	Para=nd;
				else			dp->nxt=nd;
				dp=nd;
				k=p+1;
				p=PA.InStr(k,-1,',');;
			}
		} 
	}
}

const char *DEQU::GetNameFromTrimDEQU(const char *trimdequ) 
{
	MyStr S(trimdequ);
	TMP=S;
	if((int)S<1) return (char *)TMP;
	TMP=TMP.GetRangeBtwKey(DEQUKEY,DEQUPARST);
	TMP=TMP.GetTrim();
	return (char*)TMP;
}
const char *DEQU::GetBodyFromTrimDEQU(const char *trimdequ) 
{
	MyStr S(trimdequ);
	TMP=S;
	if((int)TMP<1) return (const char *)TMP;
	TMP=TMP.GetRangeBtwKey(DEQUBDYST,DEQUBDYED);
//	TMP=TMP.GetTrim();
//	TMP=TMP.GetLineTrim();
	return (const char*)TMP;
}
const char *DEQU::GetParaFromTrimDEQU(const char *trimdequ) 
{
	MyStr S(trimdequ);
	TMP=S;
	if((int)TMP<1) return (const char *)TMP;
	TMP=TMP.GetRangeBtwKey(DEQUPARST,DEQUPARED);
//	TMP=TMP.GetLineTrimA();
	return (const char*)TMP;
}

const char *DEQU::GetName(void) { return (const char*)NAME; }
const char *DEQU::GetBody(void) { return (const char*)BODY; }
int  		DEQU::GetParN(void) { return PARN; }
const char *DEQU::GetPara(void) {
	MyStr S("");
	int n=0;
	DSLINK *dp=Para;
	while(dp!=NULL) {
		if(n>0) S+=','; 
		S+=dp->data;
		dp=dp->nxt;
		n++;
	}
	TMP=S;
	return (const char*)TMP;
}

DEQU& DEQU::operator=(const char *s) {ReleaseDSLINK(&Para); PARN=0; Setup(s); return *this; }
DEQU& DEQU::operator=(MyStr &S) { ReleaseDSLINK(&Para); PARN=0; Setup((const char*)S); return *this; }
bool DEQU::operator==(const char *name) { return NAME==name; }
bool DEQU::operator==(MyStr &S) { return NAME==S; }
bool DEQU::operator!=(const char *name) { if(NAME==name) return false; else return true; }
bool DEQU::operator!=(MyStr &S) { if(NAME==S) return false; else return true; }

//####################################################################
//#		DEQU_DB
//####################################################################
DEQU_DB::DEQU_DB(const char *dbfname) { DBfile=dbfname; CNT=0; DBP=NULL; }
DEQU_DB::DEQU_DB(const char *dbfname,DEQU& DD) { DBfile=dbfname; CNT=0; DBP=NULL; Add(DD); }
DEQU_DB::~DEQU_DB() { ReleaseDBP(); }

//===================================================
int DEQU_DB::GetCNT(void) {return CNT; }
const char* DEQU_DB::GetDBfile(void) {return (char*)DBfile; }

//===================================================
void DEQU_DB::ReleaseDBP(void) {
	while(DBP!=NULL) {
		DQLINK *tp=DBP;
		DBP=DBP->nxt;
		delete tp;
		CNT--;
	}
}
//===================================================
int DEQU_DB::Add(DEQU& DD) {
//printf("\nDEQU_DB::Add('%s')",DD.GetName());
//printf("PARN=%d Para='%s')",DD.GetParN(),DD.GetPara());
	if(DD.GetName()=="") { printf("\n Warning ! request DEQU_DB.Add(NULL) !\n"); return 0; }
	
	CNT++;
	DQLINK *dp = new DQLINK;
	dp->SN=CNT;
	dp->NAME=DD.GetName();
	dp->PARN=DD.GetParN();
	dp->nxt=NULL;
	if(DBP==NULL) DBP=dp;
	else {
		//******** FIFO *********		
		//DQLINK *tp=DBP;
		//while(tp->nxt!=NULL) tp=tp->nxt;
		//tp->nxt=dp;
		//******** LIFO *********
		dp->nxt=DBP;
		DBP=dp;
	}
	
	MyStr T;
	if(CNT==1) 	T="w";
    else 		T="a";
    
    FILE *fp=fopen((char*)DBfile,(char*)T);
	if(fp==NULL) {
		printf("\n Error ! Open '%s' for write(%s) fail !\n",(char*)DBfile,(char*)T);
		return -1;
	}
	//---------------------------------------------
	//	File write new DEQU macro
	//---------------------------------------------
	int mxlen=DEQU_DB_MaxLineLen;
	MyStr B(DD.GetBody());
	B=B.GetRangeWithWdChg("\n","\\n");
	int l=(int)B;
	int n=0;
	while(l>mxlen) { n++; l-=mxlen;}
	if(l>0) n++;
	fprintf(fp,"_{%s}_(%d)_[%d]_<%s>_@%s@_$%d$_\n",(char*)DBP->NAME,DBP->PARN,n,DD.GetPara(),_dequFmtVer_,DBP->SN);
	for(l=1;l<n;l++) fprintf(fp,"%s\n",B.GetRangeByIdx((l-1)*mxlen,(l-1)*mxlen+mxlen-1));
	fprintf(fp,"%s\n",B.GetRangeByIdx((n-1)*mxlen,-1));
	//---------------------------------------------
	fclose(fp);
	return CNT;
}
//===================================================
int DEQU_DB::GetDEQUSeqN(const char *dequname) {
	MyStr DQ(dequname);
	if(CNT>0 || (int)DQ>0) {
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			if(dp->NAME==DQ) return dp->SN;
			dp=dp->nxt;
		}
	}
	return -1;
}
//===================================================
int DEQU_DB::SearchDEQUparN(const char *dequname) {
	MyStr DQ(dequname);
	if(CNT>0 || (int)DQ>0) {
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			if(dp->NAME==DQ) return dp->PARN;
			dp=dp->nxt;
		}
	}
	return -1;
}
//===================================================
const char*  DEQU_DB::GetDEQUnameByDBIdx(const int si) {
	TMP="";
	if(CNT>0 && si>-1 && si<CNT) {
		int n=-1;
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			n++;
			if(n==si) { TMP=dp->NAME; break; }
			dp=dp->nxt;
		}
	}
	return (char*)TMP;
}
//===================================================
const char* DEQU_DB::DEQU_Inside(const char *line) {
	TMP="";
	MyStr LL(line);
	LL=LL.GetLineDelByKeyExSymBlk(DEQULCMT,"",DEQUSYMS);
	int n=-1;
	int l=-1;
	
	if(CNT>0 || (int)LL>0) {
		DQLINK *dp=DBP;
		while(dp!=NULL) {
			int p=LL.InStr((char*)dp->NAME);
			int x=(int)dp->NAME;
			if(p>-1) {
				if(n<0 || p<n || (p==n && x>l) ) { n=p; TMP=dp->NAME; l=x; }
			}
			dp=dp->nxt;
		}
	}
	return (char*)TMP;
}
//===================================================
const char *DEQU_DB::GetDEQUdefParaInDB(const char *dequname) {
	TMP="";
	int sq=GetDEQUSeqN(dequname);
	if(sq<1) return (char*)TMP;
	FILE *fp;
	char line[DEQU_DB_MaxLineLen+5];
	if((fp=fopen((char*)DBfile,"r"))==NULL) {
		printf("\n Error ! Open '%s' for read fail !\n",(char*)DBfile);
		return (char*)TMP;
	}
	MyStr DQ("_{");
	DQ+=dequname;
	DQ+="}_";
	while(1) {
		if(fgets(line,DEQU_DB_MaxLineLen+2,fp)==NULL) break;
		MyStr LL(line);
		int s=atoi(LL.GetRangeBtwKey("_$","$_"));
		if(LL.InStr((char*)DQ)>-1 && s==sq) { TMP=LL.GetRangeBtwKey("_<",">_"); break; }
	}
	fclose(fp);
	return (char*)TMP;
}
//===================================================
const char *DEQU_DB::GetDEQUbodyInDB(const char *dequname) {
	TMP="";
	int sq=GetDEQUSeqN(dequname);
//printf("\ndequname[%s],Seq[%d]",dequname,sq);
	if(sq<1) return (char*)TMP;
	FILE *fp;
	char line[DEQU_DB_MaxLineLen+5];
	if((fp=fopen((char*)DBfile,"r"))==NULL) {
		printf("\n Error ! Open '%s' for read fail !\n",(char*)DBfile);
		return (char*)TMP;
	}
	MyStr DQ("_{");
	DQ+=dequname;
	DQ+="}_";
	while(1) {
		if(fgets(line,DEQU_DB_MaxLineLen+2,fp)==NULL) { fclose(fp); break; }
		MyStr LL(line);
		int s=atoi(LL.GetRangeBtwKey("_$","$_"));
//printf("\nLL[%s],s[%d]",(char*)LL,s);
		if(LL.InStr((char*)DQ)>-1 && s==sq) {
//printf("\nline='%s'",line);
			int n=atoi(LL.GetRangeBtwKey("_[","]_"));
//printf(" => LL='%s' , n=%d",(char*)LL,n);
			LL="";
			for(int x=0;x<n;x++) {
				if(fgets(line,DEQU_DB_MaxLineLen+2,fp)==NULL) break;
//printf("\n>> line='%s'",line);
				LL+=line;
			}
			fclose(fp);
//printf("\n##>LL='%s'",(char*)LL);
			LL=LL.GetRangeWithWdDel('\n');
			TMP=LL.GetRangeWithWdChg("\\n","\n");
			break;
		}
	}
	return (char*)TMP;
}
//===================================================
const char *DEQU_DB::DEQU_xfer(const char *line) {
	MyStr BDY,LS,LE,PX;
	MyStr LL(line);
	MyStr NM(DEQU_Inside((char*)LL));

	MyStr SYMS(DEQUSYMS);
	MyStr SYMA(SYMS+DEQUSYMX);

//printf("\n#>LL=[%s]",(char*)LL);
//printf("\n#>NM=[%s]",(char*)NM);
	
	if(NM!="") {
		BDY=GetDEQUbodyInDB((char*)NM);
		BDY=BDY.GetTrim();
		
		//MyStr PA(PickupLineDequPara(LL,NM,SYMA,LS,LE));
		MyStr PA(PickupLineDequPara(LL,NM,SYMS,LS,LE));
		if(PA!="") {
//printf("\n##>PA=[%s]",(char*)PA);
			MyStr PAC(PA.GetRangeWithSpDelExSymBlk((char*)SYMA));
			if(PAC!="") { 
				PA+=',';
				int c=SearchDEQUparN((char*)NM);
				//int s=0;
				for(int a=0;a<c;a++) {
					PX=ParaAnalyze(PA,SYMA);
//printf("\n##>PX[%d]=[%s]\n>>>PA=[%s]",a+1,(char*)PX,(char*)PA);
					PX=PX.GetLineTrimExSymBlk((char*)SYMA);
					MyStr NX('$');
					NX+=(a+1);
					NX+='$';
					BDY=BDY.GetRangeWithWdChg((char*)NX,(char*)PX);
//printf("\n##>BDY=[%s]",(char*)BDY);
				}
			}
		}
//printf("\n###>LS 1 =[%s]",(char*)LS);
		LS+=BDY;
//printf("\n###>LS 2 =[%s]",(char*)LS);
		LS+=LE;
		LS=LS.GetDos2Unix();
//printf("\n###>LS 3 =[%s]",(char*)LS);
		return DEQU_xfer((char*)LS);
	}
//printf("\n####>LL=[%s]",(char*)LL);

	NM=DEQUSYMX;
	int n=(int)NM;
	if(n>0) {
		LS="";
		int k=0;
		PO2 PS=LL.SymBlkIdxInStr(k,-1,DEQUSYMS);
		while(PS.p1>-1) {
			if(PS.p1>k) { LE=LL.GetRangeByIdx(k,PS.p1-1); LS+=LE.GetRangeWithDelBlkSymChr(-1,-1,DEQUSYMX); }
			LE=LL.GetRangeByIdx(PS.p1,PS.p2);
			LS+=LE.GetRangeWithDelBlkSymChr(DEQUSYMX);
			k=PS.p2+1;
			PS=LL.SymBlkIdxInStr(k,-1,DEQUSYMS);
		}
		if(k<(int)LL) {
			LE=LL.GetRangeByIdx(k,-1);
			LS+=LE.GetRangeWithDelBlkSymChr(DEQUSYMX);
		}
		PS=LS.SymBlkIdxInStr(-1,-1,DEQUSYMX);
		if(PS.p1>-1) 	return DEQU_xfer((char*)LS);
	} else LS=LL;

	TMP=LS.GetRangeWithDelSpLine();

	return (char*)TMP;
}

//===================================================
const char *DEQU_DB::PickupLineDequPara(MyStr &LL,MyStr &DEQNM,MyStr &SYM,MyStr &LS,MyStr &LE) {
	LS="";
	LE="";
	MyStr T;
	int n=LL.InStrExSymBlk((char*)DEQNM,(char*)SYM);

//printf("\n**>DEQNM=[%s] n=%d LL=[%s]",(char*)DEQNM,n,(char*)LL);	
	if(n>-1) { 
		if(n>0) LS=LL.GetRangeByIdx(-1,n-1);
		int sp=n+(int)DEQNM;
	
		MyStr NM(DEQUPARED);
		int lpaed=(int)NM;
		NM=DEQUPARST;
		int lpast=(int)NM;
		
		int a=LL.InStrExSymBlk(sp,DEQUPARST,(char*)SYM);
		NM=LL.GetRangeByIdx(sp,a-1);
		NM=NM.GetTrim();

		int b=sp;
		
//printf("\n**>sp=%d a=%d LS=[%s]",sp,a,(char*)LS);	
		if(a>-1 && (int)NM==0) { 
			sp=a+lpast;	
			int b=LL.InStrExSymBlk(sp,DEQUPARED,(char*)SYM);
			int x=LL.InStrExSymBlk(sp,DEQUPARST,(char*)SYM);
//printf("\n**>sp=%d b=%d x=%d",sp,b,x);	
			while(x>-1 && x<b) {
				sp=b+lpaed;
				b=LL.InStrExSymBlk(sp,DEQUPARED,(char*)SYM);
				x=LL.InStrExSymBlk(sp,DEQUPARST,(char*)SYM);
//printf("\n**>sp=%d b=%d x=%d",sp,b,x);	
			}
			if(b>0) {
				T=LL.GetRangeByIdx(a+lpast,b-1);
				sp=b+lpaed;
			}
		}
		LE=LL.GetRangeByIdx(sp,-1);
//printf("\n**>LE=[%s]",(char*)LE);	

	}
//printf("\n**>LS=[%s]",(char*)LS);	
//printf("\n**>T=[%s]",(char*)T);	
//printf("\n**>LE=[%s]",(char*)LE);	

	TMP=T;
    return (char*)TMP;
}
//===================================================

const char *DEQU_DB::ParaAnalyze(MyStr &PA,MyStr &SYM) {
	MyStr PX(DEQUPARED);
	int lpaed=(int)PX;
	PX=DEQUPARST;
	int lpast=(int)PX;
//printf("\n*>ParaAnalyze: PA=[%s],SYM=[%s]",(char*)PA,(char*)SYM);
	MyStr T;
	MyStr PAC(PA.GetRangeWithSpDelExSymBlk((char*)SYM));
	if(PAC!="") {
		int s=0;
		int p=PA.InStrExSymBlk(s,",",(char*)SYM);
		int x=PA.InStrExSymBlk(s,DEQUPARST,(char*)SYM);
//printf("\n*> 1 s=%d p=%d x=%d",s,p,x);
		while(x>-1 && x<p) {
			s=x+lpast;
			int y=PA.InStrExSymBlk(s,-1,DEQUPARED,(char*)SYM);
			int k=PA.InStrExSymBlk(s,y-1,DEQUPARST,(char*)SYM);
//printf("\n*> 2 s=%d y=%d k=%d",s,y,k);
			while(y>-1) {
//printf("\n*> 3 s=%d y=%d k=%d",s,y,k);
				s=y+lpaed;
				if(k>-1) {
					y=PA.InStrExSymBlk(s,-1,DEQUPARED,(char*)SYM);
					k=PA.InStrExSymBlk(s,y-1,DEQUPARST,(char*)SYM);
				} else y=-1;
			}
			p=PA.InStrExSymBlk(s,",",(char*)SYM);
			x=PA.InStrExSymBlk(s,DEQUPARST,(char*)SYM);
//printf("\n*> 4 s=%d p=%d",s,p);
		}
		if(p>0) T=PA.GetRangeByIdx(-1,p-1);  
//printf("\n*>T=[%s]",(char*)T);
		PA=PA.GetRangeByIdx(p+1,-1);
    }
    TMP=T;
    return (char*)TMP;
}

int DEQU_DB::DB_foutput(const char *filename) {
	
	MyStr FIL(filename);

	FILE *fp=fopen((char*)FIL,"w");
	if(fp==NULL) {
		printf("\n Error ! Open '%s' for write fail !\n",(char*)FIL);
		return -1;
	}
	
	if(DBP==NULL) { fclose(fp);  return 0; }
	
    MyStr T,PA,PX,BDY;
	int k , l=0;
	DQLINK *dp;
	DSLINK *ppa,*ppx;			

	//================ list ====================
	for(int n=0;n<CNT;n++) {
		T="";
		dp=DBP;
		while(dp!=NULL) {
			if(dp->SN==(n+1)) {
				T+=dp->NAME+DEQUPARST;
				if(dp->PARN>0) T+=GetDEQUdefParaInDB((char*)dp->NAME);
				T+=DEQUPARED;
				break;
			}
			dp=dp->nxt;
		}
		l++;
		fprintf(fp,"; %s\n",(char*)T);
	}

	//================= Declare & body =====================
	fprintf(fp,"\n");
				
	for(int n=0;n<CNT;n++) {		
		T=DEQUKEY;
		T+=" ";
		dp=DBP;
		while(dp!=NULL) {
//printf("\n%s(%d) n=%d",(char*)dp->NAME,dp->SN,n);
			if(dp->SN==(n+1)) {
//printf("\n[%s]<",(char*)dp->NAME);
				ppa=NULL;
				T+=dp->NAME+DEQUPARST;
				if(dp->PARN>0) {
					PA=GetDEQUdefParaInDB((char*)dp->NAME);
					T+=PA;
					//-----------------------------------
//printf("%s>",(char*)PA);
					PA+=",";
					k=0;
					int p=PA.InStr(k,',');
					while(p>-1) { 
						DSLINK *pd=new DSLINK;
						if(p>k) pd->data=PA.GetRangeByIdx(k,p-1);
						else	pd->data="";
						pd->nxt=NULL;
						if(ppa==NULL)  	ppa=pd;
						else			ppx->nxt=pd;
//printf(" %s",(char*)pd->data);
						ppx=pd;  k=p+1;
						p=PA.InStr(k,',');
					}
					//-----------------------------------
				}
//printf(">");
				T+=DEQUPARED;
				break;
			}
			dp=dp->nxt;
		}
		//============================================

		T+=" ";
		T+=DEQUBDYST;
		fprintf(fp,"%s",(char*)T);
		T=GetDEQUbodyInDB((char*)dp->NAME);

//printf("\n[%s]{{%s}}\n",(char*)dp->NAME,(char*)T);
		ppx=ppa; 
		k=1;
		while(ppx!=NULL) {
			PA="$"; PA+=k; PA+="$";
			PX="$"; PX+=ppx->data; PX+="$";
//printf("%d[%s]->[%s] ",k,(char*)PA,(char*)PX);
			T=T.GetRangeWithWdChg((char*)PA,(char*)PX);
			k++;
			ppx=ppx->nxt;
		}
		T+=DEQUBDYED;
//printf("\n>>[%s]%s\n",(char*)dp->NAME,(char*)T);
		fprintf(fp,"%s\n",(char*)T);

		//============================================
		ReleaseDSLINK(&ppa);
	}
	
	fprintf(fp,"\n");
	
	fclose(fp);
	return l;
}
